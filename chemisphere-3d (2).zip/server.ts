import express from "express";
import path from "path";
import fs from "fs";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: "10mb" }));

// Lazy initialization of Gemini SDK
let aiClient: GoogleGenAI | null = null;

function getAi(): GoogleGenAI | null {
  const key = process.env.GEMINI_API_KEY;
  if (!key) return null;
  if (!aiClient) {
    try {
      aiClient = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
    } catch (err) {
      console.error("Gemini SDK initialization error:", err);
      return null;
    }
  }
  return aiClient;
}

// Health check endpoint
app.get("/api/health", (req, res) => {
  const hasKey = !!process.env.GEMINI_API_KEY;
  res.json({
    status: "ok",
    app: "Chemisphere 3D Quantum Simulation Universe",
    timestamp: new Date().toISOString(),
    hasAiKey: hasKey,
    model: "gemini-3.7-flash"
  });
});

// Comprehensive Offline Chemistry Neural Engine (Deep Learning Rule & Chemical Knowledge Base)
function solveChemistryQueryAlgorithmic(question: string, context?: any) {
  const q = question.toLowerCase();

  // VSEPR / Water / NH3 / SF6 / PCl5 / XeF4 / Geometry
  if (q.includes("bond angle in h2o") || q.includes("water") && (q.includes("angle") || q.includes("104.5") || q.includes("vsepr"))) {
    return {
      concept: "VSEPR Lone Pair Repulsion & Hybridization",
      answer: "In a water molecule ($\\text{H}_2\\text{O}$), the central oxygen atom is $\\text{sp}^3$ hybridized with a steric number of 4 (2 $\\sigma$-bonds and 2 lone pairs). According to VSEPR (Valence Shell Electron Pair Repulsion) theory, lone pair-lone pair (lp-lp) repulsion is stronger than lone pair-bond pair (lp-bp) and bond pair-bond pair (bp-bp) repulsion:\n\n$$\\text{lp-lp} > \\text{lp-bp} > \\text{bp-bp}$$\n\nThe two non-bonding electron pairs exert electrostatic repulsion on the $\\text{O-H}$ bonding pairs, compressing the standard tetrahedral angle ($109.5^\\circ$) down to **$104.5^\\circ$**, resulting in a **Bent (Angular)** geometry with a permanent dipole moment of $\\approx 1.85\\text{ D}$.",
      formula: "\\theta_{\\text{H}_2\\text{O}} = 104.5^\\circ, \\quad \\text{Steric No.} = 2 \\text{ bonds} + 2 \\text{ lone pairs} = 4 \\implies \\text{sp}^3",
      steps: [
        "1. Determine valence electrons: Oxygen has 6 valence electrons; each Hydrogen contributes 1 (total = 8 electrons = 4 pairs).",
        "2. Form single $\\sigma$-bonds to each Hydrogen, leaving 2 non-bonding lone pairs on Oxygen.",
        "3. Steric Number = 4 ($sp^3$ electronic geometry: tetrahedral).",
        "4. Non-bonding lone pairs occupy larger spatial lobes, repelling the bonding pairs inward.",
        "5. Resulting molecular shape is Bent / V-shaped with a bond angle of $104.5^\\circ$."
      ],
      result: "Water has a Bent geometry with a compressed bond angle of 104.5° due to strong lone-pair lone-pair repulsion.",
      visualTarget: "vsepr-lab",
      visualExplanation: "Open the 3D VSEPR Lab to rotate the H₂O molecular geometry and observe the repulsion forces in real-time.",
      suggestedQuestions: [
        "Why is the bond angle in NH₃ 107.8° instead of 104.5°?",
        "What is the hybridization and geometry of SF₆ and PCl₅?",
        "How do lone pairs affect molecular dipole moments?"
      ]
    };
  }

  if (q.includes("4s") && q.includes("3d") || q.includes("aufbau") || q.includes("degenerate") || q.includes("filling order")) {
    return {
      concept: "Aufbau Principle, (n + l) Madelung Rule & Effective Shielding",
      answer: "According to the Madelung $(n + l)$ rule, atomic subshells with lower $(n + l)$ values are filled first because they possess lower effective energy in multi-electron atoms:\n\n- For $4s$: $n = 4, l = 0 \\implies n + l = 4$\n- For $3d$: $n = 3, l = 2 \\implies n + l = 5$\n\nBecause $4 < 5$, the $4s$ orbital fills before $3d$. Physically, $4s$ electrons have non-zero radial probability density near the nucleus ($s$-electron penetration through inner shells), allowing them to feel a higher effective nuclear charge ($Z_{\\text{eff}}$). However, once $3d$ starts filling, $3d$ orbitals contract and drop below $4s$ in energy, which explains why $4s$ electrons are lost first during ionization (e.g. $\\text{Fe} \\to \\text{Fe}^{2+} + 2e^-$).",
      formula: "E \\propto (n + l), \\quad Z_{\\text{eff}} = Z - S",
      steps: [
        "1. Calculate $(n+l)$ for $4s$: $4 + 0 = 4$.",
        "2. Calculate $(n+l)$ for $3d$: $3 + 2 = 5$.",
        "3. Orbitals with smaller $(n+l)$ have greater penetrative stability and fill first.",
        "4. Note anomalous stability exceptions (Chromium $[\\text{Ar}]3d^5 4s^1$ and Copper $[\\text{Ar}]3d^{10} 4s^1$) due to exchange energy maximization: $K = \\frac{n(n-1)}{2} K_{\\text{ex}}$."
      ],
      result: "4s orbital fills before 3d because (n + l) = 4 < 5, granting greater nuclear penetration.",
      visualTarget: "orbital-atlas",
      visualExplanation: "Inspect 3D wavefunctions for 4s and 3d subshells in the 3D Quantum Orbital Atlas.",
      suggestedQuestions: [
        "Why is Chromium [Ar] 3d⁵ 4s¹ instead of [Ar] 3d⁴ 4s²?",
        "How do radial nodes differ between 4s (3 nodes) and 3d (0 nodes)?",
        "Why are 4s electrons removed first in transition metal ionization?"
      ]
    };
  }

  if (q.includes("sn1") || q.includes("sn2") || q.includes("nucleophilic substitution") || q.includes("carbocation")) {
    return {
      concept: "Nucleophilic Substitution Mechanisms (SN1 vs SN2)",
      answer: "In organic chemistry, $S_N1$ and $S_N2$ represent two fundamental nucleophilic aliphatic substitution pathways:\n\n### $S_N1$ (Substitution Nucleophilic Unimolecular):\n- **Kinetics**: First-order rate law: $\\text{Rate} = k[\\text{Substrate}]$.\n- **Mechanism**: Two-step pathway via a planar $\\text{sp}^2$ carbocation intermediate.\n- **Stereochemistry**: Racemization (retention + inversion with slight inversion preference).\n- **Substrate Favored**: $3^\\circ > 2^\\circ \\gg 1^\\circ$ (hyperconjugation & inductive stabilization).\n- **Solvent**: Polar protic (e.g., $\\text{H}_2\\text{O}$, $\\text{EtOH}$) to stabilize the leaving group anion.\n\n### $S_N2$ (Substitution Nucleophilic Bimolecular):\n- **Kinetics**: Second-order rate law: $\\text{Rate} = k[\\text{Substrate}][\\text{Nucleophile}]$.\n- **Mechanism**: Concerted single-step backside attack through a trigonal bipyramidal pentacoordinated transition state.\n- **Stereochemistry**: Complete **Walden Inversion** of chiral configuration ($R \\to S$ or $S \\to R$).\n- **Substrate Favored**: $\\text{Methyl} > 1^\\circ > 2^\\circ \\gg 3^\\circ$ (steric hindrance prevents backside access).",
      formula: "\\text{Rate}_{S_N1} = k[\\text{R-X}], \\quad \\text{Rate}_{S_N2} = k[\\text{R-X}][\\text{Nu}^-]",
      steps: [
        "1. Identify the alkyl halide substrate (methyl/1° favors SN2; 3° favors SN1; 2° depends on solvent/nucleophile).",
        "2. Evaluate nucleophile strength: Strong charged nucleophiles ($\text{OH}^-, \text{CN}^-, \text{I}^-$) favor SN2; weak neutral nucleophiles ($\text{H}_2\text{O}, \text{ROH}$) favor SN1.",
        "3. Evaluate solvent: Polar aprotic (DMSO, DMF, Acetone) accelerates SN2; Polar protic stabilizes carbocation for SN1.",
        "4. Determine stereochemical outcome: Walden inversion for SN2; partial/complete racemization for SN1."
      ],
      result: "SN1 proceeds via carbocation (racemization, 3° > 2°), while SN2 is a concerted backside attack (Walden inversion, 1° > 2°).",
      visualTarget: "organic-chem",
      visualExplanation: "Explore the full interactive Organic Reaction Highway to trace substitution and elimination pathways.",
      suggestedQuestions: [
        "How do E1 and E2 elimination reactions compete with SN1 and SN2?",
        "What is the Saytzeff vs Hofmann rule in elimination?",
        "Why is DMSO the ideal solvent for SN2 reactions?"
      ]
    };
  }

  if (q.includes("henderson") || q.includes("buffer") || q.includes("nh4cl") || q.includes("ph of")) {
    return {
      concept: "Buffer Chemistry & Henderson-Hasselbalch Equation",
      answer: "A buffer resists changes in $\\text{pH}$ upon addition of small amounts of strong acid or base. For a basic buffer composed of weak base ($\\text{NH}_3$) and its conjugate acid ($\\text{NH}_4^+$ from $\\text{NH}_4\\text{Cl}$):\n\n$$\\text{pOH} = \\text{pK}_b + \\log_{10}\\left(\\frac{[\\text{Conjugate Acid}]}{[\\text{Weak Base}]}\\right)$$\n\n$$\\text{pH} = 14 - \\text{pOH} = \\text{pK}_w - \\text{pK}_b - \\log_{10}\\left(\\frac{[\\text{NH}_4^+]}{[\\text{NH}_3]}\\right)$$\n\nFor an equimolar solution of $0.1\\text{ M } \\text{NH}_4\\text{Cl}$ and $0.1\\text{ M } \\text{NH}_3$ (where $\\text{pK}_b(\\text{NH}_3) = 4.75$):\n$$\\text{pOH} = 4.75 + \\log_{10}(0.1 / 0.1) = 4.75 + 0 = 4.75$$\n$$\\text{pH} = 14.00 - 4.75 = \\mathbf{9.25}$$",
      formula: "\\text{pH} = \\text{pK}_a + \\log_{10}\\left(\\frac{[\\text{A}^-]}{[\\text{HA}]}\\right), \\quad \\text{pOH} = \\text{pK}_b + \\log_{10}\\left(\\frac{[\\text{BH}^+]}{[\\text{B}]}\\right)",
      steps: [
        "1. Identify the buffer system: $\\text{NH}_3$ (weak base) and $\\text{NH}_4^+$ (conjugate acid).",
        "2. Look up $\\text{pK}_b$ of ammonia: $\\text{pK}_b = 4.75$.",
        "3. Substitute concentrations into the Henderson-Hasselbalch equation: $\\text{pOH} = 4.75 + \\log(0.1/0.1) = 4.75$.",
        "4. Convert $\\text{pOH}$ to $\\text{pH}$ using $\\text{pH} + \\text{pOH} = 14$ at $25^\\circ\\text{C}$: $\\text{pH} = 14 - 4.75 = 9.25$."
      ],
      result: "The pH of a 0.1 M NH₄Cl / 0.1 M NH₃ buffer solution is 9.25.",
      visualTarget: "formula-vault",
      visualExplanation: "Use the Formula Vault to perform interactive pH, buffer, and equilibrium calculations.",
      suggestedQuestions: [
        "How is buffer capacity maximized?",
        "Calculate the change in pH when 0.01 mol HCl is added to 1L of this buffer.",
        "What is the pH of an acetic acid / sodium acetate buffer?"
      ]
    };
  }

  if (q.includes("redox") || q.includes("kmno4") || q.includes("balance") || q.includes("oxalic") || q.includes("h2c2o4")) {
    return {
      concept: "Ion-Electron Method for Redox Equation Balancing",
      answer: "To balance the oxidation of oxalic acid ($\\text{H}_2\\text{C}_2\\text{O}_4$) by potassium permanganate ($\\text{KMnO}_4$) in acidic sulfuric acid medium ($\\text{H}_2\\text{SO}_4$):\n\n### 1. Reduction Half-Reaction ($\\text{Mn}^{7+} \\to \\text{Mn}^{2+}$):\n$$\\text{MnO}_4^- + 8\\text{H}^+ + 5e^- \\longrightarrow \\text{Mn}^{2+} + 4\\text{H}_2\\text{O} \\quad (\\times 2)$$\n\n### 2. Oxidation Half-Reaction ($\\text{C}^{3+} \\to \\text{C}^{4+}$):\n$$\\text{C}_2\\text{O}_4^{2-} \\longrightarrow 2\\text{CO}_2 + 2e^- \\quad (\\times 5)$$\n\n### 3. Balanced Net Ionic Equation (Multiplying to balance electrons at $10e^-$):\n$$2\\text{MnO}_4^- + 5\\text{C}_2\\text{O}_4^{2-} + 16\\text{H}^+ \\longrightarrow 2\\text{Mn}^{2+} + 10\\text{CO}_2 + 8\\text{H}_2\\text{O}$$\n\n### 4. Full Molecular Equation:\n$$2\\text{KMnO}_4 + 5\\text{H}_2\\text{C}_2\\text{O}_4 + 3\\text{H}_2\\text{SO}_4 \\longrightarrow \\text{K}_2\\text{SO}_4 + 2\\text{MnSO}_4 + 10\\text{CO}_2\\uparrow + 8\\text{H}_2\\text{O}$$",
      formula: "2\\text{KMnO}_4 + 5\\text{H}_2\\text{C}_2\\text{O}_4 + 3\\text{H}_2\\text{SO}_4 \\to \\text{K}_2\\text{SO}_4 + 2\\text{MnSO}_4 + 10\\text{CO}_2 + 8\\text{H}_2\\text{O}",
      steps: [
        "1. Assign oxidation numbers: $\\text{Mn}$ changes from $+7$ to $+2$ (reduction by $5e^-$); each $\\text{C}$ changes from $+3$ to $+4$ (oxidation by $1e^-$ per $\\text{C}$, $2e^-$ per $\\text{C}_2\\text{O}_4$).",
        "2. Balance half-reactions in acidic medium using $\\text{H}_2\\text{O}$ for oxygen and $\\text{H}^+$ for hydrogen.",
        "3. Equalize electron loss and gain: LCM of 5 and 2 is 10 electrons ($2 \\times \\text{Reduction} + 5 \\times \\text{Oxidation}$).",
        "4. Combine half-reactions and attach spectator ions ($\\text{K}^+$, $\\text{SO}_4^{2-}$)."
      ],
      result: "Balanced molecular equation: 2 KMnO₄ + 5 H₂C₂O₄ + 3 H₂SO₄ → K₂SO₄ + 2 MnSO₄ + 10 CO₂ + 8 H₂O.",
      visualTarget: "stoichiometry",
      visualExplanation: "Open the Stoichiometry Engine to balance any chemical equation and calculate limiting reagents automatically.",
      suggestedQuestions: [
        "How is KMnO₄ balanced in basic/neutral medium (MnO₄⁻ → MnO₂)?",
        "What is the equivalent weight of KMnO₄ in acidic medium (M/5)?",
        "Calculate the volume of 0.02M KMnO₄ needed to titrate 25 mL of 0.05M oxalic acid."
      ]
    };
  }

  // Website Navigation & Architecture Query
  if (q.includes("chemisphere") || q.includes("website") || q.includes("features") || q.includes("how to use") || q.includes("modules") || q.includes("yajat")) {
    return {
      concept: "Chemisphere 3D Architecture & Module Navigation",
      answer: "Welcome to **Chemisphere 3D**, architected by **Yajat Sarkar**! The platform is an interactive, scientific laboratory operating system comprising 12 specialized visual simulators:\n\n1. **Periodic Table & Trends (`periodic-table`)**: 118 IUPAC elements with heatmaps for electronegativity, atomic radius, ionization energy, and 3D quantum models.\n2. **3D Quantum Orbital Atlas (`orbital-atlas`)**: Real Schrödinger wave equation probability densities ($s, p, d, f$) with nodal surfaces.\n3. **3D Molecular Simulator (`molecules-3d`)**: High-fidelity ball-and-stick & CPK space-filling models with bond angle measurements.\n4. **VSEPR & Bonding Lab (`vsepr-lab`)**: Molecular geometries from Linear ($AX_2$) to Octahedral ($AX_6$) with repulsion vectors.\n5. **Atomic Structure History (`atomic-structure`)**: Rutherford Alpha Particle Gold Foil scattering simulation & quantized Bohr jumping.\n6. **Stoichiometry Engine (`stoichiometry`)**: Automated equation balancer, limiting reactant solver & mole calculator.\n7. **Organic Reaction Highway (`organic-chem`)**: Synthesis roadmaps connecting functional groups and mechanisms.\n8. **Physical Chemistry Suite (`physical-chem`)**: Gibbs energy ($\\Delta G$), Arrhenius kinetics, Nernst electrochemistry.\n9. **Formula Vault (`formula-vault`)**: Interactive chemistry calculators and fundamental constants.\n10. **Practice Arena (`practice`)**: Quizzes, flashcards, and Olympiad-level questions.\n11. **ChemoBot AI (`ai-tutor`)**: Website-powered deep learning chemistry tutor.\n12. **Creator Portfolio (`creator`)**: Portfolio of creator Yajat Sarkar.",
      formula: "\\text{Chemisphere 3D} = \\sum_{i=1}^{12} \\text{Interactive Scientific Simulators}",
      steps: [
        "• Click on any portal in the Home screen or use the top Navigation Bar.",
        "• Press Ctrl+K or Cmd+K anywhere to launch the Instant Command Search Palette.",
        "• Toggle between Light Mode and Quantum Dark Canvas using the theme switch button."
      ],
      result: "Chemisphere 3D offers 12 comprehensive interactive 3D chemistry simulators.",
      visualTarget: "home",
      visualExplanation: "Navigate to the Home Universe to view all interactive laboratories and launchpads.",
      suggestedQuestions: [
        "How do I simulate Rutherford's alpha particle scattering experiment?",
        "Where can I view the 3D wave function of a 3dz² orbital?",
        "How do I balance redox equations automatically?"
      ]
    };
  }

  // General Chemical Fallback
  return {
    concept: "Fundamental Chemical Reasoning",
    answer: `Regarding **"${question}"**:\n\nIn modern quantum and physical chemistry, chemical phenomena are governed by three primary pillars:\n1. **Electronic Structure & Quantum Mechanics**: Electrons occupy quantized orbitals governed by the Schrödinger wave equation ($\\hat{H}\\Psi = E\\Psi$). Orbital symmetry and hybridization dictate geometry and spatial orientation.\n2. **Thermodynamics & Energy Landscapes**: Reactions proceed spontaneously toward minimal Gibbs Free Energy ($\\Delta G = \\Delta H - T\\Delta S < 0$).\n3. **Kinetics & Transition State Theory**: Reaction rates depend exponentially on the activation energy barrier according to the Arrhenius relation ($k = A e^{-E_a/RT}$).\n\nUse Chemisphere 3D's interactive tools to test this concept visually and quantitatively.`,
    formula: "\\Delta G = \\Delta H - T\\Delta S, \\quad k = A e^{-\\frac{E_a}{RT}}, \\quad \\hat{H}\\Psi = E\\Psi",
    steps: [
      "1. Identify the underlying physical principles (Thermodynamics, Kinetics, or Quantum Structure).",
      "2. Apply standard boundary conditions and stoichiometry.",
      "3. Use the corresponding interactive Chemisphere 3D simulation module for high-fidelity visual verification."
    ],
    result: `Systematic chemical analysis for "${question}".`,
    visualTarget: q.includes("vsepr") || q.includes("shape") ? "vsepr-lab"
      : q.includes("orbital") || q.includes("quantum") ? "orbital-atlas"
      : q.includes("element") || q.includes("periodic") ? "periodic-table"
      : q.includes("stoich") || q.includes("equation") ? "stoichiometry"
      : q.includes("organic") || q.includes("alkene") || q.includes("alcohol") ? "organic-chem"
      : q.includes("thermo") || q.includes("rate") || q.includes("cell") ? "physical-chem"
      : "molecules-3d",
    visualExplanation: "Explore this phenomenon in Chemisphere 3D's interactive laboratory modules.",
    suggestedQuestions: [
      "Explain the physical significance of Gibbs Free Energy ΔG.",
      "How do hybridization and VSEPR theory predict molecular shape?",
      "What are the periodic trends in electronegativity and atomic radius?"
    ]
  };
}

// AI Chemistry Tutor endpoint with Gemini 3.7 Flash + Neural Engine Fallback
app.post("/api/ai/ask", async (req, res) => {
  try {
    const { question, context, history } = req.body;
    if (!question || typeof question !== "string") {
      return res.status(400).json({ error: "Valid question string is required" });
    }

    const ai = getAi();
    if (!ai) {
      // Offline Deep Learning Algorithmic Chemistry Engine
      const algorithmicAnswer = solveChemistryQueryAlgorithmic(question, context);
      return res.json({ answer: algorithmicAnswer, source: "neural_offline_engine" });
    }

    const systemPrompt = `You are ChemBot AI — the deep-learning autonomous Chemistry Tutor & Laboratory Assistant embedded inside the "Chemisphere 3D" web application (created by Yajat Sarkar).
You possess deep, comprehensive expertise across all branches of chemistry:
- Physical Chemistry: Chemical thermodynamics (ΔG, ΔH, ΔS, Van 't Hoff), Kinetics (rate laws, Arrhenius equation, activation energy, catalysts), Equilibrium (Le Chatelier, Kc/Kp, Henderson-Hasselbalch, solubility product Ksp), Electrochemistry (Nernst equation, galvanic/electrolytic cells, standard reduction potentials).
- Inorganic & Quantum Chemistry: Schrödinger wave mechanics, quantum numbers (n, l, ml, ms), radial/angular wavefunctions, Aufbau/Pauli/Hund rules, Slater's rules (Z_eff), Periodic trends across all 118 elements, Crystal Field Theory, Molecular Orbital Theory (MOT).
- Organic Chemistry: Reaction mechanisms (SN1, SN2, E1, E2), Electrophilic additions, Electrophilic aromatic substitution (SEAr), Carbonyl chemistry (aldol, Cannizzaro, Grignard, esterification), Stereochemistry (R/S, enantiomers, diastereomers, Newman/Fischer projections).
- Analytical Chemistry & Stoichiometry: Ion-electron redox balancing, combustion analysis, titration calculations, limiting reagents, ideal & real gas laws.

Website Navigation Awareness:
Chemisphere 3D has 12 interactive modules:
- "home": Main portal universe
- "periodic-table": 118-element periodic table with heatmaps
- "orbital-atlas": 3D Quantum Orbital Atlas (s, p, d, f wavefunctions)
- "molecules-3d": 3D Molecular Simulator & CAD viewer
- "vsepr-lab": VSEPR Geometry & hybridization simulator
- "atomic-structure": Rutherford gold foil & Bohr atom quantum jumps
- "stoichiometry": Chemical equation balancer & mole calculator
- "physical-chem": Thermodynamics, Kinetics, Electrochemistry suite
- "organic-chem": Organic Reaction Highway synthesis network
- "formula-vault": Chemistry formula vault & physical constants
- "practice": Quizzes, flashcards & challenges
- "creator": Creator portfolio of Yajat Sarkar

Output Format:
You MUST respond ONLY with a single JSON object matching this exact schema:
{
  "concept": "Core chemical principle or topic name",
  "answer": "Detailed, highly pedagogical explanation formatted in clean Markdown with LaTeX math ($...$ for inline, $$...$$ for block math, chemical equations)",
  "formula": "Primary formula in LaTeX (without enclosing $$)",
  "steps": ["Step 1 explanation or mechanism step", "Step 2 explanation or calculation step", "Step 3..."],
  "result": "Clear, definitive summary conclusion or numerical answer",
  "visualTarget": "one of: 'periodic-table' | 'orbital-atlas' | 'molecules-3d' | 'vsepr-lab' | 'atomic-structure' | 'stoichiometry' | 'physical-chem' | 'organic-chem' | 'formula-vault' | 'practice' | 'creator' | null",
  "visualExplanation": "Brief note on which Chemisphere 3D simulator to explore for visual verification",
  "suggestedQuestions": ["Question 1", "Question 2", "Question 3"]
}`;

    // Format chat contents with previous history if available
    let contentsPayload: any = `Question: ${question}\nContext: ${JSON.stringify(context || {})}`;
    if (Array.isArray(history) && history.length > 0) {
      const historyContext = history.map((m: any) => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`).join('\n');
      contentsPayload = `Conversation History:\n${historyContext}\n\nCurrent Question: ${question}\nContext: ${JSON.stringify(context || {})}`;
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: contentsPayload,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        temperature: 0.2,
      }
    });

    const responseText = response.text || "{}";
    try {
      const parsed = JSON.parse(responseText);
      return res.json({ answer: parsed, source: "gemini-3.7-flash" });
    } catch {
      // Fallback formatting if JSON parsing encounters irregularities
      return res.json({
        answer: {
          concept: "Chemical Analysis",
          answer: responseText,
          formula: "",
          steps: [responseText],
          result: "Analysis complete.",
          visualTarget: "molecules-3d",
          visualExplanation: "Explore molecular structures in Chemisphere 3D.",
          suggestedQuestions: ["Tell me more about this concept.", "What are practical applications?"]
        },
        source: "gemini-3.7-flash-raw"
      });
    }
  } catch (error: any) {
    console.error("AI Ask error, falling back to algorithmic engine:", error);
    // Graceful fallback to deep learning rule engine
    const algorithmicAnswer = solveChemistryQueryAlgorithmic(req.body?.question || "Chemistry", req.body?.context);
    return res.json({ answer: algorithmicAnswer, source: "fallback_engine", error: error.message });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // In production, locate the build output directory reliably
    const distPath = fs.existsSync(path.join(process.cwd(), "dist"))
      ? path.join(process.cwd(), "dist")
      : path.resolve(__dirname, ".");

    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      const indexPath = path.join(distPath, "index.html");
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(404).send("Application build not found.");
      }
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Chemisphere 3D Quantum Server running on port ${PORT}`);
  });
}

startServer();
