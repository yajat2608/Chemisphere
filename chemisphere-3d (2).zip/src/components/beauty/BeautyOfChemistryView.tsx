import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Sparkles,
  Volume2,
  VolumeX,
  Compass,
  ArrowDown,
  ArrowRight,
  BookOpen,
  Atom,
  Orbit,
  Layers,
  Award,
  ChevronDown,
  ChevronRight,
  Quote,
  Zap,
  Flame,
  Activity,
  Maximize2,
  Minimize2,
  Share2,
  Check,
  Search,
  ExternalLink,
  Sigma,
  Box,
  Eye,
  Sliders,
  Radio,
  Music,
  Bell
} from 'lucide-react';
import {
  BEAUTY_CHAPTERS,
  FAMOUS_CHEMISTS,
  SCALE_OF_MATTER,
  ChapterData,
  FamousChemist,
  ScaleLevel
} from '../../data/beautyOfChemistryData';
import { BeautyCanvas3D } from './BeautyCanvas3D';
import {
  beautyAudioEngine,
  SOUNDSCAPE_PRESETS,
  SoundscapePreset
} from './BeautyAmbientSoundscape';
import { NavigationTab } from '../../types';
import { LatexRenderer } from '../common/LatexRenderer';

interface BeautyOfChemistryViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

/** Helper component to render scientific equations in clean, elegant typography */
const FormattedMathEquation: React.FC<{ rawLatex: string }> = ({ rawLatex }) => {
  if (!rawLatex) return null;
  return (
    <div className="text-amber-200 text-sm sm:text-base md:text-lg select-all leading-snug py-1 flex items-center justify-center overflow-x-auto">
      <LatexRenderer latex={rawLatex} displayMode={true} className="text-amber-200" />
    </div>
  );
};

export const BeautyOfChemistryView: React.FC<BeautyOfChemistryViewProps> = ({ onNavigate }) => {
  const [activeChapterIndex, setActiveChapterIndex] = useState<number>(0);
  const [activeScaleIndex, setActiveScaleIndex] = useState<number>(3); // 10^0 m (Human)
  const [selectedChemist, setSelectedChemist] = useState<FamousChemist>(FAMOUS_CHEMISTS[0]);
  const [isAudioPlaying, setIsAudioPlaying] = useState<boolean>(false);
  const [audioVolume, setAudioVolume] = useState<number>(0.6);
  const [activePresetIndex, setActivePresetIndex] = useState<number>(0);
  const [showAudioSettings, setShowAudioSettings] = useState<boolean>(false);
  const [scrollProgress, setScrollProgress] = useState<number>(0);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [is3DStageMode, setIs3DStageMode] = useState<boolean>(false);

  // Scroll Spy Container
  const chapterRefs = useRef<(HTMLElement | null)[]>([]);

  const activeChapter: ChapterData = BEAUTY_CHAPTERS[activeChapterIndex] || BEAUTY_CHAPTERS[0];

  // Sync active chapter theme to ambient audio engine
  useEffect(() => {
    if (activeChapter?.visualTheme) {
      beautyAudioEngine.setChapterTheme(activeChapter.visualTheme);
    }
  }, [activeChapter?.visualTheme]);

  // ==========================================
  // AMBIENT RESONANCE HARMONIC SYNTHESIZER
  // ==========================================
  const toggleAmbientAudio = async () => {
    if (isAudioPlaying) {
      beautyAudioEngine.stop();
      setIsAudioPlaying(false);
    } else {
      const ok = await beautyAudioEngine.start();
      if (ok) {
        setIsAudioPlaying(true);
        beautyAudioEngine.setVolume(audioVolume);
        beautyAudioEngine.setChapterTheme(activeChapter.visualTheme);
      }
    }
  };

  const handlePresetSelect = (idx: number) => {
    setActivePresetIndex(idx);
    beautyAudioEngine.setPreset(idx);
  };

  const handleVolumeChange = (val: number) => {
    setAudioVolume(val);
    beautyAudioEngine.setVolume(val);
  };

  const handleTriggerChime = () => {
    beautyAudioEngine.triggerChimeDrop(true);
  };

  // Clean up audio on unmount
  useEffect(() => {
    return () => {
      beautyAudioEngine.stop();
    };
  }, []);

  // Handle Scroll Spy for Chapters
  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = totalHeight > 0 ? Math.min(1, Math.max(0, scrollY / totalHeight)) : 0;
      setScrollProgress(progress);

      // Find closest chapter to top third of viewport
      let closestIdx = 0;
      let minDistance = Infinity;

      chapterRefs.current.forEach((el, index) => {
        if (!el) return;
        const rect = el.getBoundingClientRect();
        const dist = Math.abs(rect.top - 180);
        if (dist < minDistance && rect.bottom > 100) {
          minDistance = dist;
          closestIdx = index;
        }
      });

      if (closestIdx >= 0 && closestIdx < BEAUTY_CHAPTERS.length) {
        setActiveChapterIndex(closestIdx);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToChapter = (index: number) => {
    if (index < 0 || index >= BEAUTY_CHAPTERS.length) return;
    const target = chapterRefs.current[index];
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setActiveChapterIndex(index);
    }
  };

  const handleShareQuote = (id: string, quoteText: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(quoteText);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    }
  };

  const currentPreset: SoundscapePreset = SOUNDSCAPE_PRESETS[activePresetIndex];

  return (
    <div className="relative min-h-screen bg-[#07090e] text-slate-200 font-sans selection:bg-cyan-500/30 selection:text-white pb-32">
      {/* Dynamic 3D WebGL Background Canvas with All 13 Thematic Scenes */}
      <div className={`fixed inset-0 z-0 transition-opacity duration-700 ${is3DStageMode ? 'pointer-events-auto opacity-100' : 'pointer-events-none opacity-90'}`}>
        <BeautyCanvas3D
          theme={activeChapter.visualTheme}
          scrollProgress={scrollProgress}
          interactive={is3DStageMode}
        />
        {/* Subtle Dark Vignette & Atmospheric Fog Overlay */}
        {!is3DStageMode && (
          <>
            <div className="absolute inset-0 bg-gradient-to-b from-[#07090e]/85 via-transparent to-[#07090e] pointer-events-none" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-transparent via-[#07090e]/40 to-[#07090e]/95 pointer-events-none" />
          </>
        )}
      </div>

      {/* Persistent Floating Audio & Exhibition Control HUD */}
      <div className="fixed top-20 right-4 sm:right-8 z-40 flex flex-col items-end gap-2">
        <div className="flex items-center gap-1.5 p-1.5 rounded-full bg-[#0a0d14]/90 backdrop-blur-xl border border-white/10 shadow-2xl">
          <button
            onClick={() => setIs3DStageMode(!is3DStageMode)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-mono font-bold transition-all ${
              is3DStageMode
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-lg shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white hover:bg-white/10'
            }`}
            title={is3DStageMode ? 'Exit Interactive 3D Model Mode' : 'Inspect 3D Geometry (Interactive Rotate)'}
          >
            <Box className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">{is3DStageMode ? 'Exit 3D Stage' : '3D Stage'}</span>
          </button>

          <div className="h-4 w-px bg-white/10" />

          {/* Soundscape Play/Pause Main Button */}
          <button
            onClick={toggleAmbientAudio}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-mono font-bold transition-all ${
              isAudioPlaying
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-lg shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-white/10'
            }`}
            title={isAudioPlaying ? 'Pause Ambient Soundscape' : 'Enable Generative Ambient Soundscape (528Hz/432Hz)'}
          >
            {isAudioPlaying ? (
              <>
                <Volume2 className="w-4 h-4 text-amber-400 animate-pulse" />
                <span className="hidden sm:inline">528 Hz Resonator</span>
                {/* Visual pulsating harmonic wave indicator */}
                <div className="flex items-center gap-0.5 ml-1">
                  <span className="w-1 h-3 bg-amber-400 rounded-full animate-pulse" />
                  <span className="w-1 h-4 bg-cyan-400 rounded-full animate-pulse delay-75" />
                  <span className="w-1 h-2 bg-amber-300 rounded-full animate-pulse delay-150" />
                </div>
              </>
            ) : (
              <>
                <VolumeX className="w-4 h-4" />
                <span className="hidden sm:inline">Ambient Audio</span>
              </>
            )}
          </button>

          {/* Soundscape Tuning & Controls Settings Toggle */}
          <button
            onClick={() => setShowAudioSettings(!showAudioSettings)}
            className={`p-1.5 rounded-full text-xs font-mono transition-all ${
              showAudioSettings
                ? 'bg-amber-500/30 text-amber-300'
                : 'text-slate-400 hover:text-white hover:bg-white/10'
            }`}
            title="Ambient Music Tunings & Settings"
          >
            <Sliders className="w-3.5 h-3.5" />
          </button>

          <div className="h-4 w-px bg-white/10 hidden sm:block" />

          <div className="hidden sm:flex items-center gap-2 px-3 text-xs font-mono text-cyan-400">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            <span>Chapter {activeChapter.number} / 13</span>
          </div>
        </div>

        {/* Expandable Audio Soundscape Customization Card */}
        {showAudioSettings && (
          <div className="w-80 p-5 rounded-3xl bg-[#0a0e17]/95 border border-amber-500/30 shadow-2xl backdrop-blur-2xl space-y-4 text-xs font-mono animate-in fade-in slide-in-from-top-3 duration-200">
            <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
              <div className="flex items-center gap-2 text-amber-300 font-bold">
                <Music className="w-4 h-4 text-amber-400" />
                <span>Harmonic Resonator Engine</span>
              </div>
              <button
                onClick={handleTriggerChime}
                className="px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-[10px] flex items-center gap-1 transition-all border border-amber-500/30"
                title="Strike Quantum Crystal Chime"
              >
                <Bell className="w-3 h-3" />
                <span>Chime</span>
              </button>
            </div>

            {/* Volume Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>Master Volume</span>
                <span className="text-white font-bold">{Math.round(audioVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={audioVolume}
                onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
            </div>

            {/* Harmonic Tuning Preset Selector */}
            <div className="space-y-2">
              <div className="text-slate-400 text-[11px] font-bold uppercase tracking-wider">
                Resonant Scale Tunings
              </div>
              <div className="grid grid-cols-1 gap-1.5">
                {SOUNDSCAPE_PRESETS.map((preset, idx) => (
                  <button
                    key={preset.id}
                    onClick={() => handlePresetSelect(idx)}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      activePresetIndex === idx
                        ? 'bg-amber-500/20 border-amber-500/50 text-white shadow-md shadow-amber-500/10'
                        : 'bg-black/40 border-white/5 text-slate-400 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <div className="font-bold text-xs text-amber-200">{preset.name}</div>
                    <div className="text-[10px] text-slate-400 leading-tight mt-0.5">
                      {preset.description}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Chapter Harmonic Tracking Info */}
            <div className="p-2.5 rounded-xl bg-cyan-950/30 border border-cyan-500/30 text-[11px] text-cyan-200">
              <span className="text-cyan-400 font-bold block mb-0.5">Chapter Harmonic Shift:</span>
              Adapting acoustic chords dynamically to Chapter {activeChapter.number} ({activeChapter.title}).
            </div>
          </div>
        )}
      </div>

      {/* Floating 3D Stage Mode Overlay Bar */}
      {is3DStageMode && (
        <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 p-4 rounded-2xl bg-[#090d16]/95 border border-cyan-400/40 shadow-2xl backdrop-blur-xl flex flex-col sm:flex-row items-center gap-4 text-xs font-mono">
          <div className="flex items-center gap-2 text-cyan-300">
            <Eye className="w-4 h-4 text-cyan-400" />
            <span><strong>3D Interactive Stage:</strong> Click & drag anywhere to orbit the active scene.</span>
          </div>
          <div className="flex items-center gap-2">
            <select
              value={activeChapterIndex}
              onChange={(e) => setActiveChapterIndex(Number(e.target.value))}
              className="bg-black/60 border border-white/20 rounded-lg px-3 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-cyan-400"
            >
              {BEAUTY_CHAPTERS.map((ch, idx) => (
                <option key={ch.id} value={idx}>
                  Ch {ch.number}: {ch.title}
                </option>
              ))}
            </select>
            <button
              onClick={() => setIs3DStageMode(false)}
              className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-bold font-mono transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Sticky Top Chapter Carousel & Timeline Bar */}
      <div className="sticky top-0 z-30 bg-[#07090e]/90 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4 overflow-x-auto no-scrollbar">
          <div className="flex items-center gap-2 shrink-0">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <span className="font-serif font-black tracking-widest text-white text-sm sm:text-base uppercase">
              The Beauty of Chemistry
            </span>
          </div>

          {/* Chapters Navigation Tabs */}
          <div className="flex items-center gap-1.5 shrink-0 overflow-x-auto py-1">
            {BEAUTY_CHAPTERS.map((ch, idx) => (
              <button
                key={ch.id}
                onClick={() => scrollToChapter(idx)}
                className={`px-3 py-1 rounded-full text-xs font-serif transition-all shrink-0 flex items-center gap-1.5 ${
                  activeChapterIndex === idx
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50 shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                }`}
              >
                <span className="font-mono text-[10px] opacity-70">{ch.number}</span>
                <span>{ch.title}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Exhibition Container */}
      <div className={`relative z-10 max-w-5xl mx-auto px-4 sm:px-8 pt-16 space-y-36 ${is3DStageMode ? 'opacity-20 pointer-events-none' : 'opacity-100'} transition-opacity duration-300`}>
        {/* ==========================================
            EXHIBITION OVERVIEW INTRO
           ========================================== */}
        <section className="text-center space-y-8 pt-12 pb-8">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono tracking-widest uppercase shadow-inner">
            <Compass className="w-3.5 h-3.5" />
            <span>Digital Scientific Exhibition</span>
          </div>

          <h1 className="font-serif font-black text-4xl sm:text-6xl md:text-7xl text-white tracking-tight leading-none">
            The Poetry of <br />
            <span className="bg-gradient-to-r from-amber-200 via-cyan-200 to-amber-400 bg-clip-text text-transparent">
              Transformative Matter
            </span>
          </h1>

          <p className="max-w-2xl mx-auto font-serif italic text-lg sm:text-xl text-slate-300 leading-relaxed">
            “Chemistry is not merely the catalog of substances. It is the poetic language through which the cosmos organizes matter into stars, oceans, DNA, and human thought.”
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 pt-4 font-mono text-xs">
            <button
              onClick={() => scrollToChapter(0)}
              className="px-6 py-3 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold tracking-wider uppercase transition-all shadow-xl shadow-amber-500/20 flex items-center gap-2"
            >
              <span>Begin Curated Journey</span>
              <ArrowDown className="w-4 h-4" />
            </button>

            {onNavigate && (
              <button
                onClick={() => onNavigate('atomic-structure')}
                className="px-6 py-3 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white font-serif transition-all flex items-center gap-2"
              >
                <span>Atomic Observatory</span>
                <ArrowRight className="w-4 h-4 text-amber-400" />
              </button>
            )}
          </div>
        </section>

        {/* ==========================================
            13 CURATED ESSAY CHAPTERS
           ========================================== */}
        {BEAUTY_CHAPTERS.map((chapter, index) => {
          return (
            <section
              key={chapter.id}
              ref={(el) => {
                chapterRefs.current[index] = el;
              }}
              className="scroll-mt-28 space-y-8"
            >
              {/* Chapter Header */}
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-3xl sm:text-4xl font-bold text-amber-400/80">
                    {chapter.number}
                  </span>
                  <div className="h-px flex-1 bg-gradient-to-r from-amber-500/40 via-white/10 to-transparent" />
                  <span className="text-xs font-mono uppercase tracking-widest px-3 py-1 rounded-full bg-white/5 border border-white/10 text-cyan-300">
                    Theme: {chapter.visualTheme}
                  </span>
                </div>

                <h2 className="font-serif font-black text-3xl sm:text-5xl text-white tracking-tight">
                  {chapter.title}
                </h2>
                <p className="font-serif text-base sm:text-xl text-amber-300/80">
                  {chapter.subtitle}
                </p>
              </div>

              {/* Epigraph Callout Card */}
              <div className="relative p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#0d121f] via-[#090d16] to-[#0d121f] border border-amber-500/20 shadow-2xl">
                <Quote className="w-8 h-8 text-amber-500/25 absolute top-6 right-6 pointer-events-none" />
                <blockquote className="font-serif italic text-base sm:text-lg text-amber-100/90 leading-relaxed mb-3 pr-8">
                  {chapter.epigraph}
                </blockquote>
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-amber-400 font-bold">— {chapter.epigraphAuthor}</span>
                  <button
                    onClick={() => handleShareQuote(chapter.id, `${chapter.epigraph} — ${chapter.epigraphAuthor}`)}
                    className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white transition-all"
                    title="Copy Quote to Clipboard"
                  >
                    {copiedId === chapter.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-[11px] text-emerald-400 font-bold">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Share2 className="w-3.5 h-3.5" />
                        <span className="text-[11px]">Copy Quote</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Editorial Narrative & Key Scientific Formulations */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                {/* Left Narrative Column */}
                <div className="lg:col-span-7 space-y-5 text-sm sm:text-base text-slate-300 font-sans leading-relaxed">
                  {chapter.narrative.map((paragraph, pIdx) => (
                    <p key={pIdx} className="leading-relaxed">
                      {paragraph}
                    </p>
                  ))}

                  {/* Scientific Insight Box */}
                  <div className="p-4 rounded-2xl bg-cyan-950/20 border border-cyan-500/30 text-cyan-200 text-xs sm:text-sm font-sans flex items-start gap-3 shadow-md">
                    <Sparkles className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold font-mono text-cyan-300 uppercase tracking-wider block text-[11px] mb-1">
                        Fundamental Insight:
                      </span>
                      {chapter.scientificInsight}
                    </div>
                  </div>
                </div>

                {/* Right Equations & Interactive Metrics Column */}
                <div className="lg:col-span-5 space-y-4 font-mono">
                  {/* Master Equation Card (Formatted with crisp mathematical typography) */}
                  {chapter.keyEquation && (
                    <div className="p-5 rounded-2xl bg-[#0b0f1a]/95 border border-amber-500/30 shadow-xl space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5 text-[11px] uppercase text-amber-400 tracking-wider font-bold">
                          <Sigma className="w-4 h-4 text-amber-400" />
                          <span>Master Formulation</span>
                        </div>
                        <span className="text-[10px] text-slate-400 font-sans">Physical Law</span>
                      </div>

                      <div className="p-4 rounded-xl bg-black/70 border border-amber-500/20 text-center shadow-inner overflow-x-auto">
                        <FormattedMathEquation rawLatex={chapter.keyEquation.latex} />
                      </div>

                      <p className="text-[11px] text-slate-400 font-sans leading-snug">
                        {chapter.keyEquation.description}
                      </p>
                    </div>
                  )}

                  {/* Three Interactive Key Metrics */}
                  <div className="grid grid-cols-1 gap-2.5">
                    {chapter.interactiveMetrics.map((met, mIdx) => (
                      <div
                        key={mIdx}
                        className="p-3.5 rounded-2xl bg-[#090d16]/90 border border-white/10 hover:border-cyan-500/40 transition-all flex items-center justify-between"
                      >
                        <div>
                          <div className="text-slate-400 text-[10px] uppercase tracking-wider font-mono">{met.label}</div>
                          <div className="text-white font-bold text-sm sm:text-base mt-0.5 font-mono">{met.value}</div>
                        </div>
                        <div className="text-right text-[11px] text-cyan-300/80 max-w-[140px] leading-tight font-sans">
                          {met.detail}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </section>
          );
        })}

        {/* ==========================================
            SUPPLEMENTARY SECTION 1:
            THE SCALE OF MATTER (Cosmos to Quarks)
           ========================================== */}
        <section className="space-y-8 pt-12 border-t border-white/10">
          <div className="text-center max-w-3xl mx-auto space-y-2">
            <span className="text-xs font-mono uppercase tracking-widest px-3 py-1 rounded-full bg-cyan-950/60 text-cyan-300 border border-cyan-500/30">
              Dimensional Continuum
            </span>
            <h2 className="font-serif font-black text-3xl sm:text-5xl text-white">
              The Scale of Matter
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Chemistry is the central golden bridge connecting cosmological dimensions (10²⁶ m) with fundamental subatomic quantum fields (10⁻¹⁸ m).
            </p>
          </div>

          <div className="p-6 sm:p-8 rounded-3xl bg-[#090d16]/90 border border-cyan-500/30 shadow-2xl space-y-6">
            {/* Scale Slider / Steps */}
            <div className="space-y-2 font-mono text-xs">
              <div className="flex justify-between text-slate-400">
                <span>10²⁶ m (Cosmos)</span>
                <span className="text-cyan-300 font-bold">Selected: {SCALE_OF_MATTER[activeScaleIndex].exponent}</span>
                <span>10⁻¹⁸ m (Quarks)</span>
              </div>
              <input
                type="range"
                min={0}
                max={SCALE_OF_MATTER.length - 1}
                value={activeScaleIndex}
                onChange={(e) => setActiveScaleIndex(parseInt(e.target.value))}
                className="w-full accent-cyan-400 bg-slate-800 h-2.5 rounded-lg cursor-pointer"
              />
            </div>

            {/* Active Scale Focus Card */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center p-6 rounded-2xl bg-black/50 border border-white/10 font-sans">
              <div className="md:col-span-4 text-center md:text-left space-y-1 font-mono">
                <div className="text-4xl font-black text-cyan-300">
                  {SCALE_OF_MATTER[activeScaleIndex].exponent}
                </div>
                <div className="text-xs uppercase text-amber-400 font-bold">
                  {SCALE_OF_MATTER[activeScaleIndex].realm}
                </div>
                <div className="text-lg font-serif font-bold text-white">
                  {SCALE_OF_MATTER[activeScaleIndex].title}
                </div>
              </div>

              <div className="md:col-span-8 space-y-3">
                <p className="text-sm text-slate-300 leading-relaxed">
                  {SCALE_OF_MATTER[activeScaleIndex].description}
                </p>
                <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 text-xs text-cyan-200 font-mono">
                  <span className="text-slate-400 mr-2">Exemplar:</span>
                  <strong>{SCALE_OF_MATTER[activeScaleIndex].example}</strong>
                </div>
              </div>
            </div>

            {/* Quick Scale Step Buttons */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 font-mono text-xs">
              {SCALE_OF_MATTER.map((sc, idx) => (
                <button
                  key={sc.exponent}
                  onClick={() => setActiveScaleIndex(idx)}
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    activeScaleIndex === idx
                      ? 'bg-cyan-500/20 border-cyan-400 text-white font-bold shadow-md shadow-cyan-500/20'
                      : 'bg-black/40 border-white/5 text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <div className="font-bold">{sc.exponent}</div>
                  <div className="text-[10px] opacity-70 truncate">{sc.title}</div>
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* ==========================================
            SUPPLEMENTARY SECTION 2:
            THE PANTHEON OF CHEMISTS
           ========================================== */}
        <section className="space-y-8 pt-12 border-t border-white/10">
          <div className="text-center max-w-3xl mx-auto space-y-2">
            <span className="text-xs font-mono uppercase tracking-widest px-3 py-1 rounded-full bg-amber-950/60 text-amber-300 border border-amber-500/30">
              Architects of Reality
            </span>
            <h2 className="font-serif font-black text-3xl sm:text-5xl text-white">
              The Pantheon of Chemists
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              The pioneers whose intellect and experiments unveiled the hidden laws of atomic organization.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Chemists List Selector */}
            <div className="lg:col-span-5 space-y-2">
              {FAMOUS_CHEMISTS.map((chm) => (
                <button
                  key={chm.id}
                  onClick={() => setSelectedChemist(chm)}
                  className={`w-full p-3.5 rounded-2xl border text-left transition-all flex items-center justify-between ${
                    selectedChemist.id === chm.id
                      ? 'bg-amber-500/20 border-amber-500 text-white shadow-lg shadow-amber-500/10'
                      : 'bg-[#090d16]/80 border-white/5 text-slate-300 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{chm.portrait}</span>
                    <div>
                      <div className="font-serif font-bold text-sm">{chm.name}</div>
                      <div className="text-[11px] font-mono text-amber-400/80">{chm.lifespan}</div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 opacity-60" />
                </button>
              ))}
            </div>

            {/* Selected Chemist Deep Archival Card */}
            <div className="lg:col-span-7 p-6 sm:p-8 rounded-3xl bg-[#090d16]/95 border border-amber-500/30 shadow-2xl space-y-5">
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-xs font-mono text-amber-400 uppercase tracking-widest">
                    {selectedChemist.era}
                  </span>
                  <h3 className="font-serif font-black text-2xl sm:text-3xl text-white mt-1">
                    {selectedChemist.name}
                  </h3>
                  <div className="text-xs font-serif text-cyan-300 mt-0.5">
                    {selectedChemist.title}
                  </div>
                </div>
                <div className="text-4xl p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30">
                  {selectedChemist.portrait}
                </div>
              </div>

              {/* Breakthrough Badge */}
              <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-200 text-xs font-mono">
                <span className="text-amber-400 font-bold block mb-1">Key Breakthrough:</span>
                {selectedChemist.breakthrough}
              </div>

              {/* Quote */}
              <blockquote className="p-4 rounded-2xl bg-black/40 border-l-4 border-amber-500 font-serif italic text-sm text-amber-100 leading-relaxed">
                “{selectedChemist.quote}”
              </blockquote>

              <div className="space-y-2 text-xs sm:text-sm text-slate-300 leading-relaxed">
                <h4 className="font-mono text-[11px] uppercase text-slate-400 font-bold">Historical Significance:</h4>
                <p>{selectedChemist.historicalSignificance}</p>
              </div>

              <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs font-mono text-slate-400">
                <span>Iconic Publication:</span>
                <span className="text-amber-300 font-serif font-bold italic">{selectedChemist.iconicWork}</span>
              </div>
            </div>
          </div>
        </section>

        {/* ==========================================
            EXHIBITION FOOTER & NAVIGATION
           ========================================== */}
        <footer className="text-center pt-16 border-t border-white/10 space-y-6">
          <div className="font-serif italic text-lg text-amber-200 max-w-xl mx-auto">
            “The universe is not just matter; it is a tapestry woven from the deliberate laws of chemical beauty.”
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 font-mono text-xs">
            {onNavigate && (
              <>
                <button
                  onClick={() => onNavigate('periodic-table')}
                  className="px-5 py-2.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white transition-all"
                >
                  Explore Periodic Table
                </button>
                <button
                  onClick={() => onNavigate('stoichiometry')}
                  className="px-5 py-2.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white transition-all"
                >
                  Stoichiometry & Reactions
                </button>
                <button
                  onClick={() => onNavigate('orbital-atlas')}
                  className="px-5 py-2.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white transition-all"
                >
                  3D Quantum Orbital Atlas
                </button>
              </>
            )}
          </div>

          <div className="text-[11px] font-mono text-slate-500">
            Chemisphere 3D • Curated Digital Scientific Exhibition • All 13 Dimensions of Matter
          </div>
        </footer>
      </div>
    </div>
  );
};
