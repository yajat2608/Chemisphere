import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

interface BeautyCanvas3DProps {
  theme: string;
  scrollProgress?: number;
  interactive?: boolean;
  className?: string;
}

export const BeautyCanvas3D: React.FC<BeautyCanvas3DProps> = ({
  theme,
  scrollProgress = 0,
  interactive = false,
  className = 'w-full h-full'
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const themeRef = useRef<string>(theme);
  const scrollProgressRef = useRef<number>(scrollProgress);
  const [webGlError, setWebGlError] = useState<boolean>(false);

  useEffect(() => {
    themeRef.current = theme;
  }, [theme]);

  useEffect(() => {
    scrollProgressRef.current = Number.isFinite(scrollProgress) ? scrollProgress : 0;
  }, [scrollProgress]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    let animId: number;
    let renderer: THREE.WebGLRenderer | null = null;
    let scene: THREE.Scene | null = null;
    let camera: THREE.PerspectiveCamera | null = null;
    let isDisposed = false;

    // Mouse drag rotation state for interactive mode
    let isDragging = false;
    let previousMousePosition = { x: 0, y: 0 };
    let userRotation = { x: 0, y: 0 };

    try {
      const getWidth = () => Math.max(container.clientWidth || window.innerWidth, 320);
      const getHeight = () => Math.max(container.clientHeight || window.innerHeight, 240);

      const width = getWidth();
      const height = getHeight();

      scene = new THREE.Scene();
      scene.fog = new THREE.FogExp2(0x07090e, 0.035);

      camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
      camera.position.set(0, 0, 12);

      // WebGL Renderer with safe context recovery
      renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: true,
        powerPreference: 'high-performance',
        preserveDrawingBuffer: false
      });

      renderer.setSize(width, height);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.1;

      container.innerHTML = '';
      container.appendChild(renderer.domElement);

      // Studio Multi-Spectrum Lighting
      const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
      scene.add(ambientLight);

      const cyanPointLight = new THREE.PointLight(0x38bdf8, 4.0, 60);
      cyanPointLight.position.set(9, 9, 10);
      scene.add(cyanPointLight);

      const amberPointLight = new THREE.PointLight(0xf59e0b, 3.5, 60);
      amberPointLight.position.set(-9, -7, 8);
      scene.add(amberPointLight);

      const purplePointLight = new THREE.PointLight(0xa855f7, 2.5, 60);
      purplePointLight.position.set(0, 9, -7);
      scene.add(purplePointLight);

      const rootGroup = new THREE.Group();
      scene.add(rootGroup);

      // ==========================================
      // 1. STARFIELD / DUST PARTICLES BACKGROUND
      // ==========================================
      const particleCount = 1200;
      const dustGeo = new THREE.BufferGeometry();
      const dustPositions = new Float32Array(particleCount * 3);
      const dustColors = new Float32Array(particleCount * 3);

      for (let i = 0; i < particleCount; i++) {
        dustPositions[i * 3] = (Math.random() - 0.5) * 55;
        dustPositions[i * 3 + 1] = (Math.random() - 0.5) * 55;
        dustPositions[i * 3 + 2] = (Math.random() - 0.5) * 45;

        const isGold = Math.random() > 0.55;
        dustColors[i * 3] = isGold ? 0.96 : 0.22;
        dustColors[i * 3 + 1] = isGold ? 0.68 : 0.75;
        dustColors[i * 3 + 2] = isGold ? 0.18 : 0.98;
      }

      dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPositions, 3));
      dustGeo.setAttribute('color', new THREE.BufferAttribute(dustColors, 3));

      const dustMat = new THREE.PointsMaterial({
        size: 0.085,
        vertexColors: true,
        transparent: true,
        opacity: 0.65,
        blending: THREE.AdditiveBlending
      });

      const dustPoints = new THREE.Points(dustGeo, dustMat);
      scene.add(dustPoints);

      // ==========================================
      // 2. THEMATIC 3D OBJECT GROUPS (13 CHAPTERS)
      // ==========================================
      const dynamicGroup = new THREE.Group();
      rootGroup.add(dynamicGroup);

      const safelyDisposeGroup = (group: THREE.Group) => {
        while (group.children.length > 0) {
          const obj = group.children[0];
          group.remove(obj);
          if ((obj as THREE.Mesh).geometry) {
            (obj as THREE.Mesh).geometry.dispose();
          }
          if ((obj as THREE.Mesh).material) {
            const mat = (obj as THREE.Mesh).material;
            if (Array.isArray(mat)) {
              mat.forEach((m) => m.dispose());
            } else {
              mat.dispose();
            }
          }
        }
      };

      const rebuildThematicScene = (currentTheme: string) => {
        safelyDisposeGroup(dynamicGroup);

        if (currentTheme === 'cosmos') {
          // 1. Glowing Stellar Nucleosynthesis Core & Coronal Rings
          const coreGeo = new THREE.SphereGeometry(1.3, 32, 32);
          const coreMat = new THREE.MeshStandardMaterial({
            color: 0xf59e0b,
            emissive: 0xd97706,
            emissiveIntensity: 1.6,
            roughness: 0.2,
            metalness: 0.1
          });
          const core = new THREE.Mesh(coreGeo, coreMat);
          dynamicGroup.add(core);

          for (let i = 0; i < 4; i++) {
            const ringGeo = new THREE.RingGeometry(1.8 + i * 0.65, 1.86 + i * 0.65, 64);
            const ringMat = new THREE.MeshBasicMaterial({
              color: i % 2 === 0 ? 0xf59e0b : 0x38bdf8,
              side: THREE.DoubleSide,
              transparent: true,
              opacity: 0.55
            });
            const ring = new THREE.Mesh(ringGeo, ringMat);
            ring.rotation.x = Math.PI / 2.5 + i * 0.25;
            ring.rotation.y = i * 0.45;
            dynamicGroup.add(ring);
          }
        } else if (currentTheme === 'atom') {
          // 2. Quantum Nucleus & Resonant Standing Shells
          const nucGeo = new THREE.SphereGeometry(0.55, 24, 24);
          const nucMat = new THREE.MeshStandardMaterial({
            color: 0xef4444,
            emissive: 0x991b1b,
            emissiveIntensity: 1.2
          });
          const nuc = new THREE.Mesh(nucGeo, nucMat);
          dynamicGroup.add(nuc);

          [1.8, 2.7, 3.7].forEach((r, idx) => {
            const shellGeo = new THREE.TorusGeometry(r, 0.03, 16, 64);
            const shellMat = new THREE.MeshBasicMaterial({
              color: idx === 0 ? 0x38bdf8 : idx === 1 ? 0xf59e0b : 0xa855f7,
              transparent: true,
              opacity: 0.75
            });
            const shell = new THREE.Mesh(shellGeo, shellMat);
            shell.rotation.x = Math.PI / 3 + idx * 0.6;
            shell.rotation.y = idx * 0.8;
            dynamicGroup.add(shell);
          });
        } else if (currentTheme === 'symphony') {
          // 3. Cylindrical Periodic Octave Helical Spiral
          const turns = 3.5;
          const totalPts = 96;
          const spiralPts: THREE.Vector3[] = [];
          const atomGeo = new THREE.SphereGeometry(0.13, 12, 12);
          const goldMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, emissive: 0xb45309 });
          const cyanMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x0284c7 });

          for (let i = 0; i < totalPts; i++) {
            const t = (i / totalPts) * Math.PI * 2 * turns;
            const y = (i / totalPts) * 6.5 - 3.25;
            const r = 2.1;
            const x = Math.cos(t) * r;
            const z = Math.sin(t) * r;
            spiralPts.push(new THREE.Vector3(x, y, z));

            if (i % 3 === 0) {
              const atom = new THREE.Mesh(atomGeo, i % 6 === 0 ? goldMat : cyanMat);
              atom.position.set(x, y, z);
              dynamicGroup.add(atom);
            }
          }
          const spiralLine = new THREE.Line(
            new THREE.BufferGeometry().setFromPoints(spiralPts),
            new THREE.LineBasicMaterial({ color: 0xfbbf24, transparent: true, opacity: 0.75 })
          );
          dynamicGroup.add(spiralLine);
        } else if (currentTheme === 'bond') {
          // 4. Overlapping Covalent Molecular Orbitals
          const atomGeo = new THREE.SphereGeometry(0.55, 24, 24);
          const atomMat1 = new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x0284c7 });
          const atomMat2 = new THREE.MeshStandardMaterial({ color: 0xf59e0b, emissive: 0xb45309 });

          const atom1 = new THREE.Mesh(atomGeo, atomMat1);
          atom1.position.set(-1.6, 0, 0);
          dynamicGroup.add(atom1);

          const atom2 = new THREE.Mesh(atomGeo, atomMat2);
          atom2.position.set(1.6, 0, 0);
          dynamicGroup.add(atom2);

          const bridgeGeo = new THREE.SphereGeometry(1.2, 24, 24);
          bridgeGeo.scale(1.8, 0.9, 0.9);
          const bridgeMat = new THREE.MeshBasicMaterial({
            color: 0x06b6d4,
            wireframe: true,
            transparent: true,
            opacity: 0.5
          });
          const bridge = new THREE.Mesh(bridgeGeo, bridgeMat);
          dynamicGroup.add(bridge);
        } else if (currentTheme === 'geometry') {
          // 5. Coordination Polyhedron (Icosahedron + Octahedron)
          const icoGeo = new THREE.IcosahedronGeometry(2.3, 1);
          const icoMat = new THREE.MeshStandardMaterial({
            color: 0xa855f7,
            wireframe: true,
            emissive: 0x7e22ce,
            emissiveIntensity: 0.6
          });
          const ico = new THREE.Mesh(icoGeo, icoMat);
          dynamicGroup.add(ico);

          const innerGeo = new THREE.OctahedronGeometry(1.25);
          const innerMat = new THREE.MeshStandardMaterial({
            color: 0xf59e0b,
            transparent: true,
            opacity: 0.7,
            metalness: 0.7
          });
          const inner = new THREE.Mesh(innerGeo, innerMat);
          dynamicGroup.add(inner);
        } else if (currentTheme === 'motion') {
          // 6. Kinetic Thermal Agitation Gas Chamber
          const boxGeo = new THREE.BoxGeometry(3.6, 3.6, 3.6);
          const boxMat = new THREE.MeshBasicMaterial({ color: 0xf97316, wireframe: true, transparent: true, opacity: 0.4 });
          const box = new THREE.Mesh(boxGeo, boxMat);
          dynamicGroup.add(box);

          const pGeo = new THREE.SphereGeometry(0.09, 8, 8);
          const pMat = new THREE.MeshBasicMaterial({ color: 0xfbbf24 });
          for (let i = 0; i < 36; i++) {
            const p = new THREE.Mesh(pGeo, pMat);
            p.position.set(
              (Math.random() - 0.5) * 3.1,
              (Math.random() - 0.5) * 3.1,
              (Math.random() - 0.5) * 3.1
            );
            dynamicGroup.add(p);
          }
        } else if (currentTheme === 'reaction') {
          // 7. Activated Transition State Complex
          const atomGeo = new THREE.SphereGeometry(0.45, 20, 20);
          const centerMat = new THREE.MeshStandardMaterial({ color: 0xef4444, emissive: 0xb91c1c, emissiveIntensity: 1.3 });
          const reactantMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x0369a1 });

          const center = new THREE.Mesh(atomGeo, centerMat);
          dynamicGroup.add(center);

          [-1.8, 1.8].forEach((x, idx) => {
            const rAtom = new THREE.Mesh(atomGeo, reactantMat);
            rAtom.position.set(x, idx === 0 ? 0.8 : -0.8, 0);
            dynamicGroup.add(rAtom);

            // Transition bond line (computed safely)
            const linePts = [new THREE.Vector3(0, 0, 0), new THREE.Vector3(x, idx === 0 ? 0.8 : -0.8, 0)];
            const lineGeo = new THREE.BufferGeometry().setFromPoints(linePts);
            const bondLine = new THREE.Line(
              lineGeo,
              new THREE.LineBasicMaterial({ color: 0xfbbf24, transparent: true, opacity: 0.8 })
            );
            dynamicGroup.add(bondLine);
          });
        } else if (currentTheme === 'energy') {
          // 8. Quantized Photon Wave Packet (Orthogonal Transverse Waves)
          const wavePts1: THREE.Vector3[] = [];
          const wavePts2: THREE.Vector3[] = [];
          const span = 6.4;
          for (let i = 0; i <= 100; i++) {
            const x = (i / 100) * span - span / 2;
            const k = 4;
            const y = Math.sin(k * x) * 0.95;
            const z = Math.cos(k * x) * 0.95;
            wavePts1.push(new THREE.Vector3(x, y, 0));
            wavePts2.push(new THREE.Vector3(x, 0, z));
          }
          const line1 = new THREE.Line(
            new THREE.BufferGeometry().setFromPoints(wavePts1),
            new THREE.LineBasicMaterial({ color: 0xfbbf24 })
          );
          const line2 = new THREE.Line(
            new THREE.BufferGeometry().setFromPoints(wavePts2),
            new THREE.LineBasicMaterial({ color: 0x38bdf8 })
          );
          dynamicGroup.add(line1);
          dynamicGroup.add(line2);
        } else if (currentTheme === 'colors') {
          // 9. Octahedral d-Orbital Crystal Field Splitting
          const lobeGeo = new THREE.SphereGeometry(0.35, 16, 16);
          lobeGeo.scale(0.8, 2.3, 0.8);
          const colorsList = [0x6366f1, 0x06b6d4, 0x10b981, 0xf59e0b, 0xef4444];

          for (let i = 0; i < 5; i++) {
            const lMat = new THREE.MeshStandardMaterial({
              color: colorsList[i],
              emissive: colorsList[i],
              emissiveIntensity: 0.8,
              transparent: true,
              opacity: 0.85
            });
            const lobe = new THREE.Mesh(lobeGeo, lMat);
            const angle = (i / 5) * Math.PI * 2;
            lobe.position.set(Math.cos(angle) * 1.5, Math.sin(angle) * 1.5, 0);
            lobe.rotation.z = angle;
            dynamicGroup.add(lobe);
          }
        } else if (currentTheme === 'crystals') {
          // 10. 3D Cubic Lattice Unit Cell
          const latticeGeo = new THREE.BoxGeometry(3.2, 3.2, 3.2);
          const latticeWireMat = new THREE.MeshBasicMaterial({
            color: 0x38bdf8,
            wireframe: true,
            transparent: true,
            opacity: 0.75
          });
          const wireBox = new THREE.Mesh(latticeGeo, latticeWireMat);
          dynamicGroup.add(wireBox);

          const atomGeo = new THREE.SphereGeometry(0.24, 16, 16);
          const atomMat = new THREE.MeshStandardMaterial({
            color: 0x38bdf8,
            emissive: 0x0284c7,
            emissiveIntensity: 0.9,
            metalness: 0.8,
            roughness: 0.1
          });

          [-1.6, 1.6].forEach((x) => {
            [-1.6, 1.6].forEach((y) => {
              [-1.6, 1.6].forEach((z) => {
                const atom = new THREE.Mesh(atomGeo, atomMat);
                atom.position.set(x, y, z);
                dynamicGroup.add(atom);
              });
            });
          });

          const centerAtom = new THREE.Mesh(
            new THREE.SphereGeometry(0.32, 16, 16),
            new THREE.MeshStandardMaterial({ color: 0xf59e0b, emissive: 0xd97706, emissiveIntensity: 1.2 })
          );
          dynamicGroup.add(centerAtom);
        } else if (currentTheme === 'life') {
          // 11. DNA Double Helix Structure
          const rungs = 26;
          const radius = 1.45;
          const heightSpan = 8.5;
          const sphereGeo = new THREE.SphereGeometry(0.13, 12, 12);
          const strand1Mat = new THREE.MeshStandardMaterial({ color: 0x10b981, emissive: 0x047857 });
          const strand2Mat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x0369a1 });
          const rungMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b, transparent: true, opacity: 0.75 });

          for (let i = 0; i < rungs; i++) {
            const t = (i / rungs) * Math.PI * 4;
            const y = (i / rungs) * heightSpan - heightSpan / 2;
            const x1 = radius * Math.cos(t);
            const z1 = radius * Math.sin(t);
            const x2 = radius * Math.cos(t + Math.PI);
            const z2 = radius * Math.sin(t + Math.PI);

            const s1 = new THREE.Mesh(sphereGeo, strand1Mat);
            s1.position.set(x1, y, z1);
            dynamicGroup.add(s1);

            const s2 = new THREE.Mesh(sphereGeo, strand2Mat);
            s2.position.set(x2, y, z2);
            dynamicGroup.add(s2);

            const rungGeo = new THREE.CylinderGeometry(0.03, 0.03, radius * 2, 8);
            const rung = new THREE.Mesh(rungGeo, rungMat);
            rung.position.set(0, y, 0);
            rung.rotation.z = Math.PI / 2;
            rung.rotation.y = -t;
            dynamicGroup.add(rung);
          }
        } else if (currentTheme === 'organic') {
          // 12. Benzene Aromatic Ring
          const hexPts: THREE.Vector3[] = [];
          const rHex = 2.1;
          const cAtomGeo = new THREE.SphereGeometry(0.22, 16, 16);
          const cMat = new THREE.MeshStandardMaterial({ color: 0xec4899, emissive: 0xbe185d });

          for (let i = 0; i <= 6; i++) {
            const a = (i / 6) * Math.PI * 2;
            const x = Math.cos(a) * rHex;
            const y = Math.sin(a) * rHex;
            hexPts.push(new THREE.Vector3(x, y, 0));
            if (i < 6) {
              const cAtom = new THREE.Mesh(cAtomGeo, cMat);
              cAtom.position.set(x, y, 0);
              dynamicGroup.add(cAtom);
            }
          }
          const hexLine = new THREE.Line(
            new THREE.BufferGeometry().setFromPoints(hexPts),
            new THREE.LineBasicMaterial({ color: 0xf472b6 })
          );
          dynamicGroup.add(hexLine);

          [-0.5, 0.5].forEach((zVal) => {
            const piRingGeo = new THREE.TorusGeometry(1.65, 0.07, 16, 64);
            const piRingMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.55 });
            const piRing = new THREE.Mesh(piRingGeo, piRingMat);
            piRing.position.z = zVal;
            dynamicGroup.add(piRing);
          });
        } else {
          // 13. Everyday Chemistry (Micelle Spherical Assembly)
          const micelleCore = new THREE.Mesh(
            new THREE.SphereGeometry(1.05, 24, 24),
            new THREE.MeshStandardMaterial({ color: 0xf59e0b, emissive: 0xb45309, roughness: 0.4 })
          );
          dynamicGroup.add(micelleCore);

          const headGeo = new THREE.SphereGeometry(0.13, 12, 12);
          const headMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x0284c7 });
          for (let i = 0; i < 42; i++) {
            const phi = Math.acos(-1 + (2 * i) / 42);
            const theta = Math.sqrt(42 * Math.PI) * phi;
            const r = 1.95;
            const head = new THREE.Mesh(headGeo, headMat);
            head.position.set(
              r * Math.cos(theta) * Math.sin(phi),
              r * Math.sin(theta) * Math.sin(phi),
              r * Math.cos(phi)
            );
            dynamicGroup.add(head);
          }
        }
      };

      rebuildThematicScene(theme);

      // Safe Resize Handler
      const handleResize = () => {
        if (!container || !renderer || !camera || isDisposed) return;
        const w = getWidth();
        const h = getHeight();
        if (w <= 0 || h <= 0) return;
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      };
      window.addEventListener('resize', handleResize);

      // Mouse drag controls for interactive mode
      const onMouseDown = (e: MouseEvent) => {
        isDragging = true;
        previousMousePosition = { x: e.clientX, y: e.clientY };
      };
      const onMouseMove = (e: MouseEvent) => {
        if (!isDragging) return;
        const deltaX = e.clientX - previousMousePosition.x;
        const deltaY = e.clientY - previousMousePosition.y;
        userRotation.y += deltaX * 0.006;
        userRotation.x += deltaY * 0.006;
        previousMousePosition = { x: e.clientX, y: e.clientY };
      };
      const onMouseUp = () => {
        isDragging = false;
      };

      if (interactive) {
        window.addEventListener('mousedown', onMouseDown);
        window.addEventListener('mousemove', onMouseMove);
        window.addEventListener('mouseup', onMouseUp);
      }

      // Animation Loop with robust error guarding
      let clock = new THREE.Clock();
      let currentActiveTheme = theme;

      const animate = () => {
        if (isDisposed || !renderer || !scene || !camera) return;
        animId = requestAnimationFrame(animate);

        try {
          const delta = clock.getDelta();
          const elapsedTime = clock.getElapsedTime();

          // Smoothly detect theme switch
          if (currentActiveTheme !== themeRef.current) {
            currentActiveTheme = themeRef.current;
            rebuildThematicScene(currentActiveTheme);
          }

          // Compute rotation combining scroll and subtle ambient drift
          const sProgress = scrollProgressRef.current || 0;
          rootGroup.rotation.y = elapsedTime * 0.12 + sProgress * Math.PI + userRotation.y;
          rootGroup.rotation.x = Math.sin(elapsedTime * 0.15) * 0.2 + sProgress * 0.4 + userRotation.x;

          // Dust starfield slow drift
          dustPoints.rotation.y = elapsedTime * 0.02;
          dustPoints.rotation.z = elapsedTime * 0.01;

          // Dynamic breathing scale
          const pulse = 1.0 + Math.sin(elapsedTime * 1.5) * 0.03;
          dynamicGroup.scale.set(pulse, pulse, pulse);

          renderer.render(scene, camera);
        } catch (renderErr) {
          console.warn('BeautyCanvas3D frame render error:', renderErr);
        }
      };

      animate();

      return () => {
        isDisposed = true;
        cancelAnimationFrame(animId);
        window.removeEventListener('resize', handleResize);
        if (interactive) {
          window.removeEventListener('mousedown', onMouseDown);
          window.removeEventListener('mousemove', onMouseMove);
          window.removeEventListener('mouseup', onMouseUp);
        }
        if (dynamicGroup) safelyDisposeGroup(dynamicGroup);
        if (scene) {
          scene.clear();
        }
        if (renderer) {
          renderer.dispose();
          if (renderer.domElement && renderer.domElement.parentNode) {
            renderer.domElement.parentNode.removeChild(renderer.domElement);
          }
        }
      };
    } catch (initErr) {
      console.error('BeautyCanvas3D WebGL initialization error:', initErr);
      setWebGlError(true);
      return;
    }
  }, [interactive]);

  if (webGlError) {
    // Graceful fallback for devices without WebGL
    return (
      <div className={`absolute inset-0 overflow-hidden ${className}`}>
        <div className="absolute inset-0 bg-gradient-to-br from-amber-950/20 via-cyan-950/20 to-purple-950/20 animate-pulse" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 rounded-full bg-gradient-to-tr from-amber-500/20 via-cyan-500/20 to-purple-500/20 blur-3xl" />
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className={`absolute inset-0 ${interactive ? 'cursor-grab active:cursor-grabbing' : 'pointer-events-none'} ${className}`}
      style={{ filter: 'drop-shadow(0 0 40px rgba(56, 189, 248, 0.08))' }}
    />
  );
};
