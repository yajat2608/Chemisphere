/**
 * BeautyAmbientSoundscape.ts
 * High-fidelity, multi-layered generative ambient audio engine for "The Beauty of Chemistry"
 * Built entirely with Web Audio API (zero external assets/network dependency).
 *
 * Features:
 * - Solfeggio & Pythagorean harmonic scales (528Hz transformation, 432Hz celestial grounding)
 * - Chapter-adaptive chord progressions & harmonic morphing
 * - Generative crystalline chime drops (simulating quantum transitions / crystal lattice reflections)
 * - Expansive multi-tap feedback delay & spatial stereo imaging
 * - Organic breathing low-frequency cosmic drone & filtered brown noise breath
 */

export interface SoundscapePreset {
  id: string;
  name: string;
  description: string;
  baseFreq: number; // Hz
  scaleIntervals: number[]; // Ratios or semitones
  filterCutoff: number; // Hz
  chimeColor: 'celestial' | 'warm' | 'crystal' | 'deep';
}

export const SOUNDSCAPE_PRESETS: SoundscapePreset[] = [
  {
    id: '528hz-transformation',
    name: '528 Hz Genesis & DNA Repair',
    description: 'Ancient Solfeggio frequency of molecular resonance and biological transformation.',
    baseFreq: 66.0, // C2 (sub-harmonic of 528Hz)
    scaleIntervals: [1, 9 / 8, 5 / 4, 4 / 3, 3 / 2, 5 / 3, 15 / 8, 2], // Just Intonation Major
    filterCutoff: 380,
    chimeColor: 'warm'
  },
  {
    id: '432hz-cosmic-order',
    name: '432 Hz Celestial Matrix',
    description: 'Pythagorean cosmic tuning mirroring the mathematical curvature of planetary orbits.',
    baseFreq: 54.0, // A1
    scaleIntervals: [1, 9 / 8, 81 / 64, 4 / 3, 3 / 2, 27 / 16, 2], // Pythagorean tuning
    filterCutoff: 320,
    chimeColor: 'celestial'
  },
  {
    id: 'quantum-shimmer',
    name: 'Quantum Lydian Shimmer',
    description: 'Luminous #4 Lydian modal harmonies evoking wave-particle duality and photon emissions.',
    baseFreq: 65.41, // C2
    scaleIntervals: [1, 9 / 8, 5 / 4, 45 / 32, 3 / 2, 5 / 3, 15 / 8, 2], // Lydian Just Intonation
    filterCutoff: 460,
    chimeColor: 'crystal'
  },
  {
    id: 'deep-observatory',
    name: 'Observatory Void (Deep Sub)',
    description: 'Ultra-low sub-bass resonance and stellar nucleosynthesis coronal hum.',
    baseFreq: 43.65, // F1
    scaleIntervals: [1, 6 / 5, 4 / 3, 3 / 2, 8 / 5, 9 / 5, 2], // Minor 7th / Aeolian
    filterCutoff: 240,
    chimeColor: 'deep'
  }
];

// Map 13 chapters to custom harmonic chords (base frequency multipliers)
export const CHAPTER_HARMONICS: Record<string, number[]> = {
  cosmos: [1, 1.5, 2, 2.25, 3], // Open 5ths & Octaves
  atom: [1, 1.25, 1.5, 1.875, 2.37], // Maj9 Shimmer
  symphony: [1, 1.125, 1.333, 1.5, 1.667, 2], // Harmonic Octave scale
  bond: [1, 1.2, 1.5, 1.8, 2.4], // Covalent Minor 9th
  geometry: [1, 1.25, 1.414, 1.5, 2], // Symmetry & Golden ratios
  motion: [1, 1.189, 1.414, 1.682, 2], // Dynamic Kinetic dispersion
  reaction: [1, 1.333, 1.5, 1.777, 2.25], // Activated Sus4 Transition
  energy: [1, 1.25, 1.5, 1.875, 2.812], // High Photon Overtone
  colors: [1, 1.2, 1.4, 1.6, 1.8, 2.1], // Crystal Field Spectrum
  crystals: [1, 1.333, 1.5, 2, 2.666], // Cubic Lattice Symmetry
  life: [1, 1.25, 1.5, 1.667, 2, 2.5], // Solfeggio 528 Harmonic series
  organic: [1, 1.2, 1.5, 1.75, 2.25], // Aromatic Ring Resonance
  everyday: [1, 1.25, 1.5, 1.75, 2] // Peaceful Resolution
};

export class BeautyAmbientEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private droneGains: GainNode[] = [];
  private droneOscs: OscillatorNode[] = [];
  private lfoOscs: OscillatorNode[] = [];
  private filterNode: BiquadFilterNode | null = null;
  private delayNode: DelayNode | null = null;
  private delayFeedback: GainNode | null = null;
  private noiseNode: AudioBufferSourceNode | null = null;
  private noiseGain: GainNode | null = null;
  private isRunning: boolean = false;
  private currentPresetIndex: number = 0;
  private chimeTimerId: number | null = null;
  private currentTheme: string = 'cosmos';
  private volume: number = 0.5;

  constructor() {
    // Lazy initialized on user action
  }

  public getIsPlaying(): boolean {
    return this.isRunning;
  }

  public getCurrentPreset(): SoundscapePreset {
    return SOUNDSCAPE_PRESETS[this.currentPresetIndex];
  }

  public setVolume(val: number) {
    this.volume = Math.max(0, Math.min(1, val));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.volume * 0.12, this.ctx.currentTime, 0.1);
    }
  }

  public getVolume(): number {
    return this.volume;
  }

  public async start(): Promise<boolean> {
    if (this.isRunning) return true;

    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!this.ctx || this.ctx.state === 'closed') {
        this.ctx = new AudioCtx();
      }

      if (this.ctx.state === 'suspended') {
        await this.ctx.resume();
      }

      const ctx = this.ctx;
      const now = ctx.currentTime;

      // Master output gain
      this.masterGain = ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.0001, now);
      this.masterGain.gain.exponentialRampToValueAtTime(this.volume * 0.12, now + 2.5);
      this.masterGain.connect(ctx.destination);

      // Low-pass warm master filter
      this.filterNode = ctx.createBiquadFilter();
      this.filterNode.type = 'lowpass';
      const preset = SOUNDSCAPE_PRESETS[this.currentPresetIndex];
      this.filterNode.frequency.setValueAtTime(preset.filterCutoff, now);
      this.filterNode.Q.setValueAtTime(1.8, now);
      this.filterNode.connect(this.masterGain);

      // Multi-tap Stereo Delay / Cathedral Space Simulation
      this.delayNode = ctx.createDelay();
      this.delayNode.delayTime.setValueAtTime(0.48, now);
      this.delayFeedback = ctx.createGain();
      this.delayFeedback.gain.setValueAtTime(0.42, now);

      const delayFilter = ctx.createBiquadFilter();
      delayFilter.type = 'lowpass';
      delayFilter.frequency.setValueAtTime(900, now);

      this.delayNode.connect(delayFilter);
      delayFilter.connect(this.delayFeedback);
      this.delayFeedback.connect(this.delayNode);
      this.delayNode.connect(this.masterGain);

      // Build initial drone voices
      this.buildDroneVoices();

      // Build Cosmic Brown Noise background ocean
      this.startCosmicNoise();

      // Start generative crystal chime loop
      this.startChimeLoop();

      this.isRunning = true;
      return true;
    } catch (err) {
      console.warn('Ambient Soundscape start error:', err);
      return false;
    }
  }

  public stop() {
    if (!this.isRunning || !this.ctx || !this.masterGain) {
      this.isRunning = false;
      return;
    }

    try {
      const now = this.ctx.currentTime;
      this.masterGain.gain.setTargetAtTime(0.0001, now, 0.4);

      if (this.chimeTimerId) {
        window.clearTimeout(this.chimeTimerId);
        this.chimeTimerId = null;
      }

      setTimeout(() => {
        this.droneOscs.forEach((osc) => {
          try {
            osc.stop();
            osc.disconnect();
          } catch (e) {
            // ignore
          }
        });
        this.lfoOscs.forEach((lfo) => {
          try {
            lfo.stop();
            lfo.disconnect();
          } catch (e) {
            // ignore
          }
        });
        if (this.noiseNode) {
          try {
            this.noiseNode.stop();
            this.noiseNode.disconnect();
          } catch (e) {
            // ignore
          }
        }
        this.droneOscs = [];
        this.lfoOscs = [];
        this.droneGains = [];
        this.isRunning = false;
      }, 500);
    } catch (err) {
      console.warn('Ambient Soundscape stop error:', err);
      this.isRunning = false;
    }
  }

  public setPreset(index: number) {
    this.currentPresetIndex = (index + SOUNDSCAPE_PRESETS.length) % SOUNDSCAPE_PRESETS.length;
    if (this.isRunning && this.ctx && this.filterNode) {
      const preset = SOUNDSCAPE_PRESETS[this.currentPresetIndex];
      this.filterNode.frequency.setTargetAtTime(preset.filterCutoff, this.ctx.currentTime, 1.2);
      this.retuneDroneVoices();
    }
  }

  public setChapterTheme(theme: string) {
    if (this.currentTheme === theme) return;
    this.currentTheme = theme;
    if (this.isRunning) {
      this.retuneDroneVoices();
      this.triggerChimeDrop(true); // Soft affirmative transition chime
    }
  }

  private buildDroneVoices() {
    if (!this.ctx || !this.filterNode) return;
    const ctx = this.ctx;
    const now = ctx.currentTime;
    const preset = SOUNDSCAPE_PRESETS[this.currentPresetIndex];
    const base = preset.baseFreq;
    const ratios = CHAPTER_HARMONICS[this.currentTheme] || [1, 1.5, 2, 2.5, 3];

    // Clean old voices
    this.droneOscs.forEach((o) => {
      try {
        o.stop();
        o.disconnect();
      } catch (e) {}
    });
    this.lfoOscs.forEach((l) => {
      try {
        l.stop();
        l.disconnect();
      } catch (e) {}
    });
    this.droneOscs = [];
    this.lfoOscs = [];
    this.droneGains = [];

    // Create 4 harmonic oscillators with subtle stereo spatialization
    ratios.slice(0, 4).forEach((ratio, idx) => {
      const osc = ctx.createOscillator();
      osc.type = idx === 0 ? 'sine' : idx === 1 ? 'triangle' : idx === 2 ? 'sawtooth' : 'sine';
      const targetFreq = base * ratio * (idx === 0 ? 1 : idx === 1 ? 2 : idx === 2 ? 3 : 4);
      osc.frequency.setValueAtTime(targetFreq, now);

      // Voice gain
      const voiceGain = ctx.createGain();
      const initialGain = idx === 0 ? 0.45 : idx === 1 ? 0.3 : idx === 2 ? 0.15 : 0.1;
      voiceGain.gain.setValueAtTime(initialGain, now);

      // Gentle LFO detune & breathing tremolo
      const lfo = ctx.createOscillator();
      const lfoGain = ctx.createGain();
      lfo.frequency.setValueAtTime(0.08 + idx * 0.04, now);
      lfoGain.gain.setValueAtTime(2.2 + idx * 0.8, now); // Hz detune
      lfo.connect(lfoGain);
      lfoGain.connect(osc.detune);
      lfo.start();
      this.lfoOscs.push(lfo);

      // Tremolo gain modulation
      const tremoloLfo = ctx.createOscillator();
      const tremoloGain = ctx.createGain();
      tremoloLfo.frequency.setValueAtTime(0.12 + idx * 0.03, now);
      tremoloGain.gain.setValueAtTime(0.08, now);
      tremoloLfo.connect(tremoloGain);
      tremoloGain.connect(voiceGain.gain);
      tremoloLfo.start();
      this.lfoOscs.push(tremoloLfo);

      osc.connect(voiceGain);
      voiceGain.connect(this.filterNode!);
      osc.start();

      this.droneOscs.push(osc);
      this.droneGains.push(voiceGain);
    });
  }

  private retuneDroneVoices() {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const now = ctx.currentTime;
    const preset = SOUNDSCAPE_PRESETS[this.currentPresetIndex];
    const base = preset.baseFreq;
    const ratios = CHAPTER_HARMONICS[this.currentTheme] || [1, 1.5, 2, 2.5, 3];

    this.droneOscs.forEach((osc, idx) => {
      const ratio = ratios[idx % ratios.length];
      const targetFreq = base * ratio * (idx === 0 ? 1 : idx === 1 ? 2 : idx === 2 ? 3 : 4);
      osc.frequency.setTargetAtTime(targetFreq, now, 1.8);
    });
  }

  private startCosmicNoise() {
    if (!this.ctx || !this.masterGain) return;
    try {
      const ctx = this.ctx;
      const bufferSize = ctx.sampleRate * 4; // 4 seconds of brown noise
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      let lastOut = 0.0;

      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        data[i] = (lastOut + 0.02 * white) / 1.02;
        lastOut = data[i];
        data[i] *= 3.5; // Gain compensation
      }

      this.noiseNode = ctx.createBufferSource();
      this.noiseNode.buffer = buffer;
      this.noiseNode.loop = true;

      const noiseFilter = ctx.createBiquadFilter();
      noiseFilter.type = 'lowpass';
      noiseFilter.frequency.setValueAtTime(140, ctx.currentTime);

      this.noiseGain = ctx.createGain();
      this.noiseGain.gain.setValueAtTime(0.04, ctx.currentTime);

      this.noiseNode.connect(noiseFilter);
      noiseFilter.connect(this.noiseGain);
      this.noiseGain.connect(this.masterGain);
      this.noiseNode.start();
    } catch (e) {
      console.warn('Cosmic noise generation skipped:', e);
    }
  }

  private startChimeLoop() {
    const scheduleNextChime = () => {
      if (!this.isRunning) return;
      // Random interval between 2.5 and 5.5 seconds for natural, organic cadence
      const delayMs = 2400 + Math.random() * 3200;
      this.chimeTimerId = window.setTimeout(() => {
        this.triggerChimeDrop();
        scheduleNextChime();
      }, delayMs);
    };

    scheduleNextChime();
  }

  /** Triggers a delicate glass/crystal bell chime representing quantum transitions */
  public triggerChimeDrop(isAffirmative: boolean = false) {
    if (!this.isRunning || !this.ctx || !this.masterGain) return;
    try {
      const ctx = this.ctx;
      const now = ctx.currentTime;
      const preset = SOUNDSCAPE_PRESETS[this.currentPresetIndex];
      const base = preset.baseFreq;

      // Select harmonic multiplier from the active scale
      const intervals = preset.scaleIntervals;
      const selectedInterval = intervals[Math.floor(Math.random() * intervals.length)];
      const octaveMult = isAffirmative ? 8 : Math.random() > 0.4 ? 8 : 12;
      const chimeFreq = base * selectedInterval * octaveMult;

      const chimeOsc = ctx.createOscillator();
      chimeOsc.type = 'sine';
      chimeOsc.frequency.setValueAtTime(chimeFreq, now);

      // Overtone shimmer (metallic bell harmonic)
      const overtoneOsc = ctx.createOscillator();
      overtoneOsc.type = 'triangle';
      overtoneOsc.frequency.setValueAtTime(chimeFreq * 2.76, now); // Inharmonic metallic ratio

      const chimeGain = ctx.createGain();
      const strikeVol = isAffirmative ? 0.07 : 0.035 + Math.random() * 0.03;
      chimeGain.gain.setValueAtTime(0.0001, now);
      chimeGain.gain.exponentialRampToValueAtTime(strikeVol, now + 0.02); // Sharp attack
      chimeGain.gain.exponentialRampToValueAtTime(0.0001, now + 2.8); // Long decaying ring

      const overtoneGain = ctx.createGain();
      overtoneGain.gain.setValueAtTime(strikeVol * 0.3, now);
      overtoneGain.gain.exponentialRampToValueAtTime(0.0001, now + 1.2);

      chimeOsc.connect(chimeGain);
      overtoneOsc.connect(overtoneGain);
      overtoneGain.connect(chimeGain);

      // Send to main mix AND spatial delay network
      chimeGain.connect(this.masterGain);
      if (this.delayNode) {
        chimeGain.connect(this.delayNode);
      }

      chimeOsc.start(now);
      overtoneOsc.start(now);
      chimeOsc.stop(now + 3.0);
      overtoneOsc.stop(now + 3.0);
    } catch (err) {
      // ignore
    }
  }

  public dispose() {
    this.stop();
    if (this.ctx && this.ctx.state !== 'closed') {
      try {
        this.ctx.close();
      } catch (e) {}
    }
  }
}

// Global Singleton Instance
export const beautyAudioEngine = new BeautyAmbientEngine();
