import React, { useState } from 'react';
import { Award, CheckCircle2, XCircle, RefreshCw, Sparkles, BookOpen, ChevronRight } from 'lucide-react';
import { PRACTICE_QUESTIONS, QuizQuestion } from '../../data/practice';
import { NavigationTab } from '../../types';

interface PracticeViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

export const PracticeView: React.FC<PracticeViewProps> = ({ onNavigate }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [answeredCount, setAnsweredCount] = useState<number>(0);

  const categories = [
    { id: 'all', label: 'All Topics' },
    { id: 'periodic-table', label: 'Periodic Table' },
    { id: 'quantum-orbitals', label: 'Quantum Orbitals' },
    { id: 'vsepr', label: 'VSEPR & Bonding' },
    { id: 'stoichiometry', label: 'Stoichiometry' },
    { id: 'thermodynamics', label: 'Thermodynamics' },
    { id: 'organic', label: 'Organic Chemistry' }
  ];

  const filteredQuestions = PRACTICE_QUESTIONS.filter((q) =>
    selectedCategory === 'all' ? true : q.category === selectedCategory
  );

  const activeQuestion: QuizQuestion | undefined = filteredQuestions[currentIdx] || filteredQuestions[0];

  const handleSelectOption = (idx: number) => {
    if (isAnswered) return;
    setSelectedOption(idx);
    setIsAnswered(true);
    setAnsweredCount((prev) => prev + 1);
    if (activeQuestion && idx === activeQuestion.correctAnswer) {
      setScore((prev) => prev + 1);
    }
  };

  const handleNextQuestion = () => {
    if (currentIdx < filteredQuestions.length - 1) {
      setCurrentIdx((prev) => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    }
  };

  const handleResetQuiz = () => {
    setCurrentIdx(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setScore(0);
    setAnsweredCount(0);
  };

  if (!activeQuestion) {
    return (
      <div className="max-w-4xl mx-auto p-8 text-center text-slate-400 font-mono">
        No questions found for this category.
      </div>
    );
  }

  const isCorrect = isAnswered && selectedOption === activeQuestion.correctAnswer;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-[#090d16]/90 border border-slate-800 backdrop-blur-md">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <span>Chemistry Mastery & Practice Lab</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 font-mono">
              MCQs & Conceptual Solvers
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Test and cement your understanding across quantum mechanics, thermodynamics, kinetics, and organic synthesis.
          </p>
        </div>

        {/* Score Card */}
        <div className="flex items-center gap-3 p-2 rounded-xl bg-slate-900 border border-slate-800 font-mono text-xs">
          <div className="px-3 py-1 rounded-lg bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 font-bold">
            Score: {score} / {answeredCount}
          </div>
          <div className="text-slate-400">
            Accuracy: {answeredCount > 0 ? Math.round((score / answeredCount) * 100) : 0}%
          </div>
          <button
            onClick={handleResetQuiz}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
            title="Reset Quiz"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Category selector */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => {
              setSelectedCategory(cat.id);
              setCurrentIdx(0);
              setSelectedOption(null);
              setIsAnswered(false);
            }}
            className={`px-3.5 py-1.5 rounded-xl font-mono text-xs transition-all whitespace-nowrap ${
              selectedCategory === cat.id
                ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/30'
                : 'bg-slate-900/80 text-slate-400 border border-slate-800 hover:text-white'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Main Question Card */}
      <div className="p-6 rounded-2xl bg-[#090d16]/95 border border-slate-800 backdrop-blur-md space-y-6">
        {/* Progress header */}
        <div className="flex items-center justify-between font-mono text-xs">
          <span className="text-cyan-400 font-bold">
            Question {currentIdx + 1} of {filteredQuestions.length}
          </span>
          <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 capitalize">
            {activeQuestion.difficulty} Difficulty
          </span>
        </div>

        {/* Question Text */}
        <div className="text-lg font-medium text-white leading-relaxed">
          {activeQuestion.question}
        </div>

        {/* Options List */}
        <div className="space-y-3">
          {activeQuestion.options.map((opt, idx) => {
            let optionStyles = 'bg-slate-900/70 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-850';

            if (isAnswered) {
              if (idx === activeQuestion.correctAnswer) {
                optionStyles = 'bg-emerald-950/80 border-emerald-500 text-emerald-200 font-bold ring-1 ring-emerald-500';
              } else if (idx === selectedOption) {
                optionStyles = 'bg-rose-950/80 border-rose-500 text-rose-200 font-bold';
              } else {
                optionStyles = 'bg-slate-900/40 border-slate-800/50 text-slate-500';
              }
            }

            return (
              <button
                key={idx}
                onClick={() => handleSelectOption(idx)}
                disabled={isAnswered}
                className={`w-full p-4 rounded-xl border text-left transition-all font-mono text-xs flex items-center justify-between ${optionStyles}`}
              >
                <div className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-slate-300">
                    {String.fromCharCode(65 + idx)}
                  </span>
                  <span className="text-sm font-sans">{opt}</span>
                </div>

                {isAnswered && idx === activeQuestion.correctAnswer && (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                )}
                {isAnswered && idx === selectedOption && idx !== activeQuestion.correctAnswer && (
                  <XCircle className="w-5 h-5 text-rose-400" />
                )}
              </button>
            );
          })}
        </div>

        {/* Explanation Card */}
        {isAnswered && (
          <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2 animate-fadeIn">
            <div className="flex items-center gap-2 font-mono text-xs">
              <span className={`font-bold ${isCorrect ? 'text-emerald-400' : 'text-rose-400'}`}>
                {isCorrect ? '✓ Correct Answer' : '✗ Incorrect Answer'}
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              {activeQuestion.explanation}
            </p>
          </div>
        )}

        {/* Navigation Actions */}
        <div className="flex items-center justify-between pt-2">
          <button
            onClick={() => onNavigate && onNavigate('ai-tutor')}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-950/70 border border-indigo-500/40 text-indigo-300 text-xs font-mono hover:bg-indigo-900/70 transition-all"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Ask AI to Explain Concept</span>
          </button>

          {currentIdx < filteredQuestions.length - 1 ? (
            <button
              onClick={handleNextQuestion}
              disabled={!isAnswered}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold text-xs disabled:opacity-30 disabled:cursor-not-allowed hover:shadow-lg hover:shadow-cyan-500/25 transition-all font-mono"
            >
              <span>Next Question</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={handleResetQuiz}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 text-white font-semibold text-xs hover:bg-emerald-500 transition-all font-mono"
            >
              <span>Restart Quiz</span>
              <RefreshCw className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
