import React, { useState } from 'react';
import { Orbit, Eye, Layers, Compass, Zap, Sparkles, RefreshCw, Sliders } from 'lucide-react';
import { OrbitalCanvas3D } from '../3d/OrbitalCanvas3D';
import { ORBITALS_DATA, SUBSHELL_LEVELS } from '../../data/orbitals';
import { OrbitalData, NavigationTab } from '../../types';
import { LatexRenderer } from '../common/LatexRenderer';

interface OrbitalAtlasViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

export const OrbitalAtlasView: React.FC<OrbitalAtlasViewProps> = ({ onNavigate }) => {
  const [selectedOrbital, setSelectedOrbital] = useState<OrbitalData>(ORBITALS_DATA[3]); // 2pz default
  const [selectedType, setSelectedType] = useState<'s' | 'p' | 'd' | 'f'>('p');
  const [probabilityThreshold, setProbabilityThreshold] = useState<number>(75);
  const [showNodalPlanes, setShowNodalPlanes] = useState<boolean>(true);
  const [showAxes, setShowAxes] = useState<boolean>(true);
  const [wireframe, setWireframe] = useState<boolean>(false);
  const [autoRotate, setAutoRotate] = useState<boolean>(true);

  const filteredOrbitals = ORBITALS_DATA.filter((orb) => orb.type === selectedType);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 rounded-3xl bg-white/[0.03] border border-white/10 backdrop-blur-xl shadow-xl">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <span>3D Quantum Orbital Atlas</span>
            <span className="text-xs px-3 py-0.5 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/30 font-mono">
              Ψ(r, θ, φ) Wave Functions
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1 font-light">
            Real Schrödinger atomic orbital isosurfaces with phase signs (+ Cyan / - Magenta) and quantum nodal surfaces.
          </p>
        </div>

        {/* Subshell Type Switcher */}
        <div className="flex items-center rounded-full bg-white/5 border border-white/10 p-1 font-mono text-xs backdrop-blur-md">
          {(['s', 'p', 'd', 'f'] as const).map((t) => (
            <button
              key={t}
              onClick={() => {
                setSelectedType(t);
                const first = ORBITALS_DATA.find((o) => o.type === t);
                if (first) setSelectedOrbital(first);
              }}
              className={`px-4 py-1.5 rounded-full transition-all ${
                selectedType === t
                  ? 'bg-white/20 text-white font-bold border border-white/20 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {t.toUpperCase()}-Orbitals
            </button>
          ))}
        </div>
      </div>

      {/* Main 3D Canvas & Controls Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 3D WebGL Canvas Viewport */}
        <div className="lg:col-span-2 rounded-3xl bg-white/[0.03] border border-white/10 p-6 flex flex-col justify-between backdrop-blur-2xl relative shadow-2xl">
          <div className="flex items-center justify-between z-10">
            <div className="flex items-center gap-2">
              <span className="text-base font-bold text-white font-mono">{selectedOrbital.name}</span>
              <span className="text-xs px-3 py-0.5 rounded-full bg-white/10 text-cyan-300 font-mono border border-white/10">
                {selectedOrbital.orientation}
              </span>
            </div>

            {/* Quick Canvas Toggles */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setAutoRotate(!autoRotate)}
                className={`p-2 rounded-full text-xs font-mono border transition-all ${
                  autoRotate ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' : 'bg-white/5 text-slate-400 border-white/10 hover:bg-white/10'
                }`}
                title="Toggle Auto-Rotation"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${autoRotate ? 'animate-spin-slow' : ''}`} />
              </button>
              <button
                onClick={() => setShowNodalPlanes(!showNodalPlanes)}
                className={`px-3 py-1 rounded-full text-xs font-mono border transition-all ${
                  showNodalPlanes ? 'bg-purple-500/20 text-purple-300 border-purple-500/40' : 'bg-white/5 text-slate-400 border-white/10 hover:bg-white/10'
                }`}
              >
                Nodal Planes
              </button>
              <button
                onClick={() => setShowAxes(!showAxes)}
                className={`px-3 py-1 rounded-full text-xs font-mono border transition-all ${
                  showAxes ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' : 'bg-white/5 text-slate-400 border-white/10 hover:bg-white/10'
                }`}
              >
                Axes
              </button>
              <button
                onClick={() => setWireframe(!wireframe)}
                className={`px-3 py-1 rounded-full text-xs font-mono border transition-all ${
                  wireframe ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' : 'bg-white/5 text-slate-400 border-white/10 hover:bg-white/10'
                }`}
              >
                Wireframe
              </button>
            </div>
          </div>

          {/* 3D WebGL Element */}
          <div className="w-full h-[440px] my-2">
            <OrbitalCanvas3D
              orbital={selectedOrbital}
              probabilityThreshold={probabilityThreshold}
              showNodalPlanes={showNodalPlanes}
              showAxes={showAxes}
              wireframe={wireframe}
              autoRotate={autoRotate}
            />
          </div>

          {/* Probability Density Slider */}
          <div className="flex items-center justify-between gap-4 p-3.5 rounded-2xl bg-white/5 border border-white/10 z-10 backdrop-blur-md">
            <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
              <Sliders className="w-3.5 h-3.5 text-cyan-400" />
              <span>Probability Isosurface:</span>
            </div>
            <div className="flex-1 max-w-xs flex items-center gap-3">
              <input
                type="range"
                min="10"
                max="99"
                value={probabilityThreshold}
                onChange={(e) => setProbabilityThreshold(parseInt(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
              <span className="text-xs font-mono text-cyan-400 w-10 text-right font-bold">
                {probabilityThreshold}%
              </span>
            </div>
            <div className="hidden sm:flex items-center gap-3 text-[11px] font-mono">
              <span className="flex items-center gap-1.5 text-cyan-400">
                <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,197,254,0.8)]" /> (+) Wave Phase
              </span>
              <span className="flex items-center gap-1.5 text-fuchsia-400">
                <span className="w-2 h-2 rounded-full bg-fuchsia-400 shadow-[0_0_8px_rgba(232,121,249,0.8)]" /> (-) Wave Phase
              </span>
            </div>
          </div>
        </div>

        {/* Quantum Orbital Detail & Subshell Selector Panel */}
        <div className="space-y-4">
          {/* Orbital Variations in this Subshell */}
          <div className="p-6 rounded-3xl bg-white/[0.03] border border-white/10 backdrop-blur-xl">
            <h3 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-3 font-semibold">
              Available {selectedType.toUpperCase()} Orbitals
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {filteredOrbitals.map((orb) => (
                <button
                  key={orb.id}
                  onClick={() => setSelectedOrbital(orb)}
                  className={`p-3 rounded-2xl border text-left transition-all font-mono text-xs ${
                    selectedOrbital.id === orb.id
                      ? 'bg-white/15 border-white/30 text-white shadow-md'
                      : 'bg-white/5 border-white/10 text-slate-400 hover:border-white/20 hover:text-white'
                  }`}
                >
                  <div className="font-bold text-white">{orb.name}</div>
                  <div className="text-[10px] text-slate-400 mt-0.5">m_l = {orb.ml}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Quantum Numbers & Node Analysis */}
          <div className="p-6 rounded-3xl bg-white/[0.03] border border-white/10 backdrop-blur-xl space-y-4">
            <h3 className="text-xs font-mono text-cyan-400 uppercase tracking-wider font-bold">
              Quantum Numbers & Nodal Properties
            </h3>

            <div className="grid grid-cols-2 gap-2.5 font-mono text-xs">
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="text-[10px] text-slate-400">PRINCIPAL (n)</div>
                <div className="text-base font-bold text-white mt-0.5">{selectedOrbital.n}</div>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="text-[10px] text-slate-400">AZIMUTHAL (l)</div>
                <div className="text-base font-bold text-white mt-0.5">{selectedOrbital.l}</div>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="text-[10px] text-slate-400">MAGNETIC (m_l)</div>
                <div className="text-base font-bold text-white mt-0.5">{selectedOrbital.ml}</div>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="text-[10px] text-slate-400">ANGULAR NODES (l)</div>
                <div className="text-base font-bold text-purple-400 mt-0.5">{selectedOrbital.angularNodes}</div>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="text-[10px] text-slate-400">RADIAL NODES (n-l-1)</div>
                <div className="text-base font-bold text-cyan-400 mt-0.5">{selectedOrbital.radialNodes}</div>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="text-[10px] text-slate-400">TOTAL NODES (n-1)</div>
                <div className="text-base font-bold text-emerald-400 mt-0.5">{selectedOrbital.totalNodes}</div>
              </div>
            </div>

            {/* LaTeX Radial Wave Function */}
            <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1.5 backdrop-blur-md">
              <div className="text-[10px] font-mono text-slate-400 uppercase">SCHRÖDINGER WAVE EQUATION</div>
              <div className="overflow-x-auto py-1 text-cyan-300">
                <LatexRenderer latex={selectedOrbital.formulaLatex} displayMode />
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed font-light">
              {selectedOrbital.description}
            </p>
          </div>
        </div>
      </div>

      {/* Subshell Hierarchy Table */}
      <div className="p-6 rounded-3xl bg-white/[0.03] border border-white/10 backdrop-blur-xl">
        <h3 className="text-sm font-bold text-white tracking-tight mb-4 font-mono flex items-center gap-2">
          <span>Aufbau Quantum Shell Electron Capacities (2n²)</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {SUBSHELL_LEVELS.map((lvl) => (
            <div key={lvl.n} className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2 backdrop-blur-md">
              <div className="flex items-center justify-between text-xs font-mono font-bold text-cyan-400">
                <span>Principal Shell n = {lvl.n}</span>
                <span className="text-slate-400">{2 * lvl.n * lvl.n} e⁻ max</span>
              </div>
              <div className="space-y-1.5 text-xs font-mono">
                {lvl.subshells.map((sub) => (
                  <div key={sub.symbol} className="flex items-center justify-between p-2 rounded-xl bg-white/5 border border-white/5 text-slate-300">
                    <span>{sub.symbol} ({sub.shape})</span>
                    <span className="text-cyan-300 font-bold">{sub.maxElectrons} e⁻</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
