import React, { useState, useMemo } from 'react';
import {
  Sparkles,
  Search,
  Atom,
  Grid3X3,
  Orbit,
  Boxes,
  Zap,
  FlaskConical,
  Scale,
  Calculator,
  Compass,
  Layers,
  Activity,
  Flame,
  Cpu,
  Radio,
  Eye,
  ArrowRight,
  ShieldAlert,
  ChevronRight,
  BarChart3,
  Dna,
  PieChart,
  Binary,
  Maximize2,
  ChevronDown,
  BookOpen,
  Filter,
  CheckCircle2,
  Share2,
  FlameKindling,
  Radiation,
  Waves,
  Boxes as CrystalIcon,
  Bot
} from 'lucide-react';
import { NavigationTab } from '../../types';

interface LabDirectoryViewProps {
  onNavigate: (tab: NavigationTab) => void;
}

export type ChemistryDisciplineId =
  | 'all'
  | 'inorganic'
  | 'atomic-quantum'
  | 'spectroscopy'
  | 'physical'
  | 'electrochemistry'
  | 'organic'
  | 'molecular-bonding'
  | 'stoichiometry'
  | 'analytical'
  | 'nuclear'
  | 'waves-radiation'
  | 'materials'
  | 'ai-knowledge'
  | 'calculators-tools';

export interface ChemistryDisciplineDefinition {
  id: ChemistryDisciplineId;
  name: string;
  shortName: string;
  icon: React.ComponentType<{ className?: string }>;
  accentColor: string;
  borderClass: string;
  bgClass: string;
  textClass: string;
  description: string;
  curriculumTopics: {
    topic: string;
    targetTab: NavigationTab;
    description: string;
  }[];
}

export interface LabCardInfo {
  id: NavigationTab;
  title: string;
  primaryCategory: ChemistryDisciplineId;
  categoryLabel: string;
  relatedDisciplines: { id: ChemistryDisciplineId; label: string }[];
  subtitle: string;
  simulates: string;
  curriculumBreadcrumb: string;
  toolCount: number;
  visCount: number;
  highlightColor: string;
  gradient: string;
  icon: React.ComponentType<{ className?: string }>;
  tags: string[];
}

export const CHEMISTRY_DISCIPLINES: ChemistryDisciplineDefinition[] = [
  {
    id: 'inorganic',
    name: '1. Inorganic Chemistry',
    shortName: 'Inorganic',
    icon: Grid3X3,
    accentColor: '#38bdf8',
    borderClass: 'border-sky-500/30 hover:border-sky-400',
    bgClass: 'bg-sky-500/10',
    textClass: 'text-sky-400',
    description: 'Periodic table, periodic trends, atomic properties, chemical classifications, and inorganic compounds.',
    curriculumTopics: [
      { topic: 'Periodic Table (118 IUPAC Elements)', targetTab: 'periodic-table', description: 'Complete 118-element matrix with atomic radii, electronegativity, and electron configurations' },
      { topic: 'Periodic Trends Engine', targetTab: 'periodic-table', description: 'Continuous SVG grapher for ionization energy, electron affinity, and atomic radius across periods/groups' },
      { topic: 'Inorganic Properties & Blocks', targetTab: 'periodic-table', description: 's, p, d, f blocks, transition metal oxidation states, and noble gas stability' }
    ]
  },
  {
    id: 'atomic-quantum',
    name: '2. Atomic & Quantum Chemistry',
    shortName: 'Atomic & Quantum',
    icon: Orbit,
    accentColor: '#a855f7',
    borderClass: 'border-purple-500/30 hover:border-purple-400',
    bgClass: 'bg-purple-500/10',
    textClass: 'text-purple-400',
    description: 'Atomic models, historical scattering, wavefunctions, orbitals, particle-in-a-box, and tunnelling.',
    curriculumTopics: [
      { topic: 'Atomic Structure & Historical Models', targetTab: 'atomic-structure', description: 'Dalton, Thomson plum-pudding, Rutherford alpha scattering, and Bohr quantized orbits' },
      { topic: 'Quantum Mechanics & Modern Physics', targetTab: 'quantum-lab', description: 'Particle-in-a-box ψ & |ψ|², wave packet barrier tunnelling, and photoelectric stopping potential' },
      { topic: '3D Quantum Orbital Atlas', targetTab: 'orbital-atlas', description: 'Exact Schrödinger wave equations for 1s, 2p, 3d, 4f subshells with radial/angular nodal planes' },
      { topic: 'Quantized Energy Transitions', targetTab: 'atomic-spectra', description: 'Bohr hydrogen energy levels, Rydberg series (Lyman, Balmer, Paschen), and photon emission' }
    ]
  },
  {
    id: 'spectroscopy',
    name: '3. Spectroscopy & Spectral Science',
    shortName: 'Spectroscopy',
    icon: Activity,
    accentColor: '#ec4899',
    borderClass: 'border-pink-500/30 hover:border-pink-400',
    bgClass: 'bg-pink-500/10',
    textClass: 'text-pink-400',
    description: 'Atomic emission, UV-Vis, FTIR, 1H-NMR, Quadrupole Mass Spectrometry, and XRD Bragg diffraction.',
    curriculumTopics: [
      { topic: 'Atomic Spectra & Emission Lab', targetTab: 'atomic-spectra', description: 'Rydberg formula solver, hydrogen spectral series, and analytical Bunsen flame test colorimetry' },
      { topic: 'UV-Vis Spectrophotometer', targetTab: 'spectroscopy-suite', description: 'Beer-Lambert absorbance law, molar absorptivity, chromophores, and λmax determination' },
      { topic: 'FTIR Functional Group Spectrometer', targetTab: 'spectroscopy-suite', description: 'Infrared stretching/bending frequencies, fingerprint region, and carbonyl/alcohol identification' },
      { topic: '1H-NMR Nuclear Magnetic Resonance', targetTab: 'spectroscopy-suite', description: 'Chemical shifts (ppm), TMS reference, n+1 spin-spin splitting, and peak integration' },
      { topic: 'Mass Spectrometry (Quadrupole m/z)', targetTab: 'spectroscopy-suite', description: 'Molecular ion peak [M]+, base peak, isotope distribution, and fragmentation patterns' },
      { topic: 'X-Ray Diffraction (XRD Bragg)', targetTab: 'spectroscopy-suite', description: 'Bragg law (nλ = 2d sinθ), lattice spacing, and crystalline 2θ diffractograms' }
    ]
  },
  {
    id: 'physical',
    name: '4. Physical Chemistry & Kinetics',
    shortName: 'Physical Chem',
    icon: Flame,
    accentColor: '#f97316',
    borderClass: 'border-orange-500/30 hover:border-orange-400',
    bgClass: 'bg-orange-500/10',
    textClass: 'text-orange-400',
    description: 'Thermodynamics, chemical kinetics, equilibrium, gas laws, calorimetry, and Le Chatelier principle.',
    curriculumTopics: [
      { topic: 'Thermodynamics & Reaction Energetics', targetTab: 'thermo-kinetics', description: 'Enthalpy (ΔH), Entropy (ΔS), Gibbs Free Energy (ΔG), and spontaneous phase equilibria' },
      { topic: 'Chemical Kinetics & Arrhenius Engine', targetTab: 'thermo-kinetics', description: '2D particle collision simulator, reaction order, rate laws, and activation energy (Ea)' },
      { topic: 'Chemical Equilibrium & Le Chatelier', targetTab: 'thermo-kinetics', description: 'Equilibrium constant (Kc/Kp), reaction quotient Q, and pressure/temperature disturbances' },
      { topic: 'Ideal & Real Gas Laws (van der Waals)', targetTab: 'physical-chem', description: 'PV=nRT, (P + a/V²)(V - b) = RT, and Maxwell-Boltzmann molecular speed distribution' },
      { topic: 'Calorimetry & Born-Haber Cycles', targetTab: 'thermo-kinetics', description: 'Constant-pressure & bomb calorimetry, lattice energy, and Hess law enthalpy summation' }
    ]
  },
  {
    id: 'electrochemistry',
    name: '5. Electrochemistry',
    shortName: 'Electrochemistry',
    icon: Zap,
    accentColor: '#10b981',
    borderClass: 'border-emerald-500/30 hover:border-emerald-400',
    bgClass: 'bg-emerald-500/10',
    textClass: 'text-emerald-400',
    description: 'Galvanic voltaic cells, Nernst equation, electrolytic cells, batteries, and redox potentials.',
    curriculumTopics: [
      { topic: 'Daniell Galvanic Voltaic Cell', targetTab: 'electro-solutions', description: 'Zn/Cu redox couple, salt bridge ion migration, electron flow, and standard cell EMF (E°cell)' },
      { topic: 'Nernst Equation & Concentration Cells', targetTab: 'electrochemistry-lab', description: 'Dynamic non-standard potential E = E° - (RT/nF)ln(Q) with live voltage readout' },
      { topic: 'Battery Chemistry & Li-Ion Cells', targetTab: 'electrochemistry-lab', description: 'Intercalation electrode mechanics, lead-acid charge/discharge, and fuel cell efficiency' },
      { topic: 'Electrolysis & Faraday Laws', targetTab: 'electrochemistry-lab', description: 'Quantitative electrodeposition, mass m = (ItM)/(zF), and overpotential kinetics' }
    ]
  },
  {
    id: 'organic',
    name: '6. Organic Chemistry',
    shortName: 'Organic Chem',
    icon: Dna,
    accentColor: '#c084fc',
    borderClass: 'border-purple-400/30 hover:border-purple-300',
    bgClass: 'bg-purple-400/10',
    textClass: 'text-purple-300',
    description: 'Reaction mechanisms, functional groups, stereochemistry, curved-arrow flow, and synthesis pathways.',
    curriculumTopics: [
      { topic: 'Organic Reaction Highway & Functional Groups', targetTab: 'organic-chem', description: 'Interconnected synthetic pathways spanning alkanes, alkenes, alkynes, halides, alcohols, aldehydes & acids' },
      { topic: 'Curved-Arrow Reaction Mechanisms', targetTab: 'organic-mechanisms', description: 'SN1, SN2, E1, E2, electrophilic addition, and electrophilic aromatic substitution (EAS)' },
      { topic: 'Stereochemistry & 3D Chirality', targetTab: 'organic-mechanisms', description: 'Cahn-Ingold-Prelog (R/S) stereocenters, enantiomers, diastereomers, and Fischer projections' },
      { topic: 'Advanced Organic Synthesis & Retrosynthesis', targetTab: 'advanced-organic', description: 'Multi-step disconnections, protecting groups, carbonyl condensations, and Diels-Alder cycloadditions' }
    ]
  },
  {
    id: 'molecular-bonding',
    name: '7. Molecular Chemistry & Chemical Bonding',
    shortName: 'Molecular & Bonding',
    icon: Boxes,
    accentColor: '#6366f1',
    borderClass: 'border-indigo-500/30 hover:border-indigo-400',
    bgClass: 'bg-indigo-500/10',
    textClass: 'text-indigo-400',
    description: '3D molecular CAD, Lewis structures, VSEPR geometry, orbital hybridization, and bond angles.',
    curriculumTopics: [
      { topic: '3D Molecular Simulator & CAD', targetTab: 'molecules-3d', description: 'Ball-and-stick, CPK space-filling models with live bond distance measurement and dipole vectors' },
      { topic: 'VSEPR Molecular Geometry & Hybridization', targetTab: 'vsepr-lab', description: 'AXnEm steric electron domain geometry from linear to octahedral, sp, sp², sp³, sp³d, sp³d²' },
      { topic: 'Chemical Bonding & Molecular Polarity', targetTab: 'molecules-3d', description: 'Electronegativity differences, dipole moments, ionic vs covalent character, and resonance' }
    ]
  },
  {
    id: 'stoichiometry',
    name: '8. Stoichiometry & Chemical Calculations',
    shortName: 'Stoichiometry',
    icon: Scale,
    accentColor: '#84cc16',
    borderClass: 'border-lime-500/30 hover:border-lime-400',
    bgClass: 'bg-lime-500/10',
    textClass: 'text-lime-400',
    description: 'Mole concept, matrix reaction balancing, limiting reagents, percent yield, and solution dilutions.',
    curriculumTopics: [
      { topic: 'Matrix Equation Balancing Engine', targetTab: 'stoichiometry', description: 'Linear algebra nullspace solver balancing complex chemical and redox equations instantly' },
      { topic: 'Limiting Reagent & Theoretical Yield', targetTab: 'stoichiometry', description: 'Stepwise mass-mole-mass stoichiometry, percent yield calculation, and excess reagent analysis' },
      { topic: 'Solution Concentration (Molarity & Dilution)', targetTab: 'stoichiometry', description: 'M1V1 = M2V2 dilution solver, molality, mole fraction, and parts per million (ppm)' }
    ]
  },
  {
    id: 'analytical',
    name: '9. Analytical Chemistry',
    shortName: 'Analytical Chem',
    icon: FlaskConical,
    accentColor: '#14b8a6',
    borderClass: 'border-teal-500/30 hover:border-teal-400',
    bgClass: 'bg-teal-500/10',
    textClass: 'text-teal-400',
    description: 'Titration curves, chromatography separation, buffer equilibria, and quantitative analysis.',
    curriculumTopics: [
      { topic: 'Acid-Base Titration & pH Curves', targetTab: 'analytical-lab', description: 'Drop-by-drop burette simulation, equivalence point determination, and indicator transition intervals' },
      { topic: 'Chromatography (TLC & Column Separation)', targetTab: 'analytical-materials', description: 'Stationary vs mobile phase migration, Retention Factor (Rf) calculations, and polarity sorting' },
      { topic: 'Buffer Solutions & Henderson-Hasselbalch', targetTab: 'analytical-lab', description: 'pH = pKa + log([A⁻]/[HA]) buffer capacity modeling against strong acid/base additions' }
    ]
  },
  {
    id: 'nuclear',
    name: '10. Nuclear Chemistry',
    shortName: 'Nuclear Chem',
    icon: Atom,
    accentColor: '#f43f5e',
    borderClass: 'border-rose-500/30 hover:border-rose-400',
    bgClass: 'bg-rose-500/10',
    textClass: 'text-rose-400',
    description: 'Radioactive decay, half-life kinetics, nuclear binding energy, fission, and fusion.',
    curriculumTopics: [
      { topic: 'Monte Carlo Radioactive Decay Counter', targetTab: 'nuclear-lab', description: 'Stochastic simulation of 10,000 nuclei with N(t) = N₀e^(-λt) exponential decay curve' },
      { topic: 'Alpha, Beta & Gamma Decay Modes', targetTab: 'nuclear-chemistry', description: 'Helium-4 emission, positron/electron conversion with neutrinos, and gamma photon release' },
      { topic: 'Nuclear Binding Energy Curve (Fe-56 Peak)', targetTab: 'nuclear-lab', description: 'Mass defect Δm = Zm_p + Nm_n - M_nucleus and binding energy per nucleon across all elements' },
      { topic: 'Nuclear Fission & Fusion Reactors', targetTab: 'nuclear-chemistry', description: 'U-235 neutron-induced chain reaction criticality and Deuterium-Tritium fusion energetics' }
    ]
  },
  {
    id: 'waves-radiation',
    name: '11. Waves & Physical Phenomena',
    shortName: 'Waves & Radiation',
    icon: Radio,
    accentColor: '#eab308',
    borderClass: 'border-yellow-500/30 hover:border-yellow-400',
    bgClass: 'bg-yellow-500/10',
    textClass: 'text-yellow-400',
    description: 'Wave harmonics, electromagnetic radiation, interference, diffraction, and EM spectrum.',
    curriculumTopics: [
      { topic: 'Traveling & Standing Waves Harmonics', targetTab: 'waves-radiation', description: 'Fundamental frequencies, harmonics (n=1,2,3,4), wave speed v=fλ, and nodal boundaries' },
      { topic: 'Two-Source Wave Interference & Superposition', targetTab: 'waves-radiation', description: 'Constructive/destructive phase interference patterns and spatial intensity distributions' },
      { topic: '3D Orthogonal EM Field Propagation', targetTab: 'waves-radiation', description: 'Coupled electric (E) and magnetic (B) transverse vectors propagating at speed of light c' },
      { topic: '7-Band Electromagnetic Spectrum Atlas', targetTab: 'waves-radiation', description: 'Radio, Microwave, Infrared, Visible, Ultraviolet, X-Ray, Gamma Ray with Planck-Einstein E=hν' }
    ]
  },
  {
    id: 'materials',
    name: '12. Materials & Solid-State Chemistry',
    shortName: 'Materials & Solid-State',
    icon: Layers,
    accentColor: '#06b6d4',
    borderClass: 'border-cyan-500/30 hover:border-cyan-400',
    bgClass: 'bg-cyan-500/10',
    textClass: 'text-cyan-400',
    description: 'Crystal structures, unit cells, packing efficiency, semiconductors, and green chemistry.',
    curriculumTopics: [
      { topic: '3D Unit Cells & Crystal Lattices', targetTab: 'analytical-materials', description: 'Simple Cubic (SC), Body-Centered Cubic (BCC), Face-Centered Cubic (FCC), and Hexagonal Close-Packed (HCP)' },
      { topic: 'Atomic Packing Efficiency & Coordination', targetTab: 'analytical-materials', description: '52.4% (SC), 68% (BCC), 74% (FCC/HCP) volume derivations with live atomic coordination counts' },
      { topic: '12 Principles of Green Chemistry & Sustainability', targetTab: 'analytical-materials', description: 'Atom economy, renewable feedstocks, catalysis, safer solvents, and degradation design' }
    ]
  },
  {
    id: 'ai-knowledge',
    name: '13. Chemistry AI & Knowledge System',
    shortName: 'ChemoBot AI',
    icon: Bot,
    accentColor: '#8b5cf6',
    borderClass: 'border-violet-500/30 hover:border-violet-400',
    bgClass: 'bg-violet-500/10',
    textClass: 'text-violet-400',
    description: 'ChemoBot AI tutor, stepwise reaction balancing, concept reasoning, and cross-lab assistance.',
    curriculumTopics: [
      { topic: 'ChemoBot Stepwise Chemistry Solver', targetTab: 'ai-tutor', description: 'Step-by-step mathematical derivations, balancing procedures, VSEPR hybridizations, and spectral reasoning' },
      { topic: 'Context-Aware Lab Intelligence Copilot', targetTab: 'ai-tutor', description: 'AI assistant trained on physical constants, IUPAC nomenclature, and reaction mechanisms' }
    ]
  },
  {
    id: 'calculators-tools',
    name: '14. Calculators & Scientific Tools',
    shortName: 'Calculators & Tools',
    icon: Calculator,
    accentColor: '#f59e0b',
    borderClass: 'border-amber-500/30 hover:border-amber-400',
    bgClass: 'bg-amber-500/10',
    textClass: 'text-amber-400',
    description: '24 Stepwise chemistry solvers, universal regression curve grapher, and formula library.',
    curriculumTopics: [
      { topic: 'Universal Chemistry Calculator (24 Solvers)', targetTab: 'universal-calc-graph', description: 'Input -> Formula -> Stepwise Solution pipeline across Gas Laws, Solutions, Thermo, Kinetics, and Quantum' },
      { topic: 'Scientific Multi-Dataset Curve Grapher', targetTab: 'universal-calc-graph', description: 'Linear, exponential, and polynomial regression curve fitting with exportable high-DPI plots' },
      { topic: 'Formula Vault & Fundamental Constants', targetTab: 'formula-vault', description: 'Interactive equations with SI constants (h, c, R, F, k_B, N_A) and unit dimensional converters' }
    ]
  }
];

export const LAB_DIRECTORY_CATALOG: LabCardInfo[] = [
  {
    id: 'lab-directory',
    title: 'Laboratory Hub & Map',
    primaryCategory: 'inorganic',
    categoryLabel: 'Navigation Hub',
    relatedDisciplines: [
      { id: 'inorganic', label: 'Inorganic' },
      { id: 'atomic-quantum', label: 'Atomic' },
      { id: 'organic', label: 'Organic' },
      { id: 'physical', label: 'Physical' }
    ],
    subtitle: 'Central Navigation Matrix',
    simulates: 'Multi-domain scientific laboratory network, curriculum knowledge map, and directory matrix',
    curriculumBreadcrumb: 'CHEMISPHERE 3D > Navigation Core > Knowledge Topology',
    toolCount: 14,
    visCount: 10,
    highlightColor: '#38bdf8',
    gradient: 'from-cyan-500/20 to-blue-600/10',
    icon: Compass,
    tags: ['Hub', 'Map', 'Navigation', 'Directory', 'Curriculum']
  },
  {
    id: 'periodic-table',
    title: 'Interactive Periodic Table & Trends Engine',
    primaryCategory: 'inorganic',
    categoryLabel: '1. Inorganic Chemistry',
    relatedDisciplines: [
      { id: 'inorganic', label: 'Inorganic' },
      { id: 'atomic-quantum', label: 'Atomic & Quantum' },
      { id: 'physical', label: 'Physical' }
    ],
    subtitle: '118 Elements & Continuous Graph Engine',
    simulates: 'Full interactive 118-element periodic grid, 12-property SVG trend graph generator with dual comparison & playhead sweep',
    curriculumBreadcrumb: 'INORGANIC > Periodic Law > 118 IUPAC Elements & Trend Engine',
    toolCount: 18,
    visCount: 12,
    highlightColor: '#38bdf8',
    gradient: 'from-cyan-500/20 to-blue-600/10',
    icon: Grid3X3,
    tags: ['Periodic Table', '118 Elements', 'Trends', 'Electronegativity', 'Ionization Energy', 'Atomic Radius']
  },
  {
    id: 'atomic-structure',
    title: 'Atomic Structure & Historical Models',
    primaryCategory: 'atomic-quantum',
    categoryLabel: '2. Atomic & Quantum',
    relatedDisciplines: [
      { id: 'atomic-quantum', label: 'Atomic & Quantum' },
      { id: 'inorganic', label: 'Inorganic' },
      { id: 'spectroscopy', label: 'Spectroscopy' }
    ],
    subtitle: 'Dalton to Quantum Cloud',
    simulates: 'Dalton solid sphere, Thomson plum-pudding, Rutherford gold-foil alpha scattering, Bohr orbits, and wave mechanical probability cloud',
    curriculumBreadcrumb: 'ATOMIC & QUANTUM > Historical Evolution > Rutherford Scattering & Bohr Shells',
    toolCount: 8,
    visCount: 6,
    highlightColor: '#eab308',
    gradient: 'from-yellow-500/20 to-amber-600/10',
    icon: Zap,
    tags: ['Rutherford', 'Thomson', 'Bohr', 'Alpha Scattering', 'History', 'Gold Foil']
  },
  {
    id: 'quantum-lab',
    title: 'Quantum Mechanics & Modern Physics Lab',
    primaryCategory: 'atomic-quantum',
    categoryLabel: '2. Atomic & Quantum',
    relatedDisciplines: [
      { id: 'atomic-quantum', label: 'Atomic & Quantum' },
      { id: 'waves-radiation', label: 'Waves & Radiation' },
      { id: 'spectroscopy', label: 'Spectroscopy' }
    ],
    subtitle: 'Particle-in-a-Box, Tunnelling & Photoelectric',
    simulates: 'Infinite square well ψ & |ψ|², wave packet barrier tunnelling, photoelectric effect I-V curves, de Broglie wavelength, and Heisenberg uncertainty',
    curriculumBreadcrumb: 'ATOMIC & QUANTUM > Quantum Physics > Wavefunctions, Tunnelling & Photoelectric',
    toolCount: 12,
    visCount: 8,
    highlightColor: '#38bdf8',
    gradient: 'from-cyan-500/20 to-teal-600/10',
    icon: Cpu,
    tags: ['Particle-in-a-Box', 'Tunnelling', 'Photoelectric', 'de Broglie', 'Heisenberg', 'Schrödinger']
  },
  {
    id: 'orbital-atlas',
    title: '3D Quantum Orbital Atlas',
    primaryCategory: 'atomic-quantum',
    categoryLabel: '2. Atomic & Quantum',
    relatedDisciplines: [
      { id: 'atomic-quantum', label: 'Atomic & Quantum' },
      { id: 'molecular-bonding', label: 'Molecular & Bonding' },
      { id: 'inorganic', label: 'Inorganic' }
    ],
    subtitle: 'Hydrogenic Spherical Harmonics',
    simulates: '3D iso-surface point clouds for 1s, 2p, 3d, 4f orbitals with radial and angular nodal planes derived from exact hydrogenic wave equations',
    curriculumBreadcrumb: 'ATOMIC & QUANTUM > Orbitals > 3D Spherical Harmonics (s, p, d, f)',
    toolCount: 8,
    visCount: 8,
    highlightColor: '#06b6d4',
    gradient: 'from-cyan-500/20 to-blue-600/10',
    icon: Orbit,
    tags: ['Orbitals', 'Quantum Numbers', 'Hydrogenic', '3D Spherical Harmonics', 'Nodes', 'Wavefunctions']
  },
  {
    id: 'spectroscopy-suite',
    title: 'Spectroscopy Suite (UV-Vis, FTIR, NMR, MS, XRD)',
    primaryCategory: 'spectroscopy',
    categoryLabel: '3. Spectroscopy',
    relatedDisciplines: [
      { id: 'spectroscopy', label: 'Spectroscopy' },
      { id: 'analytical', label: 'Analytical Chem' },
      { id: 'organic', label: 'Organic Chem' },
      { id: 'materials', label: 'Materials' }
    ],
    subtitle: '5 Analytical Spectrometers',
    simulates: 'Beer-Lambert UV-Vis, FTIR functional groups, 1H NMR chemical shifts & splitting, Quadrupole Mass Spec m/z, XRD Bragg diffraction',
    curriculumBreadcrumb: 'SPECTROSCOPY > Multi-Instrument Suite > UV-Vis, FTIR, 1H-NMR, MS, XRD',
    toolCount: 16,
    visCount: 10,
    highlightColor: '#ec4899',
    gradient: 'from-pink-500/20 to-purple-600/10',
    icon: Activity,
    tags: ['UV-Vis', 'IR', 'FTIR', 'NMR', 'Mass Spec', 'XRD', 'Bragg', 'Spectroscopy']
  },
  {
    id: 'atomic-spectra',
    title: 'Atomic Spectra & Emission Lab',
    primaryCategory: 'spectroscopy',
    categoryLabel: '3. Spectroscopy',
    relatedDisciplines: [
      { id: 'spectroscopy', label: 'Spectroscopy (Primary)' },
      { id: 'atomic-quantum', label: 'Atomic & Quantum' },
      { id: 'analytical', label: 'Analytical Chem' }
    ],
    subtitle: 'Rydberg Transitions & Flame Test',
    simulates: 'Bohr hydrogen quantized transitions (Lyman, Balmer, Paschen), photon emission wavelength 1/λ = R_H(1/n1² - 1/n2²), and analytical Bunsen flame test colorimetry',
    curriculumBreadcrumb: 'SPECTROSCOPY > Atomic Emission > Rydberg Hydrogen Series & Flame Tests',
    toolCount: 9,
    visCount: 6,
    highlightColor: '#c084fc',
    gradient: 'from-purple-500/20 to-indigo-600/10',
    icon: Sparkles,
    tags: ['Spectra', 'Bohr', 'Balmer', 'Lyman', 'Flame Test', 'Photons', 'Rydberg']
  },
  {
    id: 'thermo-kinetics',
    title: 'Thermodynamics, Kinetics & Equilibrium Lab',
    primaryCategory: 'physical',
    categoryLabel: '4. Physical Chemistry',
    relatedDisciplines: [
      { id: 'physical', label: 'Physical Chem' },
      { id: 'calculators-tools', label: 'Calculators & Tools' },
      { id: 'electrochemistry', label: 'Electrochemistry' }
    ],
    subtitle: 'Cycles, Calorimetry, Rates & Le Chatelier',
    simulates: 'Real-time ΔU/ΔH/ΔS/ΔG engine, P-V Carnot diagrams, bomb calorimetry, 2D particle collision kinetics, Arrhenius plots, Haber equilibrium shifts',
    curriculumBreadcrumb: 'PHYSICAL > Thermodynamics & Kinetics > ΔG, Arrhenius, Calorimetry & Equilibrium',
    toolCount: 16,
    visCount: 9,
    highlightColor: '#f97316',
    gradient: 'from-orange-500/20 to-red-600/10',
    icon: Flame,
    tags: ['Thermodynamics', 'Calorimetry', 'Carnot', 'Kinetics', 'Arrhenius', 'Le Chatelier', 'Equilibrium']
  },
  {
    id: 'physical-chem',
    title: 'Physical Chemistry Engine & Gas Laws',
    primaryCategory: 'physical',
    categoryLabel: '4. Physical Chemistry',
    relatedDisciplines: [
      { id: 'physical', label: 'Physical Chem' },
      { id: 'stoichiometry', label: 'Calculations' },
      { id: 'calculators-tools', label: 'Calculators & Tools' }
    ],
    subtitle: 'PV=nRT, van der Waals & Raoult Law',
    simulates: 'Ideal gas container, van der Waals non-ideal equation of state, Maxwell-Boltzmann velocity distributions, and Raoult colligative vapor pressures',
    curriculumBreadcrumb: 'PHYSICAL > States of Matter > Gas Laws, van der Waals & Solutions',
    toolCount: 10,
    visCount: 6,
    highlightColor: '#ea580c',
    gradient: 'from-orange-600/20 to-amber-600/10',
    icon: FlaskConical,
    tags: ['Gas Laws', 'van der Waals', 'Maxwell-Boltzmann', 'Raoult', 'Colligative', 'Physical']
  },
  {
    id: 'electro-solutions',
    title: 'Electrochemistry, Acid-Base & Solutions Lab',
    primaryCategory: 'electrochemistry',
    categoryLabel: '5. Electrochemistry',
    relatedDisciplines: [
      { id: 'electrochemistry', label: 'Electrochemistry (Primary)' },
      { id: 'physical', label: 'Physical Chem' },
      { id: 'analytical', label: 'Analytical Chem' }
    ],
    subtitle: 'Daniell Cell, Burette Titration & PV=nRT',
    simulates: 'Galvanic cell electron flow with live Nernst equation, drop-by-drop burette titration curve, 3D Maxwell-Boltzmann gas container, P-T phase diagrams',
    curriculumBreadcrumb: 'ELECTROCHEMISTRY > Voltaic Cells > Daniell Cell & Nernst Potential',
    toolCount: 16,
    visCount: 9,
    highlightColor: '#10b981',
    gradient: 'from-emerald-500/20 to-teal-600/10',
    icon: Zap,
    tags: ['Galvanic Cell', 'Nernst', 'Titration', 'pH', 'Gas Laws', 'Phase Diagram', 'Redox']
  },
  {
    id: 'electrochemistry-lab',
    title: 'Electrochemistry & Battery Lab',
    primaryCategory: 'electrochemistry',
    categoryLabel: '5. Electrochemistry',
    relatedDisciplines: [
      { id: 'electrochemistry', label: 'Electrochemistry' },
      { id: 'materials', label: 'Materials' },
      { id: 'physical', label: 'Physical Chem' }
    ],
    subtitle: 'Nernst Equation & Li-Ion Batteries',
    simulates: 'Galvanic redox couple potentials, Nernst non-standard voltage adjustments, and Lithium-ion battery intercalation cathode/anode mechanics',
    curriculumBreadcrumb: 'ELECTROCHEMISTRY > Energy Storage > Nernst Solver & Battery Chemistry',
    toolCount: 10,
    visCount: 6,
    highlightColor: '#059669',
    gradient: 'from-emerald-600/20 to-cyan-600/10',
    icon: Zap,
    tags: ['Batteries', 'Li-Ion', 'Nernst', 'Redox', 'Galvanic', 'Electrochemistry']
  },
  {
    id: 'organic-mechanisms',
    title: 'Organic Mechanisms & Stereochemistry Lab',
    primaryCategory: 'organic',
    categoryLabel: '6. Organic Chemistry',
    relatedDisciplines: [
      { id: 'organic', label: 'Organic Chem' },
      { id: 'molecular-bonding', label: 'Molecular & Bonding' },
      { id: 'spectroscopy', label: 'Spectroscopy' }
    ],
    subtitle: 'Curved Arrow Electron Flow & 3D Chirality',
    simulates: 'SN1/SN2/E1/E2 & electrophilic addition mechanisms, 3D R/S stereocenters, Fischer/Newman projections, aromaticity Frost circles, polymerization',
    curriculumBreadcrumb: 'ORGANIC > Reaction Mechanisms > Curved Arrow Flow & Stereochemistry',
    toolCount: 14,
    visCount: 8,
    highlightColor: '#a855f7',
    gradient: 'from-purple-500/20 to-pink-600/10',
    icon: Dna,
    tags: ['SN1', 'SN2', 'E1', 'E2', 'Stereochemistry', 'Chirality', 'R/S', 'Aromaticity', 'Polymers']
  },
  {
    id: 'organic-chem',
    title: 'Organic Reaction Highway & Functional Groups',
    primaryCategory: 'organic',
    categoryLabel: '6. Organic Chemistry',
    relatedDisciplines: [
      { id: 'organic', label: 'Organic Chem' },
      { id: 'spectroscopy', label: 'Spectroscopy' },
      { id: 'inorganic', label: 'Inorganic' }
    ],
    subtitle: 'IUPAC Synthesis Pathways',
    simulates: 'Multi-step organic transformations across alkanes, alkenes, alkynes, halides, alcohols, aldehydes, ketones, and carboxylic acids',
    curriculumBreadcrumb: 'ORGANIC > Synthetic Highway > Functional Group Conversions & IUPAC',
    toolCount: 12,
    visCount: 6,
    highlightColor: '#8b5cf6',
    gradient: 'from-violet-500/20 to-purple-600/10',
    icon: Sparkles,
    tags: ['Organic Highway', 'IUPAC', 'Functional Groups', 'Synthesis', 'Reactions']
  },
  {
    id: 'advanced-organic',
    title: 'Advanced Organic Synthesis & Retrosynthesis',
    primaryCategory: 'organic',
    categoryLabel: '6. Organic Chemistry',
    relatedDisciplines: [
      { id: 'organic', label: 'Organic Chem' },
      { id: 'analytical', label: 'Analytical Chem' },
      { id: 'spectroscopy', label: 'Spectroscopy' }
    ],
    subtitle: 'Retrosynthetic Disconnections & Named Reactions',
    simulates: 'Retrosynthetic analysis, protecting group strategies, Diels-Alder cycloadditions, and complex multi-step organic total synthesis',
    curriculumBreadcrumb: 'ORGANIC > Advanced Synthesis > Retrosynthesis & Complex Transformations',
    toolCount: 10,
    visCount: 6,
    highlightColor: '#9333ea',
    gradient: 'from-purple-600/20 to-indigo-600/10',
    icon: Sparkles,
    tags: ['Retrosynthesis', 'Diels-Alder', 'Synthesis', 'Named Reactions', 'Carbonyl']
  },
  {
    id: 'molecules-3d',
    title: '3D Molecular Simulator & ChemBond',
    primaryCategory: 'molecular-bonding',
    categoryLabel: '7. Molecular & Bonding',
    relatedDisciplines: [
      { id: 'molecular-bonding', label: 'Molecular & Bonding' },
      { id: 'organic', label: 'Organic Chem' },
      { id: 'inorganic', label: 'Inorganic Chem' },
      { id: 'atomic-quantum', label: 'Atomic & Quantum' }
    ],
    subtitle: 'Interactive 3D Geometry & Bond Angles',
    simulates: 'Interactive 3D ball-and-stick molecules, geometry measurements, dipole vectors, and electrostatic potential surfaces',
    curriculumBreadcrumb: 'MOLECULAR & BONDING > 3D Molecular CAD > Ball-and-Stick & Dipole Vectors',
    toolCount: 10,
    visCount: 7,
    highlightColor: '#6366f1',
    gradient: 'from-indigo-500/20 to-purple-600/10',
    icon: Boxes,
    tags: ['3D Molecules', 'Ball-and-Stick', 'Geometry', 'Dipole', 'Bond Length', 'Polarity']
  },
  {
    id: 'vsepr-lab',
    title: 'VSEPR Molecular Geometry & Hybridization',
    primaryCategory: 'molecular-bonding',
    categoryLabel: '7. Molecular & Bonding',
    relatedDisciplines: [
      { id: 'molecular-bonding', label: 'Molecular & Bonding' },
      { id: 'inorganic', label: 'Inorganic Chem' },
      { id: 'atomic-quantum', label: 'Atomic & Quantum' }
    ],
    subtitle: 'Electron Domain Repulsion',
    simulates: 'AXnEm steric electron domain geometry from linear to octahedral, sp, sp2, sp3, sp3d, sp3d2 hybridizations with lone-pair angle distortions',
    curriculumBreadcrumb: 'MOLECULAR & BONDING > VSEPR Theory > Steric Repulsion & Hybridization',
    toolCount: 8,
    visCount: 5,
    highlightColor: '#0ea5e9',
    gradient: 'from-sky-500/20 to-cyan-600/10',
    icon: Atom,
    tags: ['VSEPR', 'Steric Number', 'Hybridization', 'Lone Pairs', 'Bond Angles']
  },
  {
    id: 'stoichiometry',
    title: 'Stoichiometry & Reaction Balancing Engine',
    primaryCategory: 'stoichiometry',
    categoryLabel: '8. Stoichiometry',
    relatedDisciplines: [
      { id: 'stoichiometry', label: 'Stoichiometry' },
      { id: 'inorganic', label: 'Inorganic Chem' },
      { id: 'calculators-tools', label: 'Calculators & Tools' }
    ],
    subtitle: 'Matrix Balancing & Limiting Reagents',
    simulates: 'Linear algebra equation balancing, mole-to-mass conversions, limiting reagents, percent yield, and solution dilutions',
    curriculumBreadcrumb: 'STOICHIOMETRY > Quantitative Reactions > Matrix Balancer & Yield Engine',
    toolCount: 10,
    visCount: 5,
    highlightColor: '#84cc16',
    gradient: 'from-lime-500/20 to-green-600/10',
    icon: Scale,
    tags: ['Stoichiometry', 'Balancing', 'Limiting Reagent', 'Moles', 'Yield', 'Dilutions']
  },
  {
    id: 'analytical-materials',
    title: 'Analytical Chromatography & Materials Lab',
    primaryCategory: 'analytical',
    categoryLabel: '9. Analytical & Materials',
    relatedDisciplines: [
      { id: 'analytical', label: 'Analytical Chem' },
      { id: 'materials', label: 'Materials & Solid-State' },
      { id: 'spectroscopy', label: 'Spectroscopy' }
    ],
    subtitle: 'TLC, Solid State Crystals & Green Chemistry',
    simulates: 'TLC & Column chromatography Rf separation, 3D SC/BCC/FCC/HCP unit cells & packing efficiency, 12 Principles of Green Chemistry, everyday chemistry',
    curriculumBreadcrumb: 'ANALYTICAL & MATERIALS > Separation & Solid-State > TLC, Crystals & Green Chem',
    toolCount: 14,
    visCount: 8,
    highlightColor: '#14b8a6',
    gradient: 'from-teal-500/20 to-emerald-600/10',
    icon: Layers,
    tags: ['Chromatography', 'TLC', 'Rf', 'Solid State', 'Crystals', 'BCC', 'FCC', 'Green Chemistry']
  },
  {
    id: 'analytical-lab',
    title: 'Analytical Chemistry & Environmental Lab',
    primaryCategory: 'analytical',
    categoryLabel: '9. Analytical Chemistry',
    relatedDisciplines: [
      { id: 'analytical', label: 'Analytical Chem' },
      { id: 'electrochemistry', label: 'Electrochemistry' },
      { id: 'physical', label: 'Physical Chem' }
    ],
    subtitle: 'Titration, Buffers & Quantitative Analysis',
    simulates: 'Acid-base titration curves, Henderson-Hasselbalch buffer calculations, HPLC separation columns, and environmental water quality metrics',
    curriculumBreadcrumb: 'ANALYTICAL > Quantitative Wet Lab > Titration Curves & Buffer Capacity',
    toolCount: 11,
    visCount: 7,
    highlightColor: '#0d9488',
    gradient: 'from-teal-600/20 to-cyan-600/10',
    icon: FlaskConical,
    tags: ['Titration', 'Buffers', 'pH', 'Henderson-Hasselbalch', 'HPLC', 'Quantitative']
  },
  {
    id: 'nuclear-lab',
    title: 'Nuclear Chemistry & Decay Lab',
    primaryCategory: 'nuclear',
    categoryLabel: '10. Nuclear Chemistry',
    relatedDisciplines: [
      { id: 'nuclear', label: 'Nuclear Chem' },
      { id: 'atomic-quantum', label: 'Atomic & Quantum' },
      { id: 'waves-radiation', label: 'Radiation' }
    ],
    subtitle: 'Stochastic Half-Life, Binding Energy & Fission',
    simulates: '10,000 active nuclei stochastic decay simulation, alpha/beta/gamma emission mechanics, Fe-56 binding energy curve, Uranium-235 chain fission',
    curriculumBreadcrumb: 'NUCLEAR > Nuclear Physics > Monte Carlo Decay, Fe-56 Binding & Fission',
    toolCount: 12,
    visCount: 8,
    highlightColor: '#f43f5e',
    gradient: 'from-rose-500/20 to-red-600/10',
    icon: Atom,
    tags: ['Radioactive Decay', 'Half-Life', 'Alpha', 'Beta', 'Gamma', 'Binding Energy', 'Fission', 'Fusion']
  },
  {
    id: 'nuclear-chemistry',
    title: 'Nuclear Reactions & Cosmic Nucleosynthesis',
    primaryCategory: 'nuclear',
    categoryLabel: '10. Nuclear Chemistry',
    relatedDisciplines: [
      { id: 'nuclear', label: 'Nuclear Chem' },
      { id: 'inorganic', label: 'Inorganic' },
      { id: 'atomic-quantum', label: 'Atomic' }
    ],
    subtitle: 'Stellar Fusion & Isotope Decay Chains',
    simulates: 'Hydrogen burning p-p chain, CNO cycle, Uranium decay series, and isotope stability band (N/Z ratio)',
    curriculumBreadcrumb: 'NUCLEAR > Stellar Chemistry > Cosmic Nucleosynthesis & Decay Series',
    toolCount: 9,
    visCount: 5,
    highlightColor: '#e11d48',
    gradient: 'from-rose-600/20 to-pink-600/10',
    icon: Atom,
    tags: ['Stellar Fusion', 'Nucleosynthesis', 'CNO Cycle', 'Isotopes', 'Half-Life']
  },
  {
    id: 'waves-radiation',
    title: 'Waves & Electromagnetic Radiation Lab',
    primaryCategory: 'waves-radiation',
    categoryLabel: '11. Waves & Radiation',
    relatedDisciplines: [
      { id: 'waves-radiation', label: 'Waves & Radiation' },
      { id: 'spectroscopy', label: 'Spectroscopy' },
      { id: 'atomic-quantum', label: 'Quantum' }
    ],
    subtitle: 'Harmonics, Interference & EM Spectrum',
    simulates: 'Traveling/standing waves, 2-source wave interference, 3D orthogonal E-B fields, 7-band EM spectrum atlas, Planck solver',
    curriculumBreadcrumb: 'WAVES & RADIATION > Wave Mechanics > EM Spectrum, Interference & E-B Fields',
    toolCount: 10,
    visCount: 6,
    highlightColor: '#eab308',
    gradient: 'from-amber-500/20 to-yellow-600/10',
    icon: Radio,
    tags: ['Waves', 'Harmonics', 'EM Spectrum', 'Interference', 'Planck-Einstein', 'E-B Fields']
  },
  {
    id: 'ai-tutor',
    title: 'ChemoBot AI Laboratory Intelligence Copilot',
    primaryCategory: 'ai-knowledge',
    categoryLabel: '13. Chemistry AI',
    relatedDisciplines: [
      { id: 'ai-knowledge', label: 'AI Intelligence' },
      { id: 'calculators-tools', label: 'Tools' },
      { id: 'inorganic', label: 'All Disciplines' }
    ],
    subtitle: 'AI Research Assistant & Live Tutor',
    simulates: 'Real-time scientific reasoning, equation solving, concept analysis, and automated cross-lab navigation grounded in chemical principles',
    curriculumBreadcrumb: 'AI INTELLIGENCE > ChemoBot Core > Stepwise Chemistry Problem Solver',
    toolCount: 12,
    visCount: 5,
    highlightColor: '#8b5cf6',
    gradient: 'from-purple-500/20 to-indigo-600/10',
    icon: Bot,
    tags: ['AI Tutor', 'ChemoBot', 'Gemini', 'Reasoning', 'Assistant', 'Stepwise']
  },
  {
    id: 'universal-calc-graph',
    title: 'Universal Chemistry Calculator & Scientific Grapher',
    primaryCategory: 'calculators-tools',
    categoryLabel: '14. Calculators & Tools',
    relatedDisciplines: [
      { id: 'calculators-tools', label: 'Calculators & Tools' },
      { id: 'physical', label: 'Physical Chem' },
      { id: 'stoichiometry', label: 'Stoichiometry' }
    ],
    subtitle: '24 Stepwise Solvers & Multi-Dataset Plotter',
    simulates: 'Complete Input -> Formula -> Substitution -> Stepwise Solution pipeline across 24 domains, regression curve fitting',
    curriculumBreadcrumb: 'CALCULATORS & TOOLS > Universal Computational Core > 24 Solvers & Plotter',
    toolCount: 24,
    visCount: 10,
    highlightColor: '#f59e0b',
    gradient: 'from-amber-500/20 to-orange-600/10',
    icon: Calculator,
    tags: ['Calculator', 'Stepwise Solvers', 'Scientific Grapher', 'Regression', 'Data Plotting']
  },
  {
    id: 'formula-vault',
    title: 'Chemistry Formula Vault & Physical Constants',
    primaryCategory: 'calculators-tools',
    categoryLabel: '14. Calculators & Tools',
    relatedDisciplines: [
      { id: 'calculators-tools', label: 'Calculators & Tools' },
      { id: 'physical', label: 'Physical Chem' },
      { id: 'atomic-quantum', label: 'Quantum' }
    ],
    subtitle: 'Universal Reference Library',
    simulates: 'Formulas across Thermodynamics, Atomic Physics, Solutions, Electrochemistry with interactive inputs and SI fundamental constants',
    curriculumBreadcrumb: 'CALCULATORS & TOOLS > Formula Library > Constants & SI Reference',
    toolCount: 16,
    visCount: 6,
    highlightColor: '#d97706',
    gradient: 'from-amber-600/20 to-yellow-600/10',
    icon: Binary,
    tags: ['Formulas', 'Constants', 'SI Units', 'Equations', 'Reference']
  },
  {
    id: 'beauty-of-chemistry',
    title: 'The Beauty of Chemistry (Exhibition)',
    primaryCategory: 'atomic-quantum',
    categoryLabel: 'Exhibition & Aesthetics',
    relatedDisciplines: [
      { id: 'atomic-quantum', label: 'Cosmic & Atomic' },
      { id: 'molecular-bonding', label: 'Crystals & Forms' },
      { id: 'spectroscopy', label: 'Spectral Harmony' }
    ],
    subtitle: '13-Chapter Cinematic Scientific Odyssey',
    simulates: 'Cosmic nucleosynthesis, molecular symmetry, crystalline acoustic harmonics, and the profound aesthetic order of the chemical universe',
    curriculumBreadcrumb: 'EXHIBITION > The Beauty of Chemistry > 13 Master Audio-Visual Chapters',
    toolCount: 13,
    visCount: 13,
    highlightColor: '#ec4899',
    gradient: 'from-pink-500/20 to-purple-600/10',
    icon: Sparkles,
    tags: ['Beauty', 'Exhibition', 'Cosmic', 'Harmonics', 'Symmetry', 'Cinematic']
  }
];

export const LabDirectoryView: React.FC<LabDirectoryViewProps> = ({ onNavigate }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDiscipline, setSelectedDiscipline] = useState<ChemistryDisciplineId>('all');
  const [viewMode, setViewMode] = useState<'curriculum-tree' | 'cards' | '3d-map'>('curriculum-tree');
  const [expandedDisciplines, setExpandedDisciplines] = useState<Record<string, boolean>>({
    inorganic: true,
    'atomic-quantum': true,
    spectroscopy: true,
    physical: true,
    electrochemistry: true,
    organic: true,
    'molecular-bonding': true
  });

  const toggleDiscipline = (id: string) => {
    setExpandedDisciplines((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const expandAll = () => {
    const all: Record<string, boolean> = {};
    CHEMISTRY_DISCIPLINES.forEach((d) => {
      all[d.id] = true;
    });
    setExpandedDisciplines(all);
  };

  const collapseAll = () => {
    setExpandedDisciplines({});
  };

  const filteredLabs = useMemo(() => {
    return LAB_DIRECTORY_CATALOG.filter((lab) => {
      const matchesDiscipline =
        selectedDiscipline === 'all' ||
        lab.primaryCategory === selectedDiscipline ||
        lab.relatedDisciplines.some((r) => r.id === selectedDiscipline);

      const q = searchQuery.toLowerCase().trim();
      if (!q) return matchesDiscipline;

      const matchesSearch =
        lab.title.toLowerCase().includes(q) ||
        lab.subtitle.toLowerCase().includes(q) ||
        lab.simulates.toLowerCase().includes(q) ||
        lab.curriculumBreadcrumb.toLowerCase().includes(q) ||
        lab.tags.some((t) => t.toLowerCase().includes(q));

      return matchesDiscipline && matchesSearch;
    });
  }, [searchQuery, selectedDiscipline]);

  const totalTools = useMemo(() => LAB_DIRECTORY_CATALOG.reduce((sum, l) => sum + l.toolCount, 0), []);
  const totalVis = useMemo(() => LAB_DIRECTORY_CATALOG.reduce((sum, l) => sum + l.visCount, 0), []);

  return (
    <div className="min-h-screen py-6 sm:py-8 px-3.5 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8 font-sans">
      {/* Top Hero Banner */}
      <div className="relative rounded-3xl overflow-hidden border border-cyan-500/30 bg-[#080d1a] p-6 sm:p-10 shadow-2xl">
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-20 -bottom-20 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-400/30 text-cyan-400 text-xs font-mono font-bold tracking-wide">
            <Compass className="w-3.5 h-3.5" />
            <span>CHEMISTRY CURRICULUM & LABORATORY DIRECTORY</span>
          </div>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-display-periodic">
                CHEMISPHERE 3D KNOWLEDGE MAP
              </h1>
              <p className="text-slate-300 text-sm sm:text-base max-w-3xl mt-2 leading-relaxed">
                Structured across <strong>14 comprehensive chemistry disciplines</strong>. Every laboratory contains active mathematical engines, 3D WebGL physics viewports, real-time parametric controls, and cross-linked scientific models.
              </p>
            </div>

            {/* Quick Stats Pill */}
            <div className="flex items-center gap-4 bg-black/40 border border-white/10 rounded-2xl p-3 shrink-0 font-mono text-xs shadow-inner">
              <div className="text-center px-3 border-r border-white/10">
                <span className="block text-xl font-bold text-cyan-400 font-display-periodic">14</span>
                <span className="text-[10px] text-slate-400 uppercase">Disciplines</span>
              </div>
              <div className="text-center px-3 border-r border-white/10">
                <span className="block text-xl font-bold text-purple-400 font-display-periodic">{totalTools}+</span>
                <span className="text-[10px] text-slate-400 uppercase">Scientific Tools</span>
              </div>
              <div className="text-center px-3">
                <span className="block text-xl font-bold text-emerald-400 font-display-periodic">{totalVis}+</span>
                <span className="text-[10px] text-slate-400 uppercase">Simulations</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Controls & Chemistry Discipline Filter Bar */}
      <div className="space-y-4 font-mono">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search curriculum, laws, instruments (e.g. 'FTIR', 'VSEPR', 'Nernst', 'Rydberg', 'Carnot', 'SN2')..."
              className="w-full pl-10 pr-16 py-3 rounded-2xl bg-[#090d16] border border-white/10 text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-cyan-400 transition-colors shadow-inner"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white px-2 py-0.5 rounded bg-white/10"
              >
                Clear
              </button>
            )}
          </div>

          {/* View Mode Switcher */}
          <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-[#090d16] border border-white/10 shrink-0 text-xs">
            <button
              onClick={() => setViewMode('curriculum-tree')}
              className={`px-3 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 ${
                viewMode === 'curriculum-tree'
                  ? 'bg-cyan-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Curriculum Tree</span>
            </button>
            <button
              onClick={() => setViewMode('cards')}
              className={`px-3 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 ${
                viewMode === 'cards'
                  ? 'bg-cyan-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Grid3X3 className="w-3.5 h-3.5" />
              <span>Lab Cards ({filteredLabs.length})</span>
            </button>
            <button
              onClick={() => setViewMode('3d-map')}
              className={`px-3 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 ${
                viewMode === '3d-map'
                  ? 'bg-cyan-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Compass className="w-3.5 h-3.5" />
              <span>Topology Map</span>
            </button>
          </div>
        </div>

        {/* Discipline Filter Ribbons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 text-xs scrollbar-none">
          <button
            onClick={() => setSelectedDiscipline('all')}
            className={`px-3.5 py-1.5 rounded-xl whitespace-nowrap transition-all border ${
              selectedDiscipline === 'all'
                ? 'bg-white/20 text-cyan-300 border-cyan-400/50 font-bold shadow-sm'
                : 'bg-white/[0.02] hover:bg-white/[0.06] text-slate-400 hover:text-white border-white/5'
            }`}
          >
            All Disciplines (14)
          </button>
          {CHEMISTRY_DISCIPLINES.map((disc) => {
            const isSel = selectedDiscipline === disc.id;
            const Icon = disc.icon;
            return (
              <button
                key={disc.id}
                onClick={() => setSelectedDiscipline(disc.id)}
                className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all border flex items-center gap-1.5 ${
                  isSel
                    ? 'bg-white/20 font-bold shadow-sm'
                    : 'bg-white/[0.02] hover:bg-white/[0.06] text-slate-400 hover:text-white border-white/5'
                }`}
                style={{
                  color: isSel ? disc.accentColor : undefined,
                  borderColor: isSel ? `${disc.accentColor}60` : undefined
                }}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{disc.shortName}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* VIEW MODE 1: COMPREHENSIVE CURRICULUM TREE EXPLORER                       */}
      {/* ========================================================================= */}
      {viewMode === 'curriculum-tree' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between font-mono text-xs text-slate-400 pb-2 border-b border-white/10">
            <div className="flex items-center gap-2">
              <span className="text-cyan-400 font-bold uppercase tracking-wider">
                CHEMISPHERE CURRICULUM HIERARCHY
              </span>
              <span className="text-[11px] text-slate-500">
                (Click any leaf topic to launch directly into that lab)
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={expandAll}
                className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
              >
                Expand All
              </button>
              <button
                onClick={collapseAll}
                className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
              >
                Collapse All
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono">
            {CHEMISTRY_DISCIPLINES.filter(
              (d) => selectedDiscipline === 'all' || selectedDiscipline === d.id
            ).map((disc) => {
              const Icon = disc.icon;
              const isExpanded = !!expandedDisciplines[disc.id];
              return (
                <div
                  key={disc.id}
                  className="rounded-2xl bg-[#090d16] border border-white/10 hover:border-white/20 transition-all overflow-hidden shadow-lg"
                >
                  {/* Discipline Header Bar */}
                  <div
                    onClick={() => toggleDiscipline(disc.id)}
                    className="p-4 flex items-center justify-between cursor-pointer bg-white/[0.02] hover:bg-white/[0.05] transition-colors border-b border-white/5 select-none"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 border"
                        style={{
                          backgroundColor: `${disc.accentColor}15`,
                          borderColor: `${disc.accentColor}40`,
                          color: disc.accentColor
                        }}
                      >
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white flex items-center gap-2">
                          <span>{disc.name}</span>
                          <span
                            className="text-[10px] px-2 py-0.2 rounded-full border"
                            style={{
                              backgroundColor: `${disc.accentColor}10`,
                              borderColor: `${disc.accentColor}30`,
                              color: disc.accentColor
                            }}
                          >
                            {disc.curriculumTopics.length} Topics
                          </span>
                        </h3>
                        <p className="text-[11px] text-slate-400 font-sans line-clamp-1 mt-0.5">
                          {disc.description}
                        </p>
                      </div>
                    </div>

                    <ChevronDown
                      className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${
                        isExpanded ? 'rotate-180 text-cyan-400' : ''
                      }`}
                    />
                  </div>

                  {/* Expandable Topic Nodes */}
                  {isExpanded && (
                    <div className="p-3 space-y-1.5 bg-black/20">
                      {disc.curriculumTopics.map((node, idx) => (
                        <div
                          key={idx}
                          onClick={() => onNavigate(node.targetTab)}
                          className="group p-2.5 rounded-xl bg-white/[0.02] hover:bg-white/[0.07] border border-white/5 hover:border-cyan-400/40 transition-all cursor-pointer flex items-start justify-between gap-3"
                        >
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-2">
                              <span className="text-slate-500 text-xs">├─</span>
                              <span className="text-xs font-bold text-slate-200 group-hover:text-cyan-300 transition-colors">
                                {node.topic}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-400 pl-4 font-sans leading-relaxed">
                              {node.description}
                            </p>
                          </div>

                          <div className="shrink-0 pt-0.5 flex items-center gap-1 text-[11px] text-slate-500 group-hover:text-cyan-400 transition-colors font-bold">
                            <span className="hidden sm:inline">Launch</span>
                            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* VIEW MODE 2: RICH MULTI-CLASSIFICATION LABORATORY CARDS GRID             */}
      {/* ========================================================================= */}
      {viewMode === 'cards' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredLabs.map((lab) => {
            const Icon = lab.icon;
            return (
              <div
                key={lab.id}
                onClick={() => onNavigate(lab.id)}
                className="group relative rounded-3xl bg-[#090d16] border border-white/10 hover:border-cyan-400/40 p-6 flex flex-col justify-between transition-all duration-300 hover:shadow-2xl hover:shadow-cyan-500/10 cursor-pointer overflow-hidden font-mono"
              >
                {/* Subtle background glow */}
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${lab.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none`}
                />

                <div className="relative z-10 space-y-4">
                  {/* Header Badge */}
                  <div className="flex items-center justify-between">
                    <span
                      className="text-[10px] px-2.5 py-1 rounded-full uppercase tracking-wider font-bold"
                      style={{
                        backgroundColor: `${lab.highlightColor}15`,
                        color: lab.highlightColor,
                        border: `1px solid ${lab.highlightColor}30`
                      }}
                    >
                      {lab.categoryLabel}
                    </span>

                    <div className="w-9 h-9 rounded-xl bg-white/[0.03] border border-white/10 flex items-center justify-center text-slate-300 group-hover:text-cyan-300 group-hover:scale-110 transition-all">
                      <Icon className="w-4 h-4" />
                    </div>
                  </div>

                  {/* Title and Subtitle */}
                  <div>
                    <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition-colors font-display-periodic tracking-tight">
                      {lab.title}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 font-sans">{lab.subtitle}</p>
                  </div>

                  {/* Curriculum Breadcrumb */}
                  <div className="text-[10px] text-cyan-400/80 font-mono tracking-tight bg-cyan-500/5 px-2.5 py-1 rounded-lg border border-cyan-500/15 truncate">
                    {lab.curriculumBreadcrumb}
                  </div>

                  {/* Simulation Description */}
                  <div className="p-3 rounded-2xl bg-black/40 border border-white/5 text-[11px] text-slate-300 leading-relaxed font-sans">
                    <strong className="text-slate-400 font-mono block text-[10px] uppercase mb-1">Simulates:</strong>
                    {lab.simulates}
                  </div>

                  {/* Multi-Classification Cross-Link Pills */}
                  <div className="space-y-1 pt-1">
                    <div className="text-[9px] text-slate-500 uppercase tracking-wider">
                      Cross-Linked Disciplines:
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {lab.relatedDisciplines.map((rel) => (
                        <span
                          key={rel.id}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedDiscipline(rel.id);
                          }}
                          className="text-[10px] px-2 py-0.5 rounded-md bg-white/5 hover:bg-white/15 border border-white/10 text-slate-300 hover:text-cyan-300 transition-colors cursor-pointer"
                        >
                          {rel.label}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Card Footer: Instrument Counts & Action CTA */}
                <div className="relative z-10 pt-4 mt-4 border-t border-white/10 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3 text-slate-400 text-[11px]">
                    <span><strong>{lab.toolCount}</strong> Tools</span>
                    <span>•</span>
                    <span><strong>{lab.visCount}</strong> Visualizations</span>
                  </div>

                  <div className="flex items-center gap-1.5 font-bold text-cyan-400 group-hover:translate-x-1 transition-transform">
                    <span>OPEN LAB</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ========================================================================= */}
      {/* VIEW MODE 3: INTERACTIVE LABORATORY TOPOLOGY MAP                          */}
      {/* ========================================================================= */}
      {viewMode === '3d-map' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-[#080c16] border border-cyan-500/30 shadow-2xl relative overflow-hidden space-y-6">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div>
              <h2 className="text-lg font-bold font-mono text-white flex items-center gap-2">
                <Atom className="w-5 h-5 text-cyan-400" />
                <span>INTERACTIVE 3D LABORATORY TOPOLOGY MAP</span>
              </h2>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                Organized by atomic foundations, molecular architecture, physical dynamics, and analytical suites
              </p>
            </div>
            <span className="text-xs font-mono text-cyan-300 bg-cyan-500/10 px-3 py-1 rounded-full border border-cyan-500/20">
              14 Connected Scientific Hubs
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 font-mono text-xs">
            {/* Column 1: Atomic, Quantum & Spectroscopy */}
            <div className="space-y-3 p-4 rounded-2xl bg-black/40 border border-purple-500/20">
              <h3 className="text-purple-400 font-bold uppercase text-xs tracking-wider border-b border-purple-500/20 pb-2">
                Atomic, Quantum & Spectroscopy
              </h3>
              {[
                { id: 'periodic-table' as NavigationTab, name: 'Periodic Table (118 Elements)', desc: 'Inorganic Law & SVG Trends' },
                { id: 'atomic-structure' as NavigationTab, name: 'Atomic Structure History', desc: 'Thomson, Rutherford, Bohr' },
                { id: 'quantum-lab' as NavigationTab, name: 'Quantum Mechanics Lab', desc: 'Particle in Box, Tunneling' },
                { id: 'orbital-atlas' as NavigationTab, name: '3D Quantum Orbitals', desc: 'Spherical Harmonics (1s-4f)' },
                { id: 'spectroscopy-suite' as NavigationTab, name: 'Spectroscopy Suite (5 Instruments)', desc: 'UV-Vis, FTIR, NMR, MS, XRD' },
                { id: 'atomic-spectra' as NavigationTab, name: 'Atomic Spectra & Flame Lab', desc: 'Rydberg Hydrogen Emission' }
              ].map((node) => (
                <button
                  key={node.id}
                  onClick={() => onNavigate(node.id)}
                  className="w-full text-left p-3 rounded-xl bg-white/[0.03] hover:bg-purple-500/15 border border-white/5 hover:border-purple-500/30 transition-all flex items-center justify-between group"
                >
                  <div>
                    <div className="font-bold text-white group-hover:text-purple-300 transition-colors">{node.name}</div>
                    <div className="text-[10px] text-slate-400">{node.desc}</div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-purple-400 group-hover:translate-x-1 transition-all" />
                </button>
              ))}
            </div>

            {/* Column 2: Physical, Electrochemistry & Molecular */}
            <div className="space-y-3 p-4 rounded-2xl bg-black/40 border border-cyan-500/20">
              <h3 className="text-cyan-400 font-bold uppercase text-xs tracking-wider border-b border-cyan-500/20 pb-2">
                Physical, Electro & Molecular
              </h3>
              {[
                { id: 'thermo-kinetics' as NavigationTab, name: 'Thermo & Kinetics Lab', desc: 'ΔG, Cycles, Arrhenius' },
                { id: 'physical-chem' as NavigationTab, name: 'Physical Chem & Gas Laws', desc: 'PV=nRT, van der Waals' },
                { id: 'electro-solutions' as NavigationTab, name: 'Electro & Solutions Lab', desc: 'Daniell Cell, Nernst, Titration' },
                { id: 'electrochemistry-lab' as NavigationTab, name: 'Electrochemistry & Batteries', desc: 'Li-Ion Intercalation & Cells' },
                { id: 'molecules-3d' as NavigationTab, name: '3D Molecular CAD Viewer', desc: 'Ball-and-Stick, Bond Angles' },
                { id: 'vsepr-lab' as NavigationTab, name: 'VSEPR & Hybridization', desc: 'Steric Domain Repulsion' }
              ].map((node) => (
                <button
                  key={node.id}
                  onClick={() => onNavigate(node.id)}
                  className="w-full text-left p-3 rounded-xl bg-white/[0.03] hover:bg-cyan-500/15 border border-white/5 hover:border-cyan-500/30 transition-all flex items-center justify-between group"
                >
                  <div>
                    <div className="font-bold text-white group-hover:text-cyan-300 transition-colors">{node.name}</div>
                    <div className="text-[10px] text-slate-400">{node.desc}</div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 group-hover:translate-x-1 transition-all" />
                </button>
              ))}
            </div>

            {/* Column 3: Organic, Nuclear, Analytical & Tools */}
            <div className="space-y-3 p-4 rounded-2xl bg-black/40 border border-emerald-500/20">
              <h3 className="text-emerald-400 font-bold uppercase text-xs tracking-wider border-b border-emerald-500/20 pb-2">
                Organic, Nuclear, Analytical & Tools
              </h3>
              {[
                { id: 'organic-mechanisms' as NavigationTab, name: 'Organic Mechanisms Lab', desc: 'SN1/SN2, Stereochemistry' },
                { id: 'organic-chem' as NavigationTab, name: 'Organic Reaction Highway', desc: 'IUPAC Functional Groups' },
                { id: 'analytical-materials' as NavigationTab, name: 'Analytical & Materials', desc: 'TLC, Unit Cells, Green Chem' },
                { id: 'nuclear-lab' as NavigationTab, name: 'Nuclear Chemistry Lab', desc: 'Decay, Half-Life, Fission' },
                { id: 'universal-calc-graph' as NavigationTab, name: 'Universal Calc & Grapher', desc: '24 Stepwise Solvers' },
                { id: 'ai-tutor' as NavigationTab, name: 'ChemoBot AI Tutor', desc: 'Stepwise Reasoning Copilot' }
              ].map((node) => (
                <button
                  key={node.id}
                  onClick={() => onNavigate(node.id)}
                  className="w-full text-left p-3 rounded-xl bg-white/[0.03] hover:bg-emerald-500/15 border border-white/5 hover:border-emerald-500/30 transition-all flex items-center justify-between group"
                >
                  <div>
                    <div className="font-bold text-white group-hover:text-emerald-300 transition-colors">{node.name}</div>
                    <div className="text-[10px] text-slate-400">{node.desc}</div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 group-hover:translate-x-1 transition-all" />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
