import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Sparkles,
  X,
  Orbit,
  Zap,
  Info,
  Eye,
  Layers,
  Atom,
  Flame,
  Activity,
  Sliders,
  ChevronRight,
  Thermometer,
  Compass,
  ArrowRight,
  TrendingUp,
  HelpCircle,
  BarChart3,
  Scale,
  GitCompare,
  Lightbulb,
  Radio,
  Cpu,
  Layers3
} from 'lucide-react';
import { ChemicalElement, NavigationTab } from '../../types';
import { ALL_118_ELEMENTS, getElementByNumber } from '../../data/elements';
import { ElementObservatoryModal } from '../observatory/ElementObservatoryModal';
import { ElementComparisonModal } from '../observatory/ElementComparisonModal';
import { PeriodicTrendPathModal } from '../observatory/PeriodicTrendPathModal';
import { LatexRenderer } from '../common/LatexRenderer';

interface PeriodicTableViewProps {
  onNavigate?: (tab: NavigationTab) => void;
  selectedElementFromProp?: ChemicalElement | null;
}

export type ViewByMode =
  | 'category'
  | 'groups'
  | 'periods'
  | 'blocks'
  | 'metals-nonmetals'
  | 'metallicCharacter'
  | 'nonMetallicCharacter'
  | 'valence'
  | 'oxidation'
  | 'atomicRadius'
  | 'ionicRadius'
  | 'electronegativity'
  | 'ionizationEnergy'
  | 'electronAffinity'
  | 'meltingPoint'
  | 'boilingPoint'
  | 'density'
  | 'electricalConductivity'
  | 'thermalConductivity'
  | 'state-stp'
  | 'electronConfig'
  | 'valenceSlider'
  | 'reactivity';

export const PeriodicTableView: React.FC<PeriodicTableViewProps> = ({
  onNavigate,
  selectedElementFromProp
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [viewByMode, setViewByMode] = useState<ViewByMode>('category');
  const [selectedBlock, setSelectedBlock] = useState<'all' | 's' | 'p' | 'd' | 'f'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [valenceFilter, setValenceFilter] = useState<number | null>(null);
  
  // Interactive Inspector States
  const [inspectedGroup, setInspectedGroup] = useState<number | null>(null);
  const [inspectedPeriod, setInspectedPeriod] = useState<number | null>(null);
  const [activeTrendWhy, setActiveTrendWhy] = useState<string | null>(null);

  // Dynamic Temperature State (Kelvin)
  const [temperatureK, setTemperatureK] = useState<number>(298.15); // 25°C STP default
  const [tempUnit, setTempUnit] = useState<'C' | 'K'>('C');

  // Comparison & Trend Path Modals
  const [isComparisonOpen, setIsComparisonOpen] = useState(false);
  const [isTrendPathOpen, setIsTrendPathOpen] = useState(false);
  const [activeReactivityWhy, setActiveReactivityWhy] = useState(false);

  // Aufbau Subshell filling step
  const [aufbauStep, setAufbauStep] = useState<number>(118);

  // Selected element for observatory modal
  const [activeElement, setActiveElement] = useState<ChemicalElement | null>(
    selectedElementFromProp || getElementByNumber(6) // Carbon
  );
  const [isObservatoryOpen, setIsObservatoryOpen] = useState(false);

  // Temperature conversions
  const tempC = Math.round(temperatureK - 273.15);

  const setTempFromC = (c: number) => {
    setTemperatureK(Math.max(0, c + 273.15));
  };

  // Helper to determine state at current temperature
  const getElementStateAtTemp = (el: ChemicalElement): 'solid' | 'liquid' | 'gas' | 'unknown' => {
    if (el.meltingPoint === null || el.meltingPoint === undefined) return 'solid';
    if (temperatureK < el.meltingPoint) return 'solid';
    if (el.boilingPoint && temperatureK >= el.boilingPoint) return 'gas';
    return 'liquid';
  };

  // Real-time State of matter counts at current temperature
  const stateCounts = useMemo(() => {
    let solids = 0;
    let liquids = 0;
    let gases = 0;
    ALL_118_ELEMENTS.forEach((el) => {
      const st = getElementStateAtTemp(el);
      if (st === 'solid') solids++;
      else if (st === 'liquid') liquids++;
      else if (st === 'gas') gases++;
    });
    return { solids, liquids, gases };
  }, [temperatureK]);

  // Category definitions
  const categoryDefinitions = [
    { id: 'all', label: 'All Elements', color: '#94a3b8' },
    { id: 'alkali-metal', label: 'Alkali Metals', color: '#ef4444' },
    { id: 'alkaline-earth', label: 'Alkaline Earth', color: '#f97316' },
    { id: 'transition-metal', label: 'Transition Metals', color: '#3b82f6' },
    { id: 'post-transition-metal', label: 'Post-Transition', color: '#10b981' },
    { id: 'metalloid', label: 'Metalloids', color: '#14b8a6' },
    { id: 'reactive-nonmetal', label: 'Reactive Nonmetals', color: '#38bdf8' },
    { id: 'halogen', label: 'Halogens', color: '#a855f7' },
    { id: 'noble-gas', label: 'Noble Gases', color: '#ec4899' },
    { id: 'lanthanoid', label: 'Lanthanides', color: '#8b5cf6' },
    { id: 'actinoid', label: 'Actinides', color: '#d946ef' }
  ];

  // Block definitions
  const blockDefinitions = [
    { id: 'all', label: 'All Blocks', l: null, capacity: 118, desc: 'Complete 118 Periodic System' },
    { id: 's', label: 's-Block', l: 'l = 0', capacity: '2 e⁻ / shell', desc: 'Alkali & Alkaline Earth Metals + H, He. Spherical probability density.' },
    { id: 'p', label: 'p-Block', l: 'l = 1', capacity: '6 e⁻ / shell', desc: 'Groups 13–18. Dumbbell-shaped orthogonal lobes (px, py, pz).' },
    { id: 'd', label: 'd-Block', l: 'l = 2', capacity: '10 e⁻ / shell', desc: 'Transition Metals. Cloverleaf geometry, variable oxidation states, catalytic activity.' },
    { id: 'f', label: 'f-Block', l: 'l = 3', capacity: '14 e⁻ / shell', desc: 'Lanthanides & Actinides. Inner transition elements with multi-lobed complex nodes.' }
  ];

  // Periodic trends definitions & "WHY?" explanations
  const trendExplanations: Record<string, { title: string; trend: string; why: string; equation: string; anomaly: string }> = {
    atomicRadius: {
      title: 'Atomic Radius',
      trend: 'Decreases across Period (→), Increases down Group (↓)',
      why: 'Across a period, nuclear protons increase while electrons enter the same principal quantum shell. The effective nuclear charge (Z_eff) rises, exerting tighter Coulombic pull that contracts electron clouds. Down a group, new principal quantum shells (n) are added, increasing radius and shielding.',
      equation: 'F = \\frac{Z_{\\text{eff}} \\cdot e^2}{4\\pi \\varepsilon_0 r^2}',
      anomaly: 'Noble gases have larger van der Waals radii compared to covalent halogen radii. Lanthanide contraction causes 4d and 5d transition metals (e.g. Zr and Hf) to have nearly identical radii.'
    },
    electronegativity: {
      title: 'Electronegativity (Pauling Scale)',
      trend: 'Increases across Period (→), Decreases down Group (↓)',
      why: 'Higher effective nuclear charge and smaller atomic radius allow the nucleus to attract shared bonding electron pairs much more strongly.',
      equation: '\\chi_A - \\chi_B = 0.102 \\sqrt{E_d(A-B) - \\sqrt{E_d(A-A)E_d(B-B)}}',
      anomaly: 'Fluorine is the most electronegative element (3.98). Noble gases have undefined standard electronegativities as they typically do not form covalent pairs.'
    },
    ionizationEnergy: {
      title: 'First Ionization Energy',
      trend: 'Increases across Period (→), Decreases down Group (↓)',
      why: 'As Z_eff increases and atomic radius shrinks across a period, valence electrons are held more tightly, requiring greater energy to eject.',
      equation: 'X(g) + \\text{IE}_1 \\longrightarrow X^+(g) + e^-',
      anomaly: 'Group 15 (N with 2p³) has higher IE than Group 16 (O with 2p⁴) due to half-filled subshell extra exchange energy stability. Group 2 (Be, 2s²) has higher IE than Group 13 (B, 2p¹) due to s-penetration.'
    },
    electronAffinity: {
      title: 'Electron Affinity',
      trend: 'Generally increases (more exothermic) across Period (→), decreases down Group (↓)',
      why: 'Smaller atoms with higher effective nuclear charge release more energy upon capturing an electron into their valence shell.',
      equation: 'X(g) + e^- \\longrightarrow X^-(g) + \\text{EA}',
      anomaly: 'Chlorine (349 kJ/mol) has higher electron affinity than Fluorine (328 kJ/mol) because Fluorine\'s extremely compact 2p subshell creates significant inter-electronic repulsion.'
    },
    metallicCharacter: {
      title: 'Metallic Character (Electropositivity)',
      trend: 'Decreases across Period (→), Increases down Group (↓)',
      why: 'Metals readily lose valence electrons to form cations. Larger atoms with low ionization energy lose electrons with minimal energy input.',
      equation: 'M(s) \\longrightarrow M^{n+}(aq) + n e^-',
      anomaly: 'Diagonal relationships (e.g. Li & Mg, Be & Al, B & Si) exhibit similar polarizing power (charge/radius ratio).'
    }
  };

  // Group detailed data for inspector drawer
  const getGroupDetails = (grp: number) => {
    const names: Record<number, { name: string; valence: string; behavior: string; reactions: string }> = {
      1: { name: 'Alkali Metals', valence: 'ns¹', behavior: 'Extremely reactive, soft, low melting points, form +1 basic hydroxides', reactions: '2Na + 2H₂O → 2NaOH + H₂↑ (Exothermic)' },
      2: { name: 'Alkaline Earth Metals', valence: 'ns²', behavior: 'Reactive, silvery-white, form +2 ionic basic oxides', reactions: 'Mg + 2HCl → MgCl₂ + H₂↑' },
      13: { name: 'Boron Family (Triels)', valence: 'ns² np¹', behavior: 'Metalloid to post-transition metals, +3 and +1 oxidation states (inert pair effect)', reactions: '2Al + 6HCl → 2AlCl₃ + 3H₂↑' },
      14: { name: 'Carbon Family (Tetrels)', valence: 'ns² np²', behavior: 'Catenation champion, semiconductor transition from non-metal to metal', reactions: 'C + O₂ → CO₂; Si + 2Cl₂ → SiCl₄' },
      15: { name: 'Pnictogens', valence: 'ns² np³', behavior: 'Variable oxidation states (-3 to +5), forms multiple allotropes', reactions: 'N₂ + 3H₂ ⇌ 2NH₃ (Haber-Bosch)' },
      16: { name: 'Chalcogens (Oxygen Family)', valence: 'ns² np⁴', behavior: 'Strong oxidizers, allotropic (O₂, O₃, S₈), form acidic oxides', reactions: 'S + O₂ → SO₂; 2SO₂ + O₂ ⇌ 2SO₃' },
      17: { name: 'Halogens', valence: 'ns² np⁵', behavior: 'Most reactive nonmetals, form diatomic salts with metals (halides)', reactions: 'Cl₂ + 2KBr → 2KCl + Br₂ (Displacement)' },
      18: { name: 'Noble Gases', valence: 'ns² np⁶ (Octet)', behavior: 'Complete valence shells, extremely inert, monatomic cryogenic fluids', reactions: 'Xe + F₂ → XeF₂ (Under photochemical conditions)' }
    };
    return names[grp] || {
      name: `Group ${grp} Transition Metals`,
      valence: `(n-1)d¹⁻¹⁰ ns¹⁻²`,
      behavior: 'Partially filled d-subshells, variable oxidation states, colorful coordination complexes, paramagnetic properties, strong metallic bonding.',
      reactions: 'Forms robust alloys and coordination catalysts (e.g., Fe, Pt, Cu, Ni).'
    };
  };

  // Compute tile background color based on the 23 analysis modes
  const getTileColor = (el: ChemicalElement): string => {
    // Dim inactive block if filtered
    if (selectedBlock !== 'all' && el.block !== selectedBlock) {
      return 'rgba(15, 23, 42, 0.2)';
    }

    if (viewByMode === 'electronConfig' && el.number > aufbauStep) {
      return 'rgba(15, 23, 42, 0.15)';
    }

    if (viewByMode === 'blocks') {
      const blockColorMap = {
        s: 'rgba(239, 68, 68, 0.35)',
        p: 'rgba(56, 189, 248, 0.35)',
        d: 'rgba(245, 158, 11, 0.35)',
        f: 'rgba(168, 85, 247, 0.35)'
      };
      return blockColorMap[el.block];
    }

    if (viewByMode === 'groups') {
      const gColor = (el.group * 19) % 360;
      return `hsla(${gColor}, 70%, 50%, 0.35)`;
    }

    if (viewByMode === 'periods') {
      const pColor = (el.period * 48) % 360;
      return `hsla(${pColor}, 75%, 55%, 0.35)`;
    }

    if (viewByMode === 'metals-nonmetals') {
      if (el.category.includes('metal') && !el.category.includes('nonmetal') && !el.category.includes('metalloid')) {
        return 'rgba(59, 130, 246, 0.35)';
      }
      if (el.category === 'metalloid') return 'rgba(20, 184, 166, 0.4)';
      return 'rgba(244, 63, 94, 0.35)';
    }

    if (viewByMode === 'metallicCharacter') {
      const isMetal = el.category.includes('metal') && !el.category.includes('nonmetal');
      const ratio = isMetal ? Math.max(0.2, 1 - (el.electronegativity || 2) / 4.0) : 0.1;
      return `rgba(59, 130, 246, ${0.2 + ratio * 0.7})`;
    }

    if (viewByMode === 'nonMetallicCharacter') {
      const en = el.electronegativity || 1.0;
      const ratio = Math.max(0, Math.min(1, (en - 0.7) / 3.3));
      return `rgba(236, 72, 153, ${0.2 + ratio * 0.75})`;
    }

    if (viewByMode === 'valence' || viewByMode === 'valenceSlider') {
      const v = el.valenceElectrons || 1;
      const ratio = v / 8;
      return `rgba(99, 102, 241, ${0.2 + ratio * 0.7})`;
    }

    if (viewByMode === 'oxidation') {
      const ox = el.oxidationStates ? Math.max(...el.oxidationStates.map(Math.abs)) : 1;
      const ratio = Math.min(1, ox / 8);
      return `rgba(245, 158, 11, ${0.2 + ratio * 0.75})`;
    }

    if (viewByMode === 'state-stp' || temperatureK !== 298.15) {
      const st = getElementStateAtTemp(el);
      if (st === 'solid') return 'rgba(100, 116, 139, 0.35)';
      if (st === 'liquid') return 'rgba(14, 165, 233, 0.45)';
      return 'rgba(236, 72, 153, 0.45)';
    }

    if (viewByMode === 'electronegativity') {
      if (el.electronegativity === null || el.electronegativity === undefined) return 'rgba(15, 23, 42, 0.4)';
      const ratio = Math.max(0, Math.min(1, (el.electronegativity - 0.7) / (4.0 - 0.7)));
      return `rgba(239, 68, 68, ${0.2 + ratio * 0.75})`;
    }

    if (viewByMode === 'atomicRadius') {
      if (!el.atomicRadius) return 'rgba(15, 23, 42, 0.4)';
      const ratio = Math.max(0, Math.min(1, (el.atomicRadius - 30) / (270 - 30)));
      return `rgba(56, 189, 248, ${0.2 + ratio * 0.75})`;
    }

    if (viewByMode === 'ionicRadius') {
      if (!el.ionicRadius) return 'rgba(15, 23, 42, 0.4)';
      const ratio = Math.max(0, Math.min(1, el.ionicRadius / 180));
      return `rgba(147, 51, 234, ${0.2 + ratio * 0.75})`;
    }

    if (viewByMode === 'ionizationEnergy') {
      if (!el.ionizationEnergy) return 'rgba(15, 23, 42, 0.4)';
      const ratio = Math.max(0, Math.min(1, (el.ionizationEnergy - 380) / (2372 - 380)));
      return `rgba(168, 85, 247, ${0.2 + ratio * 0.75})`;
    }

    if (viewByMode === 'electronAffinity') {
      if (el.electronAffinity === null || el.electronAffinity === undefined) return 'rgba(15, 23, 42, 0.4)';
      const ratio = Math.max(0, Math.min(1, el.electronAffinity / 350));
      return `rgba(34, 197, 94, ${0.2 + ratio * 0.75})`;
    }

    if (viewByMode === 'meltingPoint') {
      if (!el.meltingPoint) return 'rgba(15, 23, 42, 0.4)';
      const ratio = Math.max(0, Math.min(1, el.meltingPoint / 3850));
      return `rgba(245, 158, 11, ${0.2 + ratio * 0.75})`;
    }

    if (viewByMode === 'boilingPoint') {
      if (!el.boilingPoint) return 'rgba(15, 23, 42, 0.4)';
      const ratio = Math.max(0, Math.min(1, el.boilingPoint / 5900));
      return `rgba(217, 70, 239, ${0.2 + ratio * 0.75})`;
    }

    if (viewByMode === 'density') {
      if (!el.density) return 'rgba(15, 23, 42, 0.4)';
      const ratio = Math.max(0, Math.min(1, el.density / 22.6));
      return `rgba(16, 185, 129, ${0.2 + ratio * 0.75})`;
    }

    if (viewByMode === 'electricalConductivity') {
      if (!el.electricalConductivity) return 'rgba(15, 23, 42, 0.4)';
      const ratio = Math.max(0, Math.min(1, el.electricalConductivity / 63));
      return `rgba(6, 182, 212, ${0.2 + ratio * 0.75})`;
    }

    if (viewByMode === 'thermalConductivity') {
      if (!el.thermalConductivity) return 'rgba(15, 23, 42, 0.4)';
      const ratio = Math.max(0, Math.min(1, el.thermalConductivity / 430));
      return `rgba(249, 115, 22, ${0.2 + ratio * 0.75})`;
    }

    if (viewByMode === 'reactivity') {
      if (el.group === 1 || el.group === 17) return 'rgba(239, 68, 68, 0.55)'; // High
      if (el.group === 2 || el.group === 16) return 'rgba(245, 158, 11, 0.45)'; // Moderate-High
      if (el.group === 18) return 'rgba(100, 116, 139, 0.3)'; // Inert
      return 'rgba(59, 130, 246, 0.35)'; // Moderate
    }

    // Default category mode
    const categoryBgMap: Record<string, string> = {
      'alkali-metal': 'rgba(239, 68, 68, 0.22)',
      'alkaline-earth': 'rgba(249, 115, 22, 0.22)',
      'transition-metal': 'rgba(59, 130, 246, 0.22)',
      'post-transition': 'rgba(16, 185, 129, 0.22)',
      'post-transition-metal': 'rgba(16, 185, 129, 0.22)',
      'metalloid': 'rgba(20, 184, 166, 0.22)',
      'reactive-nonmetal': 'rgba(56, 189, 248, 0.22)',
      'nonmetal': 'rgba(56, 189, 248, 0.22)',
      'halogen': 'rgba(168, 85, 247, 0.22)',
      'noble-gas': 'rgba(236, 72, 153, 0.22)',
      'lanthanoid': 'rgba(139, 92, 246, 0.22)',
      'actinoid': 'rgba(217, 70, 239, 0.22)'
    };
    return categoryBgMap[el.category] || 'rgba(15, 23, 42, 0.6)';
  };

  // Smart natural language query parser & filter check
  const isElementMatched = (el: ChemicalElement) => {
    if (selectedBlock !== 'all' && el.block !== selectedBlock) return false;
    if (selectedCategory !== 'all' && el.category !== selectedCategory && !el.category.includes(selectedCategory)) return false;
    if (inspectedGroup !== null && el.group !== inspectedGroup) return false;
    if (inspectedPeriod !== null && el.period !== inspectedPeriod) return false;
    if (valenceFilter !== null && el.valenceElectrons !== valenceFilter) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();

      // Number comparison queries like "mass < 40", "z > 20", "radius > 100"
      if (q.includes('<') || q.includes('>')) {
        const isLess = q.includes('<');
        const parts = q.split(/[<>]/).map((p) => p.trim());
        const prop = parts[0];
        const num = parseFloat(parts[1]);

        if (!isNaN(num)) {
          if (prop.includes('mass')) return isLess ? el.atomicMass < num : el.atomicMass > num;
          if (prop.includes('z') || prop.includes('number') || prop.includes('atomic')) return isLess ? el.number < num : el.number > num;
          if (prop.includes('radius')) return el.atomicRadius ? (isLess ? el.atomicRadius < num : el.atomicRadius > num) : false;
          if (prop.includes('en') || prop.includes('electronegativity')) return el.electronegativity ? (isLess ? el.electronegativity < num : el.electronegativity > num) : false;
          if (prop.includes('temp') || prop.includes('melting')) return el.meltingPoint ? (isLess ? el.meltingPoint < num : el.meltingPoint > num) : false;
        }
      }

      // Natural language keywords
      if (q === 'gas' || q === 'gases') return getElementStateAtTemp(el) === 'gas';
      if (q === 'liquid' || q === 'liquids') return getElementStateAtTemp(el) === 'liquid';
      if (q === 'solid' || q === 'solids') return getElementStateAtTemp(el) === 'solid';
      if (q.includes('noble')) return el.group === 18;
      if (q.includes('halogen')) return el.group === 17;
      if (q.includes('alkali')) return el.group === 1;

      return (
        el.name.toLowerCase().includes(q) ||
        el.symbol.toLowerCase().includes(q) ||
        el.number.toString() === q ||
        el.category.toLowerCase().includes(q) ||
        el.electronConfiguration.toLowerCase().includes(q) ||
        (el.discoveredBy && el.discoveredBy.toLowerCase().includes(q)) ||
        (el.yearDiscovered && el.yearDiscovered.toString().includes(q))
      );
    }
    return true;
  };

  // Filtered elements list
  const filteredElements = useMemo(() => {
    return ALL_118_ELEMENTS.filter(isElementMatched);
  }, [searchQuery, selectedBlock, selectedCategory, inspectedGroup, inspectedPeriod, valenceFilter, temperatureK]);

  // Main grid layout coordinates map (Period 1-7, Group 1-18)
  const getGridStyle = (el: ChemicalElement) => {
    if (el.number >= 57 && el.number <= 71) {
      return {
        gridRow: '9',
        gridColumn: `${el.number - 57 + 4}`
      };
    }
    if (el.number >= 89 && el.number <= 103) {
      return {
        gridRow: '10',
        gridColumn: `${el.number - 89 + 4}`
      };
    }
    return {
      gridRow: `${el.period + 1}`,
      gridColumn: `${el.group}`
    };
  };

  const handleTileClick = (el: ChemicalElement) => {
    setActiveElement(el);
    setIsObservatoryOpen(true);
  };

  return (
    <div className="min-h-screen bg-lab-inorganic text-slate-100 px-3 sm:px-6 py-6 space-y-6">
      {/* Header & Laboratory Control Hub */}
      <div className="max-w-[1440px] mx-auto p-5 sm:p-6 rounded-3xl bg-white/[0.03] border border-white/10 backdrop-blur-2xl shadow-2xl flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
        <div className="space-y-1.5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-400 shadow-lg shadow-cyan-500/20">
              <Atom className="w-6 h-6 animate-spin-slow" />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold font-display-periodic text-white tracking-tight flex items-center gap-3">
                <span>INORGANIC PERIODIC ENGINE</span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-400/30 font-mono">
                  23 Analysis Modes
                </span>
              </h1>
              <p className="text-xs text-slate-400 font-light">
                Quantum Shell Analyzer • Thermodynamic Phase Transitions • Vector Trend Graphs • Property Comparison
              </p>
            </div>
          </div>
        </div>

        {/* Global Search & Classification Mode Selector */}
        <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
          {/* Smart Natural Language Search Input */}
          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search or filter ('mass < 40', 'noble', 'gas')..."
              className="w-full pl-10 pr-4 py-2 rounded-xl bg-white/[0.05] border border-white/10 text-xs font-mono text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400/60 focus:bg-white/[0.08] transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* 23 Analysis Modes Selector */}
          <div className="flex items-center gap-2 bg-white/[0.04] border border-white/10 rounded-xl px-3 py-1.5 font-mono text-xs">
            <Filter className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-slate-400 text-[11px] uppercase tracking-wider">Analyze By:</span>
            <select
              value={viewByMode}
              onChange={(e) => setViewByMode(e.target.value as ViewByMode)}
              className="bg-transparent text-cyan-300 font-bold focus:outline-none cursor-pointer"
            >
              <optgroup label="Core Structural Modes" className="bg-slate-900 text-cyan-400 font-bold">
                <option value="category" className="bg-slate-900 text-white">1. Element Family (Standard)</option>
                <option value="groups" className="bg-slate-900 text-white">2. Groups (1–18 Columns)</option>
                <option value="periods" className="bg-slate-900 text-white">3. Periods (1–7 Shells)</option>
                <option value="blocks" className="bg-slate-900 text-white">4. Quantum Blocks (s, p, d, f)</option>
                <option value="metals-nonmetals" className="bg-slate-900 text-white">5. Metals vs Nonmetals</option>
              </optgroup>
              <optgroup label="Periodic Trends & Properties" className="bg-slate-900 text-purple-400 font-bold">
                <option value="atomicRadius" className="bg-slate-900 text-white">6. Atomic Radius (pm)</option>
                <option value="ionicRadius" className="bg-slate-900 text-white">7. Ionic Radius (pm)</option>
                <option value="electronegativity" className="bg-slate-900 text-white">8. Electronegativity (Pauling)</option>
                <option value="ionizationEnergy" className="bg-slate-900 text-white">9. 1st Ionization Energy (kJ/mol)</option>
                <option value="electronAffinity" className="bg-slate-900 text-white">10. Electron Affinity (kJ/mol)</option>
                <option value="metallicCharacter" className="bg-slate-900 text-white">11. Metallic Character</option>
                <option value="nonMetallicCharacter" className="bg-slate-900 text-white">12. Non-Metallic Character</option>
                <option value="valence" className="bg-slate-900 text-white">13. Valence Electrons (1–8)</option>
                <option value="oxidation" className="bg-slate-900 text-white">14. Oxidation States</option>
              </optgroup>
              <optgroup label="Physical & Thermodynamic Constants" className="bg-slate-900 text-amber-400 font-bold">
                <option value="meltingPoint" className="bg-slate-900 text-white">15. Melting Point (K)</option>
                <option value="boilingPoint" className="bg-slate-900 text-white">16. Boiling Point (K)</option>
                <option value="density" className="bg-slate-900 text-white">17. Density (g/cm³)</option>
                <option value="electricalConductivity" className="bg-slate-900 text-white">18. Electrical Conductivity (MS/m)</option>
                <option value="thermalConductivity" className="bg-slate-900 text-white">19. Thermal Conductivity (W/m·K)</option>
                <option value="state-stp" className="bg-slate-900 text-white">20. State of Matter (Dynamic Temp)</option>
              </optgroup>
              <optgroup label="Advanced Quantum & Reactivity" className="bg-slate-900 text-emerald-400 font-bold">
                <option value="electronConfig" className="bg-slate-900 text-white">21. Aufbau Filling Sequence (s→p→d→f)</option>
                <option value="valenceSlider" className="bg-slate-900 text-white">22. Valence Electron Filter</option>
                <option value="reactivity" className="bg-slate-900 text-white">23. Reactivity Gradient & Why</option>
              </optgroup>
            </select>
          </div>

          {/* Quick Action Comparison and Path Analyzer Buttons */}
          <button
            onClick={() => setIsComparisonOpen(true)}
            className="px-3 py-1.5 rounded-xl bg-cyan-500/20 border border-cyan-400/40 text-cyan-300 text-xs font-mono font-bold hover:bg-cyan-500/30 transition-all flex items-center gap-1.5"
            title="Compare 2 to 4 elements side-by-side"
          >
            <Scale className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Compare</span>
          </button>

          <button
            onClick={() => setIsTrendPathOpen(true)}
            className="px-3 py-1.5 rounded-xl bg-purple-500/20 border border-purple-400/40 text-purple-300 text-xs font-mono font-bold hover:bg-purple-500/30 transition-all flex items-center gap-1.5"
            title="Open Trend Path Visualizer"
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Trends</span>
          </button>
        </div>
      </div>

      {/* Interactive Control Strips: Blocks, Aufbau Sequence & Temperature Thermodynamic Engine */}
      <div className="max-w-[1440px] mx-auto grid grid-cols-1 xl:grid-cols-12 gap-4">
        {/* Block Selector */}
        <div className="xl:col-span-6 p-4 rounded-2xl bg-white/[0.02] border border-white/10 backdrop-blur-xl flex flex-col justify-between gap-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-cyan-400" />
              Quantum Subshell Blocks (s, p, d, f)
            </span>
            <span className="text-[11px] font-mono text-slate-400">
              {blockDefinitions.find((b) => b.id === selectedBlock)?.capacity}
            </span>
          </div>

          <div className="grid grid-cols-5 gap-2">
            {blockDefinitions.map((block) => {
              const isSelected = selectedBlock === block.id;
              return (
                <button
                  key={block.id}
                  onClick={() => setSelectedBlock(block.id as any)}
                  className={`py-2 px-2.5 rounded-xl border font-mono text-xs transition-all flex flex-col items-center justify-center gap-0.5 ${
                    isSelected
                      ? 'bg-cyan-500/20 border-cyan-400 text-white font-bold shadow-lg shadow-cyan-500/20 scale-[1.02]'
                      : 'bg-white/[0.03] border-white/5 text-slate-400 hover:text-white hover:border-white/20'
                  }`}
                >
                  <span>{block.label}</span>
                  {block.l && <span className="text-[10px] opacity-70">{block.l}</span>}
                </button>
              );
            })}
          </div>

          <div className="text-[11px] font-mono text-slate-400 bg-white/[0.02] p-2 rounded-lg border border-white/5 flex items-center justify-between">
            <span>{blockDefinitions.find((b) => b.id === selectedBlock)?.desc}</span>
            {viewByMode === 'electronConfig' && (
              <span className="text-cyan-300 font-bold ml-2">Aufbau Step: Z=1..{aufbauStep}</span>
            )}
          </div>
        </div>

        {/* Dynamic Temperature State Slider & Real-time Phase Counters */}
        <div className="xl:col-span-6 p-4 rounded-2xl bg-white/[0.02] border border-white/10 backdrop-blur-xl flex flex-col justify-between gap-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-orange-300 uppercase tracking-wider flex items-center gap-1.5">
              <Thermometer className="w-3.5 h-3.5 text-orange-400" />
              Thermodynamic Temperature Slider
            </span>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-white px-2 py-0.5 rounded bg-orange-500/20 border border-orange-500/40">
                {tempUnit === 'C' ? `${tempC} °C` : `${Math.round(temperatureK)} K`}
              </span>
              <button
                onClick={() => setTempUnit(tempUnit === 'C' ? 'K' : 'C')}
                className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/[0.05] border border-white/10 hover:bg-white/[0.1] text-slate-300"
              >
                Switch to °{tempUnit === 'C' ? 'K' : 'C'}
              </button>
            </div>
          </div>

          <div className="space-y-1">
            <input
              type="range"
              min={-273}
              max={4000}
              step={5}
              value={tempC}
              onChange={(e) => setTempFromC(parseFloat(e.target.value))}
              className="w-full accent-orange-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] font-mono text-slate-500">
              <span>0 K (-273°C)</span>
              <span>25°C STP</span>
              <span>1000°C</span>
              <span>4000°C</span>
            </div>
          </div>

          {/* Phase counters & Quick Presets */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
            <div className="flex items-center gap-2 text-[10px] font-mono">
              <span className="px-2 py-0.5 rounded bg-slate-800 border border-white/5 text-slate-300">
                Solids: <strong className="text-white">{stateCounts.solids}</strong>
              </span>
              <span className="px-2 py-0.5 rounded bg-cyan-950/60 border border-cyan-500/30 text-cyan-300">
                Liquids: <strong>{stateCounts.liquids}</strong>
              </span>
              <span className="px-2 py-0.5 rounded bg-pink-950/60 border border-pink-500/30 text-pink-300">
                Gases: <strong>{stateCounts.gases}</strong>
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-1">
              {[
                { label: '0 K', c: -273 },
                { label: 'Liquid N₂', c: -196 },
                { label: 'Ice 0°C', c: 0 },
                { label: 'STP 25°C', c: 25 },
                { label: 'Boiling H₂O', c: 100 },
                { label: 'Molten Fe', c: 1538 }
              ].map((preset) => (
                <button
                  key={preset.label}
                  onClick={() => setTempFromC(preset.c)}
                  className={`text-[9px] font-mono px-1.5 py-0.5 rounded border transition-all ${
                    tempC === preset.c
                      ? 'bg-orange-500/20 border-orange-400 text-orange-200 font-bold'
                      : 'bg-white/[0.03] border-white/5 text-slate-400 hover:text-white'
                  }`}
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Aufbau Subshell filling controls when mode is electronConfig */}
      {viewByMode === 'electronConfig' && (
        <div className="max-w-[1440px] mx-auto p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 backdrop-blur-xl flex flex-col sm:flex-row items-center justify-between gap-4 font-mono text-xs">
          <div className="flex items-center gap-3">
            <Cpu className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="font-bold text-white uppercase tracking-wider">Aufbau Orbital Filling Sequence</h3>
              <p className="text-slate-300 text-[11px]">
                Electrons fill subshells from lowest energy to highest: 1s → 2s → 2p → 3s → 3p → 4s → 3d → 4p → 5s → 4d → 5p → 6s → 4f → 5d → 6p → 7s → 5f → 6d → 7p
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <span className="text-emerald-300 font-bold shrink-0">Step Z = {aufbauStep} / 118</span>
            <input
              type="range"
              min={1}
              max={118}
              value={aufbauStep}
              onChange={(e) => setAufbauStep(parseInt(e.target.value))}
              className="accent-emerald-400 bg-slate-800 h-2 rounded-lg cursor-pointer w-36"
            />
          </div>
        </div>
      )}

      {/* Valence Electron slider when mode is valenceSlider */}
      {viewByMode === 'valenceSlider' && (
        <div className="max-w-[1440px] mx-auto p-4 rounded-2xl bg-indigo-950/30 border border-indigo-500/30 backdrop-blur-xl flex items-center justify-between gap-4 font-mono text-xs">
          <div className="flex items-center gap-3">
            <Radio className="w-5 h-5 text-indigo-400" />
            <span className="font-bold text-white">Filter Elements by Valence Electron Count:</span>
          </div>

          <div className="flex items-center gap-1.5">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((v) => (
              <button
                key={v}
                onClick={() => setValenceFilter(valenceFilter === v ? null : v)}
                className={`px-3 py-1 rounded-xl border transition-all ${
                  valenceFilter === v
                    ? 'bg-indigo-500/30 border-indigo-400 text-white font-bold shadow-md'
                    : 'bg-white/[0.03] border-white/5 text-slate-400 hover:text-white'
                }`}
              >
                {v} e⁻
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Active Trend Explainer & Periodic Trends Bar */}
      {['electronegativity', 'atomicRadius', 'ionizationEnergy', 'electronAffinity', 'metallicCharacter'].includes(viewByMode) && (
        <div className="max-w-[1440px] mx-auto p-4 rounded-2xl bg-cyan-950/30 border border-cyan-500/30 backdrop-blur-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-cyan-500/20 text-cyan-300">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
                <span>Periodic Trend: {trendExplanations[viewByMode]?.title}</span>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-normal">
                  {trendExplanations[viewByMode]?.trend}
                </span>
              </h2>
              <p className="text-xs text-slate-300 mt-0.5 line-clamp-1">
                {trendExplanations[viewByMode]?.why}
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveTrendWhy(viewByMode)}
            className="px-3.5 py-1.5 rounded-xl bg-cyan-500/20 border border-cyan-400/40 text-cyan-300 text-xs font-mono font-bold hover:bg-cyan-500/30 transition-all flex items-center gap-1.5 shrink-0"
          >
            <HelpCircle className="w-4 h-4" />
            <span>Why Does This Trend Occur?</span>
          </button>
        </div>
      )}

      {/* Category Pills & Inspector Reset */}
      <div className="max-w-[1440px] mx-auto flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
          {categoryDefinitions.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`text-xs font-mono px-3 py-1.5 rounded-xl border transition-all flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-white/[0.12] border-white/40 text-white font-bold shadow-md'
                    : 'bg-white/[0.03] border-white/5 text-slate-400 hover:text-white hover:border-white/15'
                }`}
              >
                <span
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: cat.color }}
                />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {(inspectedGroup !== null || inspectedPeriod !== null || selectedCategory !== 'all' || selectedBlock !== 'all' || valenceFilter !== null) && (
          <button
            onClick={() => {
              setInspectedGroup(null);
              setInspectedPeriod(null);
              setSelectedCategory('all');
              setSelectedBlock('all');
              setValenceFilter(null);
            }}
            className="text-xs font-mono px-3 py-1.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 hover:bg-red-500/20 transition-all flex items-center gap-1"
          >
            <X className="w-3.5 h-3.5" />
            <span>Clear Filters</span>
          </button>
        )}
      </div>

      {/* Main Periodic Table Grid View */}
      <div className="max-w-[1440px] mx-auto p-4 sm:p-6 rounded-3xl bg-white/[0.02] border border-white/10 backdrop-blur-2xl shadow-2xl overflow-x-auto">
        <div
          className="grid gap-1.5 min-w-[1080px]"
          style={{
            gridTemplateColumns: 'repeat(18, minmax(0, 1fr))',
            gridTemplateRows: 'repeat(10, minmax(0, auto))'
          }}
        >
          {/* Group Column Headers (1-18) */}
          {Array.from({ length: 18 }, (_, i) => i + 1).map((grp) => (
            <button
              key={`grp-hdr-${grp}`}
              onClick={() => setInspectedGroup(inspectedGroup === grp ? null : grp)}
              style={{ gridRow: '1', gridColumn: `${grp}` }}
              className={`py-1 text-center font-mono text-[11px] font-bold rounded-lg border transition-all ${
                inspectedGroup === grp
                  ? 'bg-cyan-500/30 border-cyan-400 text-white shadow-md shadow-cyan-500/20'
                  : 'bg-white/[0.02] border-white/5 text-slate-500 hover:text-cyan-300 hover:border-cyan-400/40'
              }`}
              title={`Click to inspect Group ${grp}`}
            >
              {grp}
            </button>
          ))}

          {/* Period Row Headers (1-7) */}
          {Array.from({ length: 7 }, (_, i) => i + 1).map((prd) => (
            <button
              key={`prd-hdr-${prd}`}
              onClick={() => setInspectedPeriod(inspectedPeriod === prd ? null : prd)}
              style={{ gridRow: `${prd + 1}`, gridColumn: '1' }}
              className={`absolute -left-7 font-mono text-[11px] font-bold py-3 text-slate-500 hover:text-cyan-300 transition-colors ${
                inspectedPeriod === prd ? 'text-cyan-300 font-bold' : ''
              }`}
              title={`Click to inspect Period ${prd}`}
            >
              P{prd}
            </button>
          ))}

          {/* Lanthanides & Actinides placeholder indicators */}
          <div
            style={{ gridRow: '6', gridColumn: '3' }}
            className="p-1.5 rounded-xl border border-dashed border-purple-500/40 bg-purple-500/10 flex flex-col items-center justify-center font-mono text-[10px] text-purple-300"
          >
            <span>57-71</span>
            <span className="text-[8px] opacity-75">La-Lu</span>
          </div>

          <div
            style={{ gridRow: '7', gridColumn: '3' }}
            className="p-1.5 rounded-xl border border-dashed border-pink-500/40 bg-pink-500/10 flex flex-col items-center justify-center font-mono text-[10px] text-pink-300"
          >
            <span>89-103</span>
            <span className="text-[8px] opacity-75">Ac-Lr</span>
          </div>

          {/* 118 Elements Dynamic Grid Cells */}
          {ALL_118_ELEMENTS.map((el) => {
            const isMatched = isElementMatched(el);
            const gridStyle = getGridStyle(el);
            const bgColor = getTileColor(el);
            const state = getElementStateAtTemp(el);

            // Dynamic Sub-metric label on tile
            let miniMetricValue = '';
            if (viewByMode === 'atomicRadius') miniMetricValue = el.atomicRadius ? `${el.atomicRadius}pm` : '';
            else if (viewByMode === 'electronegativity') miniMetricValue = el.electronegativity !== undefined && el.electronegativity !== null ? `${el.electronegativity}` : '';
            else if (viewByMode === 'ionizationEnergy') miniMetricValue = el.ionizationEnergy ? `${el.ionizationEnergy}` : '';
            else if (viewByMode === 'electronAffinity') miniMetricValue = el.electronAffinity !== undefined && el.electronAffinity !== null ? `${el.electronAffinity}` : '';
            else if (viewByMode === 'meltingPoint') miniMetricValue = el.meltingPoint ? `${Math.round(el.meltingPoint)}K` : '';
            else if (viewByMode === 'boilingPoint') miniMetricValue = el.boilingPoint ? `${Math.round(el.boilingPoint)}K` : '';
            else if (viewByMode === 'density') miniMetricValue = el.density ? `${el.density}` : '';
            else if (viewByMode === 'valence') miniMetricValue = el.valenceElectrons ? `${el.valenceElectrons}e⁻` : '';
            else if (viewByMode === 'oxidation') miniMetricValue = el.oxidationStates ? el.oxidationStates.slice(0, 2).join(',') : '';

            // Visual radius circle bubble ratio if in atomicRadius mode
            const radiusScaleRatio = el.atomicRadius ? Math.max(0.3, el.atomicRadius / 260) : 0.5;

            return (
              <div
                key={el.number}
                onClick={() => handleTileClick(el)}
                style={{
                  ...gridStyle,
                  backgroundColor: bgColor,
                  borderColor: el.colorHex ? `${el.colorHex}66` : 'rgba(255,255,255,0.1)'
                }}
                className={`p-1 sm:p-1.5 rounded-xl border transition-all duration-200 cursor-pointer flex flex-col justify-between select-none relative group min-h-[56px] sm:min-h-[64px] ${
                  isMatched
                    ? 'opacity-100 hover:scale-105 hover:z-20 hover:shadow-xl hover:border-cyan-400'
                    : 'opacity-20 pointer-events-none'
                }`}
              >
                {/* Header: Atomic Number & Mini Metric */}
                <div className="flex items-center justify-between text-[9px] font-mono leading-none">
                  <span className="text-slate-400 font-bold">{el.number}</span>
                  {miniMetricValue ? (
                    <span className="text-[8px] font-bold text-cyan-300 font-mono truncate max-w-[32px]">
                      {miniMetricValue}
                    </span>
                  ) : (
                    <span className="text-[8px] text-slate-500 font-mono">
                      {typeof el.atomicMass === 'number' ? el.atomicMass.toFixed(1) : ''}
                    </span>
                  )}
                </div>

                {/* Center: Symbol & Dynamic Atomic Radius Visual Circle if mode is atomicRadius */}
                <div className="flex flex-col items-center justify-center relative py-0.5">
                  {viewByMode === 'atomicRadius' && el.atomicRadius && (
                    <div
                      className="absolute rounded-full border border-cyan-400/40 pointer-events-none transition-all duration-300 opacity-40 group-hover:opacity-80"
                      style={{
                        width: `${radiusScaleRatio * 32}px`,
                        height: `${radiusScaleRatio * 32}px`,
                        backgroundColor: 'rgba(56, 189, 248, 0.15)'
                      }}
                    />
                  )}
                  <span className="text-base sm:text-lg font-bold font-display-periodic text-white leading-none tracking-tight">
                    {el.symbol}
                  </span>
                </div>

                {/* Footer: Name & Phase Dot */}
                <div className="flex items-center justify-between text-[8px] font-mono leading-none">
                  <span className="text-slate-300 truncate max-w-[42px]">{el.name}</span>
                  <span
                    className="w-1.5 h-1.5 rounded-full shrink-0"
                    title={`State at ${tempC}°C: ${state}`}
                    style={{
                      backgroundColor:
                        state === 'gas' ? '#ec4899' : state === 'liquid' ? '#0ea5e9' : '#64748b'
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Group / Period Inspector Drawer */}
      {(inspectedGroup !== null || inspectedPeriod !== null) && (
        <div className="max-w-[1440px] mx-auto p-5 rounded-3xl bg-[#090d16] border border-cyan-500/40 backdrop-blur-2xl shadow-2xl space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400">
                <Compass className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-display-periodic">
                  {inspectedGroup !== null
                    ? `Group ${inspectedGroup}: ${getGroupDetails(inspectedGroup).name}`
                    : `Period ${inspectedPeriod}: Quantum Principal Shell n=${inspectedPeriod}`}
                </h3>
                <p className="text-xs text-slate-400">
                  {inspectedGroup !== null
                    ? `Valence Config: ${getGroupDetails(inspectedGroup).valence}`
                    : `Total Elements in Shell: ${ALL_118_ELEMENTS.filter((e) => e.period === inspectedPeriod).length}`}
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                setInspectedGroup(null);
                setInspectedPeriod(null);
              }}
              className="p-1.5 rounded-xl bg-white/[0.05] text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-slate-300 leading-relaxed">
            {inspectedGroup !== null
              ? getGroupDetails(inspectedGroup).behavior
              : `Period ${inspectedPeriod} corresponds to filling the n=${inspectedPeriod} principal shell. As Z increases across this period, atomic radius steadily decreases due to rising effective nuclear charge Z_eff, while ionization energy and Pauling electronegativity steadily increase.`}
          </p>

          {/* Elements list in this Group/Period */}
          <div className="flex flex-wrap gap-2 pt-2">
            {ALL_118_ELEMENTS.filter(
              (e) => (inspectedGroup !== null ? e.group === inspectedGroup : e.period === inspectedPeriod)
            ).map((el) => (
              <button
                key={el.number}
                onClick={() => handleTileClick(el)}
                className="px-3 py-2 rounded-xl bg-white/[0.03] border border-white/10 hover:border-cyan-400 hover:bg-cyan-500/20 transition-all flex items-center gap-2 text-white"
              >
                <span className="text-[10px] text-slate-400">{el.number}</span>
                <span className="font-bold text-cyan-300">{el.symbol}</span>
                <span className="text-slate-300 text-[11px]">{el.name}</span>
                <span className="text-[10px] text-slate-500">{el.block}-block</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* "Why Does This Trend Occur?" Detailed Modal */}
      {activeTrendWhy && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-xl rounded-3xl bg-[#090d16] border border-cyan-500/40 p-6 space-y-4 shadow-2xl font-mono text-xs text-slate-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/40">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    {trendExplanations[activeTrendWhy]?.title} Analysis
                  </h3>
                  <span className="text-[10px] text-cyan-300">Coulombic & Quantum Mechanical Basis</span>
                </div>
              </div>
              <button
                onClick={() => setActiveTrendWhy(null)}
                className="p-1.5 rounded-xl bg-white/[0.05] text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 pt-2 text-slate-300 leading-relaxed">
              <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/5 space-y-1">
                <span className="text-cyan-300 font-bold uppercase text-[10px]">CORE TREND VECTOR:</span>
                <p className="text-white font-bold">{trendExplanations[activeTrendWhy]?.trend}</p>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/5 space-y-1">
                <span className="text-cyan-300 font-bold uppercase text-[10px]">PHYSICAL MECHANISM:</span>
                <p>{trendExplanations[activeTrendWhy]?.why}</p>
              </div>

              {trendExplanations[activeTrendWhy]?.equation && (
                <div className="p-3.5 rounded-2xl bg-cyan-950/20 border border-cyan-500/20 space-y-1.5 text-center overflow-x-auto">
                  <span className="text-cyan-400 font-bold uppercase text-[10px] block">GOVERNING PHYSICAL FORMULATION:</span>
                  <LatexRenderer latex={trendExplanations[activeTrendWhy].equation} displayMode={true} className="text-cyan-300 text-xs sm:text-sm" />
                </div>
              )}

              <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/5 space-y-1">
                <span className="text-orange-300 font-bold uppercase text-[10px]">NOTABLE ANOMALIES:</span>
                <p className="text-slate-300">{trendExplanations[activeTrendWhy]?.anomaly}</p>
              </div>
            </div>

            <button
              onClick={() => setActiveTrendWhy(null)}
              className="w-full py-2.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 font-bold transition-all"
            >
              Close Trend Explainer
            </button>
          </div>
        </div>
      )}

      {/* Element Observatory Modal */}
      {activeElement && (
        <ElementObservatoryModal
          element={activeElement}
          isOpen={isObservatoryOpen}
          onClose={() => setIsObservatoryOpen(false)}
          onSelectElement={(el) => setActiveElement(el)}
          onNavigate={onNavigate}
        />
      )}

      {/* Multi-Element Comparison Modal */}
      <ElementComparisonModal
        isOpen={isComparisonOpen}
        onClose={() => setIsComparisonOpen(false)}
        initialElements={activeElement ? [activeElement] : []}
        onSelectElement={(el) => {
          setActiveElement(el);
          setIsObservatoryOpen(true);
        }}
      />

      {/* Periodic Trend Path Visualizer Modal */}
      <PeriodicTrendPathModal
        isOpen={isTrendPathOpen}
        onClose={() => setIsTrendPathOpen(false)}
        onSelectElement={(el) => {
          setActiveElement(el);
          setIsObservatoryOpen(true);
        }}
      />
    </div>
  );
};
