import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  BookOpen,
  Library,
  Bookmark,
  Search,
  ChevronRight,
  ExternalLink,
  Award,
  Sparkles,
  X,
  Clock,
  Layers,
  FlaskConical,
  Atom,
  Eye,
  Copy,
  Check,
  ShieldAlert,
  Activity,
  FileText,
  HelpCircle,
  Maximize2
} from 'lucide-react';
import { NavigationTab } from '../../types';
import { ModuleThematicBackdrop } from '../common/ModuleThematicBackdrop';
import { LatexRenderer } from '../common/LatexRenderer';

export interface ArchivalBook {
  id: string;
  category: 'chemists' | 'discoveries' | 'experiments' | 'models' | 'laws' | 'reactions' | 'molecules' | 'instruments' | 'nobel' | 'tables';
  categoryLabel: string;
  title: string;
  subtitle: string;
  authorOrScientist: string;
  year: string;
  spineColor: string;
  accentGold?: boolean;
  coverImage?: string;
  imageCaption?: string;
  imageAttribution: string;
  historicalOverview: string;
  manuscriptExcerpt?: string;
  keyContributions: string[];
  scientificImpact: string;
  equationsOrPrinciples?: string[];
  relatedLab: NavigationTab;
}

export const ARCHIVAL_LIBRARY_COLLECTION: ArchivalBook[] = [
  {
    id: 'lavoisier-1789',
    category: 'chemists',
    categoryLabel: 'Famous Chemists',
    title: 'Traité Élémentaire de Chimie',
    subtitle: 'The Birth of Quantitative Modern Chemistry',
    authorOrScientist: 'Antoine-Laurent de Lavoisier',
    year: '1789',
    spineColor: '#78350f',
    accentGold: true,
    coverImage: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6c/Antoine_lavoisier_color.jpg/512px-Antoine_lavoisier_color.jpg',
    imageCaption: 'Portrait of Antoine Lavoisier, pioneer of modern chemistry',
    imageAttribution: 'Image source: Wikimedia Commons / Public Domain (Louis-Jean Desprez / Jacques-Louis David)',
    historicalOverview: 'Antoine Lavoisier revolutionized chemistry by replacing the flawed phlogiston theory with oxygen combustion and establishing the Law of Conservation of Mass: in a closed system, matter is neither created nor destroyed during chemical transformations.',
    manuscriptExcerpt: '"Nothing is created, either in the operations of art or in nature, and, as a principle, in every operation there is an equal quantity of matter before and after the operation."',
    keyContributions: [
      'Disproved Phlogiston and named Oxygen and Hydrogen',
      'Formulated the Law of Conservation of Mass in closed sealed vessels',
      'Created the first systematic chemical nomenclature table',
      'Transformed qualitative alchemy into strict quantitative stoichiometry'
    ],
    scientificImpact: 'Laid the mathematical foundation of chemical equations and stoichiometry used globally today.',
    equationsOrPrinciples: ['\\sum m_{\\text{reactants}} = \\sum m_{\\text{products}}', '2\\text{H}_2 + \\text{O}_2 \\longrightarrow 2\\text{H}_2\\text{O}'],
    relatedLab: 'stoichiometry'
  },
  {
    id: 'dalton-1803',
    category: 'chemists',
    categoryLabel: 'Famous Chemists',
    title: 'A New System of Chemical Philosophy',
    subtitle: 'Indivisible Atoms & Multiple Proportions',
    authorOrScientist: 'John Dalton',
    year: '1803',
    spineColor: '#1e3a8a',
    accentGold: true,
    coverImage: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/John_Dalton_by_Thomas_Phillips.jpg/512px-John_Dalton_by_Thomas_Phillips.jpg',
    imageCaption: 'John Dalton portrait by Thomas Phillips (1835)',
    imageAttribution: 'Image source: Wikimedia Commons / Public Domain (National Portrait Gallery, London)',
    historicalOverview: 'John Dalton proposed the first modern atomic theory, asserting that all chemical elements are composed of unique, indivisible spherical particles (atoms) with characteristic atomic weights that combine in simple integer ratios.',
    manuscriptExcerpt: '"Matter, though divisible in an extreme degree, is nevertheless not infinitely divisible. There must be some point beyond which we cannot go in the division of matter."',
    keyContributions: [
      'Postulated that elements consist of identical atoms of uniform mass',
      'Formulated the Law of Multiple Proportions (e.g. CO vs CO₂)',
      'Published the first table of relative atomic weights (setting H = 1)',
      'Introduced early circular elemental glyphs and symbols'
    ],
    scientificImpact: 'Provided the physical framework for chemical combination and molecular stoichiometry.',
    equationsOrPrinciples: ['\\frac{m_{B}^{(1)}}{m_{B}^{(2)}} = \\frac{p}{q} \\in \\mathbb{Q} \\quad (\\text{Law of Multiple Proportions})'],
    relatedLab: 'atomic-structure'
  },
  {
    id: 'mendeleev-1869',
    category: 'discoveries',
    categoryLabel: 'Milestone Discoveries',
    title: 'The Principles of Chemistry',
    subtitle: 'Discovery of the Periodic Law & Elemental Gaps',
    authorOrScientist: 'Dmitri Ivanovich Mendeleev',
    year: '1869',
    spineColor: '#064e3b',
    accentGold: true,
    coverImage: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c8/Dmitri_Mendeleev_1890s.jpg/512px-Dmitri_Mendeleev_1890s.jpg',
    imageCaption: 'Dmitri Mendeleev in the 1890s',
    imageAttribution: 'Image source: Wikimedia Commons / Public Domain',
    historicalOverview: 'While writing his textbook in Saint Petersburg, Mendeleev organized 63 known elements by atomic weight and recurring valence properties. He boldly left empty gaps, predicting the exact masses and chemical properties of undiscovered elements like Gallium (eka-aluminum), Scandium (eka-boron), and Germanium (eka-silicon).',
    manuscriptExcerpt: '"The elements, if arranged according to their atomic weights, exhibit an evident periodicity of properties."',
    keyContributions: [
      'Formulated the Periodic Law governing all elemental behavior',
      'Corrected erroneous atomic masses of known elements like Uranium',
      'Accurately predicted properties of Gallium and Germanium decades before discovery',
      'Organized elements into periodic groups by valence and oxidation state'
    ],
    scientificImpact: 'The Periodic Table remains the supreme organizational cornerstone of all physical and chemical sciences.',
    equationsOrPrinciples: ['\\text{Property}(Z) = f(\\text{Electronic Valence Configuration})', 'Z \\implies \\text{Periodic Recurrence of Valence States}'],
    relatedLab: 'periodic-table'
  },
  {
    id: 'curie-1898',
    category: 'chemists',
    categoryLabel: 'Famous Chemists',
    title: 'Researches on Radioactive Substances',
    subtitle: 'Isolation of Polonium, Radium & Radioactivity',
    authorOrScientist: 'Marie Skłodowska-Curie & Pierre Curie',
    year: '1898',
    spineColor: '#581c87',
    accentGold: true,
    coverImage: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c8/Marie_Curie_c._1920s.jpg/512px-Marie_Curie_c._1920s.jpg',
    imageCaption: 'Marie Curie in her laboratory (circa 1920s)',
    imageAttribution: 'Image source: Wikimedia Commons / Public Domain (Gallica / BnF)',
    historicalOverview: 'Working in an unheated shed with tons of pitchblende ore, Marie and Pierre Curie discovered that pitchblende was vastly more active than pure uranium. Through fractional crystallization, they isolated two new radioactive elements: Polonium (named after Poland) and Radium. Marie Curie remains the only person to win Nobel Prizes in two distinct scientific disciplines (Physics 1903, Chemistry 1911).',
    manuscriptExcerpt: '"I was taught that the way of progress was neither swift nor easy... Radioactivity is an atomic property of uranium and thorium."',
    keyContributions: [
      'Coined the term "Radioactivity" and proved it originated within the atom itself',
      'Isolated pure radium chloride and metallic radium',
      'Pioneered radiation treatment for oncology during World War I',
      'Awarded Nobel Prize in Physics (1903) and Nobel Prize in Chemistry (1911)'
    ],
    scientificImpact: 'Demolished the concept of eternal, immutable atoms and opened nuclear physics and medicine.',
    equationsOrPrinciples: ['^{226}_{88}\\text{Ra} \\longrightarrow ^{222}_{86}\\text{Rn} + ^{4}_{2}\\alpha + \\gamma'],
    relatedLab: 'nuclear-chemistry'
  },
  {
    id: 'rutherford-1911',
    category: 'experiments',
    categoryLabel: 'Classic Experiments',
    title: 'The Scattering of α and β Particles by Matter',
    subtitle: 'The Gold Foil Experiment & The Atomic Nucleus',
    authorOrScientist: 'Ernest Rutherford, Geiger & Marsden',
    year: '1911',
    spineColor: '#831843',
    accentGold: true,
    coverImage: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Ernest_Rutherford_1908.jpg/512px-Ernest_Rutherford_1908.jpg',
    imageCaption: 'Ernest Rutherford, Nobel Laureate in Chemistry 1908',
    imageAttribution: 'Image source: Wikimedia Commons / Public Domain (Bain News Service / Library of Congress)',
    historicalOverview: 'Rutherford directed alpha particles at ultra-thin gold foil (~400 nm). While 99.9% passed straight through, approximately 1 in 8,000 deflected backwards at angles greater than 90°. Rutherford famously noted it was as if a 15-inch artillery shell fired at tissue paper bounced back.',
    manuscriptExcerpt: '"It was quite the most incredible event that has ever happened to me in my life... It was as if you fired a 15-inch shell at a piece of tissue paper and it came back and hit you."',
    keyContributions: [
      'Disproved Thomson\'s diffuse Plum Pudding model',
      'Discovered the dense, positively charged atomic nucleus (< 10⁻¹⁴ m)',
      'Demonstrated that atoms are over 99.999% empty space',
      'Calculated nuclear cross-section via Coulomb electrostatic scattering'
    ],
    scientificImpact: 'Established the planetary/nuclear atom model, subsequently refined by Niels Bohr with quantum mechanics.',
    equationsOrPrinciples: ['\\frac{d\\sigma}{d\\Omega} = \\left( \\frac{z Z e^2}{4\\pi\\varepsilon_0 \\cdot 4E} \\right)^2 \\frac{1}{\\sin^4(\\theta/2)}'],
    relatedLab: 'atomic-structure'
  },
  {
    id: 'bohr-1913',
    category: 'models',
    categoryLabel: 'Historical Models',
    title: 'On the Constitution of Atoms and Molecules',
    subtitle: 'Quantized Angular Momentum & Rydberg Spectral Series',
    authorOrScientist: 'Niels Bohr',
    year: '1913',
    spineColor: '#1e293b',
    accentGold: true,
    coverImage: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/Niels_Bohr_Date_Unverified_circa_1922.jpg/512px-Niels_Bohr_Date_Unverified_circa_1922.jpg',
    imageCaption: 'Niels Bohr around 1922 (Nobel Prize in Physics)',
    imageAttribution: 'Image source: Wikimedia Commons / Public Domain (American Institute of Physics)',
    historicalOverview: 'Niels Bohr resolved classical electrodynamic collapse by quantizing electron orbits: electrons occupy non-radiating stationary states with angular momentum L = nℏ. Photon emission or absorption occurs only when jumping between discrete energy rungs.',
    manuscriptExcerpt: '"The electron of the hydrogen atom revolves around the nucleus only in certain discrete circular orbits where angular momentum is an integral multiple of h/2π."',
    keyContributions: [
      'Derived Rydberg hydrogen spectral formula analytically from fundamental constants',
      'Calculated the Bohr radius of ground state hydrogen: a₀ ≈ 0.529 Å',
      'Explained emission and absorption line spectra (Lyman, Balmer, Paschen)',
      'Introduced the correspondence principle bridging quantum and classical mechanics'
    ],
    scientificImpact: 'Formed the foundation of modern spectroscopy and early quantum physics.',
    equationsOrPrinciples: ['E_n = -\\frac{13.6 \\text{ eV}}{n^2}', '\\Delta E = h\\nu = \\frac{hc}{\\lambda}'],
    relatedLab: 'atomic-spectra'
  },
  {
    id: 'kekule-benzene-1865',
    category: 'molecules',
    categoryLabel: 'Important Molecules',
    title: 'Sur la Constitution des Substances Aromatiques',
    subtitle: 'The Hexagonal Ring Structure of Benzene (C₆H₆)',
    authorOrScientist: 'August Kekulé',
    year: '1865',
    spineColor: '#7c2d12',
    accentGold: true,
    coverImage: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Benzol_Kekule.svg/512px-Benzol_Kekule.svg.png',
    imageCaption: 'Historical 1865 structural formulas of Benzene by August Kekulé',
    imageAttribution: 'Image source: Wikimedia Commons / Public Domain (Bulletin de la Société Chimique de Paris)',
    historicalOverview: 'Kekulé solved the long-standing puzzle of benzene\'s stability and equal carbon valencies by envisioning six carbon atoms joined in a closed ring with alternating single and double bonds, famously inspired by a daydream of the Ouroboros snake seizing its own tail.',
    manuscriptExcerpt: '"I turned my chair to the fire and dozed... Look! One of the snakes had seized hold of its own tail, and the form whirled mockingly before my eyes... Let us learn to dream, gentlemen, then perhaps we shall find the truth."',
    keyContributions: [
      'Proposed the cyclic 6-carbon ring with alternating π bonds',
      'Explained the absence of alkene-like addition reactions due to aromatic resonance',
      'Pioneered aromatic organic chemistry and synthetic dye industries',
      'Precursor to modern Hückel 4n+2 delocalized aromaticity'
    ],
    scientificImpact: 'Spawned the entire modern petrochemical, polymer, and pharmaceutical industry.',
    equationsOrPrinciples: ['\\text{Aromaticity: } 4n + 2 \\; \\pi\\text{-electrons (where } n=1 \\text{ for benzene)}'],
    relatedLab: 'organic-chem'
  },
  {
    id: 'franklin-dna-1953',
    category: 'discoveries',
    categoryLabel: 'Milestone Discoveries',
    title: 'Photo 51 & The Molecular Structure of Nucleic Acids',
    subtitle: 'X-Ray Crystallography of B-Form Double Helix DNA',
    authorOrScientist: 'Rosalind Franklin, Raymond Gosling, Watson & Crick',
    year: '1953',
    spineColor: '#14532d',
    accentGold: true,
    coverImage: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Photo_51_x-ray_diffraction_image.jpg/512px-Photo_51_x-ray_diffraction_image.jpg',
    imageCaption: 'Photo 51: Rosalind Franklin\'s X-ray diffraction of hydrated B-DNA (1952)',
    imageAttribution: 'Image source: Wikimedia Commons / Public Domain (King\'s College London Archive)',
    historicalOverview: 'Rosalind Franklin captured the world\'s clearest X-ray diffraction photograph (Photo 51) of crystalline B-form DNA. The distinct "X" pattern and missing 4th layer line mathematically proved an antiparallel double-helix with external phosphate backbones and inward-pointing purine-pyrimidine base pairs.',
    manuscriptExcerpt: '"The results suggest a helical structure (which must be very closely packed) containing probably 2, 3 or 4 coaxial nucleic acid chains."',
    keyContributions: [
      'Obtained the high-resolution X-ray diffraction data proving the double helix',
      'Calculated the exact helical pitch (34 Å per turn) and diameter (20 Å)',
      'Identified the hydrophilic phosphate backbone located on the exterior',
      'Decoded the molecular machinery of genetic inheritance and replication'
    ],
    scientificImpact: 'Revealed the chemical mechanism of biological life, genetic code, and modern biotechnology.',
    equationsOrPrinciples: ['\\text{Base Pairing: } A=T \\text{ (2 H-bonds)}, \\quad G\\equiv C \\text{ (3 H-bonds)}'],
    relatedLab: 'spectroscopy-suite'
  },
  {
    id: 'pauling-1931',
    category: 'laws',
    categoryLabel: 'Chemistry Laws',
    title: 'The Nature of the Chemical Bond',
    subtitle: 'Orbital Hybridization, Electronegativity & Resonance',
    authorOrScientist: 'Linus Pauling',
    year: '1931',
    spineColor: '#312e81',
    accentGold: true,
    coverImage: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/58/Linus_Pauling_1954.jpg/512px-Linus_Pauling_1954.jpg',
    imageCaption: 'Linus Pauling receiving the 1954 Nobel Prize in Chemistry',
    imageAttribution: 'Image source: Wikimedia Commons / Public Domain (Nobel Foundation Archive)',
    historicalOverview: 'Linus Pauling applied quantum mechanics to explain molecular geometry. He introduced the concepts of orbital hybridization ($sp, sp^2, sp^3$), the electronegativity scale for bond polarity, and quantum resonance structures to explain molecules that cannot be represented by a single Lewis structure.',
    manuscriptExcerpt: '"A chemical bond between two atoms exists if the forces between them lead to the formation of an aggregate with sufficient stability to make it convenient for the chemist to consider it as an independent molecular species."',
    keyContributions: [
      'Introduced orbital hybridization to explain carbon tetrahedral 109.5° geometry',
      'Constructed the Pauling Electronegativity Scale (Fluorine = 4.0)',
      'Developed resonance theory and partial covalent/ionic character',
      'Won the 1954 Nobel Prize in Chemistry and 1962 Nobel Peace Prize'
    ],
    scientificImpact: 'Formed the universal language of structural chemistry, chemical bonding, and protein alpha-helices.',
    equationsOrPrinciples: ['\\Delta \\chi = |\\chi_A - \\chi_B|', '\\% \\text{ Ionic Character} = 1 - e^{-0.25(\\chi_A - \\chi_B)^2}'],
    relatedLab: 'vsepr-lab'
  },
  {
    id: 'diels-alder-1928',
    category: 'reactions',
    categoryLabel: 'Named Reactions',
    title: 'Synthesen in der hydroaromatischen Reihe',
    subtitle: '[4+2] Concerted Cycloaddition for 6-Membered Rings',
    authorOrScientist: 'Otto Diels & Kurt Alder',
    year: '1928',
    spineColor: '#701a75',
    accentGold: true,
    coverImage: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/Diels_Alder_Reaction.svg/512px-Diels_Alder_Reaction.svg.png',
    imageCaption: 'Concerted [4+2] pericyclic cycloaddition mechanism',
    imageAttribution: 'Image source: Wikimedia Commons / Public Domain',
    historicalOverview: 'Otto Diels and Kurt Alder discovered that a conjugated 1,3-diene reacts with an alkene (dienophile) in a single concerted pericyclic step to create a cyclohexene ring with stereo-specific endo/exo control, earning them the 1950 Nobel Prize in Chemistry.',
    manuscriptExcerpt: '"This reaction offers a uniquely smooth synthesis of hydroaromatic ring systems without harsh reagents or complex side reactions."',
    keyContributions: [
      'Discovered the quintessential pericyclic [4+2] cycloaddition',
      'Established the Alder Endo Rule governing stereochemical outcomes',
      'Enabled total synthesis of steroids, prostaglandins, and complex natural products',
      'Awarded the 1950 Nobel Prize in Chemistry'
    ],
    scientificImpact: 'The most powerful ring-forming reaction in organic synthesis and pharmaceutical drug manufacturing.',
    equationsOrPrinciples: ['\\text{Diene (4}\\pi\\text{)} + \\text{Dienophile (2}\\pi\\text{)} \\xrightarrow{\\Delta} \\text{Cyclohexene}'],
    relatedLab: 'advanced-organic'
  },
  {
    id: 'spectrometer-1940',
    category: 'instruments',
    categoryLabel: 'Scientific Instruments',
    title: 'The Beckman DU Spectrophotometer',
    subtitle: 'From Prisms to Quantitative Optical Absorbance',
    authorOrScientist: 'Arnold O. Beckman',
    year: '1940',
    spineColor: '#0f766e',
    accentGold: true,
    coverImage: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/Beckman_DU_Spectrophotometer.jpg/512px-Beckman_DU_Spectrophotometer.jpg',
    imageCaption: 'Historic Beckman DU Quartz Spectrophotometer (1941)',
    imageAttribution: 'Image source: Wikimedia Commons / CC-BY-SA-3.0 (Science History Institute)',
    historicalOverview: 'Prior to Arnold Beckman\'s quartz prism DU spectrophotometer, measuring the ultraviolet and visible absorption of a single chemical sample took weeks of tedious chemical titration. Beckman\'s device reduced the process to minutes with precision photo-multipliers, transforming industrial biochemistry, penicillin quality control, and molecular assays.',
    manuscriptExcerpt: '"A rugged, high-precision photoelectric instrument that measures spectral transmittance and optical density from 200 to 1000 nm with 0.1% accuracy."',
    keyContributions: [
      'Pioneered precision UV-Vis spectrophotometry for routine laboratories',
      'Applied the Beer-Lambert Law: A = ε · c · l for quantitative concentration analysis',
      'Enabled rapid penicillin yield testing during World War II',
      'Named by Chemical & Engineering News as one of the greatest scientific instruments of all time'
    ],
    scientificImpact: 'Standardized optical molecular analysis across global clinical, analytical, and academic labs.',
    equationsOrPrinciples: ['A = -\\log_{10}\\left(\\frac{I}{I_0}\\right) = \\varepsilon \\cdot c \\cdot l'],
    relatedLab: 'spectroscopy-suite'
  },
  {
    id: 'quantum-dots-2023',
    category: 'nobel',
    categoryLabel: 'Nobel Chemistry',
    title: 'Discovery & Chemical Synthesis of Quantum Dots',
    subtitle: 'Size-Dependent Quantum Confinement in Nanocrystals',
    authorOrScientist: 'Moungi Bawendi, Louis Brus & Alexei Ekimov',
    year: '2023',
    spineColor: '#1e1b4b',
    accentGold: true,
    coverImage: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/Colloidal_quantum_dots_under_UV_light.jpg/512px-Colloidal_quantum_dots_under_UV_light.jpg',
    imageCaption: 'Fluorescent colloidal semiconductor quantum dots under UV excitation',
    imageAttribution: 'Image source: Wikimedia Commons / CC-BY-SA-3.0 (Antipoff)',
    historicalOverview: 'Ekimov and Brus independently demonstrated that semiconductor nanocrystals exhibit quantum confinement: shrinking the physical particle size widens the optical band gap, tuning its emitted color across the entire visible spectrum. Bawendi subsequently developed the hot-injection chemical synthesis yielding near-perfect, monodisperse nanocrystals.',
    manuscriptExcerpt: '"The fundamental properties of matter are suddenly dictated not just by atomic element composition, but by physical nanoscale particle dimensions."',
    keyContributions: [
      'Proved quantum confinement in semiconductor crystallites',
      'Developed high-yield organometallic hot-injection colloidal synthesis',
      'Enabled ultra-vibrant QLED television screens, solar harvesting, and fluorescent bio-markers',
      'Awarded the 2023 Nobel Prize in Chemistry'
    ],
    scientificImpact: 'Spawned the entire discipline of colloidal nanochemistry and nanoscale quantum engineering.',
    equationsOrPrinciples: ['E_{\\text{gap}}(R) = E_{\\text{bulk}} + \\frac{\\hbar^2 \\pi^2}{2m^* R^2} - \\frac{1.8 e^2}{4\\pi\\varepsilon_0 \\varepsilon_r R}'],
    relatedLab: 'quantum-lab'
  }
];

interface ScientificArchiveViewProps {
  onNavigate: (tab: NavigationTab) => void;
}

export const ScientificArchiveView: React.FC<ScientificArchiveViewProps> = ({ onNavigate }) => {
  const [selectedWing, setSelectedWing] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [openedBook, setOpenedBook] = useState<ArchivalBook | null>(null);
  const [copiedEquation, setCopiedEquation] = useState<string | null>(null);

  const wings = [
    { id: 'all', label: 'All Library Wings', count: ARCHIVAL_LIBRARY_COLLECTION.length },
    { id: 'chemists', label: 'Famous Chemists', count: ARCHIVAL_LIBRARY_COLLECTION.filter(b => b.category === 'chemists').length },
    { id: 'discoveries', label: 'Milestone Discoveries', count: ARCHIVAL_LIBRARY_COLLECTION.filter(b => b.category === 'discoveries').length },
    { id: 'experiments', label: 'Classic Experiments', count: ARCHIVAL_LIBRARY_COLLECTION.filter(b => b.category === 'experiments').length },
    { id: 'models', label: 'Historical Models', count: ARCHIVAL_LIBRARY_COLLECTION.filter(b => b.category === 'models').length },
    { id: 'laws', label: 'Chemistry Laws', count: ARCHIVAL_LIBRARY_COLLECTION.filter(b => b.category === 'laws').length },
    { id: 'reactions', label: 'Named Reactions', count: ARCHIVAL_LIBRARY_COLLECTION.filter(b => b.category === 'reactions').length },
    { id: 'molecules', label: 'Important Molecules', count: ARCHIVAL_LIBRARY_COLLECTION.filter(b => b.category === 'molecules').length },
    { id: 'instruments', label: 'Scientific Instruments', count: ARCHIVAL_LIBRARY_COLLECTION.filter(b => b.category === 'instruments').length },
    { id: 'nobel', label: 'Nobel Laureates', count: ARCHIVAL_LIBRARY_COLLECTION.filter(b => b.category === 'nobel').length }
  ];

  const filteredBooks = ARCHIVAL_LIBRARY_COLLECTION.filter((book) => {
    const matchesWing = selectedWing === 'all' || book.category === selectedWing;
    const matchesSearch =
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.authorOrScientist.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.historicalOverview.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.year.includes(searchQuery);
    return matchesWing && matchesSearch;
  });

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedEquation(id);
    setTimeout(() => setCopiedEquation(null), 2000);
  };

  return (
    <ModuleThematicBackdrop theme="library">
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-300">
        {/* Editorial Library Banner */}
        <div className="p-6 sm:p-10 rounded-3xl bg-gradient-to-r from-[#1e150b] via-[#120e09] to-[#1a1208] border border-amber-500/30 shadow-2xl relative overflow-hidden">
          {/* Subtle Warm Library Lighting Accent */}
          <div className="absolute top-0 right-1/4 w-96 h-40 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
          
          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-3">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 text-xs font-mono font-bold tracking-wider">
                <Library className="w-4 h-4 text-amber-400" />
                <span>DIGITAL CHEMISTRY LIBRARY & ARCHIVE</span>
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight font-library">
                The Historical Codex & Rare Manuscripts
              </h1>
              <p className="text-sm sm:text-base text-amber-100/80 font-editorial max-w-3xl leading-relaxed italic">
                Step into the grand archival reading room. Select any leather-bound codex from the scientific shelves to inspect historical portraits, primary manuscript excerpts, foundational experiments, and verified public-domain citations.
              </p>
            </div>

            {/* Quick Search in Library */}
            <div className="relative min-w-[280px] shrink-0 font-sans">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search authors, discoveries, years..."
                className="w-full pl-10 pr-4 py-3 rounded-2xl bg-black/40 border border-amber-500/30 text-amber-100 placeholder-amber-200/40 text-xs focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400/50 backdrop-blur-md"
              />
              <Search className="w-4 h-4 text-amber-400/60 absolute left-3.5 top-1/2 -translate-y-1/2" />
            </div>
          </div>
        </div>

        {/* Library Wing Category Selector */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-amber-500/20">
          {wings.map((wing) => {
            const isSelected = selectedWing === wing.id;
            return (
              <button
                key={wing.id}
                onClick={() => setSelectedWing(wing.id)}
                className={`px-4 py-2 rounded-2xl text-xs font-medium whitespace-nowrap transition-all flex items-center gap-2 ${
                  isSelected
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-lg shadow-amber-500/20 scale-[1.02]'
                    : 'bg-[#15100a]/80 text-amber-200/70 hover:text-amber-100 hover:bg-[#201810] border border-amber-900/40'
                }`}
              >
                <span>{wing.label}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                    isSelected ? 'bg-black/20 text-slate-950 font-bold' : 'bg-amber-500/10 text-amber-400'
                  }`}
                >
                  {wing.count}
                </span>
              </button>
            );
          })}
        </div>

        {/* 📚 INTERACTIVE 3D LIBRARY SHELF */}
        <div className="space-y-6">
          <div className="flex items-center justify-between px-2">
            <div className="flex items-center gap-2 text-xs font-mono text-amber-300/80">
              <Bookmark className="w-4 h-4 text-amber-400" />
              <span>COLLECTION SHELF ({filteredBooks.length} CODICES AVAILABLE — CLICK TO OPEN)</span>
            </div>
            <span className="text-[11px] text-amber-200/50 font-serif italic">Curated & Authenticated with Wikimedia Commons</span>
          </div>

          {/* Wooden / Bronze Archival Shelf Container */}
          <div className="p-6 sm:p-8 rounded-3xl bg-[#110c07]/90 border-2 border-amber-900/40 shadow-2xl relative">
            {/* Shelf Wood Planks Visual Frame */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {filteredBooks.map((book) => {
                const isOpened = openedBook?.id === book.id;
                return (
                  <motion.div
                    key={book.id}
                    whileHover={{ y: -6, scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setOpenedBook(book)}
                    className="cursor-pointer group flex flex-col justify-between p-5 rounded-2xl border transition-all relative overflow-hidden shadow-xl"
                    style={{
                      backgroundColor: `${book.spineColor}25`,
                      borderColor: isOpened ? '#f59e0b' : 'rgba(217, 119, 6, 0.25)',
                      boxShadow: isOpened ? '0 0 25px rgba(245, 158, 11, 0.3)' : '0 10px 20px rgba(0,0,0,0.5)'
                    }}
                  >
                    {/* Golden Book Spine Trim */}
                    <div className="absolute top-0 left-0 bottom-0 w-2.5 bg-gradient-to-r from-amber-600 via-yellow-400 to-amber-700 opacity-75 group-hover:opacity-100" />
                    
                    <div className="pl-3 space-y-3">
                      {/* Top Callout & Year */}
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="px-2 py-0.5 rounded-md bg-black/40 text-amber-300 font-mono font-bold border border-amber-500/20">
                          {book.year}
                        </span>
                        <span className="text-[10px] text-amber-200/60 font-mono uppercase tracking-wider">
                          {book.categoryLabel}
                        </span>
                      </div>

                      {/* Book Title */}
                      <h3 className="text-base sm:text-lg font-bold text-amber-50 group-hover:text-amber-300 transition-colors font-library leading-snug">
                        {book.title}
                      </h3>

                      {/* Author / Scientist */}
                      <div className="text-xs text-amber-200/90 font-editorial italic">
                        By {book.authorOrScientist}
                      </div>

                      {/* Subtitle */}
                      <p className="text-xs text-stone-300/80 font-sans line-clamp-2 leading-relaxed">
                        {book.subtitle}
                      </p>
                    </div>

                    {/* Bottom Shelf Footer */}
                    <div className="pl-3 pt-4 mt-3 border-t border-amber-500/15 flex items-center justify-between text-xs">
                      <span className="text-[11px] text-amber-400/80 font-mono group-hover:text-amber-300 flex items-center gap-1 font-bold">
                        <span>Open Codex</span>
                        <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                      </span>
                      <BookOpen className="w-4 h-4 text-amber-400/60 group-hover:text-amber-300 transition-colors" />
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* Bottom Shelf Wooden Rim */}
            <div className="mt-8 h-3 w-full bg-gradient-to-r from-amber-950 via-[#3d210b] to-amber-950 rounded-full border-t border-amber-500/30 shadow-inner" />
          </div>
        </div>

        {/* 📖 MODAL: THE OPENED CODEX READING DESK */}
        <AnimatePresence>
          {openedBook && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto">
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
                className="w-full max-w-5xl my-auto rounded-3xl bg-[#0f0c08] border-2 border-amber-500/40 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
              >
                {/* Desk Header Bar */}
                <div className="p-4 sm:p-5 bg-gradient-to-r from-[#1f150b] to-[#140e07] border-b border-amber-500/20 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 shrink-0">
                      <BookOpen className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30">
                          {openedBook.year}
                        </span>
                        <span className="text-xs text-amber-200/60 font-mono">
                          {openedBook.categoryLabel}
                        </span>
                      </div>
                      <h2 className="text-lg sm:text-xl font-bold text-white font-library truncate">
                        {openedBook.title}
                      </h2>
                    </div>
                  </div>

                  <button
                    onClick={() => setOpenedBook(null)}
                    className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-stone-400 hover:text-white transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Desk Two-Page Layout Body */}
                <div className="flex-1 overflow-y-auto p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8 text-stone-200 font-sans">
                  {/* Left Column: Historical Image & Source Citation (5 Cols) */}
                  <div className="lg:col-span-5 space-y-5">
                    {/* Archival Framed Portrait / Plate */}
                    {openedBook.coverImage && (
                      <div className="rounded-2xl bg-black/50 border border-amber-500/30 p-2 overflow-hidden shadow-xl space-y-2">
                        <div className="relative rounded-xl overflow-hidden aspect-[4/3] bg-stone-900 flex items-center justify-center">
                          <img
                            src={openedBook.coverImage}
                            alt={openedBook.title}
                            className="w-full h-full object-contain hover:scale-105 transition-transform duration-500"
                            referrerPolicy="no-referrer"
                            loading="lazy"
                          />
                        </div>
                        {openedBook.imageCaption && (
                          <div className="px-2 text-xs text-amber-200/80 font-editorial italic text-center">
                            {openedBook.imageCaption}
                          </div>
                        )}
                        {/* MANDATORY EXPLICIT WIKIMEDIA SOURCE ATTRIBUTION */}
                        <div className="p-2 rounded-lg bg-black/60 border border-white/5 text-[10px] font-mono text-amber-400/90 text-center leading-tight">
                          {openedBook.imageAttribution}
                        </div>
                      </div>
                    )}

                    {/* Primary Manuscript Quote Box */}
                    {openedBook.manuscriptExcerpt && (
                      <div className="p-5 rounded-2xl bg-[#1a140d]/90 border border-amber-600/30 space-y-2 relative shadow-inner">
                        <div className="text-[10px] font-mono text-amber-400 uppercase tracking-widest font-bold">
                          Primary Manuscript Excerpt
                        </div>
                        <blockquote className="text-xs sm:text-sm text-amber-100 font-editorial italic leading-relaxed">
                          {openedBook.manuscriptExcerpt}
                        </blockquote>
                        <div className="text-right text-[11px] text-amber-300/80 font-serif">
                          — {openedBook.authorOrScientist} ({openedBook.year})
                        </div>
                      </div>
                    )}

                    {/* Launch Related Laboratory Action */}
                    <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-3">
                      <div>
                        <div className="text-xs font-bold text-amber-300">Explore in 3D Simulator</div>
                        <div className="text-[11px] text-stone-400">Launch the dedicated interactive laboratory</div>
                      </div>
                      <button
                        onClick={() => {
                          setOpenedBook(null);
                          onNavigate(openedBook.relatedLab);
                        }}
                        className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all shadow-md shadow-amber-500/20 shrink-0"
                      >
                        <span>Launch Lab</span>
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Right Column: Historical Overview, Breakthroughs & Equations (7 Cols) */}
                  <div className="lg:col-span-7 space-y-6">
                    {/* Header Details */}
                    <div className="space-y-1 pb-4 border-b border-amber-500/15">
                      <div className="text-xs font-mono text-amber-400 font-bold">
                        Author / Discoverer: {openedBook.authorOrScientist}
                      </div>
                      <h3 className="text-2xl font-bold text-white font-library">
                        {openedBook.subtitle}
                      </h3>
                    </div>

                    {/* Historical Overview */}
                    <div className="space-y-2">
                      <h4 className="text-xs font-mono uppercase tracking-widest text-amber-300 font-bold">
                        Historical Context & Breakthrough
                      </h4>
                      <p className="text-sm text-stone-200 leading-relaxed font-sans">
                        {openedBook.historicalOverview}
                      </p>
                    </div>

                    {/* Key Contributions Checklist */}
                    <div className="space-y-2">
                      <h4 className="text-xs font-mono uppercase tracking-widest text-amber-300 font-bold">
                        Key Scientific Milestones
                      </h4>
                      <ul className="space-y-2 text-xs text-stone-300">
                        {openedBook.keyContributions.map((point, idx) => (
                          <li key={idx} className="flex items-start gap-2.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                            <span className="leading-relaxed">{point}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Mathematical Laws & Formulas */}
                    {openedBook.equationsOrPrinciples && openedBook.equationsOrPrinciples.length > 0 && (
                      <div className="space-y-2">
                        <h4 className="text-xs font-mono uppercase tracking-widest text-amber-300 font-bold">
                          Mathematical Formulation & Equations
                        </h4>
                        <div className="space-y-2">
                          {openedBook.equationsOrPrinciples.map((eq, idx) => (
                            <div
                              key={idx}
                              className="p-3 rounded-xl bg-black/60 border border-amber-500/20 text-amber-200 flex items-center justify-between gap-3 overflow-x-auto"
                            >
                              <div className="flex-1 py-0.5">
                                <LatexRenderer latex={eq} displayMode={false} className="text-amber-200 text-xs sm:text-sm" />
                              </div>
                              <button
                                onClick={() => handleCopy(eq, `eq-${idx}`)}
                                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-stone-400 hover:text-amber-300 transition-colors shrink-0"
                                title="Copy equation"
                              >
                                {copiedEquation === `eq-${idx}` ? (
                                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                                ) : (
                                  <Copy className="w-3.5 h-3.5" />
                                )}
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Enduring Scientific Impact */}
                    <div className="p-4 rounded-2xl bg-[#161009] border border-amber-600/20 space-y-1">
                      <div className="text-[11px] font-mono text-amber-400 font-bold uppercase tracking-wider">
                        Enduring Legacy
                      </div>
                      <p className="text-xs text-stone-300 font-sans leading-relaxed">
                        {openedBook.scientificImpact}
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </ModuleThematicBackdrop>
  );
};
