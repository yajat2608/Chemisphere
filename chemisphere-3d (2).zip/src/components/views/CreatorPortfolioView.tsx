import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Trophy,
  Award,
  GraduationCap,
  Sparkles,
  Bot,
  Cpu,
  Youtube,
  Code2,
  BookOpen,
  Crown,
  Compass,
  Zap,
  Globe,
  ExternalLink,
  Atom,
  CheckCircle2,
  Layers,
  ChevronRight,
  TrendingUp,
  BrainCircuit,
  Film,
  Flame,
  Palette,
  Terminal,
  ShieldAlert,
  ArrowUpRight
} from 'lucide-react';
import { NavigationTab } from '../../types';

interface CreatorPortfolioViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

export const CreatorPortfolioView: React.FC<CreatorPortfolioViewProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'achievements' | 'innovations' | 'creative' | 'skills'>('overview');

  const stats = [
    { label: 'Grade 10 CBSE Board', value: '98%', highlight: 'Gold Academic Standard', icon: GraduationCap, color: 'text-amber-400', border: 'border-amber-500/30', bg: 'bg-amber-500/10' },
    { label: 'School Leadership', value: 'Vice Captain', highlight: 'PM Shri KV Balaghat', icon: Crown, color: 'text-cyan-400', border: 'border-cyan-500/30', bg: 'bg-cyan-500/10' },
    { label: 'National Hackathon', value: 'Zonal Winner', highlight: 'AI Vidyasetu Challenge', icon: Trophy, color: 'text-purple-400', border: 'border-purple-500/30', bg: 'bg-purple-500/10' },
    { label: 'State & National Honor', value: 'Governor Award', highlight: 'Bharat Scouts & Guides', icon: Award, color: 'text-emerald-400', border: 'border-emerald-500/30', bg: 'bg-emerald-500/10' },
  ];

  const institutions = [
    {
      name: 'PM Shri Kendriya Vidyalaya, Balaghat',
      short: 'PM Shri KV Bgt',
      role: 'Class 11 CBSE Science (PCM) • School Vice Captain',
      location: 'Balaghat, Madhya Pradesh, India',
      badge: 'Premier Central School',
      desc: 'Nurturing leadership, national integrity, rigorous science discipline, and inter-school academic excellence.',
      accent: 'from-amber-500/20 to-orange-500/10',
      border: 'border-amber-500/30',
      tagColor: 'text-amber-300 bg-amber-500/10 border-amber-500/20'
    },
    {
      name: 'Infinity Learn',
      short: 'Infinity Learn Scholar',
      role: 'Advanced Science, Competitive STEM & Core Disciplines',
      location: 'National Competitive Learning Platform',
      badge: 'Academic Excellence Track',
      desc: 'Deep problem-solving across Class 11 Chemistry, Physics, and Mathematics with advanced analytical rigor.',
      accent: 'from-cyan-500/20 to-blue-500/10',
      border: 'border-cyan-500/30',
      tagColor: 'text-cyan-300 bg-cyan-500/10 border-cyan-500/20'
    }
  ];

  const achievementsList = [
    {
      title: '98% in Grade 10 CBSE Board Examinations',
      category: 'Academic Milestone',
      body: 'Demonstrated exceptional mastery across Mathematics, Science, and Social Sciences, ranking among top percentile scorers in the region.',
      badge: 'Academic Distinction',
      icon: GraduationCap,
      color: 'text-amber-400'
    },
    {
      title: 'Zonal Winner / Top Performer — AI Vidyasetu National Hackathon',
      category: 'Artificial Intelligence & Robotics',
      body: 'Engineered high-impact computational intelligence prototypes solving real-world challenges through neural automation and ethical AI architectures.',
      badge: 'National Winner',
      icon: BrainCircuit,
      color: 'text-purple-400'
    },
    {
      title: 'Governor Award Recipient — Bharat Scouts and Guides',
      category: 'State & National Leadership',
      body: 'Conferred the prestigious Rajya Puraskar (Governor Award) recognizing disciplined service, outdoor survival excellence, civic leadership, and community development.',
      badge: 'Honorary State Award',
      icon: Award,
      color: 'text-emerald-400'
    },
    {
      title: 'Deen Dayal SPARSH Yojana Scholarship Awardee',
      category: 'National Scholarship (Govt. of India)',
      body: 'Awarded the competitive Ministry of Communications scholarship promoting philately, historical archival research, and socio-cultural preservation.',
      badge: 'National Scholar',
      icon: Trophy,
      color: 'text-cyan-400'
    }
  ];

  const innovations = [
    {
      name: 'Vriddhi-AI (वृद्दि AI)',
      tagline: 'Precision Agri-Tech Intelligence & Autonomous Agribot Concept',
      type: 'Registered Innovation Project',
      icon: Cpu,
      status: 'Active Architecture',
      description:
        'A comprehensive AI-driven smart agriculture ecosystem featuring an automated Agribot concept designed for real-time crop health monitoring, soil chemical profiling (NPK balance & pH sensing), automated irrigation telemetry, and predictive crop disease diagnosis.',
      highlights: [
        'Autonomous Agribot field rover design with multi-sensor telemetry',
        'Computer vision pipelines for leaf blight and nutrient deficiency detection',
        'Localized weather modeling and hyper-targeted resource deployment',
        'Designed to empower sustainable Indian farming communities'
      ],
      tags: ['Agri-Tech', 'Autonomous Agribot', 'Computer Vision', 'Embedded IoT', 'Python']
    },
    {
      name: 'Chemisphere 3D — Quantum Chemical Laboratory OS',
      tagline: 'Interactive 3D Molecular, Orbital, & Thermodynamic Engine',
      type: 'Interactive Scientific Platform',
      icon: Atom,
      status: 'Live & Operational',
      description:
        'A full-stack interactive chemical reasoning and quantum visualization operating system engineered for students worldwide. Synthesizes 118 elements, 3D probability density wavefunctions, VSEPR geometries, organic reaction highways, and autonomous ChemoBot reasoning.',
      highlights: [
        'Volumetric 3D electron cloud probability density manifolds (|ψ|²)',
        'Full 118-element periodic trends heatmap with thermodynamic phase controls',
        'Comprehensive 3D atomic timeline with Dalton, Thomson, Rutherford, Bohr, & Schrödinger',
        'Integrated Physical, Organic, and Stoichiometric calculation suites'
      ],
      tags: ['Three.js', 'React 19', 'Quantum Chemistry', 'TypeScript', 'Tailwind CSS']
    }
  ];

  const mediaProjects = [
    {
      name: '@NUKAIZEN_gx',
      platform: 'YouTube & Digital Production',
      icon: Youtube,
      category: 'Visual Documentaries & Cinematic Edits',
      description:
        'High-production documentary filmmaking, scientific visual storytelling, and aesthetic kinetic typography exploring technology, strategy, philosophy, and creative design.',
      stats: 'Creator & Lead Editor',
      tags: ['Cinematic Editing', 'Motion Graphics', 'Visual Storytelling', 'Documentary Production']
    },
    {
      name: 'Graphic Design & UI/UX Craft',
      platform: 'Digital Art Studios',
      icon: Palette,
      category: 'Visual Identity & Scientific Interfaces',
      description:
        'Crafting modern high-contrast digital layouts, poster art, infographics, and mathematical illustrations tailored for academic and tech initiatives.',
      stats: 'Creative Director',
      tags: ['UI/UX Design', 'Scientific Infographics', 'Vector Art', 'Typography Systems']
    }
  ];

  const skillCategories = [
    {
      category: 'Academic Core (Class 11 CBSE Science)',
      skills: ['Chemistry (Quantum Mechanics, Thermodynamics, Bonding, Organic)', 'Physics (Kinematics, Mechanics, Waves, Gravitation)', 'Mathematics (Calculus Foundations, Trigonometry, Coordinate Geometry)'],
      icon: Atom,
      color: 'text-cyan-400',
      bg: 'bg-cyan-500/10'
    },
    {
      category: 'Programming & Intelligence',
      skills: ['Python Programming', 'Algorithm Design & Data Logic', 'AI/ML Prototyping', 'Interactive Web Development & Three.js'],
      icon: Code2,
      color: 'text-purple-400',
      bg: 'bg-purple-500/10'
    },
    {
      category: 'Strategic & Mental Disciplines',
      skills: ['Competitive Chess Strategies & Tactical Analysis', 'Speedcubing Mastery (WCA 3x3 algorithms)', 'Mathematical Problem Solving & Olympiad Reasoning'],
      icon: Zap,
      color: 'text-amber-400',
      bg: 'bg-amber-500/10'
    },
    {
      category: 'Heritage & Civic Leadership',
      skills: ['Regional Indian History & Archival Philately', 'School Governance & Vice Captaincy', 'Bharat Scouts & Guides Field Leadership'],
      icon: Globe,
      color: 'text-emerald-400',
      bg: 'bg-emerald-500/10'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10 text-slate-100 font-sans">
      {/* Hero Profile Header with Floating Atmospheric Dynamics */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative rounded-3xl bg-gradient-to-b from-[#0e1626]/90 via-[#0a0f1d]/90 to-[#060811]/95 border border-cyan-500/30 p-6 sm:p-10 backdrop-blur-2xl shadow-2xl overflow-hidden"
      >
        {/* Ambient Glows */}
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-purple-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:24px_24px] opacity-10 pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Stylized Creator Identity Badge / Monogram */}
          <motion.div
            initial={{ scale: 0.92, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="lg:col-span-4 flex flex-col items-center"
          >
            <div className="relative group w-64 sm:w-72 aspect-[3/4] rounded-2xl p-1 bg-gradient-to-br from-amber-400/60 via-cyan-400/40 to-purple-500/60 shadow-2xl shadow-cyan-500/20">
              <div className="w-full h-full rounded-[14px] overflow-hidden bg-gradient-to-b from-[#0e1629] via-[#090d18] to-[#04060c] p-6 flex flex-col items-center justify-between relative border border-white/10">
                {/* Background Pattern */}
                <div className="absolute inset-0 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px] opacity-15" />
                <div className="absolute -top-10 -right-10 w-32 h-32 bg-cyan-500/20 rounded-full blur-2xl pointer-events-none" />
                <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-amber-500/20 rounded-full blur-2xl pointer-events-none" />

                {/* Top Badge */}
                <div className="relative z-10 w-full flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold text-amber-300 bg-amber-500/10 px-2.5 py-1 rounded-full border border-amber-500/30">
                    LEAD ARCHITECT
                  </span>
                  <Crown className="w-4 h-4 text-amber-400" />
                </div>

                {/* Center Monogram / Crest */}
                <div className="relative z-10 flex flex-col items-center text-center space-y-3">
                  <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-cyan-500/20 via-purple-500/20 to-amber-500/20 border-2 border-cyan-400/50 flex items-center justify-center shadow-xl shadow-cyan-500/20 group-hover:scale-105 transition-transform duration-500">
                    <span className="text-3xl font-extrabold font-display-periodic tracking-wider text-transparent bg-clip-text bg-gradient-to-br from-cyan-300 via-white to-amber-300">
                      YS
                    </span>
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-white tracking-wide">Yajat Sarkar</h2>
                    <p className="text-[11px] font-mono text-cyan-300">Class 11 CBSE Science</p>
                  </div>
                </div>

                {/* Floating Status Pill */}
                <div className="relative z-10 w-full p-2.5 rounded-xl bg-slate-950/90 border border-white/15 backdrop-blur-md flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    <span className="font-mono font-bold text-white text-[11px]">Vice Captain</span>
                  </div>
                  <span className="text-[10px] font-mono text-cyan-300">PM Shri KV Bgt</span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Biography & Core Accolades */}
          <div className="lg:col-span-8 space-y-5">
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>FOUNDER & ARCHITECT</span>
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-mono text-amber-300 bg-amber-500/10 border border-amber-500/30">
                PM SHRI KV BALAGHAT
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-mono text-purple-300 bg-purple-500/10 border border-purple-500/30">
                INFINITY LEARN SCHOLAR
              </span>
            </div>

            <div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white font-display-periodic">
                Yajat Sarkar
              </h1>
              <p className="text-base sm:text-lg text-slate-300 font-medium mt-1">
                Student, Tech Innovator, School Leader & Creative Architect
              </p>
            </div>

            <p className="text-sm text-slate-300 leading-relaxed font-normal">
              Yajat Sarkar is a Class 11 CBSE Science (PCM) scholar at <strong className="text-white font-semibold">PM Shri Kendriya Vidyalaya, Balaghat (Madhya Pradesh)</strong> and an avid learner with <strong className="text-white font-semibold">Infinity Learn</strong>. Serving as the <strong className="text-cyan-300 font-semibold">School Vice Captain</strong>, he blends scientific rigor with cutting-edge software architecture, autonomous agri-tech robotics, AI hackathon innovation, and high-impact digital storytelling.
            </p>

            {/* Institution Highlight Badges */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2">
              {institutions.map((inst, idx) => (
                <div
                  key={idx}
                  className={`p-4 rounded-2xl bg-gradient-to-br ${inst.accent} border ${inst.border} backdrop-blur-md space-y-1.5 transition-all hover:scale-[1.01]`}
                >
                  <div className="flex items-center justify-between">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold border ${inst.tagColor}`}>
                      {inst.badge}
                    </span>
                    <GraduationCap className="w-4 h-4 text-slate-400" />
                  </div>
                  <h3 className="font-bold text-white text-sm">{inst.name}</h3>
                  <div className="text-xs text-slate-300 font-medium">{inst.role}</div>
                  <p className="text-[11px] text-slate-400 leading-normal">{inst.desc}</p>
                </div>
              ))}
            </div>

            {/* Quick Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              {onNavigate && (
                <button
                  onClick={() => onNavigate('periodic-table')}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition-all"
                >
                  <Atom className="w-4 h-4 text-slate-950" />
                  <span>Explore Chemisphere 3D</span>
                </button>
              )}
              {onNavigate && (
                <button
                  onClick={() => onNavigate('ai-tutor')}
                  className="px-5 py-2.5 rounded-xl bg-purple-500/15 hover:bg-purple-500/25 text-purple-300 border border-purple-500/40 font-bold text-xs flex items-center gap-2 transition-all"
                >
                  <Bot className="w-4 h-4 text-purple-400" />
                  <span>Consult ChemoBot AI</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Numerical Accolades Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: i * 0.1 }}
              className={`p-5 rounded-2xl bg-[#090d16]/90 border ${stat.border} backdrop-blur-xl shadow-xl space-y-2 hover:bg-white/[0.04] transition-all`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-slate-400 tracking-tight">{stat.label}</span>
                <div className={`p-2 rounded-xl ${stat.bg} ${stat.color}`}>
                  <Icon className="w-4 h-4" />
                </div>
              </div>
              <div className={`text-2xl sm:text-3xl font-extrabold font-display-periodic tracking-tight ${stat.color}`}>
                {stat.value}
              </div>
              <div className="text-xs text-slate-300 font-medium">{stat.highlight}</div>
            </motion.div>
          );
        })}
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-white/10 pb-3 overflow-x-auto scrollbar-none">
        {[
          { id: 'overview', label: 'Overview & Highlights', icon: Sparkles },
          { id: 'achievements', label: 'Awards & Honors', icon: Trophy },
          { id: 'innovations', label: 'Agri-Tech & Software', icon: Cpu },
          { id: 'creative', label: 'Digital Media (@NUKAIZEN_gx)', icon: Film },
          { id: 'skills', label: 'Skills & Strategy', icon: BrainCircuit }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-white/15 text-cyan-300 border border-white/20 shadow-lg backdrop-blur-md'
                  : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Contents */}
      <AnimatePresence mode="wait">
        {/* 1. OVERVIEW */}
        {activeTab === 'overview' && (
          <motion.div
            key="overview"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-8"
          >
            {/* Spotlight Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Agri-Tech Innovation Feature Card */}
              <div className="lg:col-span-2 p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-[#0c1524]/90 via-[#080d19]/90 to-[#040710]/95 border border-cyan-500/30 backdrop-blur-xl shadow-2xl space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 font-bold">
                    FLAGSHIP AGRI-TECH INNOVATION
                  </span>
                  <Cpu className="w-5 h-5 text-cyan-400" />
                </div>
                <h3 className="text-2xl font-bold text-white font-display-periodic">
                  Vriddhi-AI (वृद्दि AI) & Autonomous Agribot
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Registered agricultural innovation engineered to modernize crop health monitoring, precision fertilizer regulation, and automated micro-field scouting. Combines embedded sensors with autonomous rover robotics to prevent disease outbreaks and optimize yield for Indian agriculture.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
                  <div className="p-3 rounded-xl bg-white/[0.03] border border-white/5 text-xs text-slate-300 space-y-1">
                    <span className="text-cyan-300 font-bold block">Autonomous Agribot:</span>
                    Field-deployable rover with soil NPK & moisture sensors.
                  </div>
                  <div className="p-3 rounded-xl bg-white/[0.03] border border-white/5 text-xs text-slate-300 space-y-1">
                    <span className="text-cyan-300 font-bold block">Predictive Diagnostics:</span>
                    Computer vision pipelines detecting leaf rust & blight.
                  </div>
                </div>
              </div>

              {/* Creative Media Feature Card */}
              <div className="p-6 rounded-3xl bg-gradient-to-br from-[#1a0f1f]/90 to-[#0d0711]/95 border border-purple-500/30 backdrop-blur-xl shadow-2xl space-y-4 flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono px-3 py-1 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/30 font-bold">
                      DIGITAL MEDIA & FILM
                    </span>
                    <Youtube className="w-5 h-5 text-red-400" />
                  </div>
                  <h3 className="text-xl font-bold text-white">@NUKAIZEN_gx</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Creative digital media initiative directing high-impact visual documentaries, aesthetic motion edits, and scientific storytelling.
                  </p>
                </div>
                <div className="p-3.5 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-xs text-purple-200">
                  Documentary Production • Motion Graphics • Graphic Design
                </div>
              </div>
            </div>

            {/* Core Pillars */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div className="p-5 rounded-2xl bg-[#090d16]/80 border border-white/10 space-y-2">
                <div className="flex items-center gap-2 text-amber-300 font-bold text-sm">
                  <GraduationCap className="w-4 h-4 text-amber-400" />
                  <span>Academic Rigor (98%)</span>
                </div>
                <p className="text-xs text-slate-400">
                  Exceptional foundation in Class 11 Physics, Chemistry, and Mathematics nurtured through PM Shri KV Balaghat and Infinity Learn.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#090d16]/80 border border-white/10 space-y-2">
                <div className="flex items-center gap-2 text-cyan-300 font-bold text-sm">
                  <Crown className="w-4 h-4 text-cyan-400" />
                  <span>School Vice Captain</span>
                </div>
                <p className="text-xs text-slate-400">
                  Elected school leadership spearheading student councils, academic mentorship, science symposiums, and institutional discipline.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#090d16]/80 border border-white/10 space-y-2">
                <div className="flex items-center gap-2 text-emerald-300 font-bold text-sm">
                  <Award className="w-4 h-4 text-emerald-400" />
                  <span>Governor Award</span>
                </div>
                <p className="text-xs text-slate-400">
                  State-level Rajya Puraskar in Bharat Scouts and Guides, exemplifying civic duty, wilderness survival, and community service.
                </p>
              </div>
            </div>
          </motion.div>
        )}

        {/* 2. ACHIEVEMENTS */}
        {activeTab === 'achievements' && (
          <motion.div
            key="achievements"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-5"
          >
            {achievementsList.map((ach, idx) => {
              const Icon = ach.icon;
              return (
                <div
                  key={idx}
                  className="p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 hover:border-cyan-500/40 backdrop-blur-xl shadow-xl space-y-3 transition-all hover:bg-white/[0.03]"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-white/5 border border-white/10 text-slate-400">
                      {ach.category}
                    </span>
                    <span className="text-xs font-mono font-bold text-cyan-300 px-2.5 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/20">
                      {ach.badge}
                    </span>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className={`p-2.5 rounded-xl bg-white/5 shrink-0 mt-0.5 ${ach.color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-white">{ach.title}</h3>
                      <p className="text-xs text-slate-300 leading-relaxed mt-1">{ach.body}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </motion.div>
        )}

        {/* 3. INNOVATIONS */}
        {activeTab === 'innovations' && (
          <motion.div
            key="innovations"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6"
          >
            {innovations.map((item, idx) => {
              const Icon = item.icon;
              return (
                <div
                  key={idx}
                  className="p-6 sm:p-8 rounded-3xl bg-[#090d16]/90 border border-cyan-500/25 backdrop-blur-xl shadow-2xl space-y-4"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300 overflow-hidden p-0.5">
                        {item.name.includes('Chemisphere') ? (
                          <img
                            src="/apple-touch-icon.png"
                            alt="Chemisphere 3D"
                            className="w-full h-full object-contain rounded-xl"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <Icon className="w-5 h-5" />
                        )}
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-white">{item.name}</h3>
                        <p className="text-xs text-cyan-300 font-mono">{item.tagline}</p>
                      </div>
                    </div>
                    <span className="text-xs font-mono px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 w-fit">
                      {item.status}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">{item.description}</p>

                  <div className="space-y-2 pt-1">
                    <span className="text-xs font-mono text-slate-400 font-bold uppercase tracking-wider">Key Capabilities:</span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {item.highlights.map((h, i) => (
                        <div key={i} className="flex items-start gap-2 text-xs text-slate-300 p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                          <span>{h}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 pt-2 border-t border-white/5">
                    {item.tags.map((t, i) => (
                      <span key={i} className="text-[11px] font-mono px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-slate-300">
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </motion.div>
        )}

        {/* 4. CREATIVE MEDIA */}
        {activeTab === 'creative' && (
          <motion.div
            key="creative"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-6"
          >
            {mediaProjects.map((m, idx) => {
              const Icon = m.icon;
              return (
                <div
                  key={idx}
                  className="p-6 sm:p-8 rounded-3xl bg-[#090d16]/90 border border-purple-500/25 backdrop-blur-xl shadow-2xl space-y-4 flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="w-10 h-10 rounded-2xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-300">
                        <Icon className="w-5 h-5" />
                      </div>
                      <span className="text-xs font-mono px-3 py-1 rounded-full bg-white/5 border border-white/10 text-slate-300">
                        {m.platform}
                      </span>
                    </div>

                    <div>
                      <h3 className="text-xl font-bold text-white">{m.name}</h3>
                      <p className="text-xs text-purple-300 font-mono mt-0.5">{m.category}</p>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed">{m.description}</p>
                  </div>

                  <div className="space-y-3 pt-2 border-t border-white/5">
                    <div className="text-xs text-slate-400 font-mono">
                      Role: <span className="text-white font-bold">{m.stats}</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {m.tags.map((t, i) => (
                        <span key={i} className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-purple-500/10 text-purple-200 border border-purple-500/20">
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </motion.div>
        )}

        {/* 5. SKILLS & STRATEGY */}
        {activeTab === 'skills' && (
          <motion.div
            key="skills"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-5"
          >
            {skillCategories.map((cat, idx) => {
              const Icon = cat.icon;
              return (
                <div
                  key={idx}
                  className="p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-xl shadow-xl space-y-4"
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-2.5 rounded-xl ${cat.bg} ${cat.color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <h3 className="font-bold text-white text-base">{cat.category}</h3>
                  </div>

                  <div className="space-y-2">
                    {cat.skills.map((skill, i) => (
                      <div
                        key={i}
                        className="flex items-center gap-2 text-xs text-slate-300 p-2.5 rounded-xl bg-white/[0.02] border border-white/5"
                      >
                        <Zap className={`w-3.5 h-3.5 ${cat.color} shrink-0`} />
                        <span>{skill}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
