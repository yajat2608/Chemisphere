import React, { useState } from 'react';
import {
  TestTube,
  Activity,
  Droplet,
  Layers,
  ArrowRight,
  Sliders,
  Play,
  RotateCcw,
  BarChart3,
  CheckCircle2,
  AlertTriangle,
  Leaf
} from 'lucide-react';
import { NavigationTab } from '../../types';

interface AnalyticalLabViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

type AnalyticalSubTab = 'titration' | 'buffers' | 'chromatography' | 'environmental';

export const AnalyticalLabView: React.FC<AnalyticalLabViewProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<AnalyticalSubTab>('titration');

  // ==========================================
  // 1. TITRATION SIMULATOR STATE
  // ==========================================
  const titrationSystems = [
    {
      name: 'Strong Acid - Strong Base (HCl + NaOH)',
      analyte: '25.0 mL of 0.10 M HCl',
      titrant: '0.10 M NaOH',
      eqVol: 25.0,
      pKa: 0,
      type: 'SA-SB'
    },
    {
      name: 'Weak Acid - Strong Base (CH₃COOH + NaOH)',
      analyte: '25.0 mL of 0.10 M CH₃COOH',
      titrant: '0.10 M NaOH',
      eqVol: 25.0,
      pKa: 4.76,
      type: 'WA-SB'
    }
  ];
  const [selectedSystem, setSelectedSystem] = useState(titrationSystems[1]); // Acetic acid
  const [titrantAdded, setTitrantAdded] = useState<number>(0); // mL added
  const [selectedIndicator, setSelectedIndicator] = useState<'phenolphthalein' | 'methyl-orange' | 'bromothymol'>('phenolphthalein');

  // Calculate pH based on volume added
  const calculatePH = (v: number, sys: typeof titrationSystems[0]) => {
    if (sys.type === 'SA-SB') {
      if (v < sys.eqVol) {
        const molH = 0.025 * 0.1 - (v / 1000) * 0.1;
        const totalVol = (25 + v) / 1000;
        const concH = Math.max(1e-7, molH / totalVol);
        return Math.min(7, -Math.log10(concH));
      } else if (v === sys.eqVol) {
        return 7.0;
      } else {
        const molOH = ((v - sys.eqVol) / 1000) * 0.1;
        const totalVol = (25 + v) / 1000;
        const concOH = molOH / totalVol;
        const pOH = -Math.log10(concOH);
        return Math.min(13.5, 14 - pOH);
      }
    } else {
      // WA-SB (Henderson-Hasselbalch in buffer zone)
      if (v === 0) return 2.87;
      if (v < sys.eqVol) {
        const ratio = v / (sys.eqVol - v);
        return Math.max(2.87, sys.pKa + Math.log10(Math.max(0.001, ratio)));
      } else if (v === sys.eqVol) {
        return 8.72; // Hydrolysis of acetate
      } else {
        const molOH = ((v - sys.eqVol) / 1000) * 0.1;
        const totalVol = (25 + v) / 1000;
        const concOH = molOH / totalVol;
        const pOH = -Math.log10(concOH);
        return Math.min(13.5, 14 - pOH);
      }
    }
  };

  const currentPH = calculatePH(titrantAdded, selectedSystem);

  // Indicator color
  let indicatorColor = '#38bdf8';
  if (selectedIndicator === 'phenolphthalein') {
    indicatorColor = currentPH >= 8.2 ? (currentPH >= 10 ? '#ec4899' : '#f472b6') : '#f8fafc';
  } else if (selectedIndicator === 'methyl-orange') {
    indicatorColor = currentPH <= 3.1 ? '#ef4444' : currentPH >= 4.4 ? '#eab308' : '#f97316';
  } else if (selectedIndicator === 'bromothymol') {
    indicatorColor = currentPH <= 6.0 ? '#eab308' : currentPH >= 7.6 ? '#3b82f6' : '#22c55e';
  }

  // ==========================================
  // 2. BUFFER CAPACITY STATE
  // ==========================================
  const [bufferRatio, setBufferRatio] = useState<number>(1.0); // [A-] / [HA]
  const bufferPH = 4.76 + Math.log10(bufferRatio);

  // ==========================================
  // 3. CHROMATOGRAPHY (TLC & HPLC) STATE
  // ==========================================
  const [solventPolarity, setSolventPolarity] = useState<number>(30); // % EtOAc in Hexane
  // Rf increases as polarity increases
  const spotARf = Math.min(0.95, 0.15 + (solventPolarity / 100) * 0.6);
  const spotBRf = Math.min(0.95, 0.40 + (solventPolarity / 100) * 0.5);

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8 font-sans">
      {/* Header Banner */}
      <div className="relative rounded-3xl overflow-hidden border border-teal-500/30 bg-[#061214] p-6 sm:p-10 shadow-2xl">
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-20 -bottom-20 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/10 border border-teal-400/30 text-teal-400 text-xs font-mono font-bold tracking-wide">
            <TestTube className="w-3.5 h-3.5" />
            <span>ANALYTICAL CHEMISTRY & ENVIRONMENTAL SCIENCE LABORATORY</span>
          </div>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-display-periodic">
                ANALYTICAL & ENVIRONMENTAL LAB
              </h1>
              <p className="text-slate-300 text-sm sm:text-base max-w-3xl mt-2 leading-relaxed font-sans">
                High-precision quantitation: <strong>Acid-Base Titration Curves</strong> with Henderson-Hasselbalch buffer calculations, <strong>Buffer Capacity Resistance</strong>, <strong>TLC & HPLC Chromatographic Separations</strong>, and <strong>Environmental Atmospheric Acid Rain / GWP Indices</strong>.
              </p>
            </div>

            {onNavigate && (
              <button
                onClick={() => onNavigate('lab-directory')}
                className="px-4 py-2.5 rounded-2xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-slate-300 hover:text-white font-mono text-xs font-bold transition-all shrink-0 flex items-center gap-2"
              >
                <span>LAB DIRECTORY</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Sub Navigation */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-[#090d16] border border-white/10 overflow-x-auto font-mono text-xs">
        {[
          { id: 'titration' as AnalyticalSubTab, label: '1. Acid-Base Titration Burette', icon: Droplet, color: 'text-teal-400' },
          { id: 'buffers' as AnalyticalSubTab, label: '2. Buffer Solution Capacity', icon: Sliders, color: 'text-cyan-400' },
          { id: 'chromatography' as AnalyticalSubTab, label: '3. TLC & HPLC Chromatography', icon: Layers, color: 'text-amber-400' },
          { id: 'environmental' as AnalyticalSubTab, label: '4. Environmental Air & Water Indices', icon: Leaf, color: 'text-emerald-400' }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2.5 rounded-xl font-bold flex items-center gap-2 whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-white/15 text-white border border-white/20 shadow-lg'
                  : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
              }`}
            >
              <Icon className={`w-4 h-4 ${tab.color}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ============================================================== */}
      {/* 1. ACID-BASE TITRATION BURETTE */}
      {/* ============================================================== */}
      {activeTab === 'titration' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-teal-500/30 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-teal-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Droplet className="w-4 h-4" />
                  <span>Burette Titrant Volume Controls</span>
                </span>
                <span className="text-slate-400 text-[10px]">pH = -log[H⁺]</span>
              </div>

              {/* Titration System Selector */}
              <div className="space-y-2">
                <label className="text-slate-400 uppercase text-[10px] block">Analyte System:</label>
                <div className="grid grid-cols-1 gap-1.5">
                  {titrationSystems.map((s) => (
                    <button
                      key={s.name}
                      onClick={() => {
                        setSelectedSystem(s);
                        setTitrantAdded(0);
                      }}
                      className={`p-2.5 rounded-xl text-left border transition-all ${
                        selectedSystem.name === s.name
                          ? 'bg-teal-500/20 border-teal-400 text-teal-300 font-bold'
                          : 'bg-white/[0.02] border-white/5 text-slate-300 hover:bg-white/[0.05]'
                      }`}
                    >
                      <div className="font-bold">{s.name}</div>
                      <div className="text-[10px] text-slate-400">Analyte: {s.analyte}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Titrant Added Slider */}
              <div className="space-y-2 pt-2 border-t border-white/5">
                <div className="flex justify-between">
                  <span className="text-slate-400">0.10 M NaOH Added:</span>
                  <span className="text-teal-300 font-bold text-sm">{titrantAdded.toFixed(1)} mL (Eq Point: {selectedSystem.eqVol} mL)</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={50}
                  step={0.5}
                  value={titrantAdded}
                  onChange={(e) => setTitrantAdded(parseFloat(e.target.value))}
                  className="w-full accent-teal-400 cursor-pointer"
                />
              </div>

              {/* Indicator Selector */}
              <div className="space-y-2">
                <label className="text-slate-400 uppercase text-[10px] block">Colorimetric Indicator:</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { id: 'phenolphthalein' as const, label: 'Phenolphthalein', range: 'pH 8.2-10' },
                    { id: 'bromothymol' as const, label: 'Bromothymol Blue', range: 'pH 6.0-7.6' },
                    { id: 'methyl-orange' as const, label: 'Methyl Orange', range: 'pH 3.1-4.4' }
                  ].map((ind) => (
                    <button
                      key={ind.id}
                      onClick={() => setSelectedIndicator(ind.id)}
                      className={`p-2 rounded-xl text-center border transition-all ${
                        selectedIndicator === ind.id
                          ? 'bg-teal-500/20 border-teal-400 text-teal-300 font-bold'
                          : 'bg-white/[0.02] border-white/5 text-slate-400 hover:bg-white/[0.05]'
                      }`}
                    >
                      <div className="text-[10px] font-bold">{ind.label}</div>
                      <div className="text-[8px] text-slate-500">{ind.range}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Live pH Flask Readout */}
              <div className="p-4 rounded-2xl bg-black/60 border border-white/10 flex items-center justify-between">
                <div>
                  <span className="text-slate-400 text-[10px] uppercase block">Current Solution pH:</span>
                  <span className="text-2xl font-extrabold text-teal-300">{currentPH.toFixed(2)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div
                    className="w-8 h-8 rounded-full border border-white/30 shadow-md transition-colors duration-300"
                    style={{ backgroundColor: indicatorColor }}
                  />
                  <span className="text-slate-300 text-[10px]">Flask Color</span>
                </div>
              </div>
            </div>

            {/* Right Titration Curve Plot */}
            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-teal-400" />
                  <span>Titration Curve (pH vs Titrant Volume)</span>
                </h3>
                <span className="text-teal-400 font-bold">V_eq = {selectedSystem.eqVol} mL</span>
              </div>

              <div className="w-full bg-black/60 rounded-2xl p-4 border border-white/5">
                <svg viewBox="0 0 500 180" className="w-full h-auto select-none">
                  {/* pH Grid Lines */}
                  {[14, 12, 10, 8, 7, 4, 2, 0].map((ph) => {
                    const y = 20 + ((14 - ph) / 14) * 140;
                    return (
                      <g key={ph}>
                        <line x1="40" y1={y} x2="470" y2={y} stroke="rgba(255,255,255,0.06)" strokeDasharray="3 3" />
                        <text x="32" y={y + 3} textAnchor="end" fill="#64748b" fontSize="8" fontFamily="monospace">{ph}</text>
                      </g>
                    );
                  })}

                  {/* Curve Path */}
                  {(() => {
                    const pts = [];
                    for (let v = 0; v <= 50; v += 0.5) {
                      const x = 40 + (v / 50) * 430;
                      const ph = calculatePH(v, selectedSystem);
                      const y = 20 + ((14 - ph) / 14) * 140;
                      pts.push(`${x.toFixed(1)},${y.toFixed(1)}`);
                    }
                    return <path d={`M ${pts.join(' L ')}`} fill="none" stroke="#2dd4bf" strokeWidth="2.5" />;
                  })()}

                  {/* Current Active Dot */}
                  {(() => {
                    const x = 40 + (titrantAdded / 50) * 430;
                    const y = 20 + ((14 - currentPH) / 14) * 140;
                    return <circle cx={x} cy={y} r="5" fill="#ffffff" stroke="#2dd4bf" strokeWidth="2" />;
                  })()}

                  <line x1="40" y1="160" x2="470" y2="160" stroke="rgba(255,255,255,0.2)" />
                  <text x="255" y="176" textAnchor="middle" fill="#94a3b8" fontSize="9">Volume of 0.10 M NaOH Added (mL) →</text>
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 2. BUFFER SOLUTION CAPACITY */}
      {/* ============================================================== */}
      {activeTab === 'buffers' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-cyan-500/30 shadow-xl space-y-5">
              <span className="text-cyan-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2 border-b border-white/10 pb-3">
                <Sliders className="w-4 h-4" />
                <span>Henderson-Hasselbalch Conjugate Buffer</span>
              </span>

              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Ratio [CH₃COO⁻] / [CH₃COOH]:</span>
                  <span className="text-cyan-300 font-bold">{bufferRatio.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min={0.1}
                  max={10.0}
                  step={0.1}
                  value={bufferRatio}
                  onChange={(e) => setBufferRatio(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div className="p-4 rounded-2xl bg-black/60 border border-white/10 space-y-2">
                <div className="flex justify-between items-center text-cyan-300 font-bold text-base">
                  <span>Buffer pH: {bufferPH.toFixed(2)}</span>
                  <span className="text-slate-400 text-xs">pKa = 4.76</span>
                </div>
                <div className="text-[11px] text-slate-300 pt-1 font-sans">
                  Optimal buffer capacity exists in the range <strong>pH = pKa ± 1 (3.76 to 5.76)</strong>.
                </div>
              </div>
            </div>

            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-white/10 pb-3">
                <Sliders className="w-4 h-4 text-cyan-400" />
                <span>Buffer Resistance Against Added Strong Acid/Base</span>
              </h3>
              <p className="text-slate-300 text-[11px] font-sans leading-relaxed">
                Adding 1 mL of 1.0 M HCl to unbuffered pure water shifts pH catastrophically from 7.0 to 2.0 (ΔpH = -5.0).<br /><br />
                In contrast, in a 0.1 M Acetate buffer, the conjugate base absorbs added hydronium ions: CH₃COO⁻ + H⁺ → CH₃COOH, buffering the change to ΔpH &lt; 0.08 units.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 3. CHROMATOGRAPHY (TLC & HPLC) */}
      {/* ============================================================== */}
      {activeTab === 'chromatography' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-amber-500/30 shadow-xl space-y-5">
              <span className="text-amber-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2 border-b border-white/10 pb-3">
                <Layers className="w-4 h-4" />
                <span>Mobile Phase Solvent Polarity</span>
              </span>

              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Ethyl Acetate in Hexane (%):</span>
                  <span className="text-amber-300 font-bold">{solventPolarity}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  step={5}
                  value={solventPolarity}
                  onChange={(e) => setSolventPolarity(parseInt(e.target.value))}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>

              <div className="p-4 rounded-2xl bg-black/60 border border-white/10 space-y-2">
                <div className="flex justify-between text-slate-300">
                  <span>Spot A (Polar Compound):</span>
                  <span className="text-amber-400 font-bold">Rf = {spotARf.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Spot B (Non-Polar Compound):</span>
                  <span className="text-cyan-400 font-bold">Rf = {spotBRf.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Right TLC Plate Visualizer */}
            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-white/10 pb-3">
                <Layers className="w-4 h-4 text-amber-400" />
                <span>TLC Silica Gel Plate Retention</span>
              </h3>

              <div className="w-full bg-black/60 rounded-2xl p-4 border border-white/5">
                <svg viewBox="0 0 500 180" className="w-full h-auto select-none">
                  {/* Silica Plate (White/Gray rectangle) */}
                  <rect x="180" y="20" width="140" height="140" rx="4" fill="#f1f5f9" stroke="#cbd5e1" strokeWidth="2" />

                  {/* Baseline and Solvent Front */}
                  <line x1="190" y1="140" x2="310" y2="140" stroke="#94a3b8" strokeDasharray="3 3" />
                  <text x="185" y="142" textAnchor="end" fill="#64748b" fontSize="8">Baseline</text>

                  <line x1="190" y1="30" x2="310" y2="30" stroke="#94a3b8" strokeDasharray="3 3" />
                  <text x="185" y="32" textAnchor="end" fill="#64748b" fontSize="8">Solvent Front</text>

                  {/* Spot A */}
                  <circle cx="225" cy={140 - spotARf * 110} r="6" fill="#f59e0b" />
                  <text x="225" y={140 - spotARf * 110 - 8} textAnchor="middle" fill="#92400e" fontSize="7" fontWeight="bold">Spot A</text>

                  {/* Spot B */}
                  <circle cx="275" cy={140 - spotBRf * 110} r="6" fill="#0284c7" />
                  <text x="275" y={140 - spotBRf * 110 - 8} textAnchor="middle" fill="#0369a1" fontSize="7" fontWeight="bold">Spot B</text>
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 4. ENVIRONMENTAL INDICES */}
      {/* ============================================================== */}
      {activeTab === 'environmental' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 rounded-3xl bg-[#090d16] border border-white/10 space-y-4">
              <h3 className="text-sm font-bold text-emerald-400 flex items-center gap-2">
                <Leaf className="w-4 h-4" />
                <span>Global Warming Potential (GWP 100-yr Index)</span>
              </h3>
              <div className="space-y-2 text-slate-300">
                <div className="flex justify-between p-2 rounded-xl bg-white/[0.02]">
                  <span>Carbon Dioxide (CO₂)</span>
                  <span className="font-bold text-white">1</span>
                </div>
                <div className="flex justify-between p-2 rounded-xl bg-white/[0.02]">
                  <span>Methane (CH₄)</span>
                  <span className="font-bold text-amber-400">28</span>
                </div>
                <div className="flex justify-between p-2 rounded-xl bg-white/[0.02]">
                  <span>Nitrous Oxide (N₂O)</span>
                  <span className="font-bold text-rose-400">265</span>
                </div>
                <div className="flex justify-between p-2 rounded-xl bg-white/[0.02]">
                  <span>Sulfur Hexafluoride (SF₆)</span>
                  <span className="font-bold text-purple-400">23,500</span>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-3xl bg-[#090d16] border border-white/10 space-y-4">
              <h3 className="text-sm font-bold text-teal-400 flex items-center gap-2">
                <Droplet className="w-4 h-4" />
                <span>Acid Rain Atmospheric Chemistry</span>
              </h3>
              <p className="text-slate-300 text-[11px] font-sans leading-relaxed">
                Combustion emissions produce SO₂ and NOₓ which react with hydroxyl radicals and atmospheric water:<br /><br />
                SO₂(g) + H₂O(l) → H₂SO₃(aq) → H₂SO₄(aq)<br />
                4 NO₂(g) + 2 H₂O(l) + O₂(g) → 4 HNO₃(aq)<br /><br />
                Lowers rainwater pH below normal 5.6 to &lt; 4.0, leaching toxic Al³⁺ ions from mineral soils into aquatic ecosystems.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
