import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  User,
  Award,
  Sparkles,
  RotateCcw,
  Trash2,
  CheckCircle2,
  Compass,
  ArrowRight,
  Trophy,
  FlaskConical,
  Activity,
  Layers,
  Atom,
  Orbit,
  Grid3X3,
  Dna,
  Flame,
  Boxes,
  Archive,
  BookOpen,
  HelpCircle,
  Clock,
  ShieldAlert,
  Zap,
  Radio,
  ExternalLink,
  Download,
  Upload,
  Calendar,
  Flame as StreakIcon,
  Pin,
  FileText,
  Plus,
  AlertCircle
} from 'lucide-react';
import { NavigationTab } from '../../types';
import {
  useUserPassport,
  CHEMISTRY_INTEREST_CHIPS,
  PURPOSE_OPTIONS,
  REFERRAL_SOURCES,
  SYSTEM_BADGES
} from '../../data/UserPassportStore';

interface UserProfileViewProps {
  onNavigate: (tab: NavigationTab) => void;
  onOpenTutorial: () => void;
  onOpenIntroModal: () => void;
}

export const UserProfileView: React.FC<UserProfileViewProps> = ({
  onNavigate,
  onOpenTutorial,
  onOpenIntroModal
}) => {
  const {
    passport,
    stats,
    setName,
    toggleInterest,
    togglePurpose,
    reset,
    exportPassport,
    importPassport,
    togglePinTab,
    addNotebookEntry,
    deleteNotebookEntry
  } = useUserPassport();

  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState('');
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Notebook state
  const [newNoteTitle, setNewNoteTitle] = useState('');
  const [newNoteContent, setNewNoteContent] = useState('');
  const [showAddNote, setShowAddNote] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleSaveName = () => {
    if (!tempName.trim()) return;
    setName(tempName.trim());
    setIsEditingName(false);
    showToast('Name updated successfully in Passport!');
  };

  const handleResetProgress = () => {
    reset('all');
    setShowResetConfirm(false);
    showToast('All user data and history has been reset to defaults.');
  };

  const handleResetTutorial = () => {
    reset('tutorial');
    showToast('Tutorial progress tracking has been reset.');
  };

  const handleRestartIntro = () => {
    reset('onboarding');
    onOpenIntroModal();
  };

  const handleExport = () => {
    const jsonStr = exportPassport();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `chemisphere_passport_${passport.name ? passport.name.toLowerCase().replace(/\s+/g, '_') : 'chemist'}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('Passport exported successfully as JSON file!');
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (!content) return;
      const res = importPassport(content);
      if (res.success) {
        showToast('Passport imported & synced successfully!');
      } else {
        showToast(`Import error: ${res.error}`);
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleAddNote = () => {
    if (!newNoteContent.trim()) return;
    addNotebookEntry(newNoteTitle, newNoteContent);
    setNewNoteTitle('');
    setNewNoteContent('');
    setShowAddNote(false);
    showToast('Scientific note recorded in Passport!');
  };

  // 14 Core Curriculum Disciplines in Passport
  const curriculumDisciplines: { id: NavigationTab; name: string; icon: any; color: string }[] = [
    { id: 'periodic-table', name: 'Inorganic & Periodic Trends', icon: Grid3X3, color: '#38bdf8' },
    { id: 'orbital-atlas', name: '3D Quantum Orbitals', icon: Orbit, color: '#a855f7' },
    { id: 'molecules-3d', name: '3D Molecular Structures', icon: Boxes, color: '#6366f1' },
    { id: 'vsepr-lab', name: 'VSEPR & Hybridization', icon: Atom, color: '#3b82f6' },
    { id: 'atomic-spectra', name: 'Atomic Spectra & Emission', icon: Activity, color: '#06b6d4' },
    { id: 'spectroscopy-suite', name: 'Spectroscopy (5 Instruments)', icon: Activity, color: '#ec4899' },
    { id: 'thermo-kinetics', name: 'Thermodynamics & Kinetics', icon: Flame, color: '#f97316' },
    { id: 'organic-chem', name: 'Organic Reaction Highway', icon: Dna, color: '#10b981' },
    { id: 'advanced-organic', name: 'Advanced Organic Synthesis', icon: Dna, color: '#059669' },
    { id: 'electrochemistry-lab', name: 'Electrochemistry & Cells', icon: Zap, color: '#eab308' },
    { id: 'nuclear-chemistry', name: 'Nuclear Reactions & Decay', icon: Radio, color: '#ef4444' },
    { id: 'analytical-lab', name: 'Analytical & Chromatography', icon: FlaskConical, color: '#14b8a6' },
    { id: 'chemistry-lab', name: 'Virtual Chemistry Sandbox', icon: FlaskConical, color: '#22c55e' },
    { id: 'questions-playground', name: 'Questions Playground', icon: Trophy, color: '#eab308' }
  ];

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-300 text-stone-200">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 px-4 py-2.5 rounded-2xl bg-[#09152b] border border-cyan-400 text-cyan-200 text-xs font-mono shadow-2xl shadow-cyan-500/30 flex items-center gap-2 animate-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-cyan-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Hidden file input for passport import */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".json,application/json"
        className="hidden"
        onChange={handleFileImport}
      />

      {/* Top Header Card with Dynamic "Hello Name" and Scientist Rank */}
      <div className="relative p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#0c162c] via-[#091122] to-[#120e28] border border-cyan-500/30 shadow-2xl overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start sm:items-center gap-4">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-3xl bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600 p-[2px] shadow-xl shadow-cyan-500/20 shrink-0">
              <div className="w-full h-full bg-[#050811] rounded-[22px] flex items-center justify-center text-2xl sm:text-3xl font-black text-cyan-300 font-mono">
                {passport.name ? passport.name.charAt(0).toUpperCase() : 'C'}
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-xs font-mono font-bold">
                  LEVEL {stats.level} • {stats.title.toUpperCase()}
                </span>
                <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold">
                  <StreakIcon className="w-3.5 h-3.5 text-amber-400" />
                  <span>{stats.streakDays} Day Active Streak</span>
                </span>
                <span className="text-xs text-stone-400 font-mono">
                  Joined: {new Date(passport.joinedAt).toLocaleDateString()}
                </span>
              </div>

              <div className="flex items-center gap-3">
                {isEditingName ? (
                  <div className="flex items-center gap-2 mt-1">
                    <input
                      type="text"
                      value={tempName}
                      onChange={(e) => setTempName(e.target.value)}
                      placeholder="Your Name"
                      className="px-3 py-1 rounded-xl bg-white/10 border border-cyan-400 text-white font-mono text-lg focus:outline-none"
                      autoFocus
                    />
                    <button
                      onClick={handleSaveName}
                      className="px-3 py-1 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs font-mono"
                    >
                      Save
                    </button>
                    <button
                      onClick={() => setIsEditingName(false)}
                      className="px-3 py-1 rounded-xl bg-white/10 text-stone-300 text-xs font-mono"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-3">
                    <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight">
                      Hello, {passport.name || 'Chemist'}!
                    </h1>
                    <button
                      onClick={() => {
                        setTempName(passport.name);
                        setIsEditingName(true);
                      }}
                      className="text-xs text-cyan-400 hover:text-cyan-300 font-mono underline"
                    >
                      Edit Name
                    </button>
                  </div>
                )}
              </div>

              <p className="text-xs sm:text-sm text-stone-300 font-sans">
                Interests: <strong className="text-cyan-300 font-mono">{passport.chemistryInterests?.join(', ') || 'General Science'}</strong>
              </p>
            </div>
          </div>

          {/* Quick Action & Backup Buttons */}
          <div className="flex flex-wrap items-center gap-2.5 font-mono text-xs">
            <button
              onClick={handleExport}
              title="Download your passport backup JSON"
              className="px-3.5 py-2 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/15 text-stone-200 hover:text-white transition-all flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span>Export JSON</span>
            </button>

            <button
              onClick={() => fileInputRef.current?.click()}
              title="Import or restore passport from JSON"
              className="px-3.5 py-2 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/15 text-stone-200 hover:text-white transition-all flex items-center gap-1.5"
            >
              <Upload className="w-3.5 h-3.5 text-purple-400" />
              <span>Import</span>
            </button>

            <button
              onClick={handleRestartIntro}
              className="px-3.5 py-2 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/15 text-stone-200 hover:text-white transition-all flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Restart Intro</span>
            </button>

            <button
              onClick={onOpenTutorial}
              className="px-4 py-2 rounded-2xl bg-gradient-to-r from-cyan-500/20 to-purple-500/20 hover:from-cyan-500/30 hover:to-purple-500/30 border border-cyan-400 text-cyan-200 transition-all flex items-center gap-1.5 shadow-md shadow-cyan-500/10"
            >
              <Compass className="w-3.5 h-3.5 text-cyan-300" />
              <span>Guided Tour</span>
            </button>
          </div>
        </div>
      </div>

      {/* Progress & Analytics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
        {/* Card 1: Experience & Level */}
        <div className="p-5 rounded-3xl bg-white/[0.02] border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-stone-400">Total Mastery XP</span>
            <Trophy className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-white">
            {passport.score || 0} <span className="text-xs font-normal text-stone-400">XP</span>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-[10px] text-stone-400">
              <span>Next Rank ({stats.nextThreshold} XP)</span>
              <span>{stats.progressPercent}%</span>
            </div>
            <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-cyan-400 to-purple-500 transition-all"
                style={{ width: `${stats.progressPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Card 2: Curriculum Exploration */}
        <div className="p-5 rounded-3xl bg-white/[0.02] border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-stone-400">Disciplines Explored</span>
            <Atom className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-cyan-300">
            {stats.totalModulesExplored} / {stats.totalModulesCount}
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-[10px] text-stone-400">
              <span>Curriculum Coverage</span>
              <span>{stats.curriculumProgressPercent}%</span>
            </div>
            <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
              <div
                className="h-full bg-cyan-400 transition-all"
                style={{ width: `${stats.curriculumProgressPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Card 3: Questions & Experiments */}
        <div className="p-5 rounded-3xl bg-white/[0.02] border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-stone-400">Problems & Wet-Labs</span>
            <FlaskConical className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-300 flex items-center gap-2">
            <span>{passport.questionsSolved || 0} Solved</span>
            <span className="text-stone-500">•</span>
            <span>{passport.experimentsConducted || 0} Labs</span>
          </div>
          <div className="text-[10px] text-stone-400">
            Accuracy: {passport.questionsAttempted > 0 ? Math.round(((passport.questionsSolved || 0) / passport.questionsAttempted) * 100) : 100}%
          </div>
        </div>

        {/* Card 4: Tour System Status */}
        <div className="p-5 rounded-3xl bg-white/[0.02] border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-stone-400">Guided Tour Concepts</span>
            <Compass className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-purple-300">
            {stats.tutorialExploredCount} / 25
          </div>
          <div className="flex items-center justify-between pt-1">
            <button
              onClick={handleResetTutorial}
              className="text-[10px] text-stone-400 hover:text-rose-300 flex items-center gap-1 transition-colors"
            >
              <RotateCcw className="w-3 h-3" /> Reset Tour
            </button>
            <button
              onClick={onOpenTutorial}
              className="text-[10px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-bold"
            >
              Resume Tour <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Curriculum Passport Matrix */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
            <Layers className="w-5 h-5 text-cyan-400" />
            <span>Interactive Scientific Passport (14 Core Disciplines)</span>
          </h2>
          <span className="text-xs font-mono text-stone-400">
            Click any discipline to launch • Pin favorites
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 gap-3 font-mono">
          {curriculumDisciplines.map((disc) => {
            const isVisited = passport.visitedTabs?.includes(disc.id);
            const isPinned = passport.pinnedTabs?.includes(disc.id);
            const stat = passport.disciplineStats?.[disc.id];
            const Icon = disc.icon;

            return (
              <div
                key={disc.id}
                onClick={() => onNavigate(disc.id)}
                className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between min-h-[120px] relative group ${
                  isVisited
                    ? 'bg-white/5 border-cyan-500/40 hover:border-cyan-400 hover:bg-cyan-500/10'
                    : 'bg-white/[0.02] border-white/5 hover:border-white/20 opacity-70 hover:opacity-100'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div
                    className="p-1.5 rounded-xl"
                    style={{ backgroundColor: `${disc.color}20`, color: disc.color }}
                  >
                    <Icon className="w-4 h-4" />
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        togglePinTab(disc.id);
                      }}
                      title={isPinned ? 'Unpin from quick bar' : 'Pin to favorites'}
                      className={`p-1 rounded-md transition-colors ${
                        isPinned ? 'text-amber-400 bg-amber-500/20' : 'text-stone-500 hover:text-stone-300'
                      }`}
                    >
                      <Pin className="w-3 h-3" />
                    </button>
                    {isVisited ? (
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        {stat?.count ? `${stat.count}×` : 'Explored'}
                      </span>
                    ) : (
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-white/5 text-stone-500">
                        New
                      </span>
                    )}
                  </div>
                </div>

                <div className="mt-2">
                  <div className="text-xs font-bold text-white group-hover:text-cyan-300 transition-colors line-clamp-2">
                    {disc.name}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Badges & Achievements Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            <span>Scientific Badges & Honours ({stats.badgesUnlockedCount} / {stats.totalBadgesCount})</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 font-mono">
          {SYSTEM_BADGES.map((b) => {
            const isUnlocked = passport.unlockedBadges?.includes(b.id);
            const unlockedDate = passport.badgeUnlockDates?.[b.id];

            return (
              <div
                key={b.id}
                className={`p-4 rounded-2xl border flex items-start gap-3 transition-all ${
                  isUnlocked
                    ? 'bg-amber-500/10 border-amber-500/30 text-white'
                    : 'bg-white/[0.02] border-white/5 text-stone-500 opacity-60'
                }`}
              >
                <div
                  className={`p-2.5 rounded-2xl shrink-0 ${
                    isUnlocked
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-white/5 text-stone-600'
                  }`}
                >
                  <Award className="w-5 h-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-bold flex items-center justify-between gap-1">
                    <span className={`truncate ${isUnlocked ? 'text-amber-200' : 'text-stone-400'}`}>
                      {b.name}
                    </span>
                    {isUnlocked && (
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 shrink-0">
                        +{b.xpReward || 50} XP
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-stone-400 font-sans mt-0.5 line-clamp-2">
                    {b.description}
                  </p>
                  {unlockedDate && (
                    <div className="text-[9px] text-amber-400/80 font-mono mt-1">
                      Unlocked {new Date(unlockedDate).toLocaleDateString()}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Scientific Notebook & Notes */}
      <div className="p-6 rounded-3xl bg-white/[0.02] border border-white/10 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-cyan-400" />
              <span>Laboratory Notebook & Insights</span>
            </h3>
            <p className="text-xs text-stone-400 font-sans mt-0.5">
              Personal research memos and reaction observations preserved in your Passport.
            </p>
          </div>

          <button
            onClick={() => setShowAddNote(!showAddNote)}
            className="px-3.5 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-200 text-xs font-mono transition-colors flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{showAddNote ? 'Close Form' : 'New Note'}</span>
          </button>
        </div>

        {showAddNote && (
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3 animate-in fade-in">
            <input
              type="text"
              placeholder="Note Title (e.g. Synthesis of Benzocaine observations)"
              value={newNoteTitle}
              onChange={(e) => setNewNoteTitle(e.target.value)}
              className="w-full px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 text-white font-mono text-xs focus:outline-none focus:border-cyan-400"
            />
            <textarea
              placeholder="Note Content / Chemical Mechanism thoughts..."
              value={newNoteContent}
              onChange={(e) => setNewNoteContent(e.target.value)}
              rows={3}
              className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white font-sans text-xs focus:outline-none focus:border-cyan-400 resize-none"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowAddNote(false)}
                className="px-3 py-1 rounded-xl bg-white/5 text-stone-300 text-xs font-mono"
              >
                Cancel
              </button>
              <button
                onClick={handleAddNote}
                className="px-4 py-1 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs font-mono"
              >
                Save to Passport
              </button>
            </div>
          </div>
        )}

        {passport.notebookEntries && passport.notebookEntries.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {passport.notebookEntries.map((note) => (
              <div
                key={note.id}
                className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 space-y-2 relative group"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-cyan-300 font-mono truncate">
                    {note.title}
                  </span>
                  <button
                    onClick={() => deleteNotebookEntry(note.id)}
                    className="text-stone-500 hover:text-rose-400 transition-colors p-1"
                    title="Delete Note"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
                <p className="text-xs text-stone-300 font-sans whitespace-pre-wrap line-clamp-4">
                  {note.content}
                </p>
                <div className="text-[10px] text-stone-500 font-mono">
                  {new Date(note.createdAt).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-xs text-stone-500 font-mono italic py-2">
            No notebook entries recorded yet. Click "New Note" above to write observations.
          </div>
        )}
      </div>

      {/* Preferences & Interests Management */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chemistry Interests */}
        <div className="p-6 rounded-3xl bg-white/[0.02] border border-white/10 space-y-4">
          <div>
            <h3 className="text-base font-bold text-white">Curriculum Interests (Multi-select)</h3>
            <p className="text-xs text-stone-400 font-sans">
              Click to toggle topics you want highlighted across Chemisphere 3D.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 font-mono text-xs max-h-[220px] overflow-y-auto pr-1">
            {CHEMISTRY_INTEREST_CHIPS.map((chip) => {
              const isSelected = passport.chemistryInterests?.includes(chip.id);
              return (
                <button
                  key={chip.id}
                  onClick={() => toggleInterest(chip.id)}
                  className={`p-2.5 rounded-2xl border text-left transition-all flex items-center justify-between gap-1.5 ${
                    isSelected
                      ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200 font-bold'
                      : 'bg-white/5 border-white/5 text-stone-400 hover:text-white'
                  }`}
                >
                  <span className="truncate text-[11px]">{chip.label}</span>
                  {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Learning Goals */}
        <div className="p-6 rounded-3xl bg-white/[0.02] border border-white/10 space-y-4">
          <div>
            <h3 className="text-base font-bold text-white">Learning Goals (Multi-select)</h3>
            <p className="text-xs text-stone-400 font-sans">
              Adjust what you aim to achieve (exams, research, virtual labs).
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 font-mono text-xs max-h-[220px] overflow-y-auto pr-1">
            {PURPOSE_OPTIONS.map((item) => {
              const isSelected = passport.purposes?.includes(item.id);
              return (
                <button
                  key={item.id}
                  onClick={() => togglePurpose(item.id)}
                  className={`p-2.5 rounded-2xl border text-left transition-all flex items-center justify-between gap-2 ${
                    isSelected
                      ? 'bg-purple-500/20 border-purple-400 text-purple-200 font-bold'
                      : 'bg-white/5 border-white/5 text-stone-400 hover:text-white'
                  }`}
                >
                  <span className="truncate text-[11px]">{item.label}</span>
                  {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-purple-400 shrink-0" />}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Danger Zone: Reset All Data */}
      <div className="p-6 rounded-3xl bg-rose-950/10 border border-rose-500/20 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold text-rose-300 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              <span>Data Reset & Clear Cache</span>
            </h3>
            <p className="text-xs text-stone-400 font-sans mt-0.5">
              Reset your passport, level XP, unlocked badges, and tutorial progression to default state.
            </p>
          </div>

          <button
            onClick={() => setShowResetConfirm(true)}
            className="px-4 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 text-xs font-mono transition-colors flex items-center justify-center gap-2 shrink-0"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Reset All User Data</span>
          </button>
        </div>
      </div>

      {/* Reset Confirmation Dialog */}
      <AnimatePresence>
        {showResetConfirm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="w-full max-w-md p-6 rounded-3xl bg-[#0b101c] border border-rose-500/40 space-y-4 font-mono text-xs text-center shadow-2xl"
            >
              <div className="w-12 h-12 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/30 flex items-center justify-center mx-auto">
                <Trash2 className="w-6 h-6" />
              </div>
              <h4 className="text-base font-bold text-white">Reset All Chemisphere Data?</h4>
              <p className="text-stone-300 font-sans text-xs">
                This will delete your XP, completed tutorials, visited labs history, and name. This action cannot be undone.
              </p>
              <div className="flex items-center justify-center gap-3 pt-2">
                <button
                  onClick={() => setShowResetConfirm(false)}
                  className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-stone-300"
                >
                  Cancel
                </button>
                <button
                  onClick={handleResetProgress}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold"
                >
                  Yes, Reset Everything
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
