import React, { useState, useEffect } from 'react';
import {
  Flame,
  Activity,
  Zap,
  Sliders,
  Play,
  Pause,
  RotateCcw,
  ArrowRight,
  BarChart3,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { NavigationTab } from '../../types';

interface ThermoKineticsViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

type ThermoSubTab = 'engine' | 'calorimetry' | 'equilibrium' | 'kinetics';

export const ThermoKineticsView: React.FC<ThermoKineticsViewProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<ThermoSubTab>('engine');

  // ==========================================
  // 1. THERMODYNAMIC ENGINE & CYCLES STATE
  // ==========================================
  const [tempK, setTempK] = useState<number>(300); // Kelvin
  const [deltaH_kJ, setDeltaH_kJ] = useState<number>(-45); // kJ/mol
  const [deltaS_J, setDeltaS_J] = useState<number>(-80); // J/(mol·K)
  const [cycleType, setCycleType] = useState<'carnot' | 'isothermal' | 'isobaric' | 'adiabatic'>('carnot');

  // Delta G = Delta H - T * Delta S
  const deltaG_kJ = deltaH_kJ - (tempK * deltaS_J) / 1000;
  const isSpontaneous = deltaG_kJ < 0;

  // Carnot Efficiency
  const tHot = 600;
  const tCold = Math.min(tempK, 580);
  const carnotEfficiency = (1 - tCold / tHot) * 100;

  // ==========================================
  // 2. VIRTUAL CALORIMETER STATE
  // ==========================================
  const calReactions = [
    { name: 'Neutralization: HCl + NaOH → NaCl + H₂O', dH: -57.1, type: 'Exothermic (Solution)', massWater: 100, deltaT: 6.8 },
    { name: 'Cold Pack: Dissolution of NH₄NO₃ in Water', dH: 25.7, type: 'Endothermic (Solution)', massWater: 100, deltaT: -4.2 },
    { name: 'Hot Pack: Dissolution of CaCl₂ in Water', dH: -81.3, type: 'Exothermic (Solution)', massWater: 100, deltaT: 9.7 },
    { name: 'Bomb Calorimetry: Benzoic Acid Combustion', dH: -3227, type: 'Exothermic (Bomb)', massWater: 1000, deltaT: 3.1 }
  ];
  const [selectedCalRxn, setSelectedCalRxn] = useState(calReactions[0]);
  const [calWaterMass, setCalWaterMass] = useState(100); // g
  const [calInitTemp, setCalInitTemp] = useState(25.0); // °C

  const specificHeatWater = 4.184; // J/(g·°C)
  // q = m * c * deltaT -> deltaT = -q / (m * c)
  const simulatedDeltaT = selectedCalRxn.deltaT * (100 / calWaterMass);
  const finalCalTemp = calInitTemp + simulatedDeltaT;
  const heatReleasedJoules = calWaterMass * specificHeatWater * simulatedDeltaT;

  // ==========================================
  // 3. EQUILIBRIUM & LE CHATELIER STATE
  // ==========================================
  const eqReactions = [
    {
      name: 'Haber-Bosch: N₂(g) + 3H₂(g) ⇌ 2NH₃(g)',
      deltaH: 'Exothermic (ΔH = -92.4 kJ/mol)',
      isExo: true,
      molesGasReactants: 4,
      molesGasProducts: 2
    },
    {
      name: 'NO₂ Dimerization: 2NO₂(g, brown) ⇌ N₂O₄(g, colorless)',
      deltaH: 'Exothermic (ΔH = -57.2 kJ/mol)',
      isExo: true,
      molesGasReactants: 2,
      molesGasProducts: 1
    }
  ];
  const [selectedEqRxn, setSelectedEqRxn] = useState(eqReactions[0]);
  const [concA, setConcA] = useState<number>(1.0); // M
  const [concB, setConcB] = useState<number>(1.0); // M
  const [eqVolume, setEqVolume] = useState<number>(1.0); // L
  const [eqTemp, setEqTemp] = useState<number>(300); // K

  // Dynamic Q vs K
  const Keq = selectedEqRxn.isExo ? 10.0 * Math.exp(1200 * (1 / eqTemp - 1 / 300)) : 10.0;
  const Q = (concB * concB) / (concA * Math.pow(eqVolume, 2));

  let eqShift = 'AT EQUILIBRIUM';
  if (Q < Keq * 0.9) eqShift = 'SHIFTS RIGHT → (Forward Rxn Favored)';
  else if (Q > Keq * 1.1) eqShift = '← SHIFTS LEFT (Reverse Rxn Favored)';

  // ==========================================
  // 4. KINETICS & COLLISION THEORY STATE
  // ==========================================
  const [kinTemp, setKinTemp] = useState<number>(320); // K
  const [activationEa, setActivationEa] = useState<number>(50); // kJ/mol
  const [hasCatalyst, setHasCatalyst] = useState<boolean>(false);

  const effectiveEa = hasCatalyst ? activationEa - 20 : activationEa;
  const R_const = 8.314;
  const arrheniusRateK = 1e7 * Math.exp(-(effectiveEa * 1000) / (R_const * kinTemp));

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8 font-sans">
      {/* Header Banner */}
      <div className="relative rounded-3xl overflow-hidden border border-orange-500/30 bg-[#120a06] p-6 sm:p-10 shadow-2xl">
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-20 -bottom-20 w-80 h-80 bg-red-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-500/10 border border-orange-400/30 text-orange-400 text-xs font-mono font-bold tracking-wide">
            <Flame className="w-3.5 h-3.5" />
            <span>PHYSICAL CHEMISTRY • THERMODYNAMICS • KINETICS • EQUILIBRIUM</span>
          </div>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-display-periodic">
                THERMODYNAMICS & KINETICS LAB
              </h1>
              <p className="text-slate-300 text-sm sm:text-base max-w-3xl mt-2 leading-relaxed font-sans">
                Explore energy transformations: <strong>Thermodynamic Cycles & Gibbs Energy</strong> (ΔG = ΔH − TΔS), <strong>Solution & Bomb Calorimetry</strong> (q = mcΔT), <strong>Le Chatelier Chemical Equilibrium</strong>, and <strong>Collision Kinetics & Arrhenius Activation Energy</strong>.
              </p>
            </div>

            {onNavigate && (
              <button
                onClick={() => onNavigate('lab-directory')}
                className="px-4 py-2.5 rounded-2xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-slate-300 hover:text-white font-mono text-xs font-bold transition-all shrink-0 flex items-center gap-2"
              >
                <span>LAB DIRECTORY</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Sub Navigation */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-[#090d16] border border-white/10 overflow-x-auto font-mono text-xs">
        {[
          { id: 'engine' as ThermoSubTab, label: '1. Thermodynamic Engine & Cycles', icon: Flame, color: 'text-orange-400' },
          { id: 'calorimetry' as ThermoSubTab, label: '2. Virtual Calorimeter Lab', icon: Activity, color: 'text-amber-400' },
          { id: 'equilibrium' as ThermoSubTab, label: '3. Chemical Equilibrium & Le Chatelier', icon: Sliders, color: 'text-cyan-400' },
          { id: 'kinetics' as ThermoSubTab, label: '4. Reaction Kinetics & Catalysts', icon: Zap, color: 'text-emerald-400' }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2.5 rounded-xl font-bold flex items-center gap-2 whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-white/15 text-white border border-white/20 shadow-lg'
                  : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
              }`}
            >
              <Icon className={`w-4 h-4 ${tab.color}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ============================================================== */}
      {/* 1. THERMODYNAMIC ENGINE & CYCLES */}
      {/* ============================================================== */}
      {activeTab === 'engine' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-orange-500/30 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-orange-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Flame className="w-4 h-4" />
                  <span>State Variables & Gibbs Spontaneity</span>
                </span>
                <span className="text-slate-400 text-[10px]">ΔG = ΔH - TΔS</span>
              </div>

              {/* Sliders */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Temperature (T):</span>
                    <span className="text-orange-300 font-bold">{tempK} K ({(tempK - 273.15).toFixed(1)} °C)</span>
                  </div>
                  <input
                    type="range"
                    min={100}
                    max={1200}
                    step={10}
                    value={tempK}
                    onChange={(e) => setTempK(parseInt(e.target.value))}
                    className="w-full accent-orange-400 cursor-pointer"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Enthalpy Change (ΔH):</span>
                    <span className="text-amber-300 font-bold">{deltaH_kJ} kJ/mol</span>
                  </div>
                  <input
                    type="range"
                    min={-150}
                    max={150}
                    step={5}
                    value={deltaH_kJ}
                    onChange={(e) => setDeltaH_kJ(parseInt(e.target.value))}
                    className="w-full accent-amber-400 cursor-pointer"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Entropy Change (ΔS):</span>
                    <span className="text-cyan-300 font-bold">{deltaS_J} J/(mol·K)</span>
                  </div>
                  <input
                    type="range"
                    min={-200}
                    max={200}
                    step={5}
                    value={deltaS_J}
                    onChange={(e) => setDeltaS_J(parseInt(e.target.value))}
                    className="w-full accent-cyan-400 cursor-pointer"
                  />
                </div>
              </div>

              {/* Gibbs Free Energy Spontaneity Readout */}
              <div className={`p-4 rounded-2xl border transition-all ${
                isSpontaneous
                  ? 'bg-emerald-500/20 border-emerald-400 text-emerald-200'
                  : 'bg-red-500/20 border-red-400 text-red-200'
              }`}>
                <div className="flex justify-between items-center font-bold">
                  <span>Gibbs Energy (ΔG): {deltaG_kJ.toFixed(2)} kJ/mol</span>
                  <span>{isSpontaneous ? 'SPONTANEOUS (ΔG < 0)' : 'NON-SPONTANEOUS (ΔG > 0)'}</span>
                </div>
                <div className="text-[11px] pt-2">
                  Enthalpic term ΔH: <strong>{deltaH_kJ} kJ</strong> • Entropic term -TΔS: <strong>{(-(tempK * deltaS_J) / 1000).toFixed(2)} kJ</strong>
                </div>
              </div>
            </div>

            {/* Right P-V Diagram */}
            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Activity className="w-4 h-4 text-orange-400" />
                  <span>Thermodynamic Indicator P-V Diagram & Carnot Cycle</span>
                </h3>
                <span className="text-[10px] text-slate-400">Carnot Efficiency: <strong className="text-orange-400">{carnotEfficiency.toFixed(1)}%</strong></span>
              </div>

              <div className="w-full bg-black/60 rounded-2xl p-4 border border-white/5">
                <svg viewBox="0 0 500 180" className="w-full h-auto select-none">
                  {/* P-V Axes */}
                  <line x1="40" y1="20" x2="40" y2="150" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5" />
                  <line x1="40" y1="150" x2="470" y2="150" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5" />
                  <text x="35" y="25" textAnchor="end" fill="#94a3b8" fontSize="9">P</text>
                  <text x="470" y="165" textAnchor="end" fill="#94a3b8" fontSize="9">V</text>

                  {/* Carnot 4-state cycle path */}
                  <polygon
                    points="120,40 280,65 380,120 180,105"
                    fill="rgba(249, 115, 22, 0.15)"
                    stroke="#f97316"
                    strokeWidth="2.5"
                  />

                  {/* Corner nodes */}
                  <circle cx="120" cy="40" r="4" fill="#38bdf8" />
                  <text x="110" y="35" fill="#38bdf8" fontSize="8" fontWeight="bold">1 (T_H)</text>

                  <circle cx="280" cy="65" r="4" fill="#f59e0b" />
                  <text x="290" y="60" fill="#f59e0b" fontSize="8" fontWeight="bold">2</text>

                  <circle cx="380" cy="120" r="4" fill="#ef4444" />
                  <text x="390" y="125" fill="#ef4444" fontSize="8" fontWeight="bold">3 (T_C)</text>

                  <circle cx="180" cy="105" r="4" fill="#10b981" />
                  <text x="165" y="115" fill="#10b981" fontSize="8" fontWeight="bold">4</text>

                  <text x="240" y="95" textAnchor="middle" fill="#f97316" fontSize="9" fontWeight="bold">
                    Net Work W = ∮ P dV
                  </text>
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 2. VIRTUAL CALORIMETER LAB */}
      {/* ============================================================== */}
      {activeTab === 'calorimetry' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-amber-500/30 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-amber-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Activity className="w-4 h-4" />
                  <span>Calorimetry Heat Exchange</span>
                </span>
                <span className="text-slate-400 text-[10px]">q = m · c · ΔT</span>
              </div>

              {/* Reaction Selection */}
              <div className="space-y-2">
                <label className="text-slate-400 uppercase text-[10px] block">Select Calorimeter Reaction:</label>
                <div className="grid grid-cols-1 gap-1.5">
                  {calReactions.map((r) => (
                    <button
                      key={r.name}
                      onClick={() => setSelectedCalRxn(r)}
                      className={`p-2.5 rounded-xl text-left border transition-all ${
                        selectedCalRxn.name === r.name
                          ? 'bg-amber-500/20 border-amber-400 text-amber-300 font-bold'
                          : 'bg-white/[0.02] border-white/5 text-slate-300 hover:bg-white/[0.05]'
                      }`}
                    >
                      <div className="font-bold">{r.name}</div>
                      <div className="text-[10px] text-slate-400">ΔH = {r.dH} kJ/mol ({r.type})</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Mass of Solution */}
              <div className="space-y-2 pt-2 border-t border-white/5">
                <div className="flex justify-between">
                  <span className="text-slate-400">Water Mass (m):</span>
                  <span className="text-amber-300 font-bold">{calWaterMass} g</span>
                </div>
                <input
                  type="range"
                  min={50}
                  max={500}
                  step={10}
                  value={calWaterMass}
                  onChange={(e) => setCalWaterMass(parseInt(e.target.value))}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>

              {/* Calculation Box */}
              <div className="p-4 rounded-2xl bg-black/60 border border-white/10 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Initial Temperature (T_i):</span>
                  <span className="text-slate-300 font-bold">{calInitTemp.toFixed(1)} °C</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Final Temperature (T_f):</span>
                  <span className="text-amber-300 font-bold text-base">{finalCalTemp.toFixed(1)} °C (ΔT = {simulatedDeltaT > 0 ? '+' : ''}{simulatedDeltaT.toFixed(1)} °C)</span>
                </div>
                <div className="flex justify-between pt-1 border-t border-white/5">
                  <span className="text-slate-400">Heat Exchanged (q_solution):</span>
                  <span className="text-cyan-300 font-bold">{(heatReleasedJoules / 1000).toFixed(2)} kJ</span>
                </div>
              </div>
            </div>

            {/* Right Thermal Curve */}
            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-white/10 pb-3">
                <Activity className="w-4 h-4 text-amber-400" />
                <span>Calorimeter Temperature vs Time Equilibration Curve</span>
              </h3>

              <div className="w-full bg-black/60 rounded-2xl p-4 border border-white/5">
                <svg viewBox="0 0 500 180" className="w-full h-auto select-none">
                  {/* Axes */}
                  <line x1="40" y1="20" x2="40" y2="150" stroke="rgba(255,255,255,0.2)" />
                  <line x1="40" y1="150" x2="470" y2="150" stroke="rgba(255,255,255,0.2)" />

                  {/* Curve from T_init to T_final */}
                  {(() => {
                    const pts = [];
                    for (let t = 0; t <= 100; t += 2) {
                      const x = 40 + (t / 100) * 430;
                      // Exponential approach to final temp
                      const currentT = calInitTemp + simulatedDeltaT * (1 - Math.exp(-t / 15));
                      const y = 140 - ((currentT - 15) / 30) * 110;
                      pts.push(`${x.toFixed(1)},${y.toFixed(1)}`);
                    }
                    return <path d={`M ${pts.join(' L ')}`} fill="none" stroke="#f59e0b" strokeWidth="2.5" />;
                  })()}

                  <text x="250" y="168" textAnchor="middle" fill="#94a3b8" fontSize="9">Time (seconds) →</text>
                  <text x="30" y="25" textAnchor="end" fill="#94a3b8" fontSize="9">Temp (°C)</text>
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 3. CHEMICAL EQUILIBRIUM & LE CHATELIER */}
      {/* ============================================================== */}
      {activeTab === 'equilibrium' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-cyan-500/30 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-cyan-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Sliders className="w-4 h-4" />
                  <span>Equilibrium Perturbation Controls</span>
                </span>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Reactant Conc [A]:</span>
                    <span className="text-cyan-300 font-bold">{concA.toFixed(2)} M</span>
                  </div>
                  <input
                    type="range"
                    min={0.2}
                    max={3.0}
                    step={0.1}
                    value={concA}
                    onChange={(e) => setConcA(parseFloat(e.target.value))}
                    className="w-full accent-cyan-400 cursor-pointer"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Vessel Volume (V):</span>
                    <span className="text-purple-300 font-bold">{eqVolume.toFixed(2)} L (P ∝ 1/V)</span>
                  </div>
                  <input
                    type="range"
                    min={0.5}
                    max={3.0}
                    step={0.1}
                    value={eqVolume}
                    onChange={(e) => setEqVolume(parseFloat(e.target.value))}
                    className="w-full accent-purple-400 cursor-pointer"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Temperature (T):</span>
                    <span className="text-orange-300 font-bold">{eqTemp} K</span>
                  </div>
                  <input
                    type="range"
                    min={250}
                    max={600}
                    step={10}
                    value={eqTemp}
                    onChange={(e) => setEqTemp(parseInt(e.target.value))}
                    className="w-full accent-orange-400 cursor-pointer"
                  />
                </div>
              </div>

              {/* Le Chatelier Response Box */}
              <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-400/30 space-y-2">
                <div className="flex justify-between items-center text-cyan-300 font-bold">
                  <span>Q = {Q.toFixed(2)} | K_eq = {Keq.toFixed(2)}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950 border border-cyan-400/40 text-cyan-300 font-bold text-center">
                  {eqShift}
                </div>
              </div>
            </div>

            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-white/10 pb-3">
                <Sliders className="w-4 h-4 text-cyan-400" />
                <span>Le Chatelier's Principle Dynamic Vessel Response</span>
              </h3>
              <p className="text-slate-300 text-[11px] font-sans leading-relaxed">
                When a stress is applied to a chemical system at equilibrium:
                <br />• <strong>Increasing [Reactant]:</strong> System consumes reactant, shifting RIGHT.
                <br />• <strong>Decreasing Volume (Increasing Pressure):</strong> Shifts toward side with FEWER moles of gas.
                <br />• <strong>Increasing Temperature in Exothermic Reaction:</strong> Shifts LEFT to consume added thermal energy.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 4. REACTION KINETICS & CATALYSTS */}
      {/* ============================================================== */}
      {activeTab === 'kinetics' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-emerald-500/30 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-emerald-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Zap className="w-4 h-4" />
                  <span>Arrhenius Collision Rate Controls</span>
                </span>
                <span className="text-slate-400 text-[10px]">k = A · e^(-Ea/RT)</span>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Temperature (T):</span>
                    <span className="text-emerald-300 font-bold">{kinTemp} K</span>
                  </div>
                  <input
                    type="range"
                    min={250}
                    max={600}
                    step={10}
                    value={kinTemp}
                    onChange={(e) => setKinTemp(parseInt(e.target.value))}
                    className="w-full accent-emerald-400 cursor-pointer"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Uncatalyzed Activation Energy (E_a):</span>
                    <span className="text-amber-300 font-bold">{activationEa} kJ/mol</span>
                  </div>
                  <input
                    type="range"
                    min={20}
                    max={100}
                    step={5}
                    value={activationEa}
                    onChange={(e) => setActivationEa(parseInt(e.target.value))}
                    className="w-full accent-amber-400 cursor-pointer"
                  />
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => setHasCatalyst(!hasCatalyst)}
                    className={`w-full p-3 rounded-xl font-bold border transition-all flex items-center justify-center gap-2 ${
                      hasCatalyst
                        ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                        : 'bg-white/[0.03] border-white/10 text-slate-400 hover:text-white'
                    }`}
                  >
                    <span>{hasCatalyst ? '✓ CATALYST ACTIVE (-20 kJ/mol Ea)' : '+ ADD REACTION CATALYST'}</span>
                  </button>
                </div>
              </div>

              {/* Rate Constant Readout */}
              <div className="p-4 rounded-2xl bg-black/60 border border-white/10 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Effective Activation Energy:</span>
                  <span className="text-emerald-300 font-bold">{effectiveEa} kJ/mol</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Rate Constant (k):</span>
                  <span className="text-cyan-400 font-bold text-base">{(arrheniusRateK).toExponential(3)} s⁻¹</span>
                </div>
              </div>
            </div>

            {/* Right Potential Energy Diagram */}
            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-white/10 pb-3">
                <Zap className="w-4 h-4 text-emerald-400" />
                <span>Reaction Coordinate Potential Energy Diagram</span>
              </h3>

              <div className="w-full bg-black/60 rounded-2xl p-4 border border-white/5">
                <svg viewBox="0 0 500 180" className="w-full h-auto select-none">
                  {/* Reactants Plateau */}
                  <line x1="40" y1="120" x2="120" y2="120" stroke="#38bdf8" strokeWidth="3" />
                  <text x="75" y="112" textAnchor="middle" fill="#38bdf8" fontSize="9" fontWeight="bold">Reactants</text>

                  {/* Products Plateau */}
                  <line x1="380" y1="140" x2="460" y2="140" stroke="#10b981" strokeWidth="3" />
                  <text x="420" y="132" textAnchor="middle" fill="#10b981" fontSize="9" fontWeight="bold">Products</text>

                  {/* Uncatalyzed Barrier (Red curve) */}
                  <path
                    d={`M 120 120 C 180 ${120 - activationEa * 1.0}, 320 ${120 - activationEa * 1.0}, 380 140`}
                    fill="none"
                    stroke="#ef4444"
                    strokeWidth="2.5"
                  />
                  <text x="250" y={110 - activationEa * 1.0} textAnchor="middle" fill="#ef4444" fontSize="8" fontWeight="bold">
                    Uncatalyzed TS (Ea = {activationEa} kJ)
                  </text>

                  {/* Catalyzed Barrier (Green curve) */}
                  {hasCatalyst && (
                    <>
                      <path
                        d={`M 120 120 C 180 ${120 - effectiveEa * 1.0}, 320 ${120 - effectiveEa * 1.0}, 380 140`}
                        fill="none"
                        stroke="#10b981"
                        strokeWidth="2.5"
                        strokeDasharray="4 2"
                      />
                      <text x="250" y={110 - effectiveEa * 1.0} textAnchor="middle" fill="#10b981" fontSize="8" fontWeight="bold">
                        Catalyzed TS (Ea = {effectiveEa} kJ)
                      </text>
                    </>
                  )}
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
