import React, { useState } from 'react';
import {
  FlaskConical,
  Zap,
  Flame,
  Activity,
  Sparkles,
  Scale,
  RefreshCw,
  Box,
  Layers,
  Thermometer,
  Compass,
  CheckCircle2,
  Gauge
} from 'lucide-react';
import { LatexRenderer } from '../common/LatexRenderer';
import { NavigationTab } from '../../types';

interface PhysicalChemViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

export const PhysicalChemView: React.FC<PhysicalChemViewProps> = ({ onNavigate }) => {
  const [activeModule, setActiveModule] = useState<
    'thermo' | 'equilibrium' | 'kinetics' | 'electro' | 'solutions' | 'surface' | 'solidstate'
  >('thermo');

  // 1. Thermodynamics State
  const [dH, setDH] = useState<number>(-50); // kJ/mol
  const [dS, setDS] = useState<number>(-120); // J/(mol*K)
  const [tempK, setTempK] = useState<number>(298); // Kelvin
  const [tHot, setTHot] = useState<number>(500); // K
  const [tCold, setTCold] = useState<number>(300); // K

  const dG = dH - tempK * (dS / 1000);
  const isSpontaneous = dG < 0;
  const carnotEfficiency = ((1 - tCold / tHot) * 100).toFixed(1);

  // 2. Equilibrium & Le Chatelier State
  const [acidConc, setAcidConc] = useState<number>(0.1);
  const [baseConc, setBaseConc] = useState<number>(0.1);
  const [pKa, setPKa] = useState<number>(4.76); // Acetic acid
  const bufferPH = pKa + Math.log10(baseConc / (acidConc || 0.001));

  const [leChatelierTemp, setLeChatelierTemp] = useState<number>(450); // °C
  const [leChatelierPressure, setLeChatelierPressure] = useState<number>(200); // atm
  // Haber-Bosch yield estimate based on Le Chatelier
  const haberYield = Math.max(
    5,
    Math.min(95, Math.round(50 + (leChatelierPressure - 150) * 0.15 - (leChatelierTemp - 400) * 0.2))
  );

  // 3. Chemical Kinetics & Arrhenius State
  const [activationEnergy, setActivationEnergy] = useState<number>(65); // kJ/mol
  const [kineticsTemp, setKineticsTemp] = useState<number>(310); // Kelvin
  const [hasCatalyst, setHasCatalyst] = useState<boolean>(false);
  const effectiveEa = hasCatalyst ? activationEnergy * 0.55 : activationEnergy;
  const A_factor = 1e11;
  const k_rate = A_factor * Math.exp(-(effectiveEa * 1000) / (8.314 * kineticsTemp));
  const halfLifeFirstOrder = (Math.LN2 / k_rate).toExponential(3);

  // 4. Electrochemistry & Nernst State (Daniell Cell)
  const [znConc, setZnConc] = useState<number>(0.01); // M
  const [cuConc, setCuConc] = useState<number>(1.0); // M
  const E0_daniell = 1.10; // Volts
  const Q_cell = znConc / (cuConc || 0.0001);
  const E_cell = E0_daniell - (0.0592 / 2) * Math.log10(Q_cell);

  // 5. Solutions & Colligative State
  const [molality, setMolality] = useState<number>(0.5); // mol/kg
  const [vanTHoffI, setVanTHoffI] = useState<number>(2); // NaCl i=2
  const Kb_water = 0.512; // K*kg/mol
  const Kf_water = 1.86; // K*kg/mol
  const deltaTb = vanTHoffI * Kb_water * molality;
  const deltaTf = vanTHoffI * Kf_water * molality;
  const osmoticPressure = (vanTHoffI * molality * 0.0821 * 298).toFixed(2); // atm

  // 6. Surface Chemistry State
  const [adsorptionPressure, setAdsorptionPressure] = useState<number>(5); // atm
  const [freundlichN, setFreundlichN] = useState<number>(2);
  const freundlichExtent = (2.5 * Math.pow(adsorptionPressure, 1 / freundlichN)).toFixed(2);

  // 7. Solid State Crystallography State
  const [latticeType, setLatticeType] = useState<'SC' | 'BCC' | 'FCC'>('FCC');
  const latticeData = {
    SC: { name: 'Simple Cubic', z: 1, coord: 6, packing: '52.4%', radiusFormula: 'r = a/2' },
    BCC: { name: 'Body-Centered Cubic', z: 2, coord: 8, packing: '68.0%', radiusFormula: 'r = (\\sqrt{3}/4)a' },
    FCC: { name: 'Face-Centered Cubic (CCP)', z: 4, coord: 12, packing: '74.0%', radiusFormula: 'r = (\\sqrt{2}/4)a' }
  }[latticeType];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6 bg-lab-physical min-h-screen text-slate-100">
      {/* Header */}
      <div className="p-6 rounded-3xl bg-[#090d16]/90 border border-cyan-500/20 backdrop-blur-xl shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 font-mono">
              LABORATORY // PHYSICAL CHEMISTRY
            </span>
            <span className="text-xs text-slate-400 font-mono">QUANTUM & THERMODYNAMIC SYSTEMS</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-display-physical text-white tracking-tight mt-1">
            Physical Chemistry & Quantum Dynamics
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Simulate Gibbs free energy, Nernst potentials, Arrhenius kinetics, colligative properties, and crystal lattices.
          </p>
        </div>

        {/* Sub-module Navigation */}
        <div className="flex flex-wrap items-center gap-1.5 p-1.5 rounded-2xl bg-black/40 border border-white/10 font-mono text-xs">
          {[
            { id: 'thermo', label: 'Thermodynamics (ΔG)' },
            { id: 'equilibrium', label: 'Equilibrium (Le Chatelier)' },
            { id: 'kinetics', label: 'Kinetics (Arrhenius)' },
            { id: 'electro', label: 'Electrochemistry (Nernst)' },
            { id: 'solutions', label: 'Colligative Solutions' },
            { id: 'surface', label: 'Surface Chemistry' },
            { id: 'solidstate', label: 'Solid State (Crystals)' }
          ].map((m) => (
            <button
              key={m.id}
              onClick={() => setActiveModule(m.id as any)}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                activeModule === m.id
                  ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-400/40 shadow-lg shadow-cyan-500/10'
                  : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>
      </div>

      {/* MODULE 1: THERMODYNAMICS */}
      {activeModule === 'thermo' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-4 font-mono text-xs">
            <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
              <Flame className="w-4 h-4" />
              <span>Gibbs Free Energy Equation & Parameters</span>
            </h2>

            <div className="p-4 rounded-2xl bg-black/40 border border-white/5 text-center py-4 text-cyan-300">
              <LatexRenderer latex="\Delta G = \Delta H - T \Delta S" displayMode />
            </div>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <div className="flex justify-between text-slate-300">
                  <span>Enthalpy Change (ΔH): {dH} kJ/mol</span>
                  <span className={dH < 0 ? 'text-cyan-400' : 'text-orange-400'}>
                    {dH < 0 ? 'Exothermic' : 'Endothermic'}
                  </span>
                </div>
                <input
                  type="range"
                  min="-200"
                  max="200"
                  value={dH}
                  onChange={(e) => setDH(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-slate-300">
                  <span>Entropy Change (ΔS): {dS} J/(mol·K)</span>
                  <span className={dS > 0 ? 'text-emerald-400' : 'text-amber-400'}>
                    {dS > 0 ? 'Disorder increases (+ΔS)' : 'Order increases (-ΔS)'}
                  </span>
                </div>
                <input
                  type="range"
                  min="-300"
                  max="300"
                  value={dS}
                  onChange={(e) => setDS(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-slate-300">
                  <span>Temperature (T): {tempK} K ({tempK - 273} °C)</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="1500"
                  value={tempK}
                  onChange={(e) => setTempK(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
                />
              </div>
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-4 font-mono text-xs flex flex-col justify-between">
            <div>
              <span className="text-cyan-400 font-bold uppercase tracking-wider text-xs block mb-3">
                Calculated Spontaneity Outcome
              </span>

              <div className={`p-5 rounded-2xl border ${
                isSpontaneous ? 'bg-emerald-500/10 border-emerald-500/30' : 'bg-red-500/10 border-red-500/30'
              }`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-slate-300">Gibbs Energy (ΔG):</span>
                  <span className={`text-xl font-bold ${isSpontaneous ? 'text-emerald-400' : 'text-red-400'}`}>
                    {dG.toFixed(2)} kJ/mol
                  </span>
                </div>
                <div className="text-sm font-bold text-white flex items-center gap-2">
                  <CheckCircle2 className={`w-4 h-4 ${isSpontaneous ? 'text-emerald-400' : 'text-red-400'}`} />
                  <span>{isSpontaneous ? 'Reaction is Thermodynamically SPONTANEOUS' : 'Reaction is NON-SPONTANEOUS'}</span>
                </div>
              </div>
            </div>

            {/* Carnot Engine Efficiency */}
            <div className="p-4 rounded-2xl bg-black/40 border border-white/5 space-y-3">
              <span className="text-slate-400 font-bold uppercase text-[11px] block">
                Second Law & Carnot Heat Engine Efficiency
              </span>
              <div className="text-cyan-300 text-xs py-1">
                <LatexRenderer latex="\eta = 1 - \frac{T_C}{T_H} = \frac{T_H - T_C}{T_H}" />
              </div>
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div>Hot Temp (T_H): {tHot} K</div>
                <div>Cold Temp (T_C): {tCold} K</div>
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-white/5">
                <span>Maximum Theoretical Efficiency:</span>
                <span className="text-cyan-300 font-bold text-sm">{carnotEfficiency}%</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODULE 2: CHEMICAL & IONIC EQUILIBRIUM */}
      {activeModule === 'equilibrium' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
          {/* Le Chatelier Simulator */}
          <div className="p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-4">
            <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
              <Activity className="w-4 h-4" />
              <span>Haber-Bosch Le Chatelier Disturbance Lab</span>
            </h2>

            <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 text-cyan-200">
              <LatexRenderer latex="N_2 (g) + 3H_2 (g) \rightleftharpoons 2NH_3 (g) \quad \Delta H = -92.4 \text{ kJ/mol}" />
            </div>

            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Temperature: {leChatelierTemp} °C</span>
                  <span className="text-amber-400">{leChatelierTemp > 450 ? 'Favors backward endothermic' : 'Favors forward exothermic'}</span>
                </div>
                <input
                  type="range"
                  min="300"
                  max="650"
                  value={leChatelierTemp}
                  onChange={(e) => setLeChatelierTemp(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Pressure: {leChatelierPressure} atm</span>
                  <span className="text-cyan-400">{leChatelierPressure > 150 ? 'High P favors fewer moles (NH₃)' : 'Low P favors reactants'}</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="350"
                  value={leChatelierPressure}
                  onChange={(e) => setLeChatelierPressure(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
                />
              </div>

              <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-between">
                <span>Calculated Equilibrium Yield of NH₃:</span>
                <span className="text-xl font-bold text-cyan-300">{haberYield}%</span>
              </div>
            </div>
          </div>

          {/* Henderson-Hasselbalch Buffer Lab */}
          <div className="p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-4">
            <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
              <Scale className="w-4 h-4" />
              <span>Henderson-Hasselbalch Buffer pH Calculator</span>
            </h2>

            <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 text-cyan-200">
              <LatexRenderer latex="\text{pH} = \text{pK}_a + \log_{10} \frac{[\text{A}^-]}{[\text{HA}]}" />
            </div>

            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Weak Acid Concentration [HA]: {acidConc} M</span>
                </div>
                <input
                  type="range"
                  min="0.01"
                  max="1.0"
                  step="0.01"
                  value={acidConc}
                  onChange={(e) => setAcidConc(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Conjugate Base [A⁻]: {baseConc} M</span>
                </div>
                <input
                  type="range"
                  min="0.01"
                  max="1.0"
                  step="0.01"
                  value={baseConc}
                  onChange={(e) => setBaseConc(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
                />
              </div>

              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-between">
                <span>Calculated Buffer pH:</span>
                <span className="text-2xl font-bold text-emerald-400">{bufferPH.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODULE 3: CHEMICAL KINETICS */}
      {activeModule === 'kinetics' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
          <div className="p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-4">
            <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
              <Gauge className="w-4 h-4" />
              <span>Arrhenius Rate Law & Activation Energy</span>
            </h2>

            <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 text-cyan-200">
              <LatexRenderer latex="k = A e^{-\frac{E_a}{RT}}, \quad t_{1/2} = \frac{\ln 2}{k} \text{ (1st order)}" />
            </div>

            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Activation Energy (E_a): {activationEnergy} kJ/mol</span>
                  {hasCatalyst && <span className="text-emerald-400">Catalyzed: {effectiveEa.toFixed(1)} kJ/mol</span>}
                </div>
                <input
                  type="range"
                  min="20"
                  max="150"
                  value={activationEnergy}
                  onChange={(e) => setActivationEnergy(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Temperature: {kineticsTemp} K ({kineticsTemp - 273} °C)</span>
                </div>
                <input
                  type="range"
                  min="200"
                  max="700"
                  value={kineticsTemp}
                  onChange={(e) => setKineticsTemp(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
                />
              </div>

              <button
                onClick={() => setHasCatalyst((c) => !c)}
                className={`w-full py-2.5 rounded-2xl font-bold transition-all border ${
                  hasCatalyst
                    ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                    : 'bg-white/[0.04] border-white/10 text-slate-300 hover:text-white'
                }`}
              >
                {hasCatalyst ? 'Catalyst Applied (Activation Energy Reduced by 45%)' : 'Apply Catalyst'}
              </button>
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <span className="text-cyan-400 font-bold uppercase text-xs block">Kinetics Execution Metrics</span>
              <div className="p-4 rounded-2xl bg-black/40 border border-white/5 space-y-2">
                <div className="flex justify-between">
                  <span>Rate Constant (k):</span>
                  <span className="text-cyan-300 font-bold">{k_rate.toExponential(4)} s⁻¹</span>
                </div>
                <div className="flex justify-between">
                  <span>First-Order Half-Life (t₁/₂):</span>
                  <span className="text-emerald-400 font-bold">{halfLifeFirstOrder} s</span>
                </div>
              </div>
            </div>

            <p className="text-slate-400 text-[11px] leading-relaxed">
              According to collision theory, only reactant collisions with energy greater than or equal to $E_a$ and proper spatial steric orientation yield chemical transformation.
            </p>
          </div>
        </div>
      )}

      {/* MODULE 4: ELECTROCHEMISTRY */}
      {activeModule === 'electro' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
          <div className="p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-4">
            <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
              <Zap className="w-4 h-4" />
              <span>Nernst Galvanic Cell Potential Simulator</span>
            </h2>

            <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 text-cyan-200">
              <LatexRenderer latex="E_{\text{cell}} = E^\circ - \frac{0.0592}{n} \log_{10} Q \quad (\text{at 298 K})" />
            </div>

            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Anode [Zn²⁺] Concentration: {znConc} M</span>
                </div>
                <input
                  type="range"
                  min="0.001"
                  max="2.0"
                  step="0.01"
                  value={znConc}
                  onChange={(e) => setZnConc(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Cathode [Cu²⁺] Concentration: {cuConc} M</span>
                </div>
                <input
                  type="range"
                  min="0.001"
                  max="2.0"
                  step="0.01"
                  value={cuConc}
                  onChange={(e) => setCuConc(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
                />
              </div>
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-4 flex flex-col justify-between">
            <div className="p-5 rounded-2xl bg-cyan-500/10 border border-cyan-500/30">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-slate-300">Live Daniell Cell EMF:</span>
                <span className="text-2xl font-bold text-cyan-300">{E_cell.toFixed(3)} V</span>
              </div>
              <div className="text-slate-400 text-[11px]">
                Reaction Quotient Q = [Zn²⁺]/[Cu²⁺] = {Q_cell.toFixed(3)} (Standard E° = +1.100 V)
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-black/40 border border-white/5 space-y-1 text-[11px]">
              <span className="text-slate-400 font-bold block">Faraday's Law of Electrolysis:</span>
              <div className="text-cyan-200">
                <LatexRenderer latex="m = \frac{M \cdot I \cdot t}{z \cdot F} \quad (F = 96,485 \text{ C/mol})" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODULE 5: COLLIGATIVE SOLUTIONS */}
      {activeModule === 'solutions' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
          <div className="p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-4">
            <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
              <FlaskConical className="w-4 h-4" />
              <span>Colligative Properties & Van 't Hoff Factor</span>
            </h2>

            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Solute Molality (m): {molality} mol/kg</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="3.0"
                  step="0.1"
                  value={molality}
                  onChange={(e) => setMolality(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Van 't Hoff Factor (i): {vanTHoffI}</span>
                  <span className="text-cyan-400">
                    {vanTHoffI === 1 ? 'Non-electrolyte (Glucose)' : vanTHoffI === 2 ? 'NaCl (i=2)' : 'CaCl₂ (i=3)'}
                  </span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="4"
                  step="1"
                  value={vanTHoffI}
                  onChange={(e) => setVanTHoffI(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
                />
              </div>
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-3">
            <span className="text-cyan-400 font-bold uppercase text-xs block">Calculated Colligative Shifts</span>
            <div className="space-y-2 text-slate-300">
              <div className="flex justify-between p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                <span>Boiling Point Elevation (ΔT_b = i·K_b·m):</span>
                <span className="text-cyan-300 font-bold">+{deltaTb.toFixed(3)} K</span>
              </div>
              <div className="flex justify-between p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                <span>Freezing Point Depression (ΔT_f = i·K_f·m):</span>
                <span className="text-cyan-300 font-bold">-{deltaTf.toFixed(3)} K</span>
              </div>
              <div className="flex justify-between p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                <span>Osmotic Pressure (Π = i·C·R·T):</span>
                <span className="text-emerald-400 font-bold">{osmoticPressure} atm</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODULE 6: SURFACE CHEMISTRY */}
      {activeModule === 'surface' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
          <div className="p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-4">
            <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
              <Layers className="w-4 h-4" />
              <span>Freundlich Adsorption Isotherm</span>
            </h2>

            <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 text-cyan-200">
              <LatexRenderer latex="\frac{x}{m} = k P^{1/n} \quad (n > 1)" />
            </div>

            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Gas Pressure (P): {adsorptionPressure} atm</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="20"
                  value={adsorptionPressure}
                  onChange={(e) => setAdsorptionPressure(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
                />
              </div>

              <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex justify-between items-center">
                <span>Extent of Adsorption (x/m):</span>
                <span className="text-xl font-bold text-cyan-300">{freundlichExtent} mg/g</span>
              </div>
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-3">
            <span className="text-cyan-400 font-bold uppercase text-xs block">Colloidal Principles</span>
            <div className="space-y-2 text-slate-300 text-[11px] leading-relaxed">
              <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                <span className="font-bold text-white block mb-0.5">Tyndall Effect:</span>
                Scattering of light by colloidal particles with dimensions comparable to incident wavelength.
              </div>
              <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                <span className="font-bold text-white block mb-0.5">Hardy-Schulze Rule:</span>
                Coagulating power of an electrolyte increases exponentially with the valency of the active flocculating ion (Al³⁺ &gt; Ba²⁺ &gt; Na⁺).
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODULE 7: SOLID STATE & CRYSTALS */}
      {activeModule === 'solidstate' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
          <div className="p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-4">
            <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
              <Box className="w-4 h-4" />
              <span>Unit Cell Geometry & Packing Efficiency</span>
            </h2>

            <div className="flex gap-2">
              {(['SC', 'BCC', 'FCC'] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => setLatticeType(type)}
                  className={`flex-1 py-2.5 rounded-2xl font-bold transition-all border ${
                    latticeType === type
                      ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow-md'
                      : 'bg-white/[0.02] border-white/5 text-slate-400 hover:text-white'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>

            <div className="space-y-2 text-slate-300">
              <div className="flex justify-between p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                <span>Lattice Name:</span>
                <span className="text-white font-bold">{latticeData.name}</span>
              </div>
              <div className="flex justify-between p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                <span>Effective Atoms per Unit Cell (z):</span>
                <span className="text-cyan-300 font-bold">{latticeData.z}</span>
              </div>
              <div className="flex justify-between p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                <span>Coordination Number:</span>
                <span className="text-white font-bold">{latticeData.coord}</span>
              </div>
              <div className="flex justify-between p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                <span>Packing Efficiency:</span>
                <span className="text-emerald-400 font-bold">{latticeData.packing}</span>
              </div>
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-4 flex flex-col justify-between">
            <div className="p-4 rounded-2xl bg-black/40 border border-white/5 space-y-2">
              <span className="text-slate-400 font-bold uppercase text-[11px] block">
                Crystal Density Equation
              </span>
              <div className="text-cyan-200 py-1">
                <LatexRenderer latex="\rho = \frac{z \cdot M}{a^3 \cdot N_A}" />
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-black/40 border border-white/5 space-y-2">
              <span className="text-slate-400 font-bold uppercase text-[11px] block">
                Bragg's Law of X-Ray Diffraction
              </span>
              <div className="text-cyan-200 py-1">
                <LatexRenderer latex="n\lambda = 2d\sin\theta" />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
