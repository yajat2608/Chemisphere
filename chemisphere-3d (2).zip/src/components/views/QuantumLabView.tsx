import React, { useState, useMemo } from 'react';
import {
  Cpu,
  Zap,
  Activity,
  Layers,
  ArrowRight,
  HelpCircle,
  Eye,
  Sliders,
  ChevronRight,
  Sparkles,
  BarChart3,
  CheckCircle2,
  Atom
} from 'lucide-react';
import { NavigationTab } from '../../types';

interface QuantumLabViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

type QuantumSubTab = 'box' | 'tunnelling' | 'photoelectric' | 'uncertainty';

export const QuantumLabView: React.FC<QuantumLabViewProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<QuantumSubTab>('box');

  // ==========================================
  // 1. PARTICLE IN A BOX STATE
  // ==========================================
  const [boxN, setBoxN] = useState<number>(3);
  const [boxL, setBoxL] = useState<number>(1.0); // nm
  const [particleType, setParticleType] = useState<'electron' | 'proton' | 'muon'>('electron');

  // Physical Constants
  const h = 6.62607015e-34; // J s
  const hbar = 1.054571817e-34; // J s
  const eCharge = 1.602176634e-19; // C
  const massMap = {
    electron: 9.1093837e-31,
    proton: 1.6726219e-27,
    muon: 1.8835316e-28
  };
  const currentMass = massMap[particleType];

  // E_n = (n^2 * h^2) / (8 * m * L^2)
  const boxLengthMeters = boxL * 1e-9;
  const energyJoules = (Math.pow(boxN, 2) * Math.pow(h, 2)) / (8 * currentMass * Math.pow(boxLengthMeters, 2));
  const energyEv = energyJoules / eCharge;

  // ==========================================
  // 2. QUANTUM TUNNELLING STATE
  // ==========================================
  const [tunnelE, setTunnelE] = useState<number>(4.0); // eV
  const [tunnelV0, setTunnelV0] = useState<number>(6.0); // eV
  const [tunnelA, setTunnelA] = useState<number>(0.2); // nm

  // Tunnelling transmission probability T
  // kappa = sqrt(2 * m * (V0 - E)) / hbar
  const v0J = tunnelV0 * eCharge;
  const eJ = tunnelE * eCharge;
  const mElectron = massMap.electron;
  const kappa = tunnelV0 > tunnelE ? Math.sqrt(2 * mElectron * (v0J - eJ)) / hbar : 0;
  const aMeters = tunnelA * 1e-9;
  const sinhTerm = tunnelV0 > tunnelE ? Math.sinh(kappa * aMeters) : 0;
  const transmissionT = tunnelV0 <= tunnelE
    ? 1.0
    : Math.max(0, Math.min(1.0, 1 / (1 + (Math.pow(v0J, 2) * Math.pow(sinhTerm, 2)) / (4 * eJ * (v0J - eJ)))));
  const reflectionR = 1 - transmissionT;

  // ==========================================
  // 3. PHOTOELECTRIC EFFECT STATE
  // ==========================================
  const photoMetals = [
    { name: 'Cesium (Cs)', phi: 2.14, color: '#f59e0b' },
    { name: 'Potassium (K)', phi: 2.30, color: '#a855f7' },
    { name: 'Sodium (Na)', phi: 2.36, color: '#38bdf8' },
    { name: 'Zinc (Zn)', phi: 4.30, color: '#10b981' },
    { name: 'Platinum (Pt)', phi: 6.35, color: '#ec4899' }
  ];
  const [selectedMetal, setSelectedMetal] = useState(photoMetals[2]); // Sodium
  const [lightWavelength, setLightWavelength] = useState<number>(450); // nm
  const [lightIntensity, setLightIntensity] = useState<number>(60); // %

  // Photon Energy = hc / lambda
  const photonEnergyJ = (h * 3e8) / (lightWavelength * 1e-9);
  const photonEnergyEv = photonEnergyJ / eCharge;
  const thresholdFreq = (selectedMetal.phi * eCharge) / h;
  const thresholdLambda = (3e8 / thresholdFreq) * 1e9; // nm
  const maxKineticEnergyEv = Math.max(0, photonEnergyEv - selectedMetal.phi);
  const stoppingPotential = maxKineticEnergyEv; // Volts
  const isEmitting = photonEnergyEv >= selectedMetal.phi;

  // ==========================================
  // 4. UNCERTAINTY & DE BROGLIE STATE
  // ==========================================
  const [slitDeltaX, setSlitDeltaX] = useState<number>(0.1); // nm
  const [particleVelocity, setParticleVelocity] = useState<number>(1e6); // m/s
  const pMomentum = massMap.electron * particleVelocity;
  const deBroglieLambda = (h / pMomentum) * 1e9; // nm
  const deltaX_meters = slitDeltaX * 1e-9;
  const minDeltaP = hbar / (2 * deltaX_meters);
  const minDeltaV = minDeltaP / massMap.electron;

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8 font-sans">
      {/* Header Banner */}
      <div className="relative rounded-3xl overflow-hidden border border-cyan-500/30 bg-[#080d1a] p-6 sm:p-10 shadow-2xl">
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-20 -bottom-20 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-400/30 text-cyan-400 text-xs font-mono font-bold tracking-wide">
            <Cpu className="w-3.5 h-3.5" />
            <span>QUANTUM MECHANICS & WAVE MECHANICS LABORATORY</span>
          </div>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-display-periodic">
                QUANTUM MECHANICS LAB
              </h1>
              <p className="text-slate-300 text-sm sm:text-base max-w-3xl mt-2 leading-relaxed font-sans">
                Explore the fundamental laws of quantum reality: <strong>Particle-in-a-Box</strong> infinite potential wells, <strong>Quantum Tunnelling</strong> barrier penetration, Einstein's <strong>Photoelectric Effect</strong>, and <strong>Heisenberg Uncertainty / de Broglie</strong> matter waves.
              </p>
            </div>

            {onNavigate && (
              <button
                onClick={() => onNavigate('lab-directory')}
                className="px-4 py-2.5 rounded-2xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-slate-300 hover:text-white font-mono text-xs font-bold transition-all shrink-0 flex items-center gap-2"
              >
                <span>LAB DIRECTORY</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Sub Navigation */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-[#090d16] border border-white/10 overflow-x-auto font-mono text-xs">
        {[
          { id: 'box' as QuantumSubTab, label: '1. Particle in a Box (1D Well)', icon: Layers, color: 'text-cyan-400' },
          { id: 'tunnelling' as QuantumSubTab, label: '2. Quantum Tunnelling Simulator', icon: Zap, color: 'text-amber-400' },
          { id: 'photoelectric' as QuantumSubTab, label: '3. Photoelectric Effect Instrument', icon: Sparkles, color: 'text-purple-400' },
          { id: 'uncertainty' as QuantumSubTab, label: '4. de Broglie & Heisenberg Uncertainty', icon: Activity, color: 'text-emerald-400' }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2.5 rounded-xl font-bold flex items-center gap-2 whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-white/15 text-white border border-white/20 shadow-lg'
                  : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
              }`}
            >
              <Icon className={`w-4 h-4 ${tab.color}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ============================================================== */}
      {/* 1. PARTICLE IN A BOX (1D INFINITE POTENTIAL WELL) */}
      {/* ============================================================== */}
      {activeTab === 'box' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Controls */}
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-cyan-500/30 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-cyan-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Layers className="w-4 h-4" />
                  <span>Infinite Potential Well Controls</span>
                </span>
                <span className="text-slate-400 text-[10px]">ψ_n(x) = √(2/L) sin(nπx/L)</span>
              </div>

              {/* Quantum Number n */}
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Principal Quantum State (n):</span>
                  <span className="text-cyan-300 font-bold text-sm">n = {boxN} ({boxN - 1} Nodes)</span>
                </div>
                <div className="flex gap-1.5 flex-wrap">
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((num) => (
                    <button
                      key={num}
                      onClick={() => setBoxN(num)}
                      className={`w-9 h-9 rounded-xl font-bold transition-all border ${
                        boxN === num
                          ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-md'
                          : 'bg-white/[0.02] border-white/10 text-slate-300 hover:bg-white/[0.06]'
                      }`}
                    >
                      {num}
                    </button>
                  ))}
                </div>
              </div>

              {/* Box Length L */}
              <div className="space-y-2 pt-2 border-t border-white/5">
                <div className="flex justify-between">
                  <span className="text-slate-400">Box Length (L):</span>
                  <span className="text-cyan-300 font-bold">{boxL.toFixed(2)} nm ({boxL * 10} Å)</span>
                </div>
                <input
                  type="range"
                  min={0.2}
                  max={3.0}
                  step={0.1}
                  value={boxL}
                  onChange={(e) => setBoxL(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Particle Mass Type */}
              <div className="space-y-2">
                <label className="text-slate-400 uppercase text-[10px] block">Trapped Quantum Particle:</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'electron' as const, label: 'Electron (e⁻)' },
                    { id: 'muon' as const, label: 'Muon (μ⁻)' },
                    { id: 'proton' as const, label: 'Proton (p⁺)' }
                  ].map((p) => (
                    <button
                      key={p.id}
                      onClick={() => setParticleType(p.id)}
                      className={`p-2 rounded-xl text-[11px] border transition-all text-center ${
                        particleType === p.id
                          ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 font-bold'
                          : 'bg-white/[0.02] border-white/5 text-slate-400 hover:bg-white/[0.05]'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Calculated Energy Level Card */}
              <div className="p-4 rounded-2xl bg-black/50 border border-white/10 space-y-2">
                <div className="flex justify-between items-center text-slate-400">
                  <span>Energy Eigenvalue (E_{'{'}boxN{'}'}):</span>
                  <span className="text-cyan-400 font-bold text-base">{energyEv.toFixed(3)} eV</span>
                </div>
                <div className="text-[10px] text-slate-500">
                  = {(energyJoules).toExponential(4)} Joules
                </div>
                <div className="text-[11px] text-slate-300 pt-1 font-sans border-t border-white/5">
                  <strong>Zero-Point Energy (n=1):</strong> Even at absolute zero, the particle has minimum ground state kinetic energy E₁ = h² / (8mL²) &gt; 0 due to quantum confinement.
                </div>
              </div>
            </div>

            {/* Right Wavefunction & Probability Density Graph */}
            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Activity className="w-4 h-4 text-cyan-400" />
                    <span>Wavefunction ψ(x) and Probability Density |ψ(x)|²</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                    Spatial probability distribution inside infinite hard-wall boundaries
                  </p>
                </div>
              </div>

              {/* SVG Wavefunction Plots */}
              <div className="w-full bg-black/60 rounded-2xl p-4 border border-white/5 space-y-4">
                {/* 1. Wavefunction psi(x) */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-cyan-400 font-bold">1. Wavefunction ψ_{boxN}(x)</span>
                    <span className="text-slate-400">{boxN - 1} Zero-Crossing Nodes</span>
                  </div>
                  <svg viewBox="0 0 500 100" className="w-full h-auto select-none">
                    {/* Walls */}
                    <rect x="40" y="5" width="4" height="90" fill="#ef4444" />
                    <rect x="456" y="5" width="4" height="90" fill="#ef4444" />
                    <line x1="40" y1="50" x2="460" y2="50" stroke="rgba(255,255,255,0.15)" />

                    {/* Sine Wave */}
                    {(() => {
                      const pts = [];
                      for (let i = 0; i <= 200; i++) {
                        const frac = i / 200;
                        const x = 44 + frac * 412;
                        const psi = Math.sin(boxN * Math.PI * frac);
                        const y = 50 - psi * 38;
                        pts.push(`${x.toFixed(1)},${y.toFixed(1)}`);
                      }
                      return <path d={`M ${pts.join(' L ')}`} fill="none" stroke="#38bdf8" strokeWidth="2.5" />;
                    })()}
                  </svg>
                </div>

                {/* 2. Probability Density |psi(x)|^2 */}
                <div className="space-y-1 pt-2 border-t border-white/10">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-purple-400 font-bold">2. Probability Density |ψ_{boxN}(x)|²</span>
                    <span className="text-slate-400">{boxN} Antinodes (Maximum Probability)</span>
                  </div>
                  <svg viewBox="0 0 500 100" className="w-full h-auto select-none">
                    {/* Walls */}
                    <rect x="40" y="5" width="4" height="90" fill="#ef4444" />
                    <rect x="456" y="5" width="4" height="90" fill="#ef4444" />
                    <line x1="40" y1="85" x2="460" y2="85" stroke="rgba(255,255,255,0.15)" />

                    {/* Area under curve */}
                    {(() => {
                      const pts = [];
                      for (let i = 0; i <= 200; i++) {
                        const frac = i / 200;
                        const x = 44 + frac * 412;
                        const prob = Math.pow(Math.sin(boxN * Math.PI * frac), 2);
                        const y = 85 - prob * 70;
                        pts.push(`${x.toFixed(1)},${y.toFixed(1)}`);
                      }
                      const d = `M ${pts.join(' L ')}`;
                      return (
                        <>
                          <defs>
                            <linearGradient id="probGrad" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="0%" stopColor="#c084fc" stopOpacity="0.5" />
                              <stop offset="100%" stopColor="#c084fc" stopOpacity="0.0" />
                            </linearGradient>
                          </defs>
                          <path d={`${d} L 456 85 L 44 85 Z`} fill="url(#probGrad)" />
                          <path d={d} fill="none" stroke="#c084fc" strokeWidth="2.5" />
                        </>
                      );
                    })()}
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 2. QUANTUM TUNNELLING SIMULATOR */}
      {/* ============================================================== */}
      {activeTab === 'tunnelling' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Controls */}
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-amber-500/30 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-amber-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Zap className="w-4 h-4" />
                  <span>Potential Barrier Tunnelling Parameters</span>
                </span>
                <span className="text-slate-400 text-[10px]">T ≈ e^(-2κa)</span>
              </div>

              {/* Particle Energy E */}
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Particle Energy (E):</span>
                  <span className="text-cyan-300 font-bold">{tunnelE.toFixed(2)} eV</span>
                </div>
                <input
                  type="range"
                  min={1.0}
                  max={8.0}
                  step={0.1}
                  value={tunnelE}
                  onChange={(e) => setTunnelE(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Barrier Height V0 */}
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Barrier Height (V₀):</span>
                  <span className="text-amber-300 font-bold">{tunnelV0.toFixed(2)} eV</span>
                </div>
                <input
                  type="range"
                  min={2.0}
                  max={10.0}
                  step={0.1}
                  value={tunnelV0}
                  onChange={(e) => setTunnelV0(parseFloat(e.target.value))}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>

              {/* Barrier Width a */}
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Barrier Width (a):</span>
                  <span className="text-purple-300 font-bold">{tunnelA.toFixed(2)} nm</span>
                </div>
                <input
                  type="range"
                  min={0.05}
                  max={0.6}
                  step={0.01}
                  value={tunnelA}
                  onChange={(e) => setTunnelA(parseFloat(e.target.value))}
                  className="w-full accent-purple-400 cursor-pointer"
                />
              </div>

              {/* Transmission / Reflection Readout */}
              <div className="p-4 rounded-2xl bg-black/60 border border-white/10 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Transmission Coefficient (T):</span>
                  <span className="text-emerald-400 font-bold text-base">{(transmissionT * 100).toFixed(2)}%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Reflection Coefficient (R):</span>
                  <span className="text-red-400 font-bold text-base">{(reflectionR * 100).toFixed(2)}%</span>
                </div>

                <div className="text-[11px] text-slate-300 pt-2 border-t border-white/5 font-sans">
                  <strong>Evanescent Decay:</strong> Inside the forbidden classical barrier (E &lt; V₀), the wavefunction does not drop abruptly to zero but decays exponentially ψ(x) ∝ e^(-κx), penetrating thin barriers to re-emerge as a traveling transmitted wave.
                </div>
              </div>
            </div>

            {/* Right Tunnelling Wave Simulation */}
            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Zap className="w-4 h-4 text-amber-400" />
                    <span>Wave Packet Barrier Penetration Visualizer</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                    Incident wave from left, decaying exponential in barrier, transmitted wave on right
                  </p>
                </div>
              </div>

              {/* SVG Tunnelling Wave */}
              <div className="w-full bg-black/60 rounded-2xl p-4 border border-white/5">
                <svg viewBox="0 0 500 180" className="w-full h-auto select-none">
                  {/* Barrier Box */}
                  <rect x="200" y="30" width="100" height="120" fill="rgba(245, 158, 11, 0.15)" stroke="#f59e0b" strokeWidth="1.5" />
                  <text x="250" y="22" textAnchor="middle" fill="#f59e0b" fontSize="9" fontWeight="bold">
                    Barrier V₀ = {tunnelV0} eV (Width a = {tunnelA} nm)
                  </text>

                  {/* Energy Line */}
                  <line x1="40" y1="100" x2="460" y2="100" stroke="rgba(56, 189, 248, 0.4)" strokeDasharray="3 3" />
                  <text x="45" y="95" fill="#38bdf8" fontSize="8">E = {tunnelE} eV</text>

                  {/* Incident + Reflected Wave (Left) */}
                  {(() => {
                    const pts = [];
                    for (let x = 40; x <= 200; x += 2) {
                      const y = 100 - Math.sin((x - 40) * 0.15) * 28;
                      pts.push(`${x},${y.toFixed(1)}`);
                    }
                    return <path d={`M ${pts.join(' L ')}`} fill="none" stroke="#38bdf8" strokeWidth="2" />;
                  })()}

                  {/* Evanescent Decay (Middle) */}
                  {(() => {
                    const pts = [];
                    for (let x = 200; x <= 300; x += 2) {
                      const frac = (x - 200) / 100;
                      const amp = 28 * Math.exp(-frac * 2.5);
                      const y = 100 - amp;
                      pts.push(`${x},${y.toFixed(1)}`);
                    }
                    return <path d={`M ${pts.join(' L ')}`} fill="none" stroke="#f59e0b" strokeWidth="2.5" strokeDasharray="2 2" />;
                  })()}

                  {/* Transmitted Wave (Right) */}
                  {(() => {
                    const pts = [];
                    const transAmp = Math.max(3, 28 * Math.sqrt(transmissionT));
                    for (let x = 300; x <= 460; x += 2) {
                      const y = 100 - Math.sin((x - 300) * 0.15) * transAmp;
                      pts.push(`${x},${y.toFixed(1)}`);
                    }
                    return <path d={`M ${pts.join(' L ')}`} fill="none" stroke="#10b981" strokeWidth="2" />;
                  })()}

                  <text x="120" y="160" textAnchor="middle" fill="#38bdf8" fontSize="8">Incident Wave</text>
                  <text x="250" y="160" textAnchor="middle" fill="#f59e0b" fontSize="8">Decay ψ ∝ e^(-κx)</text>
                  <text x="380" y="160" textAnchor="middle" fill="#10b981" fontSize="8">Transmitted Wave (T = {(transmissionT * 100).toFixed(1)}%)</text>
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 3. PHOTOELECTRIC EFFECT INSTRUMENT */}
      {/* ============================================================== */}
      {activeTab === 'photoelectric' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Controls */}
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-purple-500/30 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-purple-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Sparkles className="w-4 h-4" />
                  <span>Einstein Photoelectric Phototube</span>
                </span>
                <span className="text-slate-400 text-[10px]">E_k = hν - Φ</span>
              </div>

              {/* Target Cathode Metal */}
              <div className="space-y-2">
                <label className="text-slate-400 uppercase text-[10px] block">Photocathode Metal Plate:</label>
                <div className="grid grid-cols-1 gap-1.5">
                  {photoMetals.map((m) => (
                    <button
                      key={m.name}
                      onClick={() => setSelectedMetal(m)}
                      className={`p-2 rounded-xl text-left border transition-all flex items-center justify-between ${
                        selectedMetal.name === m.name
                          ? 'bg-purple-500/20 border-purple-400 text-purple-300 font-bold'
                          : 'bg-white/[0.02] border-white/5 text-slate-300 hover:bg-white/[0.05]'
                      }`}
                    >
                      <span>{m.name}</span>
                      <span className="text-slate-400 text-[10px]">Work Function Φ = {m.phi.toFixed(2)} eV</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Wavelength Slider */}
              <div className="space-y-2 pt-2 border-t border-white/5">
                <div className="flex justify-between">
                  <span className="text-slate-400">Light Wavelength (λ):</span>
                  <span className="text-cyan-300 font-bold">{lightWavelength} nm (E = {photonEnergyEv.toFixed(2)} eV)</span>
                </div>
                <input
                  type="range"
                  min={180}
                  max={750}
                  step={5}
                  value={lightWavelength}
                  onChange={(e) => setLightWavelength(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Intensity Slider */}
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Light Intensity:</span>
                  <span className="text-amber-300 font-bold">{lightIntensity}% (Photocurrent)</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  step={5}
                  value={lightIntensity}
                  onChange={(e) => setLightIntensity(parseInt(e.target.value))}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>

              {/* State Box */}
              <div className={`p-4 rounded-2xl border transition-all ${
                isEmitting
                  ? 'bg-emerald-500/15 border-emerald-400 text-emerald-200'
                  : 'bg-red-500/15 border-red-400 text-red-200'
              }`}>
                <div className="flex justify-between items-center font-bold">
                  <span>Emission Status:</span>
                  <span>{isEmitting ? 'PHOTOELECTRONS EMITTED' : 'NO EMISSION (hν < Φ)'}</span>
                </div>
                <div className="text-[11px] pt-2 space-y-1">
                  <div>Max Kinetic Energy (E_k): <strong>{maxKineticEnergyEv.toFixed(2)} eV</strong></div>
                  <div>Stopping Potential (V_stop): <strong>{stoppingPotential.toFixed(2)} V</strong></div>
                  <div>Threshold Wavelength (λ₀): <strong>{thresholdLambda.toFixed(1)} nm</strong></div>
                </div>
              </div>
            </div>

            {/* Right Photoelectric Chamber */}
            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-purple-400" />
                    <span>Vacuum Photocell Tube Chamber</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                    Photons strike target cathode to eject photoelectrons toward anode collector
                  </p>
                </div>
              </div>

              {/* SVG Photocell */}
              <div className="w-full bg-black/60 rounded-2xl p-4 border border-white/5">
                <svg viewBox="0 0 500 180" className="w-full h-auto select-none">
                  {/* Vacuum Tube Outline */}
                  <rect x="60" y="30" width="380" height="120" rx="30" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="2" />

                  {/* Cathode Plate (-) */}
                  <rect x="90" y="45" width="12" height="90" rx="4" fill={selectedMetal.color} stroke="#ffffff" strokeWidth="1.5" />
                  <text x="96" y="150" textAnchor="middle" fill="#94a3b8" fontSize="8">Cathode</text>

                  {/* Anode Collector (+) */}
                  <rect x="390" y="45" width="12" height="90" rx="4" fill="#64748b" stroke="#ffffff" strokeWidth="1.5" />
                  <text x="396" y="150" textAnchor="middle" fill="#94a3b8" fontSize="8">Anode</text>

                  {/* Incoming Photons */}
                  {[0, 1, 2].map((i) => (
                    <g key={i}>
                      <line x1="40" y1={55 + i * 25} x2="88" y2={65 + i * 25} stroke="#f59e0b" strokeWidth="2" strokeDasharray="3 3" />
                      <circle cx="40" cy={55 + i * 25} r="3" fill="#f59e0b" />
                    </g>
                  ))}

                  {/* Ejected Photoelectrons */}
                  {isEmitting && [0, 1, 2, 3, 4].map((i) => (
                    <g key={i}>
                      <circle cx={130 + i * 50} cy={60 + (i % 3) * 20} r="4" fill="#38bdf8" className="animate-pulse" />
                      <line x1={120 + i * 50} y1={60 + (i % 3) * 20} x2={140 + i * 50} y2={60 + (i % 3) * 20} stroke="#38bdf8" strokeWidth="1" />
                    </g>
                  ))}
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 4. DE BROGLIE & HEISENBERG UNCERTAINTY */}
      {/* ============================================================== */}
      {activeTab === 'uncertainty' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-emerald-500/30 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-emerald-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Activity className="w-4 h-4" />
                  <span>Matter Wave & Uncertainty Controls</span>
                </span>
                <span className="text-slate-400 text-[10px]">Δx · Δp ≥ ℏ/2</span>
              </div>

              {/* Slit Width Delta x */}
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Position Confinement (Δx):</span>
                  <span className="text-emerald-300 font-bold">{slitDeltaX.toFixed(2)} nm</span>
                </div>
                <input
                  type="range"
                  min={0.02}
                  max={0.5}
                  step={0.01}
                  value={slitDeltaX}
                  onChange={(e) => setSlitDeltaX(parseFloat(e.target.value))}
                  className="w-full accent-emerald-400 cursor-pointer"
                />
              </div>

              {/* Electron Velocity */}
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Electron Speed (v):</span>
                  <span className="text-cyan-300 font-bold">{(particleVelocity / 1e6).toFixed(2)} × 10⁶ m/s</span>
                </div>
                <input
                  type="range"
                  min={1e5}
                  max={5e6}
                  step={1e5}
                  value={particleVelocity}
                  onChange={(e) => setParticleVelocity(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Calculation Summary */}
              <div className="p-4 rounded-2xl bg-black/60 border border-white/10 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">de Broglie Wavelength (λ = h/p):</span>
                  <span className="text-cyan-400 font-bold">{deBroglieLambda.toFixed(3)} nm</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Minimum Momentum Spread (Δp):</span>
                  <span className="text-emerald-400 font-bold">{(minDeltaP).toExponential(3)} kg·m/s</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Velocity Uncertainty (Δv):</span>
                  <span className="text-amber-400 font-bold">{(minDeltaV / 1e3).toFixed(1)} km/s</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Atom className="w-4 h-4 text-emerald-400" />
                  <span>Single-Slit Electron Wave Diffraction Pattern</span>
                </h3>
              </div>

              <div className="w-full bg-black/60 rounded-2xl p-4 border border-white/5">
                <svg viewBox="0 0 500 150" className="w-full h-auto select-none">
                  {/* Slit Aperture */}
                  <rect x="100" y="10" width="10" height="50" fill="#64748b" />
                  <rect x="100" y={60 + slitDeltaX * 80} width="10" height="80" fill="#64748b" />

                  {/* Diffraction Intensity Envelope on Screen */}
                  {(() => {
                    const pts = [];
                    for (let y = 10; y <= 140; y += 2) {
                      const center = 75;
                      const beta = (y - center) / (slitDeltaX * 100);
                      const sinc = beta === 0 ? 1 : Math.sin(beta) / beta;
                      const intensity = Math.pow(sinc, 2);
                      const x = 460 - intensity * 120;
                      pts.push(`${x.toFixed(1)},${y}`);
                    }
                    return <path d={`M ${pts.join(' L ')}`} fill="none" stroke="#10b981" strokeWidth="2" />;
                  })()}
                  <line x1="460" y1="10" x2="460" y2="140" stroke="rgba(255,255,255,0.2)" />
                  <text x="420" y="145" fill="#94a3b8" fontSize="8">Detector Screen</text>
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
