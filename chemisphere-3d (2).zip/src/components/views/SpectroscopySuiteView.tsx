import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  Activity,
  Sparkles,
  Layers,
  ArrowRight,
  HelpCircle,
  Eye,
  Sliders,
  ChevronRight,
  Info,
  Maximize2,
  Download,
  RotateCcw,
  Zap,
  Flame,
  Radio,
  BarChart3,
  Search,
  CheckCircle2
} from 'lucide-react';
import { NavigationTab } from '../../types';

interface SpectroscopySuiteViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

type SpectrometerType = 'uv-vis' | 'ir' | 'nmr' | 'mass-spec' | 'xrd';

export const SpectroscopySuiteView: React.FC<SpectroscopySuiteViewProps> = ({ onNavigate }) => {
  const [activeInstrument, setActiveInstrument] = useState<SpectrometerType>('uv-vis');

  // ==========================================
  // 1. UV-VIS SPECTROPHOTOMETER STATE
  // ==========================================
  const uvMolecules = [
    { id: 'kmno4', name: 'Potassium Permanganate (KMnO₄)', lambdaMax: 525, molarAbs: 2400, color: '#a855f7', desc: 'Deep violet d-d/charge-transfer transition' },
    { id: 'chlorophyll', name: 'Chlorophyll a', lambdaMax: 430, secondaryMax: 662, molarAbs: 85000, color: '#10b981', desc: 'Photosynthetic porphyrin π-π* excitation' },
    { id: 'carotene', name: 'β-Carotene', lambdaMax: 450, molarAbs: 138000, color: '#f97316', desc: 'Conjugated polyene 11-double-bond chromophore' },
    { id: 'crystal-violet', name: 'Crystal Violet', lambdaMax: 590, molarAbs: 87000, color: '#6366f1', desc: 'Triphenylmethane resonance stabilized dye' },
    { id: 'cuso4', name: 'Copper(II) Sulfate (CuSO₄)', lambdaMax: 810, molarAbs: 12, color: '#06b6d4', desc: 'Octahedral [Cu(H₂O)₆]²⁺ d-d transition' }
  ];
  const [selectedUvMol, setSelectedUvMol] = useState(uvMolecules[0]);
  const [uvConcentration, setUvConcentration] = useState(0.00025); // mol/L
  const [uvPathLength, setUvPathLength] = useState(1.0); // cm
  const [uvProbeLambda, setUvProbeLambda] = useState(525); // nm

  // Calculated Beer-Lambert Absorbance
  const calcAbsorbanceAtLambda = (lambda: number, mol = selectedUvMol, conc = uvConcentration, path = uvPathLength) => {
    // Gaussian peak around lambdaMax
    const sigma = 35;
    const g1 = Math.exp(-Math.pow(lambda - mol.lambdaMax, 2) / (2 * sigma * sigma));
    let g2 = 0;
    if ((mol as any).secondaryMax) {
      g2 = 0.7 * Math.exp(-Math.pow(lambda - (mol as any).secondaryMax, 2) / (2 * sigma * sigma));
    }
    const eps = mol.molarAbs * (g1 + g2);
    const A = eps * path * conc;
    return { eps, A: Math.max(0, A) };
  };

  const currentUvProbe = calcAbsorbanceAtLambda(uvProbeLambda);
  const currentTransmittance = Math.max(0, Math.min(100, Math.pow(10, -currentUvProbe.A) * 100));

  // ==========================================
  // 2. FTIR INFRARED SPECTROMETER STATE
  // ==========================================
  const irMolecules = [
    {
      id: 'ethanol',
      name: 'Ethanol (CH₃CH₂OH)',
      formula: 'C₂H₆O',
      peaks: [
        { wn: 3350, type: 'O-H stretch (broad, H-bonded)', intensity: 0.88, group: 'Alcohol O-H', vib: 'O-H stretch' },
        { wn: 2975, type: 'C-H sp³ stretch', intensity: 0.75, group: 'Alkyl C-H', vib: 'C-H asymmetric stretch' },
        { wn: 1050, type: 'C-O stretch', intensity: 0.82, group: 'Primary Alcohol C-O', vib: 'C-O stretch' },
        { wn: 1380, type: 'C-H bend (methyl rock)', intensity: 0.35, group: '-CH₃ bend', vib: 'C-H scissor' }
      ]
    },
    {
      id: 'acetone',
      name: 'Acetone (CH₃COCH₃)',
      formula: 'C₃H₆O',
      peaks: [
        { wn: 1715, type: 'C=O stretch (strong, sharp)', intensity: 0.95, group: 'Ketone Carbonyl', vib: 'C=O stretch' },
        { wn: 2990, type: 'C-H sp³ stretch', intensity: 0.45, group: 'Alkyl C-H', vib: 'C-H stretch' },
        { wn: 1365, type: 'C-H symmetric deformation', intensity: 0.6, group: '-CH₃ bend', vib: 'Umbrella bend' },
        { wn: 1220, type: 'C-C(=O)-C stretch/bend', intensity: 0.5, group: 'Ketone skeletal', vib: 'C-C stretch' }
      ]
    },
    {
      id: 'benzoic-acid',
      name: 'Benzoic Acid (C₆H₅COOH)',
      formula: 'C₇H₆O₂',
      peaks: [
        { wn: 3000, type: 'O-H broad acid envelope (2500-3300 cm⁻¹)', intensity: 0.85, group: 'Carboxylic Acid O-H', vib: 'Dimer O-H stretch' },
        { wn: 1688, type: 'C=O conjugated stretch', intensity: 0.96, group: 'Conjugated Carbonyl', vib: 'C=O stretch' },
        { wn: 1600, type: 'Aromatic C=C ring stretch', intensity: 0.65, group: 'Benzene ring', vib: 'Ring breathing' },
        { wn: 1450, type: 'Aromatic C=C ring stretch', intensity: 0.55, group: 'Benzene ring', vib: 'Ring deformation' },
        { wn: 1290, type: 'C-O stretch', intensity: 0.72, group: 'Carboxyl C-O', vib: 'C-O stretch' },
        { wn: 710, type: 'Mono-substituted benzene OOP bend', intensity: 0.8, group: 'Aromatic C-H OOP', vib: 'Out-of-plane bend' }
      ]
    },
    {
      id: 'ethyl-acetate',
      name: 'Ethyl Acetate (CH₃COOCH₂CH₃)',
      formula: 'C₄H₈O₂',
      peaks: [
        { wn: 1740, type: 'C=O ester stretch', intensity: 0.95, group: 'Ester Carbonyl', vib: 'C=O stretch' },
        { wn: 2980, type: 'C-H stretch', intensity: 0.5, group: 'Alkyl C-H', vib: 'C-H stretch' },
        { wn: 1240, type: 'C-O-C asymmetric stretch (strong)', intensity: 0.9, group: 'Ester C-O', vib: 'C-O stretch' },
        { wn: 1045, type: 'C-O-C symmetric stretch', intensity: 0.7, group: 'Ester C-O', vib: 'C-O stretch' }
      ]
    }
  ];
  const [selectedIrMol, setSelectedIrMol] = useState(irMolecules[0]);
  const [selectedIrPeak, setSelectedIrPeak] = useState<any>(irMolecules[0].peaks[0]);
  const [isVibrating, setIsVibrating] = useState(true);

  // ==========================================
  // 3. 1H NMR SPECTROMETER STATE
  // ==========================================
  const nmrMolecules = [
    {
      id: 'ethanol',
      name: 'Ethanol (CH₃-CH₂-OH)',
      solvents: 'CDCl₃',
      peaks: [
        { shift: 1.25, mult: 'Triplet (t)', protons: 3, jVal: '7.1 Hz', group: 'CH₃ protons', env: 'Adjacent to CH₂ (n=2, 2+1=3)', color: '#38bdf8' },
        { shift: 3.70, mult: 'Quartet (q)', protons: 2, jVal: '7.1 Hz', group: 'CH₂ protons', env: 'Adjacent to CH₃ (n=3, 3+1=4) and deshielded by O', color: '#a855f7' },
        { shift: 2.60, mult: 'Singlet (s, broad)', protons: 1, jVal: 'None', group: 'OH proton', env: 'Hydroxyl proton (rapid intermolecular exchange)', color: '#ec4899' },
        { shift: 0.00, mult: 'Singlet (s)', protons: 12, jVal: 'Reference', group: 'TMS (CH₃)₄Si', env: 'Zero reference standard', color: '#64748b' }
      ]
    },
    {
      id: 'ethyl-acetate',
      name: 'Ethyl Acetate (CH₃-COO-CH₂-CH₃)',
      solvents: 'CDCl₃',
      peaks: [
        { shift: 1.26, mult: 'Triplet (t)', protons: 3, jVal: '7.2 Hz', group: 'Ester Ethyl CH₃', env: 'Adjacent to CH₂ (n=2)', color: '#38bdf8' },
        { shift: 2.04, mult: 'Singlet (s)', protons: 3, jVal: 'None', group: 'Acetyl CH₃ (CH₃-C=O)', env: 'Isolated methyl on carbonyl, no neighbors', color: '#10b981' },
        { shift: 4.12, mult: 'Quartet (q)', protons: 2, jVal: '7.2 Hz', group: 'Ester -O-CH₂-', env: 'Adjacent to CH₃ and strongly deshielded by -O-', color: '#f59e0b' }
      ]
    },
    {
      id: 'toluene',
      name: 'Toluene (C₆H₅-CH₃)',
      solvents: 'CDCl₃',
      peaks: [
        { shift: 2.36, mult: 'Singlet (s)', protons: 3, jVal: 'None', group: 'Benzylic Methyl CH₃', env: 'Methyl directly attached to aromatic ring', color: '#38bdf8' },
        { shift: 7.15, mult: 'Multiplet (m)', protons: 3, jVal: '7.5 Hz', group: 'ortho/para Aromatic H', env: 'Deshielded by aromatic ring diamagnetic ring current', color: '#a855f7' },
        { shift: 7.25, mult: 'Multiplet (m)', protons: 2, jVal: '7.5 Hz', group: 'meta Aromatic H', env: 'Aromatic protons', color: '#ec4899' }
      ]
    }
  ];
  const [selectedNmrMol, setSelectedNmrMol] = useState(nmrMolecules[0]);
  const [selectedNmrPeak, setSelectedNmrPeak] = useState<any>(nmrMolecules[0].peaks[0]);

  // ==========================================
  // 4. MASS SPECTROMETER (MS) STATE
  // ==========================================
  const msMolecules = [
    {
      id: 'ethanol',
      name: 'Ethanol (C₂H₆O, MW = 46.07)',
      basePeak: 31,
      molecularIon: 46,
      peaks: [
        { mz: 46, relAb: 15, label: '[M]⁺• (Molecular Ion)', formula: 'C₂H₆O⁺•', explanation: 'Intact radical cation formed via electron impact ionization' },
        { mz: 45, relAb: 38, label: '[M - H]⁺', formula: 'C₂H₅O⁺', explanation: 'Loss of radical hydrogen from α-carbon' },
        { mz: 31, relAb: 100, label: 'Base Peak [CH₂=OH]⁺', formula: 'CH₃O⁺', explanation: 'α-cleavage loss of methyl radical (M - 15), resonance-stabilized oxonium ion' },
        { mz: 29, relAb: 25, label: '[CHO]⁺ / [C₂H₅]⁺', formula: 'CHO⁺', explanation: 'Further fragmentation to formyl cation' },
        { mz: 15, relAb: 8, label: '[CH₃]⁺', formula: 'CH₃⁺', explanation: 'Methyl cation fragment' }
      ]
    },
    {
      id: 'bromobenzene',
      name: 'Bromobenzene (C₆H₅Br, MW = 157.01)',
      basePeak: 77,
      molecularIon: 156,
      peaks: [
        { mz: 156, relAb: 60, label: '[M]⁺ (⁷⁹Br)', formula: 'C₆H₅⁷⁹Br⁺', explanation: 'Molecular ion with Bromine-79 isotope' },
        { mz: 158, relAb: 58, label: '[M+2]⁺ (⁸¹Br)', formula: 'C₆H₅⁸¹Br⁺', explanation: 'Twin isotope peak (~1:1 ratio) characteristic of 1 Bromine atom' },
        { mz: 77, relAb: 100, label: 'Base Peak [C₆H₅]⁺', formula: 'C₆H₅⁺', explanation: 'Phenyl cation formed via loss of Bromine radical (M - 79/81)' },
        { mz: 51, relAb: 45, label: '[C₄H₃]⁺', formula: 'C₄H₃⁺', explanation: 'Retro-cleavage ring fragmentation of phenyl ring with loss of acetylene' }
      ]
    },
    {
      id: 'acetone',
      name: 'Acetone (C₃H₆O, MW = 58.08)',
      basePeak: 43,
      molecularIon: 58,
      peaks: [
        { mz: 58, relAb: 28, label: '[M]⁺• (Molecular Ion)', formula: 'C₃H₆O⁺•', explanation: 'Intact radical cation of acetone' },
        { mz: 43, relAb: 100, label: 'Base Peak [CH₃-C≡O]⁺', formula: 'C₂H₃O⁺', explanation: 'Acylium ion formed via α-cleavage of methyl radical (M - 15)' },
        { mz: 15, relAb: 20, label: '[CH₃]⁺', formula: 'CH₃⁺', explanation: 'Methyl cation fragment' }
      ]
    }
  ];
  const [selectedMsMol, setSelectedMsMol] = useState(msMolecules[0]);
  const [selectedMsPeak, setSelectedMsPeak] = useState<any>(msMolecules[0].peaks[2]);

  // ==========================================
  // 5. XRD (X-RAY DIFFRACTION) STATE
  // ==========================================
  const [xrdLambda, setXrdLambda] = useState(0.15418); // nm (Cu K-alpha)
  const [xrdThetaDeg, setXrdThetaDeg] = useState(19.8); // degrees theta
  const [xrdLatticeD, setXrdLatticeD] = useState(0.282); // nm (NaCl (200) plane)
  const [xrdOrderN, setXrdOrderN] = useState(1);

  // Bragg's Law: n*lambda = 2*d*sin(theta)
  const thetaRad = (xrdThetaDeg * Math.PI) / 180;
  const pathDifference = 2 * xrdLatticeD * Math.sin(thetaRad);
  const braggRatio = pathDifference / xrdLambda; // ideal integer n
  const isConstructive = Math.abs(braggRatio - Math.round(braggRatio)) < 0.08;

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8 font-sans">
      {/* Header Banner */}
      <div className="relative rounded-3xl overflow-hidden border border-pink-500/30 bg-[#0c0814] p-6 sm:p-10 shadow-2xl">
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-pink-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-20 -bottom-20 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-500/10 border border-pink-400/30 text-pink-400 text-xs font-mono font-bold tracking-wide">
            <Activity className="w-3.5 h-3.5" />
            <span>ANALYTICAL SPECTROSCOPY & STRUCTURAL ELUCIDATION SUITE</span>
          </div>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-display-periodic">
                SPECTROSCOPY LABORATORY
              </h1>
              <p className="text-slate-300 text-sm sm:text-base max-w-3xl mt-2 leading-relaxed font-sans">
                Interactive suite of 5 high-precision analytical instruments. Simulate electronic transitions with <strong>UV-Vis</strong>, vibrational normal modes with <strong>FTIR</strong>, nuclear spins with <strong>¹H NMR</strong>, ion fragmentation with <strong>Mass Spectrometry</strong>, and crystal lattices with <strong>X-Ray Diffraction (XRD)</strong>.
              </p>
            </div>

            {onNavigate && (
              <button
                onClick={() => onNavigate('lab-directory')}
                className="px-4 py-2.5 rounded-2xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-slate-300 hover:text-white font-mono text-xs font-bold transition-all shrink-0 flex items-center gap-2"
              >
                <span>LAB DIRECTORY</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Instrument Selection Tabs */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-[#090d16] border border-white/10 overflow-x-auto font-mono text-xs">
        {[
          { id: 'uv-vis' as SpectrometerType, label: '1. UV-Visible Spectrophotometer', icon: Eye, color: 'text-cyan-400' },
          { id: 'ir' as SpectrometerType, label: '2. FTIR Infrared Spectrometer', icon: Flame, color: 'text-amber-400' },
          { id: 'nmr' as SpectrometerType, label: '3. ¹H NMR Spectrometer', icon: Radio, color: 'text-purple-400' },
          { id: 'mass-spec' as SpectrometerType, label: '4. Mass Spectrometer (MS)', icon: Zap, color: 'text-pink-400' },
          { id: 'xrd' as SpectrometerType, label: '5. X-Ray Diffractometer (XRD)', icon: Layers, color: 'text-emerald-400' }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeInstrument === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveInstrument(tab.id)}
              className={`px-4 py-2.5 rounded-xl font-bold flex items-center gap-2 whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-white/15 text-white border border-white/20 shadow-lg'
                  : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
              }`}
            >
              <Icon className={`w-4 h-4 ${tab.color}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ============================================================== */}
      {/* 1. UV-VISIBLE SPECTROPHOTOMETER INTERACTIVE LAB */}
      {/* ============================================================== */}
      {activeInstrument === 'uv-vis' && (
        <div className="space-y-6 font-mono">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Controls & Beer-Lambert Instrument Panel */}
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-cyan-500/30 shadow-xl space-y-5 text-xs">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-cyan-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Eye className="w-4 h-4" />
                  <span>Beer-Lambert Spectrophotometer Controls</span>
                </span>
                <span className="text-slate-400 text-[10px]">A = ε · b · c</span>
              </div>

              {/* Sample Selector */}
              <div className="space-y-2">
                <label className="text-slate-400 uppercase text-[10px] block">Analyte Sample:</label>
                <div className="grid grid-cols-1 gap-2">
                  {uvMolecules.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => {
                        setSelectedUvMol(m);
                        setUvProbeLambda(m.lambdaMax);
                      }}
                      className={`w-full text-left p-2.5 rounded-xl border transition-all flex items-center justify-between ${
                        selectedUvMol.id === m.id
                          ? 'bg-cyan-500/15 border-cyan-400/40 text-cyan-300 font-bold'
                          : 'bg-white/[0.02] border-white/5 text-slate-300 hover:bg-white/[0.06]'
                      }`}
                    >
                      <span>{m.name}</span>
                      <span className="text-[10px] text-slate-400">λ_max = {m.lambdaMax} nm</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Concentration Slider */}
              <div className="space-y-2 pt-2 border-t border-white/5">
                <div className="flex justify-between">
                  <span className="text-slate-400">Concentration (c):</span>
                  <span className="text-cyan-300 font-bold">{(uvConcentration * 1000).toFixed(3)} mM ({(uvConcentration).toExponential(2)} M)</span>
                </div>
                <input
                  type="range"
                  min={0.00002}
                  max={0.001}
                  step={0.00001}
                  value={uvConcentration}
                  onChange={(e) => setUvConcentration(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Path Length Slider */}
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Cuvette Path Length (b):</span>
                  <span className="text-cyan-300 font-bold">{uvPathLength.toFixed(2)} cm</span>
                </div>
                <input
                  type="range"
                  min={0.2}
                  max={5.0}
                  step={0.1}
                  value={uvPathLength}
                  onChange={(e) => setUvPathLength(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Probe Wavelength Slider */}
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Probe Monochromator (λ):</span>
                  <span className="text-cyan-300 font-bold">{uvProbeLambda} nm</span>
                </div>
                <input
                  type="range"
                  min={350}
                  max={850}
                  step={1}
                  value={uvProbeLambda}
                  onChange={(e) => setUvProbeLambda(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Cuvette Light Absorption Visualizer */}
              <div className="p-4 rounded-2xl bg-black/60 border border-white/10 space-y-3">
                <span className="text-[10px] text-slate-400 uppercase block">Virtual Quartz Cuvette Beam Chamber:</span>
                <div className="h-14 rounded-xl bg-slate-950 border border-cyan-500/30 relative flex items-center justify-between px-3 overflow-hidden">
                  {/* Incoming Light Beam I_0 */}
                  <div className="flex items-center gap-1.5 z-10">
                    <span className="text-[10px] text-amber-300 font-bold">I₀ = 100%</span>
                    <div className="w-12 h-3 bg-gradient-to-r from-amber-300 to-amber-400 rounded-full shadow-lg shadow-amber-400/50" />
                  </div>

                  {/* Cuvette Liquid Solution */}
                  <div
                    style={{
                      backgroundColor: selectedUvMol.color,
                      opacity: Math.min(0.95, 0.15 + (uvConcentration / 0.001) * 0.8),
                      width: `${Math.min(120, uvPathLength * 24)}px`
                    }}
                    className="h-full border-x-2 border-white/40 shadow-inner flex items-center justify-center text-[10px] text-white font-bold transition-all"
                  >
                    b={uvPathLength}cm
                  </div>

                  {/* Transmitted Light Beam I */}
                  <div className="flex items-center gap-1.5 z-10">
                    <div
                      style={{ opacity: currentTransmittance / 100 }}
                      className="w-12 h-3 bg-gradient-to-r from-amber-400 to-amber-300 rounded-full shadow-lg shadow-amber-400/50 transition-opacity"
                    />
                    <span className="text-[10px] text-cyan-300 font-bold">I = {currentTransmittance.toFixed(1)}%</span>
                  </div>
                </div>
              </div>

              {/* Calculated Outputs */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/5">
                  <span className="text-slate-500 text-[10px] block">Absorbance (A)</span>
                  <span className="text-base font-bold text-cyan-300">{currentUvProbe.A.toFixed(4)}</span>
                </div>
                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/5">
                  <span className="text-slate-500 text-[10px] block">Transmittance (%T)</span>
                  <span className="text-base font-bold text-amber-300">{currentTransmittance.toFixed(2)}%</span>
                </div>
              </div>
            </div>

            {/* Right Live Spectrum Canvas & Calibration Plot */}
            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5 text-xs">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-cyan-400" />
                    <span>UV-Vis Absorption Spectrum & Calibration Curve</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                    {selectedUvMol.name}: {selectedUvMol.desc}
                  </p>
                </div>
                <span className="text-[10px] px-2.5 py-1 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-400/30 font-bold">
                  λ_max = {selectedUvMol.lambdaMax} nm
                </span>
              </div>

              {/* SVG UV-Vis Spectrum Plot */}
              <div className="w-full bg-black/40 rounded-2xl p-4 border border-white/5 space-y-2">
                <div className="flex justify-between text-[11px] text-slate-400">
                  <span>Absorbance vs Wavelength (350 - 850 nm)</span>
                  <span className="text-cyan-400 font-bold">Peak A = {calcAbsorbanceAtLambda(selectedUvMol.lambdaMax).A.toFixed(3)}</span>
                </div>

                <svg viewBox="0 0 500 180" className="w-full h-auto select-none">
                  {/* Grid */}
                  {[0, 0.5, 1.0, 1.5, 2.0].map((a, i) => {
                    const y = 150 - (a / 2.0) * 130;
                    return (
                      <g key={i}>
                        <line x1="40" y1={y} x2="480" y2={y} stroke="rgba(255,255,255,0.06)" strokeDasharray="3 3" />
                        <text x="32" y={y + 3} textAnchor="end" fill="#64748b" fontSize="8" fontFamily="monospace">
                          {a.toFixed(1)}
                        </text>
                      </g>
                    );
                  })}

                  {/* Curve Path Generation */}
                  {(() => {
                    const points = [];
                    const maxA_scale = Math.max(2.0, calcAbsorbanceAtLambda(selectedUvMol.lambdaMax).A * 1.2);
                    for (let w = 350; w <= 850; w += 5) {
                      const x = 40 + ((w - 350) / (850 - 350)) * 440;
                      const aVal = calcAbsorbanceAtLambda(w).A;
                      const y = 150 - (aVal / maxA_scale) * 130;
                      points.push(`${x.toFixed(1)},${y.toFixed(1)}`);
                    }
                    const d = `M ${points.join(' L ')}`;
                    const areaD = `${d} L 480 150 L 40 150 Z`;

                    // Probe line
                    const probeX = 40 + ((uvProbeLambda - 350) / (850 - 350)) * 440;
                    const probeY = 150 - (currentUvProbe.A / maxA_scale) * 130;

                    return (
                      <>
                        <defs>
                          <linearGradient id="uvGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.4" />
                            <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.0" />
                          </linearGradient>
                        </defs>
                        <path d={areaD} fill="url(#uvGrad)" />
                        <path d={d} fill="none" stroke="#38bdf8" strokeWidth="2.5" strokeLinecap="round" />

                        {/* Probe Cursor */}
                        <line x1={probeX} y1="20" x2={probeX} y2="150" stroke="#f59e0b" strokeWidth="1.5" strokeDasharray="3 3" />
                        <circle cx={probeX} cy={probeY} r="5" fill="#f59e0b" stroke="#ffffff" strokeWidth="2" />
                      </>
                    );
                  })()}

                  {/* X Axis Wavelength ticks */}
                  {[400, 500, 600, 700, 800].map((w) => {
                    const x = 40 + ((w - 350) / (850 - 350)) * 440;
                    return (
                      <g key={w}>
                        <line x1={x} y1="150" x2={x} y2="154" stroke="#64748b" />
                        <text x={x} y="166" textAnchor="middle" fill="#94a3b8" fontSize="8" fontFamily="monospace">
                          {w} nm
                        </text>
                      </g>
                    );
                  })}
                </svg>
              </div>

              {/* Calibration Curve Generator */}
              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 space-y-2">
                <span className="text-[11px] font-bold text-white flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Standard Calibration Curve (A vs Concentration at λ_max = {selectedUvMol.lambdaMax} nm)</span>
                </span>
                <p className="text-[11px] text-slate-400 font-sans">
                  Slope (m = ε · b) = <strong>{(selectedUvMol.molarAbs * uvPathLength).toFixed(0)} L·mol⁻¹</strong> • Regression Linearity: <strong>R² = 0.9998</strong>.
                  According to Beer's law, doubling concentration results in exact double absorbance until deviations occur above A &gt; 2.5 due to stray light and solute association.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 2. FTIR INFRARED SPECTROMETER INTERACTIVE LAB */}
      {/* ============================================================== */}
      {activeInstrument === 'ir' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left FTIR Molecule Selector & Peak Analyzer */}
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-amber-500/30 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-amber-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Flame className="w-4 h-4" />
                  <span>FTIR Molecular Vibration Inspector</span>
                </span>
                <span className="text-slate-400 text-[10px]">4000 - 600 cm⁻¹</span>
              </div>

              {/* Select Molecule */}
              <div className="space-y-2">
                <label className="text-slate-400 uppercase text-[10px] block">Select Sample Compound:</label>
                <div className="grid grid-cols-1 gap-2">
                  {irMolecules.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => {
                        setSelectedIrMol(m);
                        setSelectedIrPeak(m.peaks[0]);
                      }}
                      className={`w-full text-left p-2.5 rounded-xl border transition-all flex items-center justify-between ${
                        selectedIrMol.id === m.id
                          ? 'bg-amber-500/15 border-amber-400/40 text-amber-300 font-bold'
                          : 'bg-white/[0.02] border-white/5 text-slate-300 hover:bg-white/[0.06]'
                      }`}
                    >
                      <span>{m.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{m.formula}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Characteristic FTIR Peaks Table */}
              <div className="space-y-2 pt-2 border-t border-white/5">
                <label className="text-slate-400 uppercase text-[10px] block">Click Any Absorption Peak:</label>
                <div className="space-y-1.5">
                  {selectedIrMol.peaks.map((p, idx) => {
                    const isSel = selectedIrPeak.wn === p.wn;
                    return (
                      <button
                        key={idx}
                        onClick={() => setSelectedIrPeak(p)}
                        className={`w-full text-left p-2.5 rounded-xl border transition-all flex items-center justify-between text-[11px] ${
                          isSel
                            ? 'bg-amber-500/20 border-amber-400 text-white font-bold shadow-md'
                            : 'bg-black/40 border-white/5 text-slate-300 hover:bg-white/[0.05]'
                        }`}
                      >
                        <div>
                          <strong className="text-amber-400">{p.wn} cm⁻¹</strong>: {p.type}
                        </div>
                        <span className="text-[10px] text-slate-400">{p.group}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Active Peak Molecular Vibration Diagnostic */}
              {selectedIrPeak && (
                <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-400/30 space-y-2">
                  <div className="flex justify-between items-center text-amber-300 font-bold">
                    <span>Active Peak: {selectedIrPeak.wn} cm⁻¹</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20">
                      {selectedIrPeak.vib}
                    </span>
                  </div>
                  <p className="text-slate-300 text-[11px] font-sans leading-relaxed">
                    <strong>Interpretation:</strong> Corresponds to dipole moment change during {selectedIrPeak.type}. In accordance with Hooke's Law (v = 1/(2πc) · √(k/μ)), higher bond force constant (k) and lighter reduced mass (μ) cause higher vibrational frequencies.
                  </p>
                </div>
              )}
            </div>

            {/* Right FTIR Spectrum Graphic */}
            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Activity className="w-4 h-4 text-amber-400" />
                    <span>FTIR Transmittance Spectrum (%T vs Wavenumber cm⁻¹)</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                    Infrared absorption dips representing quantized vibrational transitions
                  </p>
                </div>
              </div>

              {/* SVG FTIR Transmittance Spectrum */}
              <div className="w-full bg-black/50 rounded-2xl p-4 border border-white/5 space-y-2">
                <svg viewBox="0 0 500 200" className="w-full h-auto select-none">
                  {/* Grid Lines */}
                  {[100, 80, 60, 40, 20, 0].map((t) => {
                    const y = 30 + ((100 - t) / 100) * 140;
                    return (
                      <g key={t}>
                        <line x1="40" y1={y} x2="480" y2={y} stroke="rgba(255,255,255,0.06)" strokeDasharray="3 3" />
                        <text x="32" y={y + 3} textAnchor="end" fill="#64748b" fontSize="8" fontFamily="monospace">
                          {t}%
                        </text>
                      </g>
                    );
                  })}

                  {/* Synthetic FTIR Spectrum Curve (4000 to 600 cm^-1, note x-axis is inverted standard) */}
                  {(() => {
                    const points = [];
                    for (let wn = 4000; wn >= 600; wn -= 10) {
                      const x = 40 + ((4000 - wn) / (4000 - 600)) * 440;
                      // Base baseline at 96% T with slight noise
                      let tVal = 95 - Math.sin(wn / 200) * 1.5;

                      // Subtract absorption peaks
                      selectedIrMol.peaks.forEach((pk: any) => {
                        const width = pk.wn > 3000 ? 120 : 35;
                        const dip = pk.intensity * 80 * Math.exp(-Math.pow(wn - pk.wn, 2) / (2 * width * width));
                        tVal -= dip;
                      });

                      tVal = Math.max(5, Math.min(98, tVal));
                      const y = 30 + ((100 - tVal) / 100) * 140;
                      points.push(`${x.toFixed(1)},${y.toFixed(1)}`);
                    }
                    const d = `M ${points.join(' L ')}`;

                    // Highlight active selected peak
                    const activeX = 40 + ((4000 - selectedIrPeak.wn) / (4000 - 600)) * 440;

                    return (
                      <>
                        <path d={d} fill="none" stroke="#f59e0b" strokeWidth="2" strokeLinecap="round" />
                        <line x1={activeX} y1="20" x2={activeX} y2="170" stroke="#38bdf8" strokeWidth="1.5" strokeDasharray="3 3" />
                        <circle cx={activeX} cy="170" r="4" fill="#38bdf8" />
                        <text x={activeX} y="15" textAnchor="middle" fill="#38bdf8" fontSize="9" fontFamily="monospace" fontWeight="bold">
                          {selectedIrPeak.wn} cm⁻¹
                        </text>
                      </>
                    );
                  })()}

                  {/* X Axis Wavenumbers (inverted 4000 -> 600 cm^-1) */}
                  {[4000, 3500, 3000, 2500, 2000, 1500, 1000, 600].map((wn) => {
                    const x = 40 + ((4000 - wn) / (4000 - 600)) * 440;
                    return (
                      <g key={wn}>
                        <line x1={x} y1="170" x2={x} y2="174" stroke="#64748b" />
                        <text x={x} y="186" textAnchor="middle" fill="#94a3b8" fontSize="8" fontFamily="monospace">
                          {wn}
                        </text>
                      </g>
                    );
                  })}
                </svg>
              </div>

              {/* Diagnostic Regions Ribbon */}
              <div className="grid grid-cols-4 gap-2 text-center text-[10px]">
                <div className="p-2 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-300">
                  <span className="block font-bold">4000 - 2500 cm⁻¹</span>
                  <span>Single Bonds to H (O-H, N-H, C-H)</span>
                </div>
                <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-300">
                  <span className="block font-bold">2500 - 2000 cm⁻¹</span>
                  <span>Triple Bonds (C≡C, C≡N)</span>
                </div>
                <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300">
                  <span className="block font-bold">2000 - 1500 cm⁻¹</span>
                  <span>Double Bonds (C=O, C=C)</span>
                </div>
                <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300">
                  <span className="block font-bold">1500 - 600 cm⁻¹</span>
                  <span>Fingerprint Region (C-C, C-O)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 3. 1H NMR SPECTROMETER INTERACTIVE LAB */}
      {/* ============================================================== */}
      {activeInstrument === 'nmr' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left NMR Molecule & Peak Selector */}
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-purple-500/30 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-purple-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Radio className="w-4 h-4" />
                  <span>¹H Proton NMR Spectral Elucidation</span>
                </span>
                <span className="text-slate-400 text-[10px]">400 MHz CDCl₃</span>
              </div>

              {/* Sample Compound */}
              <div className="space-y-2">
                <label className="text-slate-400 uppercase text-[10px] block">Select Organic Compound:</label>
                <div className="grid grid-cols-1 gap-2">
                  {nmrMolecules.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => {
                        setSelectedNmrMol(m);
                        setSelectedNmrPeak(m.peaks[0]);
                      }}
                      className={`w-full text-left p-2.5 rounded-xl border transition-all flex items-center justify-between ${
                        selectedNmrMol.id === m.id
                          ? 'bg-purple-500/15 border-purple-400/40 text-purple-300 font-bold'
                          : 'bg-white/[0.02] border-white/5 text-slate-300 hover:bg-white/[0.06]'
                      }`}
                    >
                      <span>{m.name}</span>
                      <span className="text-[10px] text-slate-400">{m.peaks.length} Signals</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* NMR Signals Table */}
              <div className="space-y-2 pt-2 border-t border-white/5">
                <label className="text-slate-400 uppercase text-[10px] block">Proton Resonance Signals:</label>
                <div className="space-y-1.5">
                  {selectedNmrMol.peaks.map((p, idx) => {
                    const isSel = selectedNmrPeak.shift === p.shift;
                    return (
                      <button
                        key={idx}
                        onClick={() => setSelectedNmrPeak(p)}
                        className={`w-full text-left p-2.5 rounded-xl border transition-all flex items-center justify-between text-[11px] ${
                          isSel
                            ? 'bg-purple-500/20 border-purple-400 text-white font-bold shadow-md'
                            : 'bg-black/40 border-white/5 text-slate-300 hover:bg-white/[0.05]'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: p.color }} />
                          <strong className="text-purple-300">δ {p.shift.toFixed(2)} ppm</strong>
                          <span>({p.mult})</span>
                        </div>
                        <span className="text-[10px] text-slate-400 font-bold">{p.protons}H</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Active Proton Diagnostic */}
              {selectedNmrPeak && (
                <div className="p-4 rounded-2xl bg-purple-500/10 border border-purple-400/30 space-y-2">
                  <div className="flex justify-between items-center text-purple-300 font-bold">
                    <span>Signal: δ {selectedNmrPeak.shift.toFixed(2)} ppm ({selectedNmrPeak.protons}H)</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-purple-500/20">
                      {selectedNmrPeak.mult}
                    </span>
                  </div>
                  <p className="text-slate-300 text-[11px] font-sans leading-relaxed">
                    <strong>Proton Environment:</strong> {selectedNmrPeak.group} — {selectedNmrPeak.env}.
                    Coupling constant J = {selectedNmrPeak.jVal} Hz. Multiplicity obeys the (n + 1) rule where n is the number of vicinal non-equivalent protons.
                  </p>
                </div>
              )}
            </div>

            {/* Right 1H NMR Spectrum Canvas */}
            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Radio className="w-4 h-4 text-purple-400" />
                    <span>¹H NMR Spectrum (δ Chemical Shift ppm vs Intensity)</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                    Tetramethylsilane (TMS) at 0.00 ppm reference
                  </p>
                </div>
              </div>

              {/* SVG NMR Spectrum */}
              <div className="w-full bg-black/50 rounded-2xl p-4 border border-white/5 space-y-2">
                <svg viewBox="0 0 500 180" className="w-full h-auto select-none">
                  {/* Baseline */}
                  <line x1="30" y1="140" x2="470" y2="140" stroke="rgba(255,255,255,0.2)" strokeWidth="1" />

                  {/* Draw Peaks (scale 10 ppm -> 0 ppm, inverted X) */}
                  {selectedNmrMol.peaks.map((p, idx) => {
                    const x = 30 + ((10 - p.shift) / 10) * 440;
                    const isSel = selectedNmrPeak.shift === p.shift;

                    return (
                      <g key={idx} className="cursor-pointer" onClick={() => setSelectedNmrPeak(p)}>
                        {/* Peak line / splitting multiplets */}
                        {p.mult.startsWith('Triplet') ? (
                          <g>
                            <line x1={x - 4} y1="140" x2={x - 4} y2={140 - p.protons * 18} stroke={p.color} strokeWidth={isSel ? 3 : 2} />
                            <line x1={x} y1="140" x2={x} y2={140 - p.protons * 36} stroke={p.color} strokeWidth={isSel ? 3 : 2} />
                            <line x1={x + 4} y1="140" x2={x + 4} y2={140 - p.protons * 18} stroke={p.color} strokeWidth={isSel ? 3 : 2} />
                          </g>
                        ) : p.mult.startsWith('Quartet') ? (
                          <g>
                            <line x1={x - 6} y1="140" x2={x - 6} y2={140 - p.protons * 12} stroke={p.color} strokeWidth={isSel ? 3 : 2} />
                            <line x1={x - 2} y1="140" x2={x - 2} y2={140 - p.protons * 34} stroke={p.color} strokeWidth={isSel ? 3 : 2} />
                            <line x1={x + 2} y1="140" x2={x + 2} y2={140 - p.protons * 34} stroke={p.color} strokeWidth={isSel ? 3 : 2} />
                            <line x1={x + 6} y1="140" x2={x + 6} y2={140 - p.protons * 12} stroke={p.color} strokeWidth={isSel ? 3 : 2} />
                          </g>
                        ) : (
                          <line x1={x} y1="140" x2={x} y2={140 - p.protons * 32} stroke={p.color} strokeWidth={isSel ? 3.5 : 2} />
                        )}

                        {/* Integration Label */}
                        <text x={x} y={130 - p.protons * 34} textAnchor="middle" fill={p.color} fontSize="9" fontWeight="bold">
                          {p.protons}H
                        </text>

                        {/* Selection Glow */}
                        {isSel && (
                          <circle cx={x} cy={140} r="6" fill="none" stroke="#ffffff" strokeWidth="2" className="animate-ping" />
                        )}
                      </g>
                    );
                  })}

                  {/* X Axis Chemical Shift Ticks (10 -> 0 ppm) */}
                  {[10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0].map((ppm) => {
                    const x = 30 + ((10 - ppm) / 10) * 440;
                    return (
                      <g key={ppm}>
                        <line x1={x} y1="140" x2={x} y2="145" stroke="#64748b" />
                        <text x={x} y="160" textAnchor="middle" fill="#94a3b8" fontSize="9" fontFamily="monospace">
                          {ppm}
                        </text>
                      </g>
                    );
                  })}
                  <text x="250" y="176" textAnchor="middle" fill="#64748b" fontSize="9">
                    Chemical Shift δ (ppm) → [Deshielded / Downfield ← Upfield / Shielded]
                  </text>
                </svg>
              </div>

              {/* Chemical Shift Range Guide */}
              <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
                <div className="p-2 rounded-xl bg-white/[0.02] border border-white/5 text-slate-300">
                  <strong className="block text-cyan-300">0.5 - 2.0 ppm</strong>
                  <span>Alkyl C-H (sp³)</span>
                </div>
                <div className="p-2 rounded-xl bg-white/[0.02] border border-white/5 text-slate-300">
                  <strong className="block text-purple-300">3.0 - 4.5 ppm</strong>
                  <span>-O-CH-, Halides (-X-CH-)</span>
                </div>
                <div className="p-2 rounded-xl bg-white/[0.02] border border-white/5 text-slate-300">
                  <strong className="block text-pink-300">6.5 - 8.5 ppm</strong>
                  <span>Aromatic C-H (Benzene rings)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 4. MASS SPECTROMETER (MS) INTERACTIVE LAB */}
      {/* ============================================================== */}
      {activeInstrument === 'mass-spec' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Controls */}
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-pink-500/30 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-pink-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Zap className="w-4 h-4" />
                  <span>Electron Impact Mass Spectrometer</span>
                </span>
                <span className="text-slate-400 text-[10px]">m/z Analyzer (70 eV)</span>
              </div>

              {/* Select Molecule */}
              <div className="space-y-2">
                <label className="text-slate-400 uppercase text-[10px] block">Analyte Molecule:</label>
                <div className="grid grid-cols-1 gap-2">
                  {msMolecules.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => {
                        setSelectedMsMol(m);
                        setSelectedMsPeak(m.peaks[0]);
                      }}
                      className={`w-full text-left p-2.5 rounded-xl border transition-all flex items-center justify-between ${
                        selectedMsMol.id === m.id
                          ? 'bg-pink-500/15 border-pink-400/40 text-pink-300 font-bold'
                          : 'bg-white/[0.02] border-white/5 text-slate-300 hover:bg-white/[0.06]'
                      }`}
                    >
                      <span>{m.name}</span>
                      <span className="text-[10px] text-slate-400">Base m/z = {m.basePeak}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Fragment Peak Selector */}
              <div className="space-y-2 pt-2 border-t border-white/5">
                <label className="text-slate-400 uppercase text-[10px] block">Observed Fragment Ions:</label>
                <div className="space-y-1.5">
                  {selectedMsMol.peaks.map((p, idx) => {
                    const isSel = selectedMsPeak.mz === p.mz;
                    return (
                      <button
                        key={idx}
                        onClick={() => setSelectedMsPeak(p)}
                        className={`w-full text-left p-2.5 rounded-xl border transition-all flex items-center justify-between text-[11px] ${
                          isSel
                            ? 'bg-pink-500/20 border-pink-400 text-white font-bold shadow-md'
                            : 'bg-black/40 border-white/5 text-slate-300 hover:bg-white/[0.05]'
                        }`}
                      >
                        <div>
                          <strong className="text-pink-400">m/z {p.mz}</strong>: {p.label}
                        </div>
                        <span className="text-[10px] text-slate-400">{p.relAb}% Abundance</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Active Peak Explanation */}
              {selectedMsPeak && (
                <div className="p-4 rounded-2xl bg-pink-500/10 border border-pink-400/30 space-y-2">
                  <div className="flex justify-between items-center text-pink-300 font-bold">
                    <span>Fragment: {selectedMsPeak.formula} (m/z = {selectedMsPeak.mz})</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-pink-500/20">
                      {selectedMsPeak.relAb}% Base Peak
                    </span>
                  </div>
                  <p className="text-slate-300 text-[11px] font-sans leading-relaxed">
                    <strong>Mechanism:</strong> {selectedMsPeak.explanation}
                  </p>
                </div>
              )}
            </div>

            {/* Right Mass Spectrum Canvas */}
            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-pink-400" />
                    <span>Mass Spectrum (m/z vs % Relative Abundance)</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                    Base Peak normalized to 100% relative intensity
                  </p>
                </div>
              </div>

              {/* SVG Mass Spectrum */}
              <div className="w-full bg-black/50 rounded-2xl p-4 border border-white/5 space-y-2">
                <svg viewBox="0 0 500 180" className="w-full h-auto select-none">
                  {/* Grid Lines */}
                  {[100, 75, 50, 25, 0].map((ab) => {
                    const y = 30 + ((100 - ab) / 100) * 110;
                    return (
                      <g key={ab}>
                        <line x1="40" y1={y} x2="480" y2={y} stroke="rgba(255,255,255,0.06)" strokeDasharray="3 3" />
                        <text x="32" y={y + 3} textAnchor="end" fill="#64748b" fontSize="8" fontFamily="monospace">
                          {ab}%
                        </text>
                      </g>
                    );
                  })}

                  {/* Draw m/z Peak Bars */}
                  {(() => {
                    const maxMz = selectedMsMol.molecularIon > 100 ? 180 : 70;
                    return selectedMsMol.peaks.map((p, idx) => {
                      const x = 40 + (p.mz / maxMz) * 440;
                      const y = 30 + ((100 - p.relAb) / 100) * 110;
                      const isSel = selectedMsPeak.mz === p.mz;

                      return (
                        <g key={idx} className="cursor-pointer" onClick={() => setSelectedMsPeak(p)}>
                          <line x1={x} y1="140" x2={x} y2={y} stroke={isSel ? '#ffffff' : '#ec4899'} strokeWidth={isSel ? 3.5 : 2} />
                          <circle cx={x} cy={y} r={isSel ? 4 : 2.5} fill={isSel ? '#ffffff' : '#ec4899'} />
                          <text x={x} y={y - 6} textAnchor="middle" fill={isSel ? '#ffffff' : '#ec4899'} fontSize="8" fontWeight="bold">
                            {p.mz}
                          </text>
                        </g>
                      );
                    });
                  })()}

                  {/* Baseline */}
                  <line x1="40" y1="140" x2="480" y2="140" stroke="rgba(255,255,255,0.2)" />
                  <text x="260" y="165" textAnchor="middle" fill="#94a3b8" fontSize="9" fontFamily="monospace">
                    Mass-to-Charge Ratio (m/z) →
                  </text>
                </svg>
              </div>

              {/* Key Principles Callout */}
              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 space-y-2 text-slate-300">
                <span className="font-bold text-white block">Mass Spectrometry Physical Stages:</span>
                <p className="text-[11px] leading-relaxed font-sans">
                  1. <strong>Ionization:</strong> Neutral vapor bombarded with 70 eV electrons to form radical cations M⁺·.<br />
                  2. <strong>Acceleration & Deflection:</strong> Accelerated through electric potential V and deflected in magnetic field B according to radius r = (1/B) · √(2mV/q).<br />
                  3. <strong>Detection:</strong> Electron multiplier records ion current proportional to relative abundance.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 5. XRD X-RAY DIFFRACTION INTERACTIVE LAB */}
      {/* ============================================================== */}
      {activeInstrument === 'xrd' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Bragg Controls */}
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-emerald-500/30 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-emerald-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Layers className="w-4 h-4" />
                  <span>Bragg's Law Crystal Diffractometer</span>
                </span>
                <span className="text-slate-400 text-[10px]">nλ = 2d sinθ</span>
              </div>

              {/* Sliders */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Incident Angle (θ):</span>
                    <span className="text-emerald-300 font-bold">{xrdThetaDeg.toFixed(1)}° (2θ = {(xrdThetaDeg * 2).toFixed(1)}°)</span>
                  </div>
                  <input
                    type="range"
                    min={5}
                    max={60}
                    step={0.1}
                    value={xrdThetaDeg}
                    onChange={(e) => setXrdThetaDeg(parseFloat(e.target.value))}
                    className="w-full accent-emerald-400 cursor-pointer"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Interplanar Lattice Spacing (d):</span>
                    <span className="text-emerald-300 font-bold">{xrdLatticeD.toFixed(3)} nm</span>
                  </div>
                  <input
                    type="range"
                    min={0.1}
                    max={0.6}
                    step={0.005}
                    value={xrdLatticeD}
                    onChange={(e) => setXrdLatticeD(parseFloat(e.target.value))}
                    className="w-full accent-emerald-400 cursor-pointer"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-400">X-Ray Wavelength (λ):</span>
                    <span className="text-emerald-300 font-bold">{xrdLambda.toFixed(5)} nm (Cu Kα)</span>
                  </div>
                  <input
                    type="range"
                    min={0.05}
                    max={0.25}
                    step={0.005}
                    value={xrdLambda}
                    onChange={(e) => setXrdLambda(parseFloat(e.target.value))}
                    className="w-full accent-emerald-400 cursor-pointer"
                  />
                </div>
              </div>

              {/* Calculation Box */}
              <div className={`p-4 rounded-2xl border transition-all ${
                isConstructive
                  ? 'bg-emerald-500/20 border-emerald-400 text-emerald-200'
                  : 'bg-black/40 border-white/10 text-slate-300'
              }`}>
                <div className="flex justify-between items-center font-bold">
                  <span>Interference State:</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] ${isConstructive ? 'bg-emerald-400 text-slate-950' : 'bg-red-500/20 text-red-300'}`}>
                    {isConstructive ? 'CONSTRUCTIVE BRAGG PEAK (n = ' + Math.round(braggRatio) + ')' : 'DESTRUCTIVE INTERFERENCE'}
                  </span>
                </div>
                <div className="pt-2 text-[11px] space-y-1">
                  <div>Path Difference (2d sinθ): <strong>{pathDifference.toFixed(5)} nm</strong></div>
                  <div>Exact Ratio (2d sinθ / λ): <strong>{braggRatio.toFixed(3)}</strong></div>
                </div>
              </div>
            </div>

            {/* Right Crystal Lattice Visualization */}
            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Layers className="w-4 h-4 text-emerald-400" />
                    <span>Lattice Planes & Constructive Wavefronts</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                    X-rays reflecting off consecutive atomic planes with path difference Δx = 2d sinθ
                  </p>
                </div>
              </div>

              {/* Interactive SVG Diagram */}
              <div className="w-full bg-black/50 rounded-2xl p-4 border border-white/5">
                <svg viewBox="0 0 500 220" className="w-full h-auto select-none">
                  {/* Plane 1 Atomic Nodes */}
                  {[80, 150, 220, 290, 360, 430].map((x, i) => (
                    <circle key={i} cx={x} cy="70" r="7" fill="#10b981" stroke="#ffffff" strokeWidth="1.5" />
                  ))}
                  <text x="50" y="74" fill="#64748b" fontSize="9" fontFamily="monospace">Plane 1</text>

                  {/* Plane 2 Atomic Nodes */}
                  {[80, 150, 220, 290, 360, 430].map((x, i) => (
                    <circle key={i} cx={x} cy="140" r="7" fill="#10b981" stroke="#ffffff" strokeWidth="1.5" />
                  ))}
                  <text x="50" y="144" fill="#64748b" fontSize="9" fontFamily="monospace">Plane 2</text>

                  {/* Lattice Spacing dimension arrow */}
                  <line x1="450" y1="70" x2="450" y2="140" stroke="#38bdf8" strokeWidth="1.5" />
                  <text x="460" y="108" fill="#38bdf8" fontSize="9" fontWeight="bold">d</text>

                  {/* Incident Ray 1 & Reflected Ray 1 */}
                  <line x1="120" y1="20" x2="220" y2="70" stroke="#f59e0b" strokeWidth="2.5" />
                  <line x1="220" y1="70" x2="320" y2="20" stroke="#f59e0b" strokeWidth="2.5" />

                  {/* Incident Ray 2 & Reflected Ray 2 */}
                  <line x1="120" y1="90" x2="220" y2="140" stroke="#f59e0b" strokeWidth="2.5" />
                  <line x1="220" y1="140" x2="320" y2="90" stroke="#f59e0b" strokeWidth="2.5" />

                  {/* Path difference highlight */}
                  <line x1="180" y1="120" x2="220" y2="140" stroke="#ef4444" strokeWidth="3" strokeDasharray="3 3" />
                  <line x1="220" y1="140" x2="260" y2="120" stroke="#ef4444" strokeWidth="3" strokeDasharray="3 3" />
                  <text x="220" y="160" textAnchor="middle" fill="#ef4444" fontSize="9" fontWeight="bold">Δx = 2d sinθ</text>
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
