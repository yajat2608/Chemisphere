import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Sparkles,
  Zap,
  Flame,
  Activity,
  Layers,
  Info,
  RotateCcw,
  Play,
  Pause,
  ArrowRight,
  Eye,
  Sliders,
  Atom,
  HelpCircle,
  ChevronRight,
  CheckCircle2,
  Volume2
} from 'lucide-react';
import { NavigationTab, ChemicalElement } from '../../types';
import { ALL_118_ELEMENTS, getElementByNumber } from '../../data/elements';

interface AtomicSpectraLabViewProps {
  onNavigate?: (tab: NavigationTab) => void;
  selectedElementNumber?: number;
}

// Characteristic Spectral Lines for key elements (Wavelength in nm, relative intensity 0-1)
export const ELEMENT_SPECTRA_DATA: Record<
  string,
  { name: string; symbol: string; number: number; flameColor: string; flameHex: string; lines: { lambda: number; intensity: number; label?: string }[] }
> = {
  H: {
    name: 'Hydrogen',
    symbol: 'H',
    number: 1,
    flameColor: 'Pale Blue-Violet',
    flameHex: '#818cf8',
    lines: [
      { lambda: 656.3, intensity: 1.0, label: 'H-alpha (Balmer 3→2)' },
      { lambda: 486.1, intensity: 0.8, label: 'H-beta (Balmer 4→2)' },
      { lambda: 434.0, intensity: 0.55, label: 'H-gamma (Balmer 5→2)' },
      { lambda: 410.2, intensity: 0.35, label: 'H-delta (Balmer 6→2)' },
      { lambda: 397.0, intensity: 0.2, label: 'H-epsilon (Balmer 7→2)' }
    ]
  },
  He: {
    name: 'Helium',
    symbol: 'He',
    number: 2,
    flameColor: 'Pale Peach / Gold',
    flameHex: '#fed7aa',
    lines: [
      { lambda: 706.5, intensity: 0.7, label: '3s³S → 2p³P' },
      { lambda: 667.8, intensity: 0.85, label: '3d¹D → 2p¹P (Red)' },
      { lambda: 587.6, intensity: 1.0, label: 'D3 Solar Line (Yellow)' },
      { lambda: 501.6, intensity: 0.75, label: '3p¹P → 2s¹S (Green)' },
      { lambda: 492.2, intensity: 0.5, label: 'Blue-Green' },
      { lambda: 471.3, intensity: 0.45, label: 'Blue' },
      { lambda: 447.1, intensity: 0.9, label: '4d³D → 2p³P (Deep Blue)' },
      { lambda: 388.9, intensity: 0.8, label: 'Near UV' }
    ]
  },
  Li: {
    name: 'Lithium',
    symbol: 'Li',
    number: 3,
    flameColor: 'Carmine Red',
    flameHex: '#f43f5e',
    lines: [
      { lambda: 670.8, intensity: 1.0, label: 'Principal Doublet (2p→2s)' },
      { lambda: 610.4, intensity: 0.35, label: '3d → 2p (Orange)' },
      { lambda: 460.3, intensity: 0.2, label: '4d → 2p (Blue)' },
      { lambda: 413.2, intensity: 0.15, label: '5d → 2p (Violet)' }
    ]
  },
  Na: {
    name: 'Sodium',
    symbol: 'Na',
    number: 11,
    flameColor: 'Intense Golden Yellow',
    flameHex: '#facc15',
    lines: [
      { lambda: 589.0, intensity: 1.0, label: 'D2 Line (3p³/₂ → 3s¹/₂)' },
      { lambda: 589.6, intensity: 0.95, label: 'D1 Line (3p¹/₂ → 3s¹/₂)' },
      { lambda: 568.8, intensity: 0.15, label: '4d → 3p (Green)' },
      { lambda: 498.3, intensity: 0.1, label: '5d → 3p (Cyan)' },
      { lambda: 330.2, intensity: 0.25, label: '4p → 3s (UV)' }
    ]
  },
  K: {
    name: 'Potassium',
    symbol: 'K',
    number: 19,
    flameColor: 'Lilac / Pale Violet',
    flameHex: '#c084fc',
    lines: [
      { lambda: 769.9, intensity: 0.9, label: '4p¹/₂ → 4s (Deep Red)' },
      { lambda: 766.5, intensity: 1.0, label: '4p³/₂ → 4s (Deep Red)' },
      { lambda: 693.9, intensity: 0.2, label: '6s → 4p' },
      { lambda: 580.2, intensity: 0.15, label: 'Yellow' },
      { lambda: 404.7, intensity: 0.65, label: '5p → 4s (Violet)' },
      { lambda: 404.4, intensity: 0.7, label: '5p → 4s (Violet Doublet)' }
    ]
  },
  Ca: {
    name: 'Calcium',
    symbol: 'Ca',
    number: 20,
    flameColor: 'Brick Red / Orange-Red',
    flameHex: '#fb923c',
    lines: [
      { lambda: 649.4, intensity: 0.45, label: 'Red' },
      { lambda: 643.9, intensity: 0.5, label: 'Red' },
      { lambda: 616.2, intensity: 0.65, label: 'Orange' },
      { lambda: 558.9, intensity: 0.4, label: 'Yellow-Green' },
      { lambda: 445.5, intensity: 0.55, label: 'Blue' },
      { lambda: 422.7, intensity: 1.0, label: 'Resonance Line (Violet)' },
      { lambda: 396.8, intensity: 0.85, label: 'Fraunhofer H Line' },
      { lambda: 393.4, intensity: 0.95, label: 'Fraunhofer K Line' }
    ]
  },
  Sr: {
    name: 'Strontium',
    symbol: 'Sr',
    number: 38,
    flameColor: 'Crimson / Scarlet',
    flameHex: '#e11d48',
    lines: [
      { lambda: 687.8, intensity: 0.6, label: 'Red' },
      { lambda: 650.4, intensity: 0.5, label: 'Red' },
      { lambda: 460.7, intensity: 1.0, label: 'Resonance Line (Blue)' },
      { lambda: 407.8, intensity: 0.8, label: 'Sr II (Violet)' }
    ]
  },
  Ba: {
    name: 'Barium',
    symbol: 'Ba',
    number: 56,
    flameColor: 'Apple Green',
    flameHex: '#84cc16',
    lines: [
      { lambda: 649.9, intensity: 0.4, label: 'Red-Orange' },
      { lambda: 553.5, intensity: 1.0, label: 'Resonance Line (Green)' },
      { lambda: 513.7, intensity: 0.55, label: 'Green Band' },
      { lambda: 493.4, intensity: 0.7, label: 'Cyan (Ba II)' },
      { lambda: 455.4, intensity: 0.85, label: 'Deep Blue (Ba II)' }
    ]
  },
  Cu: {
    name: 'Copper',
    symbol: 'Cu',
    number: 29,
    flameColor: 'Brilliant Emerald Blue-Green',
    flameHex: '#06b6d4',
    lines: [
      { lambda: 578.2, intensity: 0.6, label: 'Yellow Laser Line' },
      { lambda: 521.8, intensity: 0.9, label: 'Green' },
      { lambda: 515.3, intensity: 0.85, label: 'Green' },
      { lambda: 510.6, intensity: 1.0, label: 'Cu Vapor Laser (Green)' },
      { lambda: 406.3, intensity: 0.4, label: 'Violet' },
      { lambda: 327.4, intensity: 0.95, label: 'Resonance UV' },
      { lambda: 324.8, intensity: 1.0, label: 'Resonance UV' }
    ]
  },
  Ne: {
    name: 'Neon',
    symbol: 'Ne',
    number: 10,
    flameColor: 'Fiery Red-Orange Glow',
    flameHex: '#ff4500',
    lines: [
      { lambda: 640.2, intensity: 1.0, label: 'Intense Red' },
      { lambda: 633.4, intensity: 0.8, label: 'Red-Orange' },
      { lambda: 614.3, intensity: 0.85, label: 'Orange' },
      { lambda: 585.2, intensity: 0.95, label: 'Yellow' },
      { lambda: 540.1, intensity: 0.45, label: 'Green' }
    ]
  },
  Hg: {
    name: 'Mercury',
    symbol: 'Hg',
    number: 80,
    flameColor: 'Bluish-Green Fluorescent',
    flameHex: '#38bdf8',
    lines: [
      { lambda: 579.1, intensity: 0.7, label: 'Yellow Doublet 1' },
      { lambda: 577.0, intensity: 0.7, label: 'Yellow Doublet 2' },
      { lambda: 546.1, intensity: 1.0, label: 'Intense Green' },
      { lambda: 435.8, intensity: 0.9, label: 'Deep Blue' },
      { lambda: 404.7, intensity: 0.6, label: 'Violet' },
      { lambda: 365.0, intensity: 0.85, label: 'i-line UV' },
      { lambda: 253.7, intensity: 1.0, label: 'Germicidal UV' }
    ]
  }
};

// Helper: Convert Wavelength (nm) to RGB Color
export function nmToRGB(wavelength: number): { r: number; g: number; b: number; hex: string } {
  let r = 0, g = 0, b = 0;
  if (wavelength >= 380 && wavelength < 440) {
    r = -(wavelength - 440) / (440 - 380);
    g = 0.0;
    b = 1.0;
  } else if (wavelength >= 440 && wavelength < 490) {
    r = 0.0;
    g = (wavelength - 440) / (490 - 440);
    b = 1.0;
  } else if (wavelength >= 490 && wavelength < 510) {
    r = 0.0;
    g = 1.0;
    b = -(wavelength - 510) / (510 - 490);
  } else if (wavelength >= 510 && wavelength < 580) {
    r = (wavelength - 510) / (580 - 510);
    g = 1.0;
    b = 0.0;
  } else if (wavelength >= 580 && wavelength < 645) {
    r = 1.0;
    g = -(wavelength - 645) / (645 - 580);
    b = 0.0;
  } else if (wavelength >= 645 && wavelength <= 780) {
    r = 1.0;
    g = 0.0;
    b = 0.0;
  } else if (wavelength < 380) {
    // UV range representation
    r = 0.6; g = 0.0; b = 0.9;
  } else {
    // IR range representation
    r = 0.7; g = 0.0; b = 0.0;
  }

  // Factor intensity falloff near human visible limits
  let factor = 1.0;
  if (wavelength >= 380 && wavelength < 420) {
    factor = 0.3 + (0.7 * (wavelength - 380)) / (420 - 380);
  } else if (wavelength >= 700 && wavelength <= 780) {
    factor = 0.3 + (0.7 * (780 - wavelength)) / (780 - 700);
  } else if (wavelength < 380 || wavelength > 780) {
    factor = 0.4;
  }

  const R = Math.round(255 * Math.pow(Math.max(0, r * factor), 0.8));
  const G = Math.round(255 * Math.pow(Math.max(0, g * factor), 0.8));
  const B = Math.round(255 * Math.pow(Math.max(0, b * factor), 0.8));
  const hex = `#${((1 << 24) + (R << 16) + (G << 8) + B).toString(16).slice(1)}`;

  return { r: R, g: G, b: B, hex };
}

// Rydberg Formula Constant
const R_H = 1.0973731568508e7; // m^-1
const C_LIGHT = 2.99792458e8; // m/s
const H_PLANCK = 6.62607015e-34; // J·s
const EV_TO_J = 1.602176634e-19; // J/eV

export const AtomicSpectraLabView: React.FC<AtomicSpectraLabViewProps> = ({
  onNavigate,
  selectedElementNumber
}) => {
  const [labMode, setLabMode] = useState<'hydrogen' | 'elements' | 'flame-test'>('hydrogen');
  const [spectrumType, setSpectrumType] = useState<'emission' | 'absorption'>('emission');
  
  // Hydrogen State
  const [initialN, setInitialN] = useState<number>(3); // electron starts at n=3
  const [finalN, setFinalN] = useState<number>(2); // drops to n=2 (Balmer H-alpha)
  const [selectedSeries, setSelectedSeries] = useState<'all' | 'lyman' | 'balmer' | 'paschen' | 'brackett' | 'pfund' | 'humphreys'>('balmer');
  const [isTransitioning, setIsTransitioning] = useState<boolean>(false);
  const [activePhotonEmitted, setActivePhotonEmitted] = useState<{ lambdaNm: number; energyEv: number; freqHz: number; hex: string; region: string } | null>(null);

  // Element Spectra State
  const [activeElementKey, setActiveElementKey] = useState<string>('Na');
  const [hoveredLine, setHoveredLine] = useState<{ lambda: number; label?: string; intensity: number } | null>(null);

  // Flame Test Simulation State
  const [flameSalt, setFlameSalt] = useState<string>('Na');
  const [isRodInFlame, setIsRodInFlame] = useState<boolean>(false);
  const [flameAirVent, setFlameAirVent] = useState<'closed' | 'open'>('open'); // Bunsen burner air vent
  const flameCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Hydrogen Series Definitions
  const hydrogenSeriesList = [
    { id: 'lyman', name: 'Lyman Series', nf: 1, region: 'Ultraviolet (UV)', discovery: 'Theodore Lyman (1906)', color: '#c084fc' },
    { id: 'balmer', name: 'Balmer Series', nf: 2, region: 'Visible Light', discovery: 'Johann Balmer (1885)', color: '#38bdf8' },
    { id: 'paschen', name: 'Paschen Series', nf: 3, region: 'Near Infrared (IR)', discovery: 'Friedrich Paschen (1908)', color: '#f87171' },
    { id: 'brackett', name: 'Brackett Series', nf: 4, region: 'Infrared (IR)', discovery: 'Frederick Brackett (1922)', color: '#fb923c' },
    { id: 'pfund', name: 'Pfund Series', nf: 5, region: 'Far Infrared (IR)', discovery: 'August Pfund (1924)', color: '#eab308' },
    { id: 'humphreys', name: 'Humphreys Series', nf: 6, region: 'Far Infrared (IR)', discovery: 'Curtis Humphreys (1953)', color: '#a3e635' }
  ];

  // Calculate Hydrogen Transition Parameters
  const transitionData = useMemo(() => {
    const ni = initialN;
    const nf = finalN;
    if (ni === nf) return null;

    const nHigh = Math.max(ni, nf);
    const nLow = Math.min(ni, nf);

    // Wavenumber 1/lambda = R_H * (1/nLow^2 - 1/nHigh^2)
    const waveNumber = R_H * (1 / (nLow * nLow) - 1 / (nHigh * nHigh));
    const lambdaM = 1 / waveNumber;
    const lambdaNm = lambdaM * 1e9;
    const freqHz = C_LIGHT / lambdaM;
    const deltaEJ = H_PLANCK * freqHz;
    const deltaEEv = deltaEJ / EV_TO_J;

    // Energy of levels: E_n = -13.6 / n^2 eV
    const eInitial = -13.6 / (ni * ni);
    const eFinal = -13.6 / (nf * nf);

    let region = 'Visible';
    if (lambdaNm < 380) region = 'Ultraviolet (UV)';
    else if (lambdaNm > 750) region = 'Infrared (IR)';

    const color = nmToRGB(lambdaNm);

    return {
      ni,
      nf,
      nHigh,
      nLow,
      isEmission: ni > nf,
      lambdaNm: +lambdaNm.toFixed(2),
      freqHz: freqHz.toExponential(4),
      deltaEEv: +deltaEEv.toFixed(3),
      deltaEJ: deltaEJ.toExponential(4),
      eInitial: +eInitial.toFixed(3),
      eFinal: +eFinal.toFixed(3),
      region,
      colorHex: color.hex
    };
  }, [initialN, finalN]);

  // Hydrogen Series Line Pre-calculations (n=2 to 7 for Balmer, etc.)
  const hydrogenSeriesTransitions = useMemo(() => {
    const transitions: { ni: number; nf: number; lambdaNm: number; colorHex: string; label: string; seriesId: string }[] = [];
    
    hydrogenSeriesList.forEach((ser) => {
      for (let ni = ser.nf + 1; ni <= 7; ni++) {
        const waveNumber = R_H * (1 / (ser.nf * ser.nf) - 1 / (ni * ni));
        const lambdaNm = (1 / waveNumber) * 1e9;
        const color = nmToRGB(lambdaNm);
        transitions.push({
          ni,
          nf: ser.nf,
          lambdaNm: +lambdaNm.toFixed(1),
          colorHex: color.hex,
          label: `${ser.name.split(' ')[0]} ${ni}→${ser.nf}`,
          seriesId: ser.id
        });
      }
    });

    return transitions;
  }, []);

  // Handle Hydrogen Electron Transition Animation
  const handleExecuteTransition = () => {
    if (!transitionData || isTransitioning) return;
    setIsTransitioning(true);

    setTimeout(() => {
      if (transitionData.isEmission) {
        setActivePhotonEmitted({
          lambdaNm: transitionData.lambdaNm,
          energyEv: transitionData.deltaEEv,
          freqHz: parseFloat(transitionData.freqHz),
          hex: transitionData.colorHex,
          region: transitionData.region
        });
      }
      setIsTransitioning(false);
    }, 600);
  };

  // Flame Test Canvas Animation
  useEffect(() => {
    if (labMode !== 'flame-test') return;
    const canvas = flameCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let time = 0;

    const currentSaltData = ELEMENT_SPECTRA_DATA[flameSalt] || ELEMENT_SPECTRA_DATA.Na;

    const particles: { x: number; y: number; vx: number; vy: number; life: number; maxLife: number; size: number; color: string }[] = [];

    const render = () => {
      time += 0.05;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const cx = canvas.width / 2;
      const baseCy = canvas.height - 50;

      // Draw Bunsen Burner Nozzle
      ctx.fillStyle = '#334155';
      ctx.fillRect(cx - 16, baseCy, 32, 50);
      ctx.fillStyle = '#64748b';
      ctx.fillRect(cx - 20, baseCy + 5, 40, 8);
      // Air Vent indicator
      ctx.fillStyle = flameAirVent === 'open' ? '#0284c7' : '#1e293b';
      ctx.fillRect(cx - 6, baseCy + 20, 12, 10);

      // Base Blue Cone (Non-luminous hot flame)
      const flameHeight = flameAirVent === 'open' ? 140 : 180;
      const flameWobble = Math.sin(time * 6) * 4;

      // Draw Outer Flame Glow
      const glowGrad = ctx.createRadialGradient(cx + flameWobble, baseCy - flameHeight * 0.5, 10, cx, baseCy - flameHeight * 0.5, 90);
      if (isRodInFlame) {
        glowGrad.addColorStop(0, `${currentSaltData.flameHex}bb`);
        glowGrad.addColorStop(0.5, `${currentSaltData.flameHex}44`);
        glowGrad.addColorStop(1, 'transparent');
      } else {
        glowGrad.addColorStop(0, flameAirVent === 'open' ? 'rgba(56, 189, 248, 0.4)' : 'rgba(250, 204, 21, 0.4)');
        glowGrad.addColorStop(1, 'transparent');
      }
      ctx.fillStyle = glowGrad;
      ctx.beginPath();
      ctx.arc(cx, baseCy - flameHeight * 0.5, 90, 0, Math.PI * 2);
      ctx.fill();

      // Outer Flame Body
      ctx.beginPath();
      ctx.moveTo(cx - 18, baseCy);
      ctx.quadraticCurveTo(cx - 35 + flameWobble * 0.5, baseCy - flameHeight * 0.6, cx + flameWobble, baseCy - flameHeight);
      ctx.quadraticCurveTo(cx + 35 + flameWobble * 0.5, baseCy - flameHeight * 0.6, cx + 18, baseCy);
      ctx.closePath();

      const bodyGrad = ctx.createLinearGradient(cx, baseCy, cx, baseCy - flameHeight);
      if (isRodInFlame) {
        bodyGrad.addColorStop(0, '#38bdf8');
        bodyGrad.addColorStop(0.3, currentSaltData.flameHex);
        bodyGrad.addColorStop(0.9, `${currentSaltData.flameHex}ee`);
      } else {
        if (flameAirVent === 'open') {
          bodyGrad.addColorStop(0, '#1d4ed8');
          bodyGrad.addColorStop(0.5, '#0284c7');
          bodyGrad.addColorStop(0.9, '#38bdf8');
        } else {
          bodyGrad.addColorStop(0, '#d97706');
          bodyGrad.addColorStop(0.4, '#f59e0b');
          bodyGrad.addColorStop(0.9, '#fef08a');
        }
      }
      ctx.fillStyle = bodyGrad;
      ctx.fill();

      // Inner Core Flame (Hottest Zone)
      ctx.beginPath();
      ctx.moveTo(cx - 10, baseCy);
      ctx.quadraticCurveTo(cx - 15 + flameWobble * 0.3, baseCy - flameHeight * 0.3, cx + flameWobble * 0.5, baseCy - flameHeight * 0.5);
      ctx.quadraticCurveTo(cx + 15 + flameWobble * 0.3, baseCy - flameHeight * 0.3, cx + 10, baseCy);
      ctx.closePath();
      ctx.fillStyle = flameAirVent === 'open' ? 'rgba(191, 219, 254, 0.85)' : 'rgba(254, 240, 138, 0.85)';
      ctx.fill();

      // Platinum Wire Loop with Salt Sample
      if (isRodInFlame) {
        const wireX = cx + 8;
        const wireY = baseCy - flameHeight * 0.45;

        // Wire handle
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(canvas.width - 20, wireY - 40);
        ctx.lineTo(wireX, wireY);
        ctx.stroke();

        // Loop circle
        ctx.strokeStyle = '#facc15';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(wireX - 6, wireY, 7, 0, Math.PI * 2);
        ctx.stroke();

        // Glowing sample inside loop
        ctx.fillStyle = currentSaltData.flameHex;
        ctx.beginPath();
        ctx.arc(wireX - 6, wireY, 5, 0, Math.PI * 2);
        ctx.fill();

        // Spawn Spark/Ember Particles
        if (Math.random() < 0.6) {
          particles.push({
            x: wireX - 6 + (Math.random() - 0.5) * 8,
            y: wireY + (Math.random() - 0.5) * 8,
            vx: (Math.random() - 0.5) * 1.5,
            vy: -Math.random() * 3.5 - 1.5,
            life: 0,
            maxLife: 35 + Math.random() * 25,
            size: 2 + Math.random() * 3,
            color: currentSaltData.flameHex
          });
        }
      }

      // Render & Update Spark Particles
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.life++;

        const alpha = Math.max(0, 1 - p.life / p.maxLife);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * alpha, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1.0;

        if (p.life >= p.maxLife) {
          particles.splice(i, 1);
        }
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [labMode, flameSalt, isRodInFlame, flameAirVent]);

  const activeElementData = ELEMENT_SPECTRA_DATA[activeElementKey] || ELEMENT_SPECTRA_DATA.H;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6 animate-fade-in font-sans">
      {/* Header Banner & Mode Selector */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-[#090d16] via-[#101726] to-[#090d16] border border-cyan-500/20 shadow-2xl backdrop-blur-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
              Quantum Optics & Spectroscopy
            </span>
            <span className="text-[11px] font-mono text-slate-400">
              ΔE = hν • c = λν • Fraunhofer Lines
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-3">
            <Sparkles className="w-6 h-6 text-cyan-400" />
            <span>Atomic Spectra & Energy Transitions Lab</span>
          </h1>
          <p className="text-xs text-slate-400 max-w-3xl leading-relaxed">
            Investigate electronic quantum transitions, calculate emission photon wavelengths ($\lambda$), analyze characteristic elemental spectra, and perform qualitative analytical flame tests with synchronized line spectra.
          </p>
        </div>

        {/* Primary Lab Mode Switcher */}
        <div className="flex items-center gap-1.5 p-1.5 rounded-2xl bg-black/60 border border-white/10 font-mono text-xs shrink-0">
          <button
            onClick={() => setLabMode('hydrogen')}
            className={`px-3.5 py-2 rounded-xl font-bold transition-all flex items-center gap-2 ${
              labMode === 'hydrogen'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-lg shadow-cyan-500/30'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Atom className="w-4 h-4" />
            <span>HYDROGEN BOHR LAB</span>
          </button>
          <button
            onClick={() => setLabMode('elements')}
            className={`px-3.5 py-2 rounded-xl font-bold transition-all flex items-center gap-2 ${
              labMode === 'elements'
                ? 'bg-purple-500 text-white shadow-lg shadow-purple-500/30'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>ELEMENT SPECTRA</span>
          </button>
          <button
            onClick={() => setLabMode('flame-test')}
            className={`px-3.5 py-2 rounded-xl font-bold transition-all flex items-center gap-2 ${
              labMode === 'flame-test'
                ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/30 font-black'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Flame className="w-4 h-4 text-amber-400" />
            <span>FLAME TEST LAB</span>
          </button>
        </div>
      </div>

      {/* ==========================================
          MODE 1: HYDROGEN BOHR ENERGY LEVEL LAB
         ========================================== */}
      {labMode === 'hydrogen' && (
        <div className="space-y-6">
          {/* Controls Bar: Initial & Final Shells, Series Selector */}
          <div className="p-5 rounded-3xl bg-[#090d16] border border-cyan-900/40 shadow-xl space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4 font-mono text-xs">
              <div className="flex items-center gap-3">
                <span className="text-slate-400 uppercase font-bold">Hydrogen Series Filter:</span>
                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    onClick={() => setSelectedSeries('all')}
                    className={`px-3 py-1 rounded-xl border transition-all ${
                      selectedSeries === 'all'
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400 font-bold'
                        : 'bg-white/5 border-white/5 text-slate-400 hover:text-white'
                    }`}
                  >
                    All Series
                  </button>
                  {hydrogenSeriesList.map((ser) => (
                    <button
                      key={ser.id}
                      onClick={() => {
                        setSelectedSeries(ser.id as any);
                        setFinalN(ser.nf);
                        setInitialN(Math.max(ser.nf + 1, initialN));
                      }}
                      className={`px-3 py-1 rounded-xl border transition-all flex items-center gap-1.5 ${
                        selectedSeries === ser.id
                          ? 'bg-white/15 text-white font-bold border-cyan-400 shadow-md'
                          : 'bg-white/5 border-white/5 text-slate-400 hover:text-white'
                      }`}
                    >
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: ser.color }} />
                      <span>{ser.name} (n_f={ser.nf})</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Emission vs Absorption Switcher */}
              <div className="flex items-center gap-1 p-1 rounded-xl bg-black/50 border border-white/10">
                <button
                  onClick={() => setSpectrumType('emission')}
                  className={`px-3 py-1 rounded-lg transition-all ${
                    spectrumType === 'emission'
                      ? 'bg-cyan-500 text-slate-950 font-bold shadow'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Emission (Bright Lines)
                </button>
                <button
                  onClick={() => setSpectrumType('absorption')}
                  className={`px-3 py-1 rounded-lg transition-all ${
                    spectrumType === 'absorption'
                      ? 'bg-amber-500 text-slate-950 font-bold shadow'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Absorption (Dark Fraunhofer)
                </button>
              </div>
            </div>

            {/* Interactive Shell Sliders */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 pt-2 border-t border-white/10 items-center">
              <div className="md:col-span-4 p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2">
                <div className="flex justify-between items-center text-xs font-mono">
                  <span className="text-cyan-400 font-bold">Initial Orbit (n_initial):</span>
                  <span className="text-base font-bold text-white px-2 py-0.5 rounded-lg bg-cyan-500/20 border border-cyan-400/40">
                    n = {initialN} ({(-13.6 / (initialN * initialN)).toFixed(2)} eV)
                  </span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={7}
                  value={initialN}
                  onChange={(e) => setInitialN(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
                />
              </div>

              <div className="md:col-span-4 p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2">
                <div className="flex justify-between items-center text-xs font-mono">
                  <span className="text-amber-400 font-bold">Final Orbit (n_final):</span>
                  <span className="text-base font-bold text-white px-2 py-0.5 rounded-lg bg-amber-500/20 border border-amber-400/40">
                    n = {finalN} ({(-13.6 / (finalN * finalN)).toFixed(2)} eV)
                  </span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={7}
                  value={finalN}
                  onChange={(e) => setFinalN(parseInt(e.target.value))}
                  className="w-full accent-amber-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
                />
              </div>

              <div className="md:col-span-4 flex items-center gap-2">
                <button
                  onClick={handleExecuteTransition}
                  disabled={initialN === finalN || isTransitioning}
                  className={`w-full py-4 rounded-2xl font-mono text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                    initialN === finalN
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      : initialN > finalN
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 shadow-xl shadow-cyan-500/30 active:scale-95'
                      : 'bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 shadow-xl shadow-amber-500/30 active:scale-95'
                  }`}
                >
                  <Zap className="w-4 h-4" />
                  <span>
                    {initialN > finalN ? 'EMIT PHOTON (DE-EXCITE)' : initialN < finalN ? 'ABSORB PHOTON (EXCITE)' : 'SELECT DIFFERENT SHELLS'}
                  </span>
                </button>
              </div>
            </div>
          </div>

          {/* Main Dual Visualizer: Energy Level Diagram (Left) & Live Optical Spectrum (Right) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Column: Bohr Energy Level Ladder Diagram */}
            <div className="lg:col-span-6 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  <span>HYDROGEN ENERGY LEVEL DIAGRAM (E_n = -13.6/n² eV)</span>
                </h3>
                <span className="text-[10px] text-slate-400 font-mono">Bound States (n=1 to ∞)</span>
              </div>

              {/* Energy Ladder Canvas / SVG */}
              <div className="relative h-96 w-full rounded-2xl bg-black/60 border border-white/5 p-4 flex flex-col justify-between overflow-hidden">
                {/* Free Electron Continuum Ionization Line (E = 0 eV) */}
                <div className="border-b border-dashed border-red-500/60 pb-1 flex justify-between text-[10px] font-mono text-red-400">
                  <span>n = ∞ (Ionization Continuum)</span>
                  <span>E = 0.00 eV</span>
                </div>

                {/* Render Levels n=7 down to n=1 with physically scaled vertical placement */}
                <div className="relative flex-1 py-2">
                  {[7, 6, 5, 4, 3, 2, 1].map((n) => {
                    const energyEv = -13.6 / (n * n);
                    // Map energy from -13.6 eV (bottom 0%) to 0 eV (top 100%)
                    const bottomPercent = ((energyEv - (-13.6)) / 13.6) * 88 + 4;
                    const isInitial = initialN === n;
                    const isFinal = finalN === n;

                    return (
                      <div
                        key={n}
                        style={{ bottom: `${bottomPercent}%` }}
                        className={`absolute left-0 right-0 border-t transition-all flex items-center justify-between px-3 text-[11px] font-mono select-none ${
                          isInitial
                            ? 'border-cyan-400 border-2 bg-cyan-500/10 text-cyan-300 font-bold z-20'
                            : isFinal
                            ? 'border-amber-400 border-2 bg-amber-500/10 text-amber-300 font-bold z-20'
                            : 'border-white/20 text-slate-400 hover:border-white/50'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white">n = {n}</span>
                          {n === 1 && <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-400">Ground State</span>}
                          {isInitial && <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-500 text-slate-950 font-bold">Initial Orbit</span>}
                          {isFinal && <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500 text-slate-950 font-bold">Final Orbit</span>}
                        </div>

                        <span>{energyEv.toFixed(2)} eV</span>
                      </div>
                    );
                  })}

                  {/* Transition Vector Arrow */}
                  {transitionData && (
                    <div
                      className="absolute left-1/2 -translate-x-1/2 flex flex-col items-center pointer-events-none z-30 transition-all duration-500"
                      style={{
                        bottom: `${Math.min(
                          ((transitionData.eInitial - (-13.6)) / 13.6) * 88 + 4,
                          ((transitionData.eFinal - (-13.6)) / 13.6) * 88 + 4
                        )}%`,
                        height: `${Math.abs(
                          (((transitionData.eInitial - (-13.6)) / 13.6) * 88 + 4) -
                            (((transitionData.eFinal - (-13.6)) / 13.6) * 88 + 4)
                        )}%`
                      }}
                    >
                      <div
                        className="w-1.5 h-full rounded-full shadow-lg"
                        style={{
                          backgroundColor: transitionData.colorHex,
                          boxShadow: `0 0 16px ${transitionData.colorHex}`
                        }}
                      />
                      <div
                        className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-black/90 border mt-1 shadow-md whitespace-nowrap"
                        style={{
                          color: transitionData.colorHex,
                          borderColor: transitionData.colorHex
                        }}
                      >
                        {transitionData.isEmission ? '↓ EMISSION' : '↑ ABSORPTION'} (ΔE = {transitionData.deltaEEv} eV)
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Right Column: Physical Photon Metrics & Optical Emission/Absorption Spectrum */}
            <div className="lg:col-span-6 space-y-4">
              {/* Photon Transition Math Card */}
              {transitionData && (
                <div className="p-5 rounded-3xl bg-[#090d16] border border-cyan-500/30 shadow-2xl space-y-3 font-mono text-xs">
                  <div className="flex items-center justify-between border-b border-white/10 pb-2">
                    <span className="text-cyan-300 font-bold uppercase tracking-wider">
                      Calculated Quantum Parameters
                    </span>
                    <span
                      className="px-2.5 py-0.5 rounded-full font-bold text-[10px] border shadow-sm"
                      style={{
                        backgroundColor: `${transitionData.colorHex}22`,
                        color: transitionData.colorHex,
                        borderColor: transitionData.colorHex
                      }}
                    >
                      {transitionData.region} Region
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                    <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                      <span className="text-[10px] text-slate-400 block">Wavelength (λ)</span>
                      <span className="text-base font-bold text-white" style={{ color: transitionData.colorHex }}>
                        {transitionData.lambdaNm} nm
                      </span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                      <span className="text-[10px] text-slate-400 block">Photon Energy (ΔE)</span>
                      <span className="text-base font-bold text-white">{transitionData.deltaEEv} eV</span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                      <span className="text-[10px] text-slate-400 block">Frequency (ν)</span>
                      <span className="text-sm font-bold text-cyan-300">{transitionData.freqHz} Hz</span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                      <span className="text-[10px] text-slate-400 block">Rydberg Transition</span>
                      <span className="text-sm font-bold text-amber-300">
                        {transitionData.ni} → {transitionData.nf}
                      </span>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-black/40 border border-white/5 text-[11px] text-slate-300 space-y-1">
                    <span className="text-amber-400 font-bold block">Rydberg Quantum Formula:</span>
                    <div className="font-mono text-cyan-300">
                      1/λ = R_H × (1/n_f² - 1/n_i²) = 1.097×10⁷ m⁻¹ × (1/{transitionData.nLow}² - 1/{transitionData.nHigh}²)
                    </div>
                  </div>
                </div>
              )}

              {/* Optical Spectrum Display Strip (380 nm - 750 nm) */}
              <div className="p-5 rounded-3xl bg-[#090d16] border border-white/10 shadow-2xl space-y-3">
                <div className="flex items-center justify-between font-mono text-xs">
                  <span className="text-white font-bold">Hydrogen Line Spectrum Visualizer</span>
                  <span className="text-slate-400 text-[10px]">Visible Window (380 - 750 nm)</span>
                </div>

                {/* The Spectral Strip */}
                <div className="relative h-24 rounded-2xl overflow-hidden border border-white/20 shadow-inner">
                  {spectrumType === 'emission' ? (
                    // Emission Spectrum: Dark background with luminous vertical lines
                    <div className="w-full h-full bg-[#030712] relative">
                      {hydrogenSeriesTransitions.map((line, idx) => {
                        const isVisible = line.lambdaNm >= 380 && line.lambdaNm <= 750;
                        const isSelectedLine = transitionData && Math.abs(transitionData.lambdaNm - line.lambdaNm) < 1;
                        if (!isVisible) return null;

                        // Percent position in 380 - 750 nm range
                        const leftPercent = ((line.lambdaNm - 380) / (750 - 380)) * 100;

                        return (
                          <div
                            key={idx}
                            style={{
                              left: `${leftPercent}%`,
                              backgroundColor: line.colorHex,
                              boxShadow: isSelectedLine ? `0 0 20px ${line.colorHex}, 0 0 40px ${line.colorHex}` : `0 0 8px ${line.colorHex}`
                            }}
                            className={`absolute top-0 bottom-0 transition-all ${
                              isSelectedLine ? 'w-1.5 z-20 brightness-150' : 'w-1 z-10 opacity-80 hover:opacity-100 hover:w-1.5'
                            }`}
                            title={`${line.label} (${line.lambdaNm} nm)`}
                          />
                        );
                      })}
                    </div>
                  ) : (
                    // Absorption Spectrum: Full rainbow background with black vertical absorption lines
                    <div
                      className="w-full h-full relative"
                      style={{
                        background: 'linear-gradient(to right, #6366f1 0%, #3b82f6 15%, #06b6d4 30%, #10b981 50%, #eab308 70%, #f97316 85%, #ef4444 100%)'
                      }}
                    >
                      {hydrogenSeriesTransitions.map((line, idx) => {
                        const isVisible = line.lambdaNm >= 380 && line.lambdaNm <= 750;
                        if (!isVisible) return null;
                        const leftPercent = ((line.lambdaNm - 380) / (750 - 380)) * 100;

                        return (
                          <div
                            key={idx}
                            style={{ left: `${leftPercent}%` }}
                            className="absolute top-0 bottom-0 w-1 bg-black shadow-sm z-10 hover:w-1.5"
                            title={`Absorption Line: ${line.label} (${line.lambdaNm} nm)`}
                          />
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Spectral Axis Labels */}
                <div className="flex justify-between text-[10px] font-mono text-slate-400 px-1">
                  <span>380 nm (UV / Violet)</span>
                  <span>486 nm (H-β)</span>
                  <span>589 nm (Yellow)</span>
                  <span>656 nm (H-α Red)</span>
                  <span>750 nm (Near IR)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          MODE 2: REAL ELEMENT LINE SPECTRA
         ========================================== */}
      {labMode === 'elements' && (
        <div className="space-y-6">
          {/* Element Selection Grid */}
          <div className="p-5 rounded-3xl bg-[#090d16] border border-purple-500/30 shadow-2xl space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between">
              <span className="text-purple-300 font-bold uppercase tracking-wider">
                Select Chemical Element for High-Resolution Emission Spectrum:
              </span>
              <span className="text-slate-400 text-[10px]">
                {Object.keys(ELEMENT_SPECTRA_DATA).length} Authentic Laboratory Datasets
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {Object.entries(ELEMENT_SPECTRA_DATA).map(([key, item]) => {
                const isSelected = activeElementKey === key;
                return (
                  <button
                    key={key}
                    onClick={() => setActiveElementKey(key)}
                    className={`px-3.5 py-2 rounded-2xl border font-bold transition-all flex items-center gap-2 ${
                      isSelected
                        ? 'bg-purple-500 text-white border-purple-400 shadow-lg shadow-purple-500/30 scale-105'
                        : 'bg-white/5 border-white/10 text-slate-300 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.flameHex }} />
                    <span className="text-xs">{item.symbol}</span>
                    <span className="text-[10px] opacity-75 hidden sm:inline">{item.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Element High-Res Spectral Strip & Characteristic Lines Breakdown */}
          <div className="p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-bold text-white font-mono flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-400/40">
                    {activeElementData.symbol} ({activeElementData.number})
                  </span>
                  <span>{activeElementData.name} Characteristic Emission Spectrum</span>
                </h2>
                <p className="text-xs text-slate-400 font-mono mt-0.5">
                  Flame Color Signature: <strong style={{ color: activeElementData.flameHex }}>{activeElementData.flameColor}</strong>
                </p>
              </div>

              {/* Emission vs Absorption Switcher */}
              <div className="flex items-center gap-1 p-1 rounded-xl bg-black/50 border border-white/10 font-mono text-xs">
                <button
                  onClick={() => setSpectrumType('emission')}
                  className={`px-3 py-1 rounded-lg transition-all ${
                    spectrumType === 'emission' ? 'bg-purple-500 text-white font-bold shadow' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Emission
                </button>
                <button
                  onClick={() => setSpectrumType('absorption')}
                  className={`px-3 py-1 rounded-lg transition-all ${
                    spectrumType === 'absorption' ? 'bg-amber-500 text-slate-950 font-bold shadow' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Absorption
                </button>
              </div>
            </div>

            {/* High-Definition Optical Spectrogram Strip */}
            <div className="space-y-2">
              <div className="relative h-28 rounded-2xl overflow-hidden border border-white/20 shadow-2xl">
                {spectrumType === 'emission' ? (
                  <div className="w-full h-full bg-[#030712] relative">
                    {activeElementData.lines.map((line, idx) => {
                      const isVisible = line.lambda >= 380 && line.lambda <= 750;
                      if (!isVisible) return null;

                      const leftPercent = ((line.lambda - 380) / (750 - 380)) * 100;
                      const rgb = nmToRGB(line.lambda);

                      return (
                        <div
                          key={idx}
                          onMouseEnter={() => setHoveredLine(line)}
                          onMouseLeave={() => setHoveredLine(null)}
                          style={{
                            left: `${leftPercent}%`,
                            backgroundColor: rgb.hex,
                            opacity: 0.3 + line.intensity * 0.7,
                            boxShadow: `0 0 ${12 * line.intensity}px ${rgb.hex}`
                          }}
                          className="absolute top-0 bottom-0 w-1.5 hover:w-2.5 transition-all cursor-pointer z-10"
                        />
                      );
                    })}
                  </div>
                ) : (
                  <div
                    className="w-full h-full relative"
                    style={{
                      background: 'linear-gradient(to right, #6366f1 0%, #3b82f6 15%, #06b6d4 30%, #10b981 50%, #eab308 70%, #f97316 85%, #ef4444 100%)'
                    }}
                  >
                    {activeElementData.lines.map((line, idx) => {
                      const isVisible = line.lambda >= 380 && line.lambda <= 750;
                      if (!isVisible) return null;
                      const leftPercent = ((line.lambda - 380) / (750 - 380)) * 100;

                      return (
                        <div
                          key={idx}
                          onMouseEnter={() => setHoveredLine(line)}
                          onMouseLeave={() => setHoveredLine(null)}
                          style={{ left: `${leftPercent}%` }}
                          className="absolute top-0 bottom-0 w-1.5 bg-black hover:w-2.5 transition-all cursor-pointer z-10 shadow"
                        />
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Spectral Scale Axis */}
              <div className="flex justify-between text-[11px] font-mono text-slate-400 px-2">
                <span>380 nm</span>
                <span>450 nm</span>
                <span>500 nm</span>
                <span>550 nm</span>
                <span>600 nm</span>
                <span>650 nm</span>
                <span>700 nm</span>
                <span>750 nm</span>
              </div>
            </div>

            {/* Hover Tooltip Card */}
            {hoveredLine && (
              <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-500/40 text-xs font-mono text-purple-200 flex items-center justify-between animate-fade-in">
                <span>Spectral Line: <strong>{hoveredLine.lambda} nm</strong> ({hoveredLine.label || 'Characteristic Transition'})</span>
                <span>Relative Optical Intensity: {(hoveredLine.intensity * 100).toFixed(0)}%</span>
              </div>
            )}

            {/* Tabular Spectral Lines Database for this element */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">
                Discrete Spectroscopic Transitions Table ({activeElementData.lines.length} Lines):
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {activeElementData.lines.map((l, i) => {
                  const rgb = nmToRGB(l.lambda);
                  const isVisible = l.lambda >= 380 && l.lambda <= 750;

                  return (
                    <div
                      key={i}
                      className="p-3 rounded-2xl bg-white/[0.02] border border-white/5 flex items-center justify-between font-mono text-xs hover:border-white/20 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <div
                          className="w-4 h-4 rounded-full border border-white/20 shadow-sm shrink-0"
                          style={{ backgroundColor: rgb.hex }}
                        />
                        <div>
                          <div className="text-white font-bold text-sm">{l.lambda} nm</div>
                          <div className="text-[10px] text-slate-400 truncate max-w-[130px]">{l.label || (isVisible ? 'Visible' : 'Non-visible')}</div>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-[10px] px-2 py-0.5 rounded bg-white/10 text-cyan-300">
                          {(l.intensity * 100).toFixed(0)}% Int
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          MODE 3: QUALITATIVE FLAME TEST LAB
         ========================================== */}
      {labMode === 'flame-test' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Column: Interactive Bunsen Burner & Wire Loop Simulator */}
            <div className="lg:col-span-6 p-6 rounded-3xl bg-[#080c14] border border-amber-500/30 shadow-2xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
                  <Flame className="w-4 h-4 text-amber-400" />
                  <span>BUNSEN BURNER FLAME TEST SIMULATION</span>
                </h3>
                <div className="flex items-center gap-2 font-mono text-xs">
                  <span className="text-slate-400">Air Collar:</span>
                  <button
                    onClick={() => setFlameAirVent((v) => (v === 'open' ? 'closed' : 'open'))}
                    className={`px-2.5 py-0.5 rounded-lg border font-bold ${
                      flameAirVent === 'open'
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400'
                        : 'bg-amber-500/20 text-amber-300 border-amber-400'
                    }`}
                  >
                    {flameAirVent === 'open' ? 'Roaring Blue (Open)' : 'Luminous Yellow (Closed)'}
                  </button>
                </div>
              </div>

              {/* Flame Canvas */}
              <div className="relative h-80 rounded-2xl bg-black/80 border border-white/10 overflow-hidden flex items-center justify-center">
                <canvas
                  ref={flameCanvasRef}
                  width={420}
                  height={320}
                  className="w-full h-full object-contain"
                />
              </div>

              {/* Primary Interaction Trigger: Dip & Burn Rod */}
              <button
                onClick={() => setIsRodInFlame((f) => !f)}
                className={`w-full py-4 rounded-2xl font-mono text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-xl ${
                  isRodInFlame
                    ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/30'
                    : 'bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 shadow-amber-500/30 active:scale-95'
                }`}
              >
                <Flame className="w-4 h-4" />
                <span>
                  {isRodInFlame
                    ? 'WITHDRAW WIRE LOOP FROM FLAME'
                    : `INTRODUCE ${ELEMENT_SPECTRA_DATA[flameSalt]?.name.toUpperCase()} SAMPLE INTO FLAME`}
                </span>
              </button>
            </div>

            {/* Right Column: Salt Selector & Synchronized Line Spectrum */}
            <div className="lg:col-span-6 space-y-4">
              <div className="p-5 rounded-3xl bg-[#090d16] border border-white/10 shadow-2xl space-y-3 font-mono text-xs">
                <h3 className="text-amber-400 font-bold uppercase tracking-wider">
                  Select Analytical Metal Salt Sample:
                </h3>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {Object.entries(ELEMENT_SPECTRA_DATA).map(([key, item]) => {
                    const isSelected = flameSalt === key;
                    return (
                      <button
                        key={key}
                        onClick={() => {
                          setFlameSalt(key);
                          setIsRodInFlame(true);
                        }}
                        className={`p-3 rounded-2xl border text-left transition-all ${
                          isSelected
                            ? 'bg-amber-500/20 border-amber-400 text-white shadow-md'
                            : 'bg-white/[0.02] border-white/5 text-slate-300 hover:bg-white/[0.05]'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-sm">{item.symbol}Cl</span>
                          <span className="w-3 h-3 rounded-full" style={{ backgroundColor: item.flameHex }} />
                        </div>
                        <div className="text-[11px] font-bold" style={{ color: item.flameHex }}>
                          {item.flameColor}
                        </div>
                        <div className="text-[9px] text-slate-400">{item.name}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Synchronized Emission Spectrum for Active Flame Sample */}
              <div className="p-5 rounded-3xl bg-[#090d16] border border-white/10 shadow-2xl space-y-3 font-mono text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-white font-bold">
                    Synchronized Emission Lines for {ELEMENT_SPECTRA_DATA[flameSalt]?.name}
                  </span>
                  <span className="text-[10px] text-slate-400">Prism / Diffraction Grating View</span>
                </div>

                <div className="h-16 rounded-xl bg-[#030712] border border-white/10 relative overflow-hidden">
                  {ELEMENT_SPECTRA_DATA[flameSalt]?.lines.map((line, idx) => {
                    const isVisible = line.lambda >= 380 && line.lambda <= 750;
                    if (!isVisible) return null;
                    const leftPercent = ((line.lambda - 380) / (750 - 380)) * 100;
                    const rgb = nmToRGB(line.lambda);

                    return (
                      <div
                        key={idx}
                        style={{
                          left: `${leftPercent}%`,
                          backgroundColor: rgb.hex,
                          boxShadow: `0 0 10px ${rgb.hex}`
                        }}
                        className="absolute top-0 bottom-0 w-1.5 opacity-90"
                        title={`${line.lambda} nm`}
                      />
                    );
                  })}
                </div>

                <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
                  The thermal energy of the flame excites outer valence electrons to higher electronic orbitals. Upon rapid de-excitation back to lower energy levels, photons of characteristic discrete wavelengths ($\lambda = hc/\Delta E$) are emitted, giving rise to the diagnostic flame color.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
