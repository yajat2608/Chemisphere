import React, { useState } from 'react';
import { Atom, Zap, Eye, Sparkles, RefreshCw, Layers } from 'lucide-react';
import { VseprGeometry3D, VSEPR_SHAPES } from '../3d/VseprGeometry3D';
import { NavigationTab } from '../../types';

interface VseprLabViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

export const VseprLabView: React.FC<VseprLabViewProps> = ({ onNavigate }) => {
  const [selectedShapeKey, setSelectedShapeKey] = useState<string>('tetrahedral');
  const [showLonePairs, setShowLonePairs] = useState<boolean>(true);
  const [autoRotate, setAutoRotate] = useState<boolean>(true);

  const activeShape = VSEPR_SHAPES[selectedShapeKey] || VSEPR_SHAPES.tetrahedral;

  const shapeCategories = [
    { label: 'SN = 2 (Linear)', keys: ['linear'] },
    { label: 'SN = 3 (Trigonal Planar)', keys: ['trigonal_planar', 'bent_sn3'] },
    { label: 'SN = 4 (Tetrahedral)', keys: ['tetrahedral', 'trigonal_pyramidal', 'bent_sn4'] },
    { label: 'SN = 5 (Trigonal Bipyramidal)', keys: ['trigonal_bipyramidal', 'seesaw', 't_shaped'] },
    { label: 'SN = 6 (Octahedral)', keys: ['octahedral', 'square_planar'] }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 rounded-3xl bg-white/[0.03] border border-white/10 backdrop-blur-xl shadow-xl">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <span>VSEPR Theory & Bonding Lab</span>
            <span className="text-xs px-3 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30 font-mono">
              Valence Shell Electron Pair Repulsion
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1 font-light">
            Analyze 3D electron domain geometry, lone-pair orbital repulsion forces, and orbital hybridization states.
          </p>
        </div>

        {/* Repulsion Hierarchy Pill */}
        <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 text-[11px] font-mono text-slate-300 backdrop-blur-md">
          <span className="text-amber-400 font-bold">Repulsion:</span>
          <span>LP—LP &gt; LP—BP &gt; BP—BP</span>
        </div>
      </div>

      {/* 3D Geometry Canvas & Shape Selection */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 3D Visualizer */}
        <div className="lg:col-span-2 rounded-3xl bg-white/[0.03] border border-white/10 p-6 flex flex-col justify-between backdrop-blur-2xl relative shadow-2xl">
          <div className="flex items-center justify-between z-10">
            <div className="flex items-center gap-2">
              <span className="text-base font-bold text-white font-mono">{activeShape.name}</span>
              <span className="text-xs px-3 py-0.5 rounded-full bg-white/10 text-cyan-300 font-mono border border-white/10">
                Hybrid: {activeShape.hybridization}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setAutoRotate(!autoRotate)}
                className={`p-2 rounded-full text-xs font-mono border transition-all ${
                  autoRotate ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' : 'bg-white/5 text-slate-400 border-white/10 hover:bg-white/10'
                }`}
                title="Toggle Auto-Rotation"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${autoRotate ? 'animate-spin-slow' : ''}`} />
              </button>

              <button
                onClick={() => setShowLonePairs(!showLonePairs)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-mono border transition-all ${
                  showLonePairs ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' : 'bg-white/5 text-slate-400 border-white/10 hover:bg-white/10'
                }`}
              >
                {showLonePairs ? 'Hide Lone Pairs' : 'Show Lone Pairs'}
              </button>
            </div>
          </div>

          {/* 3D Viewport */}
          <div className="w-full h-[440px] my-2">
            <VseprGeometry3D
              shapeKey={selectedShapeKey}
              showLonePairs={showLonePairs}
              autoRotate={autoRotate}
            />
          </div>

          {/* Legend */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-2xl bg-white/5 border border-white/10 text-xs font-mono z-10 backdrop-blur-md">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5 text-purple-400">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-500 shadow-[0_0_8px_rgba(168,85,247,0.8)]" /> Central Atom (A)
              </span>
              <span className="flex items-center gap-1.5 text-cyan-400">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,197,254,0.8)]" /> Bonding Ligands (X)
              </span>
              <span className="flex items-center gap-1.5 text-amber-400">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.8)]" /> Lone Pair Balloon (E)
              </span>
            </div>
            <div className="text-slate-300">
              Bond Angle: <span className="text-white font-bold">{activeShape.bondAngle}</span>
            </div>
          </div>
        </div>

        {/* VSEPR Geometry Directory */}
        <div className="space-y-4">
          <div className="p-6 rounded-3xl bg-white/[0.03] border border-white/10 backdrop-blur-xl space-y-4">
            <h3 className="text-xs font-mono text-slate-400 uppercase tracking-wider font-semibold">
              VSEPR Geometry Hierarchy
            </h3>

            <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
              {shapeCategories.map((cat) => (
                <div key={cat.label} className="space-y-1.5">
                  <div className="text-[11px] font-mono text-slate-400 font-semibold">{cat.label}</div>
                  <div className="grid grid-cols-1 gap-1.5">
                    {cat.keys.map((key) => {
                      const sh = VSEPR_SHAPES[key];
                      if (!sh) return null;
                      const isSelected = selectedShapeKey === key;
                      return (
                        <button
                          key={key}
                          onClick={() => setSelectedShapeKey(key)}
                          className={`p-3 rounded-2xl border text-left transition-all font-mono text-xs flex items-center justify-between ${
                            isSelected
                              ? 'bg-white/15 border-white/30 text-white shadow-md'
                              : 'bg-white/5 border-white/10 text-slate-400 hover:border-white/20 hover:text-white'
                          }`}
                        >
                          <div>
                            <span className="font-bold text-white block">{sh.name}</span>
                            <span className="text-[10px] text-slate-400">Angle: {sh.bondAngle}</span>
                          </div>
                          <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-white/10 text-cyan-300 border border-white/10">
                            {sh.bondingPairs} BP / {sh.lonePairs} LP
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* VSEPR Structural Metrics Card */}
          <div className="p-6 rounded-3xl bg-white/[0.03] border border-white/10 backdrop-blur-xl space-y-4">
            <h3 className="text-xs font-mono text-amber-400 uppercase tracking-wider font-bold">
              Orbital & Structural Breakdown
            </h3>

            <div className="grid grid-cols-2 gap-2.5 font-mono text-xs">
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="text-[10px] text-slate-400">STERIC NUMBER (SN)</div>
                <div className="text-base font-bold text-white mt-0.5">{activeShape.stericNumber}</div>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="text-[10px] text-slate-400">HYBRIDIZATION</div>
                <div className="text-base font-bold text-cyan-300 mt-0.5">{activeShape.hybridization}</div>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="text-[10px] text-slate-400">ELECTRON GEOMETRY</div>
                <div className="text-xs font-bold text-slate-200 mt-0.5 truncate">{activeShape.electronGeometry}</div>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="text-[10px] text-slate-400">MOLECULAR GEOMETRY</div>
                <div className="text-xs font-bold text-amber-300 mt-0.5 truncate">{activeShape.molecularGeometry}</div>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-xs font-mono backdrop-blur-md">
              <span className="text-slate-400">Classic Examples: </span>
              <span className="text-white font-bold">{activeShape.example}</span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed font-light pt-1">
              {activeShape.description}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
