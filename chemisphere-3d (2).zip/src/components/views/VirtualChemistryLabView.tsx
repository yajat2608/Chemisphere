import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  FlaskConical,
  Sparkles,
  RotateCcw,
  Plus,
  Thermometer,
  Zap,
  Activity,
  Droplets,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  Info,
  Flame,
  Layers,
  Atom,
  HelpCircle,
  Volume2,
  Lock,
  Boxes
} from 'lucide-react';
import { NavigationTab } from '../../types';
import { userPassportStore } from '../../data/UserPassportStore';
import { ChemistryPuzzlesModal } from '../playgrounds/ChemistryPuzzlesModal';

interface Reagent {
  id: string;
  name: string;
  formula: string;
  type: 'acid' | 'base' | 'salt' | 'metal' | 'indicator' | 'oxidizer';
  color: string;
  liquidColor: string;
  state: 'liquid' | 'solid' | 'indicator';
  ph: number;
  hazard: string;
}

const REAGENTS_LIST: Reagent[] = [
  { id: 'hcl', name: 'Hydrochloric Acid (1.0 M)', formula: 'HCl', type: 'acid', color: '#ef4444', liquidColor: 'rgba(255, 255, 255, 0.15)', state: 'liquid', ph: 1.0, hazard: 'Corrosive / Irritant' },
  { id: 'naoh', name: 'Sodium Hydroxide (1.0 M)', formula: 'NaOH', type: 'base', color: '#3b82f6', liquidColor: 'rgba(255, 255, 255, 0.15)', state: 'liquid', ph: 13.5, hazard: 'Corrosive Base' },
  { id: 'cuso4', name: 'Copper(II) Sulfate (0.5 M)', formula: 'CuSO₄', type: 'salt', color: '#06b6d4', liquidColor: 'rgba(6, 182, 212, 0.65)', state: 'liquid', ph: 4.5, hazard: 'Aquatic Toxin' },
  { id: 'nh3', name: 'Aqueous Ammonia (1.0 M)', formula: 'NH₃ (aq)', type: 'base', color: '#8b5cf6', liquidColor: 'rgba(255, 255, 255, 0.15)', state: 'liquid', ph: 11.2, hazard: 'Pungent / Irritant' },
  { id: 'pbno32', name: 'Lead(II) Nitrate (0.2 M)', formula: 'Pb(NO₃)₂', type: 'salt', color: '#f59e0b', liquidColor: 'rgba(255, 255, 255, 0.15)', state: 'liquid', ph: 5.0, hazard: 'Toxic Heavy Metal' },
  { id: 'ki', name: 'Potassium Iodide (0.5 M)', formula: 'KI', type: 'salt', color: '#eab308', liquidColor: 'rgba(255, 255, 255, 0.15)', state: 'liquid', ph: 7.0, hazard: 'Low Hazard' },
  { id: 'fecl3', name: 'Iron(III) Chloride (0.2 M)', formula: 'FeCl₃', type: 'salt', color: '#d97706', liquidColor: 'rgba(217, 119, 6, 0.55)', state: 'liquid', ph: 2.2, hazard: 'Corrosive / Stains' },
  { id: 'kscn', name: 'Potassium Thiocyanate (0.2 M)', formula: 'KSCN', type: 'salt', color: '#ec4899', liquidColor: 'rgba(255, 255, 255, 0.15)', state: 'liquid', ph: 6.8, hazard: 'Harmful if swallowed' },
  { id: 'na2co3', name: 'Sodium Carbonate (0.5 M)', formula: 'Na₂CO₃', type: 'base', color: '#10b981', liquidColor: 'rgba(255, 255, 255, 0.15)', state: 'liquid', ph: 11.5, hazard: 'Mild Irritant' },
  { id: 'agno3', name: 'Silver Nitrate (0.1 M)', formula: 'AgNO₃', type: 'salt', color: '#64748b', liquidColor: 'rgba(255, 255, 255, 0.15)', state: 'liquid', ph: 5.5, hazard: 'Oxidizer / Stains skin' },
  { id: 'zn_metal', name: 'Zinc Granules (Solid)', formula: 'Zn (s)', type: 'metal', color: '#94a3b8', liquidColor: 'rgba(148, 163, 184, 0.4)', state: 'solid', ph: 7.0, hazard: 'Flammable powder' },
  { id: 'h2o2', name: 'Hydrogen Peroxide (6% conc)', formula: 'H₂O₂', type: 'oxidizer', color: '#38bdf8', liquidColor: 'rgba(255, 255, 255, 0.15)', state: 'liquid', ph: 6.0, hazard: 'Oxidizing Bleach' },
  { id: 'phenolphthalein', name: 'Phenolphthalein Indicator', formula: 'C₂₀H₁₄O₄', type: 'indicator', color: '#f43f5e', liquidColor: 'rgba(244, 63, 94, 0.4)', state: 'indicator', ph: 7.0, hazard: 'Flammable solvent' },
  { id: 'universal_ind', name: 'Universal pH Indicator', formula: 'Univ. Ind.', type: 'indicator', color: '#84cc16', liquidColor: 'rgba(132, 204, 22, 0.5)', state: 'indicator', ph: 7.0, hazard: 'Low Hazard' }
];

interface PresetExperiment {
  id: string;
  name: string;
  tag: string;
  reactants: string[];
  description: string;
}

const PRESET_EXPERIMENTS: PresetExperiment[] = [
  {
    id: 'golden_rain',
    name: 'Golden Rain (Lead Iodide Precipitation)',
    tag: 'Precipitation',
    reactants: ['pbno32', 'ki'],
    description: 'Mixing colorless Lead(II) nitrate and Potassium iodide yields a brilliant glistening yellow precipitate of Lead(II) iodide (PbI₂).'
  },
  {
    id: 'blood_red_iron',
    name: 'Blood-Red Thiocyanatoiron(III) Complex',
    tag: 'Complexation',
    reactants: ['fecl3', 'kscn'],
    description: 'Iron(III) reacts with thiocyanate to form the intensely deep blood-red pentaaquathiocyanatoiron(III) coordination ion [Fe(H₂O)₅(SCN)]²⁺.'
  },
  {
    id: 'elephant_toothpaste',
    name: 'Catalytic Peroxide Decomposition',
    tag: 'Exothermic Redox & Gas',
    reactants: ['h2o2', 'ki'],
    description: 'Iodide ions catalytically decompose hydrogen peroxide into hot steam and vigorous oxygen gas effervescence.'
  },
  {
    id: 'acid_base_phenolphthalein',
    name: 'Acid-Base Titration & Phenolphthalein',
    tag: 'Neutralization',
    reactants: ['hcl', 'naoh', 'phenolphthalein'],
    description: 'Neutralize strong acid HCl with NaOH. When alkaline pH exceeds 8.2, phenolphthalein turns brilliant magenta-fuchsia.'
  },
  {
    id: 'copper_ammonia',
    name: 'Deep Royal Blue Tetraamminecopper(II)',
    tag: 'Coordination Chemistry',
    reactants: ['cuso4', 'nh3'],
    description: 'Adding aqueous ammonia to light blue CuSO₄ first forms a pale blue precipitate, then dissolves into a spectacular deep royal blue [Cu(NH₃)₄]²⁺ complex.'
  },
  {
    id: 'carbonate_fizz',
    name: 'Effervescent Carbon Dioxide Evolution',
    tag: 'Gas Evolution',
    reactants: ['na2co3', 'hcl'],
    description: 'Sodium carbonate reacts with hydrochloric acid with brisk fizzing, evolving copious gaseous Carbon Dioxide (CO₂ ↑).'
  },
  {
    id: 'single_displacement',
    name: 'Zinc Displacement of Copper Ions',
    tag: 'Redox Displacement',
    reactants: ['cuso4', 'zn_metal'],
    description: 'Active metallic zinc reduces blue Cu²⁺ ions into reddish metallic copper precipitate, decoloring the solution into colorless ZnSO₄.'
  }
];

interface VirtualChemistryLabViewProps {
  onNavigate: (tab: NavigationTab) => void;
}

export const VirtualChemistryLabView: React.FC<VirtualChemistryLabViewProps> = ({ onNavigate }) => {
  const [beakerContents, setBeakerContents] = useState<string[]>([]);
  const [temperature, setTemperature] = useState(25.0); // °C
  const [bunsenHeatActive, setBunsenHeatActive] = useState(false);
  const [stirrerSpeed, setStirrerSpeed] = useState<'off' | 'slow' | 'fast'>('off');
  const [currentPh, setCurrentPh] = useState(7.0);
  const [liquidColor, setLiquidColor] = useState('rgba(255, 255, 255, 0.1)');
  const [hasPrecipitate, setHasPrecipitate] = useState<string | null>(null);
  const [isBubbling, setIsBubbling] = useState(false);
  const [bubblingGas, setBubblingGas] = useState<string | null>(null);
  const [conductivity, setConductivity] = useState<'Zero' | 'Weak' | 'Strong'>('Zero');
  const [reactionTitle, setReactionTitle] = useState<string | null>(null);
  const [balancedEquation, setBalancedEquation] = useState<string | null>(null);
  const [reactionType, setReactionType] = useState<string | null>(null);
  const [enthalpyNote, setEnthalpyNote] = useState<string | null>(null);

  const [isPuzzlesOpen, setIsPuzzlesOpen] = useState(false);

  // Dynamic Bunsen Burner heating effect
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (bunsenHeatActive) {
      interval = setInterval(() => {
        setTemperature(prev => Math.min(100.0, +(prev + 1.5).toFixed(1)));
      }, 500);
    } else {
      interval = setInterval(() => {
        setTemperature(prev => (prev > 25.0 ? +(prev - 0.5).toFixed(1) : 25.0));
      }, 800);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [bunsenHeatActive]);

  // Compute reaction state whenever beakerContents change
  useEffect(() => {
    const items = new Set(beakerContents);

    if (items.size === 0) {
      setTemperature(25.0);
      setCurrentPh(7.0);
      setLiquidColor('rgba(255, 255, 255, 0.1)');
      setHasPrecipitate(null);
      setIsBubbling(false);
      setBubblingGas(null);
      setConductivity('Zero');
      setReactionTitle(null);
      setBalancedEquation(null);
      setReactionType(null);
      setEnthalpyNote(null);
      return;
    }

    // Default base metrics
    let computedTemp = 25.0;
    let computedPh = 7.0;
    let computedColor = 'rgba(255, 255, 255, 0.2)';
    let precip: string | null = null;
    let gas: string | null = null;
    let title: string | null = null;
    let eq: string | null = null;
    let type: string | null = null;
    let enthalpy: string | null = null;
    let cond: 'Zero' | 'Weak' | 'Strong' = 'Weak';

    // Check Golden Rain (Pb2+ + 2I-)
    if (items.has('pbno32') && items.has('ki')) {
      title = 'Golden Rain Reaction';
      eq = 'Pb(NO₃)₂ (aq) + 2 KI (aq) → PbI₂ (s) ↓ + 2 KNO₃ (aq)';
      type = 'Double Displacement / Precipitation';
      precip = 'Golden Yellow Lead(II) Iodide (PbI₂)';
      computedColor = 'rgba(234, 179, 8, 0.7)';
      computedTemp = 26.5;
      computedPh = 6.2;
      enthalpy = 'Exothermic (ΔH° = -62.4 kJ/mol)';
      cond = 'Strong';
    }
    // Check Blood Red Iron thiocyanate
    else if (items.has('fecl3') && items.has('kscn')) {
      title = 'Iron(III) Thiocyanate Complexation';
      eq = 'Fe³⁺ (aq) + SCN⁻ (aq) ⇌ [Fe(SCN)]²⁺ (aq) (Blood Red)';
      type = 'Coordination Complexation Equilibrium';
      computedColor = 'rgba(185, 28, 28, 0.85)';
      computedTemp = 25.8;
      computedPh = 2.5;
      enthalpy = 'Mild Exothermic (ΔH° = -24.2 kJ/mol)';
      cond = 'Strong';
    }
    // Check Elephant Toothpaste (H2O2 + KI)
    else if (items.has('h2o2') && items.has('ki')) {
      title = 'Catalytic Decomposition of Hydrogen Peroxide';
      eq = '2 H₂O₂ (aq) —[KI catalyst]→ 2 H₂O (l) + O₂ (g) ↑';
      type = 'Catalytic Redox Decomposition';
      gas = 'Oxygen Gas (O₂ ↑) + Steam';
      computedColor = 'rgba(217, 119, 6, 0.6)';
      computedTemp = 68.4;
      computedPh = 6.5;
      enthalpy = 'Vigorously Exothermic (ΔH° = -196 kJ/mol)';
      cond = 'Weak';
    }
    // Check Carbonate Fizz (Na2CO3 + HCl)
    else if (items.has('na2co3') && items.has('hcl')) {
      title = 'Acid-Carbonate Gas Evolution';
      eq = 'Na₂CO₃ (aq) + 2 HCl (aq) → 2 NaCl (aq) + H₂O (l) + CO₂ (g) ↑';
      type = 'Acid-Base & Gas Evolution';
      gas = 'Carbon Dioxide (CO₂ ↑)';
      computedColor = 'rgba(255, 255, 255, 0.2)';
      computedTemp = 28.2;
      computedPh = 3.5;
      enthalpy = 'Mild Exothermic (ΔH° = -31.4 kJ/mol)';
      cond = 'Strong';
    }
    // Check Copper Ammonia Complex
    else if (items.has('cuso4') && items.has('nh3')) {
      title = 'Tetraamminecopper(II) Complexation';
      eq = 'CuSO₄ (aq) + 4 NH₃ (aq) → [Cu(NH₃)₄]SO₄ (aq) (Deep Royal Blue)';
      type = 'Coordination Complex Ion';
      computedColor = 'rgba(30, 58, 138, 0.9)';
      computedTemp = 27.0;
      computedPh = 10.5;
      enthalpy = 'Exothermic (ΔH° = -88.0 kJ/mol)';
      cond = 'Strong';
    }
    // Check Single Displacement (CuSO4 + Zn)
    else if (items.has('cuso4') && items.has('zn_metal')) {
      title = 'Zinc-Copper Redox Displacement';
      eq = 'CuSO₄ (aq) + Zn (s) → ZnSO₄ (aq) + Cu (s) ↓';
      type = 'Single Displacement Redox';
      precip = 'Reddish-Brown Metallic Copper (Cu)';
      computedColor = 'rgba(200, 200, 200, 0.3)';
      computedTemp = 42.5;
      computedPh = 5.8;
      enthalpy = 'Exothermic (ΔH° = -218 kJ/mol)';
      cond = 'Strong';
    }
    // Check Neutralization HCl + NaOH
    else if (items.has('hcl') && items.has('naoh')) {
      title = 'Strong Acid - Strong Base Neutralization';
      eq = 'HCl (aq) + NaOH (aq) → NaCl (aq) + H₂O (l)';
      type = 'Neutralization';
      computedTemp = 36.8;
      computedPh = 7.0;
      enthalpy = 'Exothermic Neutralization (ΔH° = -57.1 kJ/mol)';
      cond = 'Strong';

      if (items.has('phenolphthalein')) {
        computedColor = 'rgba(244, 63, 94, 0.75)'; // Pink indicator
      } else if (items.has('universal_ind')) {
        computedColor = 'rgba(34, 197, 94, 0.7)'; // Green pH 7
      }
    }
    // Single species handling
    else {
      cond = 'Strong';
      if (items.has('hcl')) {
        computedPh = 1.0;
        if (items.has('universal_ind')) computedColor = 'rgba(239, 68, 68, 0.7)';
      } else if (items.has('naoh')) {
        computedPh = 13.5;
        if (items.has('phenolphthalein')) computedColor = 'rgba(244, 63, 94, 0.8)';
        if (items.has('universal_ind')) computedColor = 'rgba(99, 102, 241, 0.8)';
      } else if (items.has('cuso4')) {
        computedColor = 'rgba(6, 182, 212, 0.65)';
        computedPh = 4.5;
      } else if (items.has('fecl3')) {
        computedColor = 'rgba(217, 119, 6, 0.6)';
        computedPh = 2.2;
      }
    }

    setTemperature(computedTemp);
    setCurrentPh(computedPh);
    setLiquidColor(computedColor);
    setHasPrecipitate(precip);
    setIsBubbling(!!gas);
    setBubblingGas(gas);
    setConductivity(cond);
    setReactionTitle(title);
    setBalancedEquation(eq);
    setReactionType(type);
    setEnthalpyNote(enthalpy);

    if (title) {
      userPassportStore.recordExperimentConducted(title);
    }
  }, [beakerContents]);

  const handleAddReagent = (reagentId: string) => {
    if (!beakerContents.includes(reagentId)) {
      setBeakerContents((prev) => [...prev, reagentId]);
    }
  };

  const handleLoadPreset = (preset: PresetExperiment) => {
    setBeakerContents(preset.reactants);
  };

  const handleClearBeaker = () => {
    setBeakerContents([]);
    setBunsenHeatActive(false);
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-emerald-950/30 via-slate-900 to-cyan-950/30 border border-emerald-500/30 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-mono font-bold">
            <FlaskConical className="w-4 h-4 text-emerald-400" />
            <span>VIRTUAL CHEMICAL LAB & REACTION SANDBOX</span>
          </div>
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight">
            Interactive Reaction Bench & Glassware Simulator
          </h1>
          <p className="text-sm text-slate-300 font-sans max-w-2xl">
            Mix real acids, bases, transition metal salts, and indicators. Observe color transformations, precipitates, gas evolution, and thermal enthalpy in real-time.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2.5 shrink-0 font-mono">
          <button
            onClick={() => setIsPuzzlesOpen(true)}
            className="px-4 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-amber-500/20 transition-all"
          >
            <Boxes className="w-4 h-4" />
            <span>Lab Puzzles & Escape Room</span>
          </button>
          <button
            onClick={handleClearBeaker}
            className="px-4 py-2.5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-slate-300 hover:text-white flex items-center gap-2 transition-colors"
          >
            <RotateCcw className="w-4 h-4 text-cyan-400" />
            <span>Clean Glassware</span>
          </button>
        </div>
      </div>

      {/* Main Bench: 2 Cols (Reagents Shelf + Interactive Beaker Vessel) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 font-mono">
        {/* Left Col: Reagents Shelf (5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Preset Famous Experiments */}
          <div className="p-5 rounded-3xl bg-white/[0.02] border border-cyan-500/20 backdrop-blur-md space-y-3">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>Preset Famous Reactions</span>
            </h3>
            <div className="grid grid-cols-1 gap-2 max-h-[220px] overflow-y-auto pr-1">
              {PRESET_EXPERIMENTS.map((p) => (
                <div
                  key={p.id}
                  onClick={() => handleLoadPreset(p)}
                  className="p-3 rounded-2xl bg-white/5 hover:bg-cyan-500/10 border border-white/5 hover:border-cyan-400/40 cursor-pointer transition-all flex items-start justify-between gap-2 text-xs"
                >
                  <div>
                    <div className="font-bold text-white flex items-center gap-2">
                      <span>{p.name}</span>
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                        {p.tag}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 font-sans mt-0.5 line-clamp-1">
                      {p.description}
                    </p>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-1" />
                </div>
              ))}
            </div>
          </div>

          {/* Chemical Reagents Shelf */}
          <div className="p-5 rounded-3xl bg-white/[0.02] border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Layers className="w-4 h-4 text-emerald-400" />
                <span>Chemical Reagents Shelf</span>
              </h3>
              <span className="text-[11px] text-slate-400">Click to add to beaker</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-[360px] overflow-y-auto pr-1">
              {REAGENTS_LIST.map((reagent) => {
                const isInBeaker = beakerContents.includes(reagent.id);
                return (
                  <button
                    key={reagent.id}
                    onClick={() => handleAddReagent(reagent.id)}
                    className={`p-3 rounded-2xl border text-left transition-all flex items-center justify-between gap-2 ${
                      isInBeaker
                        ? 'bg-emerald-500/20 border-emerald-400 text-white font-bold'
                        : 'bg-white/5 border-white/5 text-slate-300 hover:text-white hover:bg-white/10 hover:border-white/20'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-bold truncate flex items-center gap-1.5">
                        <span
                          className="w-2.5 h-2.5 rounded-full shrink-0"
                          style={{ backgroundColor: reagent.color }}
                        />
                        <span className="truncate">{reagent.formula}</span>
                      </div>
                      <div className="text-[10px] text-slate-400 truncate mt-0.5">
                        {reagent.name.split('(')[0]}
                      </div>
                    </div>
                    {isInBeaker ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <Plus className="w-4 h-4 text-slate-400 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Col: Interactive Beaker Vessel & Live Reaction Analytics (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Reaction Vessel Card */}
          <div className="p-6 sm:p-8 rounded-3xl bg-[#080d19] border border-cyan-500/30 shadow-2xl space-y-6">
            {/* Header Telemetry */}
            <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-white/10 text-xs">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-emerald-400 font-bold">REACTION VESSEL READY</span>
              </div>
              <div className="flex items-center gap-3 text-slate-400">
                <span>Volume: <strong className="text-white">{beakerContents.length * 25} mL</strong></span>
                <span>Species: <strong className="text-cyan-300">{beakerContents.length}</strong></span>
              </div>
            </div>

            {/* Visual Glassware Beaker Simulation */}
            <div className="relative w-full h-64 bg-slate-950/80 rounded-3xl border border-white/10 flex flex-col items-center justify-center p-6 overflow-hidden">
              {/* Glass Beaker Container Outline */}
              <div className="relative w-48 h-48 border-2 border-white/40 border-t-0 rounded-b-3xl overflow-hidden bg-white/[0.02] shadow-inner flex flex-col justify-end">
                {/* Measurement Markings */}
                <div className="absolute left-2 top-4 bottom-4 w-4 flex flex-col justify-between text-[8px] text-white/40 select-none pointer-events-none">
                  <span>- 100mL</span>
                  <span>- 75mL</span>
                  <span>- 50mL</span>
                  <span>- 25mL</span>
                </div>

                {/* Beaker Liquid Fill */}
                <motion.div
                  className="w-full relative transition-all duration-700"
                  style={{
                    height: `${Math.min(90, Math.max(15, beakerContents.length * 22))}%`,
                    backgroundColor: liquidColor
                  }}
                >
                  {/* Surface Liquid Wave Meniscus */}
                  <div className="absolute top-0 left-0 right-0 h-2 bg-white/20 blur-[1px]" />

                  {/* Gas Bubbles Animation */}
                  {(isBubbling || bunsenHeatActive) && (
                    <div className="absolute inset-0 overflow-hidden pointer-events-none">
                      <div className="w-2 h-2 rounded-full bg-white/70 absolute bottom-2 left-1/4 animate-bounce" />
                      <div className="w-3 h-3 rounded-full bg-white/80 absolute bottom-4 left-1/2 animate-ping" />
                      <div className="w-2 h-2 rounded-full bg-white/60 absolute bottom-1 right-1/3 animate-pulse" />
                    </div>
                  )}

                  {/* Magnetic Stirrer Bar */}
                  {stirrerSpeed !== 'off' && (
                    <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-8 h-2 bg-white rounded-full shadow-md animate-spin" />
                  )}

                  {/* Precipitate Settling at Bottom */}
                  {hasPrecipitate && (
                    <div
                      className="absolute bottom-0 left-0 right-0 h-4 rounded-b-2xl border-t border-white/20"
                      style={{
                        backgroundColor: hasPrecipitate.includes('Yellow')
                          ? '#eab308'
                          : hasPrecipitate.includes('Copper')
                          ? '#b45309'
                          : '#ffffff'
                      }}
                      title={hasPrecipitate}
                    />
                  )}
                </motion.div>
              </div>

              {/* Bunsen Burner Flame under beaker */}
              {bunsenHeatActive && (
                <div className="flex flex-col items-center mt-1 animate-pulse">
                  <div className="w-4 h-6 bg-gradient-to-t from-orange-500 via-amber-400 to-cyan-300 rounded-full blur-[1px]" />
                  <div className="w-12 h-1 bg-slate-600 rounded" />
                </div>
              )}

              {/* Status Overlay Badges */}
              {isBubbling && bubblingGas && (
                <div className="absolute top-4 right-4 px-3 py-1.5 rounded-xl bg-cyan-500/20 border border-cyan-400 text-cyan-200 text-xs flex items-center gap-1.5 animate-bounce">
                  <Droplets className="w-4 h-4 text-cyan-400" />
                  <span>Effervescence: {bubblingGas}</span>
                </div>
              )}

              {hasPrecipitate && (
                <div className="absolute bottom-4 left-4 px-3 py-1.5 rounded-xl bg-amber-500/20 border border-amber-400 text-amber-200 text-xs flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>Precipitate: {hasPrecipitate}</span>
                </div>
              )}
            </div>

            {/* Interactive Lab Bench Controls (Bunsen Burner & Stirrer) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 rounded-2xl bg-white/[0.02] border border-white/10">
              <button
                onClick={() => setBunsenHeatActive(prev => !prev)}
                className={`p-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                  bunsenHeatActive
                    ? 'bg-orange-500/20 border-orange-400 text-orange-200 shadow-md shadow-orange-500/20'
                    : 'bg-white/5 border-white/10 text-slate-300 hover:text-white'
                }`}
              >
                <Flame className={`w-4 h-4 ${bunsenHeatActive ? 'text-orange-400 animate-bounce' : 'text-slate-400'}`} />
                <span>{bunsenHeatActive ? 'Extinguish Bunsen Burner' : 'Ignite Bunsen Burner (Heat)'}</span>
              </button>

              <button
                onClick={() => setStirrerSpeed(prev => prev === 'off' ? 'slow' : prev === 'slow' ? 'fast' : 'off')}
                className={`p-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                  stirrerSpeed !== 'off'
                    ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200 shadow-md shadow-cyan-500/20'
                    : 'bg-white/5 border-white/10 text-slate-300 hover:text-white'
                }`}
              >
                <RotateCcw className={`w-4 h-4 ${stirrerSpeed !== 'off' ? 'text-cyan-400 animate-spin' : 'text-slate-400'}`} />
                <span>Magnetic Stirrer: {stirrerSpeed.toUpperCase()}</span>
              </button>
            </div>

            {/* Probe Measurements: Temperature, pH, Conductivity */}
            <div className="grid grid-cols-3 gap-3 text-center">
              {/* Thermometer Probe */}
              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                <div className="text-[10px] text-slate-400 flex items-center justify-center gap-1">
                  <Thermometer className="w-3.5 h-3.5 text-orange-400" />
                  <span>Temperature</span>
                </div>
                <div className={`text-base font-extrabold ${temperature > 30 ? 'text-orange-400' : 'text-cyan-300'}`}>
                  {temperature.toFixed(1)} °C
                </div>
              </div>

              {/* pH Probe */}
              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                <div className="text-[10px] text-slate-400 flex items-center justify-center gap-1">
                  <Activity className="w-3.5 h-3.5 text-purple-400" />
                  <span>pH Probe</span>
                </div>
                <div className={`text-base font-extrabold ${currentPh < 7 ? 'text-red-400' : currentPh > 7 ? 'text-blue-400' : 'text-emerald-400'}`}>
                  pH {currentPh.toFixed(1)} ({currentPh < 6.5 ? 'Acidic' : currentPh > 7.5 ? 'Basic' : 'Neutral'})
                </div>
              </div>

              {/* Conductivity Probe */}
              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                <div className="text-[10px] text-slate-400 flex items-center justify-center gap-1">
                  <Zap className="w-3.5 h-3.5 text-yellow-400" />
                  <span>Conductivity</span>
                </div>
                <div className="text-base font-extrabold text-yellow-300">
                  {conductivity} Electrolyte
                </div>
              </div>
            </div>

            {/* Live Reaction Thermodynamics & Equation Panel */}
            {reactionTitle && (
              <div className="p-5 rounded-2xl bg-slate-950 border border-cyan-500/40 space-y-3 animate-in fade-in">
                <div className="flex items-center justify-between text-xs text-cyan-300 font-bold">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Active Transformation: {reactionTitle}</span>
                  </span>
                  {reactionType && (
                    <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/20 border border-cyan-500/30">
                      {reactionType}
                    </span>
                  )}
                </div>

                {balancedEquation && (
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-white font-bold text-center text-xs tracking-wide">
                    {balancedEquation}
                  </div>
                )}

                {enthalpyNote && (
                  <div className="text-xs text-slate-300 font-sans flex items-center gap-2">
                    <Flame className="w-4 h-4 text-orange-400 shrink-0" />
                    <span>Enthalpy: <strong className="text-orange-300 font-mono">{enthalpyNote}</strong></span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Puzzles Modal Component */}
      <ChemistryPuzzlesModal
        isOpen={isPuzzlesOpen}
        onClose={() => setIsPuzzlesOpen(false)}
        initialPuzzle="molecular"
        onNavigateToTab={onNavigate}
      />
    </div>
  );
};
