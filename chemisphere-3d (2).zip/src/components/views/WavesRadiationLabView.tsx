import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Waves,
  Zap,
  Activity,
  Sparkles,
  Sliders,
  Play,
  Pause,
  RotateCcw,
  Radio,
  Eye,
  Info,
  Layers,
  ChevronRight,
  Compass,
  Volume2,
  Atom
} from 'lucide-react';
import { NavigationTab } from '../../types';

interface WavesRadiationLabViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

export type WaveSimulationMode =
  | 'traveling'
  | 'standing'
  | 'transverse'
  | 'longitudinal'
  | 'interference'
  | 'diffraction'
  | 'em-wave-3d';

export interface EMSpectrumRegion {
  id: string;
  name: string;
  wavelengthRange: string;
  frequencyRange: string;
  photonEnergyRange: string;
  colorHex: string;
  chemistryRelevance: string;
  spectroscopyTechnique: string;
  practicalApplications: string[];
  sampleTransitions: string;
}

export const EM_REGIONS: EMSpectrumRegion[] = [
  {
    id: 'gamma',
    name: 'Gamma Rays',
    wavelengthRange: '< 0.01 nm (< 10 pm)',
    frequencyRange: '> 30 EHz (> 3×10¹⁹ Hz)',
    photonEnergyRange: '> 124 keV',
    colorHex: '#a855f7',
    chemistryRelevance: 'Nuclear Transitions & Radiolytic Bond Cleavage',
    spectroscopyTechnique: 'Mössbauer Spectroscopy & Gamma-Ray Spectroscopy',
    practicalApplications: ['Radiation cancer therapy', 'Sterilization of medical instruments', 'Nuclear density logging'],
    sampleTransitions: 'Nuclear isomeric transitions (e.g. ⁵⁷Fe excited state de-excitation at 14.4 keV)'
  },
  {
    id: 'xray',
    name: 'X-Rays',
    wavelengthRange: '0.01 nm – 10 nm',
    frequencyRange: '30 PHz – 30 EHz',
    photonEnergyRange: '124 eV – 124 keV',
    colorHex: '#3b82f6',
    chemistryRelevance: 'Core-Level Electron Ejection & Crystal Lattice Diffraction',
    spectroscopyTechnique: 'X-ray Crystallography (XRD) & X-ray Photoelectron Spectroscopy (XPS/ESCA)',
    practicalApplications: ['3D Protein / Small Molecule structure determination', 'Material elemental composition analysis', 'Medical radiography'],
    sampleTransitions: 'Inner core shell ionization (K-shell 1s, L-shell 2s/2p ejection); Bragg diffraction nλ = 2d · sin(θ)'
  },
  {
    id: 'uv',
    name: 'Ultraviolet (UV)',
    wavelengthRange: '10 nm – 380 nm',
    frequencyRange: '789 THz – 30 PHz',
    photonEnergyRange: '3.26 eV – 124 eV',
    colorHex: '#8b5cf6',
    chemistryRelevance: 'Valence Electronic Transitions & Photochemical Reactions',
    spectroscopyTechnique: 'UV-Visible Spectrophotometry (UV-Vis) & Photoelectron Spectroscopy (UPS)',
    practicalApplications: ['UV-C germicidal disinfection', 'Polymer photopolymerization (resins)', 'Forensic fluorescence detection'],
    sampleTransitions: 'π → π* and n → π* conjugated electron promotions in organic dyes, carbonyls, and aromatic rings'
  },
  {
    id: 'visible',
    name: 'Visible Light',
    wavelengthRange: '380 nm – 750 nm',
    frequencyRange: '400 THz – 789 THz',
    photonEnergyRange: '1.65 eV – 3.26 eV',
    colorHex: '#06b6d4',
    chemistryRelevance: 'Valence d-d Orbital Transitions & Molecular Chromophores',
    spectroscopyTechnique: 'Visible Colorimetry & Flame Emission Spectroscopy',
    practicalApplications: ['Human vision & photosynthesis', 'Laser pointers & displays', 'Analytical spectrophotometry (Beer-Lambert law)'],
    sampleTransitions: 'Crystal field d-d splitting transitions in transition metal complexes (e.g. [Cu(H₂O)₆]²⁺ blue color)'
  },
  {
    id: 'ir',
    name: 'Infrared (IR)',
    wavelengthRange: '750 nm – 1 mm',
    frequencyRange: '300 GHz – 400 THz',
    photonEnergyRange: '1.24 meV – 1.65 eV',
    colorHex: '#ef4444',
    chemistryRelevance: 'Molecular Vibrational Modes (Stretching & Bending)',
    spectroscopyTechnique: 'Fourier-Transform Infrared Spectroscopy (FTIR) & Raman Spectroscopy',
    practicalApplications: ['Organic functional group identification', 'Thermal imaging & remote controls', 'Greenhouse gas heat absorption (CO₂, CH₄)'],
    sampleTransitions: 'C=O carbonyl stretch (1715 cm⁻¹), O-H broad hydrogen-bonded stretch (3300 cm⁻¹), C-H aliphatic vibrations'
  },
  {
    id: 'microwave',
    name: 'Microwaves',
    wavelengthRange: '1 mm – 1 m',
    frequencyRange: '300 MHz – 300 GHz',
    photonEnergyRange: '1.24 µeV – 1.24 meV',
    colorHex: '#f97316',
    chemistryRelevance: 'Molecular Dipolar Rotations & Electron Spin Transitions',
    spectroscopyTechnique: 'Rotational Microwave Spectroscopy & Electron Paramagnetic Resonance (EPR/ESR)',
    practicalApplications: ['Microwave dielectric heating (water dipole rotation)', 'RADAR & 5G telecommunications', 'Radio astronomy cosmic microwave background'],
    sampleTransitions: 'Quantized rotational states of polar molecules (J → J+1 in gas phase H₂O, CO, NH₃)'
  },
  {
    id: 'radio',
    name: 'Radio Waves',
    wavelengthRange: '1 m – 100,000 km',
    frequencyRange: '< 300 MHz',
    photonEnergyRange: '< 1.24 µeV',
    colorHex: '#eab308',
    chemistryRelevance: 'Nuclear Spin State Precession in External Magnetic Fields',
    spectroscopyTechnique: 'Nuclear Magnetic Resonance Spectroscopy (¹H-NMR & ¹³C-NMR) & MRI Imaging',
    practicalApplications: ['Organic molecular structure elucidation', 'Medical Magnetic Resonance Imaging (MRI)', 'Global radio broadcasting & WiFi'],
    sampleTransitions: 'Nuclear spin flip transitions (m_I = +½ → -½) of ¹H and ¹³C nuclei aligned in Tesla magnetic fields'
  }
];

export const WavesRadiationLabView: React.FC<WavesRadiationLabViewProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'wave-simulator' | 'em-spectrum' | 'planck-calculator'>('wave-simulator');
  const [waveMode, setWaveMode] = useState<WaveSimulationMode>('traveling');
  const [isPlaying, setIsPlaying] = useState<boolean>(true);

  // Wave Parameters
  const [amplitude, setAmplitude] = useState<number>(45); // px
  const [frequency, setFrequency] = useState<number>(1.5); // Hz
  const [wavelength, setWavelength] = useState<number>(180); // px
  const [phaseDeg, setPhaseDeg] = useState<number>(0); // degrees
  const [standingHarmonic, setStandingHarmonic] = useState<number>(2); // n = 1, 2, 3...
  const [interferenceSourceSeparation, setInterferenceSourceSeparation] = useState<number>(120);

  // EM Spectrum Selected Region
  const [selectedEMRegionId, setSelectedEMRegionId] = useState<string>('ir');

  // Planck Calculator State
  const [calcInputType, setCalcInputType] = useState<'wavelength' | 'frequency' | 'energy'>('wavelength');
  const [calcInputValue, setCalcInputValue] = useState<number>(500); // 500 nm default
  const [calcUnit, setCalcUnit] = useState<string>('nm');

  // Canvas Ref
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Computed Wave Speed (v = f * lambda)
  const waveSpeed = useMemo(() => {
    return +(frequency * (wavelength / 100)).toFixed(2);
  }, [frequency, wavelength]);

  // Selected EM Region Data
  const activeEMRegion = useMemo(() => {
    return EM_REGIONS.find((r) => r.id === selectedEMRegionId) || EM_REGIONS[3];
  }, [selectedEMRegionId]);

  // Planck Equation Math
  const planckResults = useMemo(() => {
    const H = 6.62607015e-34; // J·s
    const C = 2.99792458e8; // m/s
    const EV = 1.602176634e-19; // J/eV
    const NA = 6.02214076e23; // Avogadro

    let lambdaM = 500e-9;
    let freqHz = 6e14;
    let energyJ = H * freqHz;
    let energyEv = energyJ / EV;
    let energyKjMol = (energyJ * NA) / 1000;

    if (calcInputType === 'wavelength') {
      let valM = calcInputValue;
      if (calcUnit === 'nm') valM *= 1e-9;
      else if (calcUnit === 'µm') valM *= 1e-6;
      else if (calcUnit === 'pm') valM *= 1e-12;
      else if (calcUnit === 'cm') valM *= 1e-2;
      else if (calcUnit === 'm') valM *= 1;

      lambdaM = Math.max(1e-18, valM);
      freqHz = C / lambdaM;
      energyJ = H * freqHz;
      energyEv = energyJ / EV;
      energyKjMol = (energyJ * NA) / 1000;
    } else if (calcInputType === 'frequency') {
      let valHz = calcInputValue;
      if (calcUnit === 'THz') valHz *= 1e12;
      else if (calcUnit === 'GHz') valHz *= 1e9;
      else if (calcUnit === 'MHz') valHz *= 1e6;
      else if (calcUnit === 'kHz') valHz *= 1e3;
      else if (calcUnit === 'Hz') valHz *= 1;

      freqHz = Math.max(1, valHz);
      lambdaM = C / freqHz;
      energyJ = H * freqHz;
      energyEv = energyJ / EV;
      energyKjMol = (energyJ * NA) / 1000;
    } else {
      let valJ = calcInputValue;
      if (calcUnit === 'eV') valJ *= EV;
      else if (calcUnit === 'keV') valJ *= EV * 1e3;
      else if (calcUnit === 'MeV') valJ *= EV * 1e6;
      else if (calcUnit === 'kJ/mol') valJ = (calcInputValue * 1000) / NA;
      else if (calcUnit === 'J') valJ *= 1;

      energyJ = Math.max(1e-30, valJ);
      freqHz = energyJ / H;
      lambdaM = C / freqHz;
      energyEv = energyJ / EV;
      energyKjMol = (energyJ * NA) / 1000;
    }

    // Determine EM Region
    let region = 'Visible';
    if (lambdaM < 1e-11) region = 'Gamma Rays';
    else if (lambdaM < 1e-8) region = 'X-Rays';
    else if (lambdaM < 3.8e-7) region = 'Ultraviolet (UV)';
    else if (lambdaM <= 7.5e-7) region = 'Visible Light';
    else if (lambdaM <= 1e-3) region = 'Infrared (IR)';
    else if (lambdaM <= 1) region = 'Microwaves';
    else region = 'Radio Waves';

    return {
      lambdaM,
      lambdaNm: (lambdaM * 1e9).toFixed(3),
      freqHz: freqHz.toExponential(4),
      energyJ: energyJ.toExponential(4),
      energyEv: energyEv.toFixed(3),
      energyKjMol: energyKjMol.toFixed(2),
      wavenumberCm: (1 / (lambdaM * 100)).toFixed(1),
      region
    };
  }, [calcInputType, calcInputValue, calcUnit]);

  // Main Wave Simulation Animation Loop
  useEffect(() => {
    if (activeTab !== 'wave-simulator') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let time = 0;

    const render = () => {
      if (isPlaying) {
        time += 0.03 * frequency;
      }

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const w = canvas.width;
      const h = canvas.height;
      const cy = h / 2;

      // Draw Grid / Center Equilibrium Axis
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, cy);
      ctx.lineTo(w, cy);
      ctx.stroke();

      // Mode 1: Traveling Wave (Transverse Sinusoidal)
      if (waveMode === 'traveling' || waveMode === 'transverse') {
        const k = (2 * Math.PI) / wavelength;
        const omega = 2 * Math.PI * frequency;
        const phi = (phaseDeg * Math.PI) / 180;

        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 3;
        ctx.beginPath();

        for (let x = 0; x <= w; x += 2) {
          const y = cy - amplitude * Math.sin(k * x - time * 4 + phi);
          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();

        // Draw oscillating matter particles on the wave
        const particleSpacing = 40;
        for (let x = 30; x < w; x += particleSpacing) {
          const y = cy - amplitude * Math.sin(k * x - time * 4 + phi);

          ctx.fillStyle = '#facc15';
          ctx.beginPath();
          ctx.arc(x, y, 5, 0, Math.PI * 2);
          ctx.fill();

          // Particle velocity vector
          if (waveMode === 'transverse') {
            const vy = -amplitude * 4 * Math.cos(k * x - time * 4 + phi);
            ctx.strokeStyle = '#f43f5e';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(x, y + Math.sign(vy) * Math.min(25, Math.abs(vy) * 0.2));
            ctx.stroke();
          }
        }
      }

      // Mode 2: Standing Wave (Nodes and Antinodes)
      else if (waveMode === 'standing') {
        const L = w - 80;
        const startX = 40;
        const k = (standingHarmonic * Math.PI) / L;

        ctx.strokeStyle = '#a855f7';
        ctx.lineWidth = 3;
        ctx.beginPath();

        for (let x = 0; x <= L; x += 2) {
          const y = cy - amplitude * Math.sin(k * x) * Math.cos(time * 6);
          if (x === 0) ctx.moveTo(startX + x, y);
          else ctx.lineTo(startX + x, y);
        }
        ctx.stroke();

        // Draw Nodes (zero displacement) & Antinodes (max displacement)
        for (let n = 0; n <= standingHarmonic; n++) {
          const nodeX = startX + (n * L) / standingHarmonic;
          ctx.fillStyle = '#ef4444';
          ctx.beginPath();
          ctx.arc(nodeX, cy, 6, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = '#ffffff';
          ctx.font = '10px monospace';
          ctx.fillText(`Node`, nodeX - 12, cy + 18);
        }
      }

      // Mode 3: Longitudinal Wave (Sound / Compression & Rarefaction)
      else if (waveMode === 'longitudinal') {
        const k = (2 * Math.PI) / wavelength;
        const particleRows = 7;
        const particleCols = 45;
        const colSpacing = w / particleCols;

        for (let r = 0; r < particleRows; r++) {
          const baseY = cy - 60 + r * 20;

          for (let c = 0; c < particleCols; c++) {
            const equilibriumX = c * colSpacing;
            const displacementX = amplitude * 0.4 * Math.sin(k * equilibriumX - time * 4);
            const actualX = equilibriumX + displacementX;

            ctx.fillStyle = '#38bdf8';
            ctx.beginPath();
            ctx.arc(actualX, baseY, 3.5, 0, Math.PI * 2);
            ctx.fill();
          }
        }

        // Labels: Compression & Rarefaction
        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 11px monospace';
        ctx.fillText('COMPRESSION (High Density) ↔ RAREFACTION (Low Density)', 20, 30);
      }

      // Mode 4: Two-Source Interference Pattern
      else if (waveMode === 'interference') {
        const s1y = cy - interferenceSourceSeparation / 2;
        const s2y = cy + interferenceSourceSeparation / 2;
        const sX = 60;

        // Draw Sources
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.arc(sX, s1y, 7, 0, Math.PI * 2);
        ctx.arc(sX, s2y, 7, 0, Math.PI * 2);
        ctx.fill();

        // Draw concentric wavefront ripples
        const k = (2 * Math.PI) / (wavelength * 0.5);
        for (let r = (time * 20) % 25; r < 400; r += 25) {
          ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(sX, s1y, r, -Math.PI / 2, Math.PI / 2);
          ctx.stroke();

          ctx.strokeStyle = 'rgba(239, 68, 68, 0.4)';
          ctx.beginPath();
          ctx.arc(sX, s2y, r, -Math.PI / 2, Math.PI / 2);
          ctx.stroke();
        }
      }

      // Mode 5: Electromagnetic 3D Coupled E & B Fields
      else if (waveMode === 'em-wave-3d') {
        const k = (2 * Math.PI) / wavelength;
        const tilt = 0.45; // 2.5D Isometric tilt for Magnetic Field

        // 1. Electric Field E(x,t) in Vertical Plane (Cyan)
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        for (let x = 0; x <= w; x += 2) {
          const Ey = amplitude * Math.sin(k * x - time * 4);
          const y = cy - Ey;
          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();

        // 2. Magnetic Field B(x,t) in Horizontal Plane (Rose / Pink)
        ctx.strokeStyle = '#f43f5e';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        for (let x = 0; x <= w; x += 2) {
          const Bz = amplitude * Math.sin(k * x - time * 4);
          const y = cy + Bz * tilt;
          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();

        // Field Vectors Drop lines
        for (let x = 20; x < w; x += 35) {
          const val = amplitude * Math.sin(k * x - time * 4);

          // E vector
          ctx.strokeStyle = 'rgba(56, 189, 248, 0.7)';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(x, cy);
          ctx.lineTo(x, cy - val);
          ctx.stroke();

          // B vector
          ctx.strokeStyle = 'rgba(244, 63, 94, 0.7)';
          ctx.beginPath();
          ctx.moveTo(x, cy);
          ctx.lineTo(x, cy + val * tilt);
          ctx.stroke();
        }

        // Legend overlay
        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 11px monospace';
        ctx.fillText('Electric Field E(x,t) [Vertical]', 20, 30);
        ctx.fillStyle = '#f43f5e';
        ctx.fillText('Magnetic Field B(x,t) [Horizontal]', 20, 48);
        ctx.fillStyle = '#facc15';
        ctx.fillText('Poynting Vector S = E × B (Propagation →)', 20, 66);
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [activeTab, waveMode, amplitude, frequency, wavelength, phaseDeg, standingHarmonic, interferenceSourceSeparation, isPlaying]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6 animate-fade-in font-sans">
      {/* Header Banner & Tab Navigation */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-[#090d16] via-[#111827] to-[#090d16] border border-cyan-500/20 shadow-2xl backdrop-blur-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
              Wave Mechanics & Photons
            </span>
            <span className="text-[11px] font-mono text-slate-400">
              v = fλ • E = hν = hc/λ • S = (E × B)/μ₀
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-3">
            <Waves className="w-6 h-6 text-cyan-400" />
            <span>Waves & Electromagnetic Radiation Lab</span>
          </h1>
          <p className="text-xs text-slate-400 max-w-3xl leading-relaxed">
            Real-time interactive wave propagation simulator (transverse, longitudinal, standing, interference, 3D EM fields), full electromagnetic spectrum database, and Planck photon quantum energy relation solver.
          </p>
        </div>

        {/* View Tabs Switcher */}
        <div className="flex items-center gap-1.5 p-1.5 rounded-2xl bg-black/60 border border-white/10 font-mono text-xs shrink-0">
          <button
            onClick={() => setActiveTab('wave-simulator')}
            className={`px-3.5 py-2 rounded-xl font-bold transition-all flex items-center gap-2 ${
              activeTab === 'wave-simulator'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-lg shadow-cyan-500/30'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>WAVE SIMULATOR</span>
          </button>
          <button
            onClick={() => setActiveTab('em-spectrum')}
            className={`px-3.5 py-2 rounded-xl font-bold transition-all flex items-center gap-2 ${
              activeTab === 'em-spectrum'
                ? 'bg-purple-500 text-white shadow-lg shadow-purple-500/30'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Radio className="w-4 h-4" />
            <span>EM SPECTRUM</span>
          </button>
          <button
            onClick={() => setActiveTab('planck-calculator')}
            className={`px-3.5 py-2 rounded-xl font-bold transition-all flex items-center gap-2 ${
              activeTab === 'planck-calculator'
                ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/30 font-black'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Zap className="w-4 h-4 text-amber-400" />
            <span>PLANCK QUANTUM SOLVER</span>
          </button>
        </div>
      </div>

      {/* ==========================================
          TAB 1: LIVE INTERACTIVE WAVE SIMULATOR
         ========================================== */}
      {activeTab === 'wave-simulator' && (
        <div className="space-y-6">
          {/* Wave Mode Selector Bar */}
          <div className="p-4 rounded-2xl bg-[#090d16] border border-white/10 flex flex-wrap items-center justify-between gap-3 font-mono text-xs">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-slate-400 uppercase font-bold text-[10px] mr-1">Mode:</span>
              {[
                { id: 'traveling', label: 'Traveling Wave' },
                { id: 'transverse', label: 'Transverse (Particle Velocity)' },
                { id: 'longitudinal', label: 'Longitudinal (Sound/Pressure)' },
                { id: 'standing', label: 'Standing Wave (Nodes)' },
                { id: 'interference', label: 'Interference (2 Sources)' },
                { id: 'em-wave-3d', label: '3D EM Coupled (E & B)' }
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => setWaveMode(m.id as any)}
                  className={`px-3 py-1.5 rounded-xl border transition-all ${
                    waveMode === m.id
                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400 font-bold shadow'
                      : 'bg-white/[0.02] border-white/5 text-slate-400 hover:text-white'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsPlaying((p) => !p)}
                className="p-2 rounded-xl bg-white/5 text-slate-300 hover:text-white hover:bg-white/10 border border-white/10"
                title={isPlaying ? 'Pause' : 'Play'}
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </button>
              <button
                onClick={() => {
                  setAmplitude(45);
                  setFrequency(1.5);
                  setWavelength(180);
                  setPhaseDeg(0);
                }}
                className="p-2 rounded-xl bg-white/5 text-slate-300 hover:text-white hover:bg-white/10 border border-white/10"
                title="Reset Parameters"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Interactive Simulation Canvas */}
          <div className="p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-4">
            <div className="relative h-80 rounded-2xl bg-black/90 border border-white/10 overflow-hidden">
              <canvas
                ref={canvasRef}
                width={860}
                height={320}
                className="w-full h-full object-contain"
              />
            </div>

            {/* Live Parameter Adjustment Sliders */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs">
              <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2">
                <div className="flex justify-between text-slate-300">
                  <span>Amplitude (A):</span>
                  <span className="text-cyan-400 font-bold">{amplitude} px</span>
                </div>
                <input
                  type="range"
                  min={10}
                  max={90}
                  value={amplitude}
                  onChange={(e) => setAmplitude(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
                />
              </div>

              <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2">
                <div className="flex justify-between text-slate-300">
                  <span>Frequency (f):</span>
                  <span className="text-cyan-400 font-bold">{frequency} Hz</span>
                </div>
                <input
                  type="range"
                  min={0.2}
                  max={4.0}
                  step={0.1}
                  value={frequency}
                  onChange={(e) => setFrequency(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
                />
              </div>

              <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2">
                <div className="flex justify-between text-slate-300">
                  <span>Wavelength (λ):</span>
                  <span className="text-cyan-400 font-bold">{wavelength} px</span>
                </div>
                <input
                  type="range"
                  min={80}
                  max={360}
                  value={wavelength}
                  onChange={(e) => setWavelength(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
                />
              </div>

              <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2">
                <div className="flex justify-between text-slate-300">
                  <span>Wave Speed (v = fλ):</span>
                  <span className="text-amber-300 font-bold">{waveSpeed} px/s</span>
                </div>
                <div className="text-[10px] text-slate-400 pt-1">
                  Period T = {(1 / frequency).toFixed(2)} s • k = {((2 * Math.PI) / wavelength).toFixed(3)} rad/px
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          TAB 2: FULL ELECTROMAGNETIC SPECTRUM ATLAS
         ========================================== */}
      {activeTab === 'em-spectrum' && (
        <div className="space-y-6">
          {/* Continuous EM Spectrum Interactive Ribbon */}
          <div className="p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-4">
            <div className="flex items-center justify-between font-mono text-xs">
              <span className="text-white font-bold">ELECTROMAGNETIC SPECTRUM ATLAS</span>
              <span className="text-slate-400">High Frequency / High Energy (Left) ↔ Low Frequency (Right)</span>
            </div>

            {/* The 7-Region Spectrum Bar */}
            <div className="grid grid-cols-7 gap-1 h-20 rounded-2xl overflow-hidden p-1 bg-black/60 border border-white/20">
              {EM_REGIONS.map((region) => {
                const isSelected = selectedEMRegionId === region.id;
                return (
                  <button
                    key={region.id}
                    onClick={() => setSelectedEMRegionId(region.id)}
                    style={{
                      backgroundColor: isSelected ? region.colorHex : `${region.colorHex}22`,
                      borderColor: region.colorHex
                    }}
                    className={`h-full rounded-xl border text-center transition-all p-1.5 flex flex-col justify-between ${
                      isSelected
                        ? 'text-slate-950 font-black shadow-lg scale-105 z-10'
                        : 'text-slate-300 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <span className="text-[11px] truncate">{region.name}</span>
                    <span className="text-[9px] font-mono opacity-80 truncate">{region.wavelengthRange.split(' ')[0]}</span>
                  </button>
                );
              })}
            </div>

            {/* Expanded 380 - 750 nm Visible Window if visible light is active */}
            {selectedEMRegionId === 'visible' && (
              <div className="p-3 rounded-2xl bg-black/40 border border-white/10 space-y-1 animate-fade-in">
                <span className="text-[10px] text-cyan-300 font-mono font-bold block">
                  Human Photoreceptor Visible Band (380 nm - 750 nm):
                </span>
                <div
                  className="h-6 rounded-lg w-full"
                  style={{
                    background: 'linear-gradient(to right, #6366f1, #3b82f6, #06b6d4, #10b981, #eab308, #f97316, #ef4444)'
                  }}
                />
                <div className="flex justify-between text-[9px] font-mono text-slate-400">
                  <span>Violet (380 nm)</span>
                  <span>Blue (450 nm)</span>
                  <span>Green (520 nm)</span>
                  <span>Yellow (580 nm)</span>
                  <span>Red (700 nm)</span>
                </div>
              </div>
            )}
          </div>

          {/* Deep Chemistry & Physical Relevance Card for Selected EM Region */}
          <div className="p-6 rounded-3xl bg-[#090d16] border border-cyan-500/30 shadow-2xl space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
              <div>
                <h2 className="text-2xl font-bold text-white font-mono flex items-center gap-3">
                  <span
                    className="w-4 h-4 rounded-full shadow-md"
                    style={{ backgroundColor: activeEMRegion.colorHex }}
                  />
                  <span>{activeEMRegion.name}</span>
                </h2>
                <div className="text-xs text-cyan-300 font-mono mt-1">
                  {activeEMRegion.chemistryRelevance}
                </div>
              </div>

              <div className="text-right font-mono text-xs space-y-0.5">
                <div className="text-slate-300">Wavelength: <strong className="text-white">{activeEMRegion.wavelengthRange}</strong></div>
                <div className="text-slate-300">Photon Energy: <strong className="text-amber-300">{activeEMRegion.photonEnergyRange}</strong></div>
                <div className="text-slate-400 text-[10px]">Frequency: {activeEMRegion.frequencyRange}</div>
              </div>
            </div>

            {/* Spectroscopic Techniques & Physical Transitions */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2">
                <span className="text-cyan-300 font-bold uppercase tracking-wider block text-[10px]">
                  Primary Analytical Spectroscopy Technique
                </span>
                <p className="text-white font-bold text-sm">{activeEMRegion.spectroscopyTechnique}</p>
                <p className="text-slate-400 text-xs leading-relaxed font-sans">{activeEMRegion.sampleTransitions}</p>
              </div>

              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2">
                <span className="text-amber-300 font-bold uppercase tracking-wider block text-[10px]">
                  Real-World Laboratory & Technological Applications
                </span>
                <ul className="space-y-1.5 list-disc pl-4 text-slate-300">
                  {activeEMRegion.practicalApplications.map((app, idx) => (
                    <li key={idx}>{app}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          TAB 3: PLANCK QUANTUM ENERGY CALCULATOR
         ========================================== */}
      {activeTab === 'planck-calculator' && (
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-[#090d16] border border-amber-500/30 shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <h2 className="text-xl font-bold text-white font-mono flex items-center gap-2">
                  <Zap className="w-5 h-5 text-amber-400" />
                  <span>PLANCK-EINSTEIN PHOTON ENERGY CALCULATOR</span>
                </h2>
                <p className="text-xs text-slate-400 font-mono mt-0.5">
                  Universal photon solver using E = hν = hc/λ and molar photon enthalpy E_molar = N_A · hν
                </p>
              </div>
            </div>

            {/* Input Selection Controls */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 font-mono text-xs items-center">
              <div className="md:col-span-4 p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2">
                <span className="text-slate-400 uppercase text-[10px] font-bold">Input Quantity Type:</span>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['wavelength', 'frequency', 'energy'] as const).map((t) => (
                    <button
                      key={t}
                      onClick={() => {
                        setCalcInputType(t);
                        if (t === 'wavelength') {
                          setCalcInputValue(500);
                          setCalcUnit('nm');
                        } else if (t === 'frequency') {
                          setCalcInputValue(600);
                          setCalcUnit('THz');
                        } else {
                          setCalcInputValue(2.48);
                          setCalcUnit('eV');
                        }
                      }}
                      className={`py-2 rounded-xl border text-center font-bold capitalize transition-all ${
                        calcInputType === t
                          ? 'bg-amber-500/20 text-amber-300 border-amber-400'
                          : 'bg-white/5 border-white/5 text-slate-400 hover:text-white'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              <div className="md:col-span-5 p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2">
                <span className="text-slate-400 uppercase text-[10px] font-bold">Enter Value & Select Unit:</span>
                <div className="flex gap-2">
                  <input
                    type="number"
                    value={calcInputValue}
                    onChange={(e) => setCalcInputValue(parseFloat(e.target.value) || 0)}
                    className="flex-1 px-3 py-2 rounded-xl bg-black/50 border border-white/10 text-white font-mono font-bold focus:outline-none focus:border-amber-400"
                  />
                  <select
                    value={calcUnit}
                    onChange={(e) => setCalcUnit(e.target.value)}
                    className="px-3 py-2 rounded-xl bg-slate-800 border border-white/10 text-white font-mono text-xs focus:outline-none"
                  >
                    {calcInputType === 'wavelength' && (
                      <>
                        <option value="pm">pm (Picometers, 10⁻¹² m)</option>
                        <option value="nm">nm (Nanometers, 10⁻⁹ m)</option>
                        <option value="µm">µm (Micrometers, 10⁻⁶ m)</option>
                        <option value="cm">cm (Centimeters, 10⁻² m)</option>
                        <option value="m">m (Meters)</option>
                      </>
                    )}
                    {calcInputType === 'frequency' && (
                      <>
                        <option value="Hz">Hz</option>
                        <option value="kHz">kHz (10³ Hz)</option>
                        <option value="MHz">MHz (10⁶ Hz)</option>
                        <option value="GHz">GHz (10⁹ Hz)</option>
                        <option value="THz">THz (10¹² Hz)</option>
                      </>
                    )}
                    {calcInputType === 'energy' && (
                      <>
                        <option value="eV">eV (Electron-volts)</option>
                        <option value="keV">keV</option>
                        <option value="MeV">MeV</option>
                        <option value="J">J (Joules)</option>
                        <option value="kJ/mol">kJ/mol (Molar Enthalpy)</option>
                      </>
                    )}
                  </select>
                </div>
              </div>

              <div className="md:col-span-3 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-center space-y-1">
                <span className="text-[10px] text-amber-300 uppercase font-bold block">EM Classification</span>
                <span className="text-base font-bold text-white block">{planckResults.region}</span>
              </div>
            </div>

            {/* Calculated Multi-Unit Results Dashboard */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono text-xs">
              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
                <span className="text-[10px] text-slate-400 block">Wavelength (λ)</span>
                <div className="text-lg font-bold text-cyan-300">{planckResults.lambdaNm} nm</div>
                <div className="text-[10px] text-slate-500">{planckResults.lambdaM.toExponential(3)} m</div>
              </div>

              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
                <span className="text-[10px] text-slate-400 block">Frequency (ν)</span>
                <div className="text-lg font-bold text-purple-300">{planckResults.freqHz} Hz</div>
                <div className="text-[10px] text-slate-500">c / λ</div>
              </div>

              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
                <span className="text-[10px] text-slate-400 block">Single Photon Energy</span>
                <div className="text-lg font-bold text-amber-300">{planckResults.energyEv} eV</div>
                <div className="text-[10px] text-slate-500">{planckResults.energyJ} Joules</div>
              </div>

              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
                <span className="text-[10px] text-slate-400 block">Molar Photon Energy</span>
                <div className="text-lg font-bold text-emerald-300">{planckResults.energyKjMol} kJ/mol</div>
                <div className="text-[10px] text-slate-500">Wavenumber: {planckResults.wavenumberCm} cm⁻¹</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
