import React, { useState } from 'react';
import {
  Compass,
  History,
  BookOpen,
  Sparkles,
  Zap,
  RotateCcw,
  ArrowRight,
  Shield,
  Target,
  Orbit,
  Waves,
  Activity,
  Award,
  FlaskConical,
  HelpCircle,
  FileText,
  ChevronRight,
  Layers,
  Search
} from 'lucide-react';
import { SCIENTISTS_TIMELINE, ScientistData } from '../../data/scientists';
import { ALL_118_ELEMENTS, getElementByNumber } from '../../data/elements';
import { CylindricalTimelineBarrel3D } from '../3d/history/CylindricalTimelineBarrel3D';
import { DaltonAtom3D } from '../3d/history/DaltonAtom3D';
import { ThomsonAtom3D } from '../3d/history/ThomsonAtom3D';
import { RutherfordAtom3D } from '../3d/history/RutherfordAtom3D';
import { BohrAtomInteractive3D } from '../3d/history/BohrAtomInteractive3D';
import { DeBroglieWave3D } from '../3d/history/DeBroglieWave3D';
import { HeisenbergUncertainty3D } from '../3d/history/HeisenbergUncertainty3D';
import { SchrodingerQuantumCloud3D } from '../3d/history/SchrodingerQuantumCloud3D';
import { InteractiveBohrAtom3D } from '../3d/InteractiveBohrAtom3D';
import { NavigationTab, ChemicalElement } from '../../types';
import { LatexRenderer } from '../common/LatexRenderer';

interface AtomicStructureViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

export const AtomicStructureView: React.FC<AtomicStructureViewProps> = ({ onNavigate }) => {
  const [mainViewMode, setMainViewMode] = useState<'interactive-bohr' | 'historical-timeline'>('interactive-bohr');
  const [selectedIndex, setSelectedIndex] = useState<number>(3); // Niels Bohr by default
  const [activeSubTab, setActiveSubTab] = useState<'theory' | 'experiment' | 'limitations' | 'archival'>('theory');

  // Interactive 118-Element Studio State
  const [selectedAtomicNumber, setSelectedAtomicNumber] = useState<number>(6); // Carbon default
  const [elementSearch, setElementSearch] = useState<string>('');

  const currentElement = getElementByNumber(selectedAtomicNumber) || getElementByNumber(6)!;
  const currentScientist: ScientistData = SCIENTISTS_TIMELINE[selectedIndex] || SCIENTISTS_TIMELINE[0];

  const filteredElements = ALL_118_ELEMENTS.filter(
    (el) =>
      el.name.toLowerCase().includes(elementSearch.toLowerCase()) ||
      el.symbol.toLowerCase().includes(elementSearch.toLowerCase()) ||
      el.number.toString().includes(elementSearch)
  ).slice(0, 16);

  // Dynamic 3D model component loader based on active scientist
  const render3DModel = () => {
    switch (currentScientist.id) {
      case 'dalton':
        return <DaltonAtom3D />;
      case 'thomson':
        return <ThomsonAtom3D />;
      case 'rutherford':
        return <RutherfordAtom3D />;
      case 'bohr':
        return <BohrAtomInteractive3D />;
      case 'de_broglie':
        return <DeBroglieWave3D />;
      case 'heisenberg':
        return <HeisenbergUncertainty3D />;
      case 'schrodinger':
        return <SchrodingerQuantumCloud3D />;
      default:
        return <BohrAtomInteractive3D />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header Banner & Mode Switcher */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-[#17110c] via-[#1f1611] to-[#120e0a] border border-amber-900/40 shadow-xl backdrop-blur-md">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-serif uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-amber-950/90 text-amber-300 border border-amber-800/60">
              Atomic Structure & Theoretical Physics
            </span>
            <span className="text-[11px] font-mono text-amber-500/80">
              Coplanar Bohr Shells • Quantum Mechanics
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-serif font-black text-amber-100 tracking-tight flex items-center gap-3">
            <span>Atomic Observatory</span>
            <span className="text-sm font-sans font-normal text-amber-400/80 hidden sm:inline">
              — Interactive 3D Bohr Atom & Historical Foundations
            </span>
          </h1>
          <p className="text-xs text-amber-200/60 mt-1 max-w-3xl leading-relaxed font-sans">
            Inspect the subatomic architecture of all 118 elements with coplanar concentric electron shells, clickable nuclei, individual quantum numbers, or journey through the paradigm shifts that defined modern atomic theory.
          </p>
        </div>

        {/* Studio Mode Selector */}
        <div className="flex items-center gap-1.5 p-1.5 rounded-xl bg-black/60 border border-amber-900/60 font-mono text-xs shrink-0">
          <button
            onClick={() => setMainViewMode('interactive-bohr')}
            className={`px-3.5 py-2 rounded-lg font-bold transition-all flex items-center gap-2 ${
              mainViewMode === 'interactive-bohr'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-lg shadow-cyan-500/30'
                : 'text-amber-300/70 hover:text-amber-100 hover:bg-amber-900/30'
            }`}
          >
            <Orbit className="w-4 h-4" />
            <span>3D BOHR ATOM</span>
          </button>
          <button
            onClick={() => setMainViewMode('historical-timeline')}
            className={`px-3.5 py-2 rounded-lg font-bold transition-all flex items-center gap-2 ${
              mainViewMode === 'historical-timeline'
                ? 'bg-amber-600 text-white shadow-lg shadow-amber-950'
                : 'text-amber-300/70 hover:text-amber-100 hover:bg-amber-900/30'
            }`}
          >
            <History className="w-4 h-4" />
            <span>HISTORICAL MODELS</span>
          </button>
        </div>
      </div>

      {/* ==========================================
          MODE 1: 118-ELEMENT INTERACTIVE BOHR ATOM STUDIO
         ========================================== */}
      {mainViewMode === 'interactive-bohr' && (
        <div className="space-y-6 animate-fade-in">
          {/* Element Selection Carousel & Search */}
          <div className="p-4 rounded-2xl bg-[#0e111a] border border-cyan-900/40 shadow-xl space-y-3">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2 font-mono text-xs">
                <span className="text-cyan-400 font-bold uppercase tracking-wider">Active Element:</span>
                <span className="px-2.5 py-1 rounded-lg bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 font-bold">
                  {currentElement.number}. {currentElement.name} ({currentElement.symbol})
                </span>
                <span className="text-slate-400 hidden md:inline">• {currentElement.category}</span>
              </div>

              {/* Element Quick Search */}
              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search 118 elements..."
                  value={elementSearch}
                  onChange={(e) => setElementSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-black/50 border border-white/10 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors"
                />
              </div>
            </div>

            {/* Quick Element Pills Carousel */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
              {filteredElements.map((el) => {
                const isSelected = el.number === selectedAtomicNumber;
                return (
                  <button
                    key={el.number}
                    onClick={() => setSelectedAtomicNumber(el.number)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold shrink-0 transition-all flex items-center gap-1.5 ${
                      isSelected
                        ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/30 scale-105'
                        : 'bg-white/5 text-slate-300 hover:text-white hover:bg-white/10 border border-white/10'
                    }`}
                  >
                    <span className="text-[10px] opacity-70">#{el.number}</span>
                    <span>{el.symbol}</span>
                    <span className="text-[10px] hidden sm:inline opacity-80">{el.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Interactive 3D Bohr Atom Viewer */}
          <InteractiveBohrAtom3D element={currentElement} className="h-[620px]" />
        </div>
      )}

      {/* ==========================================
          MODE 2: HISTORICAL ATOMIC MODELS & TIMELINE
         ========================================== */}
      {mainViewMode === 'historical-timeline' && (
        <div className="space-y-6 animate-fade-in">
          {/* Milestone Quick Jump Bar */}
          <div className="flex items-center justify-between p-2 rounded-xl bg-amber-950/40 border border-amber-900/50 font-serif text-xs overflow-x-auto">
            <div className="flex items-center gap-1.5">
              {SCIENTISTS_TIMELINE.map((s, idx) => (
                <button
                  key={s.id}
                  onClick={() => setSelectedIndex(idx)}
                  className={`px-3 py-1.5 rounded-lg transition-all text-xs font-bold shrink-0 ${
                    selectedIndex === idx
                      ? 'bg-amber-600 text-white shadow-md shadow-amber-950'
                      : 'text-amber-300/60 hover:text-amber-100 hover:bg-amber-900/40'
                  }`}
                  title={`${s.name} (${s.year})`}
                >
                  {s.name.split(' ').pop()} ({s.year})
                </button>
              ))}
            </div>
          </div>

          {/* 1. The 3D Rotating Barrel Timeline Interface */}
          <div className="relative space-y-2">
            <CylindricalTimelineBarrel3D
              scientists={SCIENTISTS_TIMELINE}
              selectedIndex={selectedIndex}
              onSelectScientist={(idx) => setSelectedIndex(idx)}
            />

            {/* Connecting Timeline Bracket & Active Anchor */}
            <div className="flex items-center justify-between px-4 py-2 rounded-xl bg-[#140e0b]/90 border border-amber-900/40 text-xs font-mono">
              <div className="flex items-center gap-2 text-amber-300">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                <span className="font-bold uppercase tracking-wider">Synchronized Model:</span>
                <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-200 border border-amber-500/40 font-bold">
                  {currentScientist.name} ({currentScientist.year}) — {currentScientist.modelName}
                </span>
              </div>
              <div className="text-amber-500/70 hidden sm:flex items-center gap-1">
                <span>Era {selectedIndex + 1} of {SCIENTISTS_TIMELINE.length}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>

          {/* 2. Main Selected Epoch Studio (3D Interactive Model + Archival Papers) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Column: Interactive 3D Model of the Selected Era */}
            <div className="lg:col-span-7 space-y-4">
              <div className="p-5 rounded-2xl bg-[#110d0a]/95 border border-amber-900/40 shadow-xl backdrop-blur-md space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-serif font-black text-amber-400 text-lg">
                        {currentScientist.romanYear || currentScientist.year}
                      </span>
                      <span className="text-xs font-mono text-amber-500/70">
                        ({currentScientist.year})
                      </span>
                    </div>
                    <h2 className="text-2xl font-serif font-bold text-white tracking-wide">
                      {currentScientist.name}
                    </h2>
                    <div className="text-xs font-serif text-amber-300/80 mt-0.5">
                      {currentScientist.modelName}
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs px-3 py-1 rounded-full bg-amber-950/80 text-amber-300 font-serif border border-amber-800/60">
                      {currentScientist.lifespan}
                    </span>
                  </div>
                </div>

                {/* Render 3D Model */}
                {render3DModel()}

                {/* Archival Quote */}
                <blockquote className="p-4 rounded-xl bg-[#18120e] border-l-4 border-amber-500 font-serif italic text-xs text-amber-100/90 leading-relaxed shadow-inner">
                  "{currentScientist.quote}"
                </blockquote>
              </div>
            </div>

            {/* Right Column: Theoretical Breakdown & Experimental Proofs */}
            <div className="lg:col-span-5 space-y-4">
              {/* Tab Selector */}
              <div className="flex items-center gap-1 p-1 rounded-xl bg-amber-950/50 border border-amber-900/50 font-serif text-xs">
                {(['theory', 'experiment', 'limitations', 'archival'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveSubTab(tab)}
                    className={`flex-1 py-2 rounded-lg font-bold capitalize transition-all ${
                      activeSubTab === tab
                        ? 'bg-amber-600 text-white shadow-md'
                        : 'text-amber-300/60 hover:text-amber-200 hover:bg-amber-900/30'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>

              {/* Tab Content */}
              <div className="p-5 rounded-2xl bg-[#110d0a]/95 border border-amber-900/40 shadow-xl font-sans text-xs space-y-4 text-amber-100/80 min-h-[380px]">
                {activeSubTab === 'theory' && (
                  <div className="space-y-3 animate-fade-in">
                    <div className="flex items-center gap-2 text-amber-400 font-serif font-bold text-sm">
                      <Zap className="w-4 h-4 text-amber-400" />
                      <span>The Core Postulate</span>
                    </div>
                    <p className="leading-relaxed">{currentScientist.theory}</p>
                    {currentScientist.formulaLatex && (
                      <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/30 text-center overflow-x-auto space-y-1">
                        <span className="text-[10px] font-mono text-amber-400 font-bold uppercase block">
                          Governing Mathematical Equation:
                        </span>
                        <LatexRenderer latex={currentScientist.formulaLatex} displayMode={true} className="text-amber-200 text-xs sm:text-sm" />
                      </div>
                    )}
                    <div className="p-3 rounded-xl bg-[#18120e] border border-amber-900/40 space-y-1">
                      <span className="text-[10px] uppercase font-mono text-amber-500 block">
                        Key Physical Concept:
                      </span>
                      <span className="font-serif italic text-amber-200 block text-xs">
                        {currentScientist.keyIdea}
                      </span>
                    </div>
                  </div>
                )}

                {activeSubTab === 'experiment' && (
                  <div className="space-y-3 animate-fade-in">
                    <div className="flex items-center gap-2 text-amber-400 font-serif font-bold text-sm">
                      <FlaskConical className="w-4 h-4 text-amber-400" />
                      <span>Empirical Validation</span>
                    </div>
                    <p className="leading-relaxed">{currentScientist.experiment}</p>
                    <div className="p-3 rounded-xl bg-[#18120e] border border-amber-900/40 space-y-1">
                      <span className="text-[10px] uppercase font-mono text-amber-500 block">
                        Scientific Impact:
                      </span>
                      <span className="text-amber-200 block leading-relaxed">
                        {currentScientist.impact}
                      </span>
                    </div>
                  </div>
                )}

                {activeSubTab === 'limitations' && (
                  <div className="space-y-3 animate-fade-in">
                    <div className="flex items-center gap-2 text-rose-400 font-serif font-bold text-sm">
                      <Shield className="w-4 h-4 text-rose-400" />
                      <span>Theoretical Breakdown & Anomalies</span>
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      Every great model ultimately faced experimental limits that sparked the next revolution:
                    </p>
                    <ul className="space-y-2 list-disc pl-4 text-amber-100/80">
                      {currentScientist.limitations.map((lim, idx) => (
                        <li key={idx} className="leading-relaxed">
                          {lim}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {activeSubTab === 'archival' && (
                  <div className="space-y-3 animate-fade-in">
                    <div className="flex items-center gap-2 text-amber-400 font-serif font-bold text-sm">
                      <BookOpen className="w-4 h-4 text-amber-400" />
                      <span>Original Archival Notes</span>
                    </div>
                    <div className="space-y-2 font-mono text-[11px]">
                      {currentScientist.archivalNotes.map((note, idx) => (
                        <div
                          key={idx}
                          className="p-3 rounded-xl bg-[#18120e] border border-amber-900/30 text-amber-200/90 leading-relaxed"
                        >
                          {note}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
