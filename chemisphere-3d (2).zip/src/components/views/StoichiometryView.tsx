import React, { useState } from 'react';
import { Scale, Calculator, Sparkles, CheckCircle2, ArrowRight, Layers } from 'lucide-react';
import { LatexRenderer } from '../common/LatexRenderer';
import { NavigationTab } from '../../types';

interface StoichiometryViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

export const StoichiometryView: React.FC<StoichiometryViewProps> = ({ onNavigate }) => {
  // Preset reactions
  const presets = [
    {
      id: 'combustion',
      name: 'Combustion of Propane',
      equation: 'C_3H_8 + 5O_2 \\rightarrow 3CO_2 + 4H_2O',
      reactants: [
        { formula: 'C₃H₈', molarMass: 44.1, coeff: 1 },
        { formula: 'O₂', molarMass: 32.0, coeff: 5 }
      ],
      products: [
        { formula: 'CO₂', molarMass: 44.01, coeff: 3 },
        { formula: 'H₂O', molarMass: 18.015, coeff: 4 }
      ]
    },
    {
      id: 'haber',
      name: 'Ammonia Synthesis (Haber-Bosch)',
      equation: 'N_2 + 3H_2 \\rightleftharpoons 2NH_3',
      reactants: [
        { formula: 'N₂', molarMass: 28.014, coeff: 1 },
        { formula: 'H₂', molarMass: 2.016, coeff: 3 }
      ],
      products: [
        { formula: 'NH₃', molarMass: 17.031, coeff: 2 }
      ]
    },
    {
      id: 'thermite',
      name: 'Thermite Redox Reaction',
      equation: 'Fe_2O_3 + 2Al \\rightarrow 2Fe + Al_2O_3',
      reactants: [
        { formula: 'Fe₂O₃', molarMass: 159.69, coeff: 1 },
        { formula: 'Al', molarMass: 26.98, coeff: 2 }
      ],
      products: [
        { formula: 'Fe', molarMass: 55.845, coeff: 2 },
        { formula: 'Al₂O₃', molarMass: 101.96, coeff: 1 }
      ]
    }
  ];

  const [selectedPreset, setSelectedPreset] = useState(presets[0]);
  const [massA, setMassA] = useState<number>(44.1); // grams of reactant 1
  const [massB, setMassB] = useState<number>(160.0); // grams of reactant 2
  const [actualYield, setActualYield] = useState<number>(100.0); // grams actual

  // Stoichiometry calculation logic
  const rA = selectedPreset.reactants[0];
  const rB = selectedPreset.reactants[1];
  const mainProduct = selectedPreset.products[0];

  const molesA = massA / rA.molarMass;
  const molesB = rB ? massB / rB.molarMass : 999999;

  // Limiting reactant determination
  const maxRxnA = molesA / rA.coeff;
  const maxRxnB = rB ? molesB / rB.coeff : 999999;

  const isALimiting = maxRxnA <= maxRxnB;
  const limitingReactant = isALimiting ? rA.formula : rB?.formula || rA.formula;
  const limitingMoles = isALimiting ? maxRxnA : maxRxnB;

  // Theoretical product yield
  const theoreticalProductMoles = limitingMoles * mainProduct.coeff;
  const theoreticalProductMass = theoreticalProductMoles * mainProduct.molarMass;
  const percentYieldVal = (actualYield / (theoreticalProductMass || 1)) * 100;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-[#090d16]/90 border border-slate-800 backdrop-blur-md">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <span>Stoichiometry & Reaction Engine</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-sky-950 text-sky-400 border border-sky-800 font-mono">
              Quantitative Chemistry
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Solve limiting reagents, theoretical mass yields, mole ratios, and percent efficiency in real time.
          </p>
        </div>

        {/* Reaction Presets */}
        <div className="flex items-center rounded-xl bg-slate-900 border border-slate-800 p-1 font-mono text-xs">
          {presets.map((p) => (
            <button
              key={p.id}
              onClick={() => setSelectedPreset(p)}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                selectedPreset.id === p.id
                  ? 'bg-sky-600 text-white font-bold shadow-md shadow-sky-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {p.name}
            </button>
          ))}
        </div>
      </div>

      {/* Balanced Reaction Display Card */}
      <div className="p-5 rounded-2xl bg-[#090d16]/90 border border-slate-800 backdrop-blur-md flex flex-col items-center justify-center text-center space-y-3">
        <div className="text-xs font-mono text-slate-400 uppercase tracking-wider">
          Balanced Stoichiometric Equation
        </div>
        <div className="text-lg sm:text-2xl text-cyan-300 font-mono py-2">
          <LatexRenderer latex={selectedPreset.equation} displayMode />
        </div>
      </div>

      {/* Interactive Inputs & Limiting Reagent Engine */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Reactant Mass Inputs */}
        <div className="p-5 rounded-2xl bg-[#090d16]/90 border border-slate-800 backdrop-blur-md space-y-4">
          <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider text-sky-400">
            Initial Reactant Inputs (Mass in Grams)
          </h3>

          <div className="space-y-4">
            <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-white font-bold">Reactant 1: {rA.formula} ({rA.molarMass} g/mol)</span>
                <span className="text-cyan-400">{molesA.toFixed(3)} moles</span>
              </div>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  min="0.1"
                  step="0.5"
                  value={massA}
                  onChange={(e) => setMassA(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white font-mono text-sm focus:outline-none focus:border-cyan-400"
                />
                <span className="text-xs font-mono text-slate-400">grams</span>
              </div>
            </div>

            {rB && (
              <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-white font-bold">Reactant 2: {rB.formula} ({rB.molarMass} g/mol)</span>
                  <span className="text-cyan-400">{molesB.toFixed(3)} moles</span>
                </div>
                <div className="flex items-center gap-3">
                  <input
                    type="number"
                    min="0.1"
                    step="0.5"
                    value={massB}
                    onChange={(e) => setMassB(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white font-mono text-sm focus:outline-none focus:border-cyan-400"
                  />
                  <span className="text-xs font-mono text-slate-400">grams</span>
                </div>
              </div>
            )}

            <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-300">Actual Lab Yield of {mainProduct.formula} (for % yield)</span>
              </div>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  min="0.1"
                  step="0.5"
                  value={actualYield}
                  onChange={(e) => setActualYield(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white font-mono text-sm focus:outline-none focus:border-cyan-400"
                />
                <span className="text-xs font-mono text-slate-400">grams</span>
              </div>
            </div>
          </div>
        </div>

        {/* Stoichiometric Results Card */}
        <div className="p-5 rounded-2xl bg-[#090d16]/90 border border-slate-800 backdrop-blur-md space-y-4 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider text-emerald-400 mb-4">
              Calculated Reaction Outputs
            </h3>

            <div className="grid grid-cols-2 gap-3 font-mono text-xs">
              <div className="p-3 rounded-xl bg-slate-900/70 border border-amber-900/40">
                <div className="text-[10px] text-slate-400">LIMITING REACTANT</div>
                <div className="text-lg font-bold text-amber-400 mt-1">{limitingReactant}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">Completely consumed first</div>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/70 border border-emerald-900/40">
                <div className="text-[10px] text-slate-400">THEORETICAL YIELD</div>
                <div className="text-lg font-bold text-emerald-400 mt-1">
                  {theoreticalProductMass.toFixed(2)} g
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  {theoreticalProductMoles.toFixed(3)} mol of {mainProduct.formula}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/70 border border-cyan-900/40">
                <div className="text-[10px] text-slate-400">PERCENT YIELD (%)</div>
                <div className="text-lg font-bold text-cyan-400 mt-1">
                  {percentYieldVal.toFixed(1)}%
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">(Actual / Theoretical) × 100</div>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/70 border border-purple-900/40">
                <div className="text-[10px] text-slate-400">MAIN PRODUCT</div>
                <div className="text-lg font-bold text-purple-400 mt-1">{mainProduct.formula}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">Mw = {mainProduct.molarMass} g/mol</div>
              </div>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs font-mono space-y-1">
            <div className="text-cyan-400 font-semibold">Step-by-Step Stoichiometric Proof:</div>
            <div className="text-slate-300 text-[11px] leading-relaxed">
              1. Convert masses to moles: n({rA.formula}) = {massA}g / {rA.molarMass} = {molesA.toFixed(3)} mol.
              <br />
              2. Compare mole-to-coefficient ratio: {rA.formula} gives {maxRxnA.toFixed(3)} max reaction runs.
              <br />
              3. Theoretical {mainProduct.formula} = {limitingMoles.toFixed(3)} × {mainProduct.coeff} = {theoreticalProductMoles.toFixed(3)} mol = {theoreticalProductMass.toFixed(2)} g.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
