import React, { useState } from 'react';
import {
  BatteryCharging,
  Zap,
  Activity,
  Layers,
  ArrowRight,
  Shield,
  Sliders,
  CheckCircle2,
  BarChart3,
  Flame
} from 'lucide-react';
import { NavigationTab } from '../../types';

interface ElectrochemistryLabViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

type ElectroSubTab = 'galvanic' | 'battery' | 'electrolysis' | 'corrosion';

export const ElectrochemistryLabView: React.FC<ElectrochemistryLabViewProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<ElectroSubTab>('galvanic');

  // ==========================================
  // 1. GALVANIC CELL & NERNST STATE
  // ==========================================
  const halfCells = [
    { name: 'Magnesium (Mg²⁺/Mg)', E0: -2.37, symbol: 'Mg', n: 2, color: '#94a3b8' },
    { name: 'Zinc (Zn²⁺/Zn)', E0: -0.76, symbol: 'Zn', n: 2, color: '#a1a1aa' },
    { name: 'Iron (Fe²⁺/Fe)', E0: -0.44, symbol: 'Fe', n: 2, color: '#f59e0b' },
    { name: 'Lead (Pb²⁺/Pb)', E0: -0.13, symbol: 'Pb', n: 2, color: '#64748b' },
    { name: 'Standard Hydrogen (SHE)', E0: 0.00, symbol: 'H₂', n: 2, color: '#38bdf8' },
    { name: 'Copper (Cu²⁺/Cu)', E0: 0.34, symbol: 'Cu', n: 2, color: '#f97316' },
    { name: 'Silver (Ag⁺/Ag)', E0: 0.80, symbol: 'Ag', n: 1, color: '#e2e8f0' }
  ];

  const [anodeCell, setAnodeCell] = useState(halfCells[1]); // Zn
  const [cathodeCell, setCathodeCell] = useState(halfCells[5]); // Cu
  const [concAnode, setConcAnode] = useState<number>(0.1); // M
  const [concCathode, setConcCathode] = useState<number>(1.0); // M
  const [cellTempK, setCellTempK] = useState<number>(298); // K

  // Standard Cell Potential E0_cell = E0_cathode - E0_anode
  const E0_cell = cathodeCell.E0 - anodeCell.E0;
  // Nernst: E = E0 - (RT/nF) * ln(Q) where Q = [Anode] / [Cathode]
  const R = 8.314;
  const F = 96485;
  const nElectrons = 2; // Daniell cell standard
  const Q = Math.max(1e-6, concAnode / concCathode);
  const nernstCorrection = ((R * cellTempK) / (nElectrons * F)) * Math.log(Q);
  const E_cell = E0_cell - nernstCorrection;
  const deltaG_J = -nElectrons * F * E_cell;
  const deltaG_kJ = deltaG_J / 1000;

  // ==========================================
  // 2. LI-ION BATTERY STATE
  // ==========================================
  const [batterySOC, setBatterySOC] = useState<number>(75); // %
  const [batteryType, setBatteryType] = useState<'lfp' | 'nmc' | 'solid-state'>('nmc');

  const batteryData = {
    nmc: { name: 'NMC (LiNiMnCoO₂ / Graphite)', nominalV: 3.7, maxV: 4.2, minV: 3.0, energyDensity: '250 Wh/kg' },
    lfp: { name: 'LFP (LiFePO₄ / Graphite)', nominalV: 3.2, maxV: 3.65, minV: 2.5, energyDensity: '160 Wh/kg' },
    'solid-state': { name: 'Solid-State (Li Metal / Sulfide)', nominalV: 3.85, maxV: 4.4, minV: 3.0, energyDensity: '400 Wh/kg' }
  };
  const activeBat = batteryData[batteryType];
  const currentBatV = activeBat.minV + (batterySOC / 100) * (activeBat.maxV - activeBat.minV);

  // ==========================================
  // 3. FARADAY ELECTROLYSIS STATE
  // ==========================================
  const platingMetals = [
    { name: 'Copper (Cu)', M: 63.55, z: 2, color: '#f97316' },
    { name: 'Silver (Ag)', M: 107.87, z: 1, color: '#e2e8f0' },
    { name: 'Gold (Au)', M: 196.97, z: 3, color: '#eab308' },
    { name: 'Nickel (Ni)', M: 58.69, z: 2, color: '#94a3b8' }
  ];
  const [selectedPlateMetal, setSelectedPlateMetal] = useState(platingMetals[0]);
  const [currentAmps, setCurrentAmps] = useState<number>(2.5); // A
  const [timeMinutes, setTimeMinutes] = useState<number>(30); // min

  // Mass deposited m = (I * t * M) / (z * F)
  const timeSeconds = timeMinutes * 60;
  const massGrams = (currentAmps * timeSeconds * selectedPlateMetal.M) / (selectedPlateMetal.z * F);

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8 font-sans">
      {/* Header Banner */}
      <div className="relative rounded-3xl overflow-hidden border border-yellow-500/30 bg-[#121006] p-6 sm:p-10 shadow-2xl">
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-yellow-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-20 -bottom-20 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-yellow-500/10 border border-yellow-400/30 text-yellow-400 text-xs font-mono font-bold tracking-wide">
            <BatteryCharging className="w-3.5 h-3.5" />
            <span>ELECTROCHEMISTRY • BATTERIES • ELECTROLYSIS • NERNST EQUATION</span>
          </div>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-display-periodic">
                ELECTROCHEMISTRY & BATTERY LAB
              </h1>
              <p className="text-slate-300 text-sm sm:text-base max-w-3xl mt-2 leading-relaxed font-sans">
                Simulate <strong>Galvanic Voltaic Cells & Nernst Equation</strong> (E = E° - (RT/nF) ln Q), model <strong>Lithium-Ion Intercalation & Battery C-Rates</strong>, perform quantitative <strong>Faraday Electrolytic Plating</strong> (m = ItM / zF), and explore cathodic corrosion protection.
              </p>
            </div>

            {onNavigate && (
              <button
                onClick={() => onNavigate('lab-directory')}
                className="px-4 py-2.5 rounded-2xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-slate-300 hover:text-white font-mono text-xs font-bold transition-all shrink-0 flex items-center gap-2"
              >
                <span>LAB DIRECTORY</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Sub Navigation */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-[#090d16] border border-white/10 overflow-x-auto font-mono text-xs">
        {[
          { id: 'galvanic' as ElectroSubTab, label: '1. Galvanic Cell & Nernst Potential', icon: Zap, color: 'text-yellow-400' },
          { id: 'battery' as ElectroSubTab, label: '2. Lithium-Ion Intercalation Battery', icon: BatteryCharging, color: 'text-cyan-400' },
          { id: 'electrolysis' as ElectroSubTab, label: '3. Faraday Electrolysis & Plating', icon: Layers, color: 'text-amber-400' },
          { id: 'corrosion' as ElectroSubTab, label: '4. Corrosion & Cathodic Protection', icon: Shield, color: 'text-rose-400' }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2.5 rounded-xl font-bold flex items-center gap-2 whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-white/15 text-white border border-white/20 shadow-lg'
                  : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
              }`}
            >
              <Icon className={`w-4 h-4 ${tab.color}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ============================================================== */}
      {/* 1. GALVANIC CELL & NERNST EQUATION */}
      {/* ============================================================== */}
      {activeTab === 'galvanic' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-yellow-500/30 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-yellow-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Zap className="w-4 h-4" />
                  <span>Half-Cell Electrodes & Concentrations</span>
                </span>
                <span className="text-slate-400 text-[10px]">ΔG = -nFE</span>
              </div>

              {/* Anode Selector */}
              <div className="space-y-2">
                <label className="text-slate-400 uppercase text-[10px] block">Anode (-) Oxidation Half-Cell:</label>
                <select
                  aria-label="Anode (-) Oxidation Half-Cell"
                  value={anodeCell.name}
                  onChange={(e) => {
                    const found = halfCells.find((c) => c.name === e.target.value);
                    if (found) setAnodeCell(found);
                  }}
                  className="w-full p-2.5 rounded-xl bg-slate-900 border border-white/10 text-white font-mono text-xs cursor-pointer"
                >
                  {halfCells.map((c) => (
                    <option key={c.name} value={c.name}>
                      {c.name} (E° = {c.E0 >= 0 ? '+' : ''}{c.E0.toFixed(2)} V)
                    </option>
                  ))}
                </select>
                <div className="flex justify-between text-[11px]">
                  <span className="text-slate-400">[Anode²⁺]:</span>
                  <span className="text-yellow-300 font-bold">{concAnode.toFixed(2)} M</span>
                </div>
                <input
                  type="range"
                  min={0.01}
                  max={2.0}
                  step={0.05}
                  value={concAnode}
                  onChange={(e) => setConcAnode(parseFloat(e.target.value))}
                  className="w-full accent-yellow-400 cursor-pointer"
                />
              </div>

              {/* Cathode Selector */}
              <div className="space-y-2 pt-2 border-t border-white/5">
                <label className="text-slate-400 uppercase text-[10px] block">Cathode (+) Reduction Half-Cell:</label>
                <select
                  aria-label="Cathode (+) Reduction Half-Cell"
                  value={cathodeCell.name}
                  onChange={(e) => {
                    const found = halfCells.find((c) => c.name === e.target.value);
                    if (found) setCathodeCell(found);
                  }}
                  className="w-full p-2.5 rounded-xl bg-slate-900 border border-white/10 text-white font-mono text-xs cursor-pointer"
                >
                  {halfCells.map((c) => (
                    <option key={c.name} value={c.name}>
                      {c.name} (E° = {c.E0 >= 0 ? '+' : ''}{c.E0.toFixed(2)} V)
                    </option>
                  ))}
                </select>
                <div className="flex justify-between text-[11px]">
                  <span className="text-slate-400">[Cathode²⁺]:</span>
                  <span className="text-cyan-300 font-bold">{concCathode.toFixed(2)} M</span>
                </div>
                <input
                  type="range"
                  min={0.01}
                  max={2.0}
                  step={0.05}
                  value={concCathode}
                  onChange={(e) => setConcCathode(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Live Voltage Readout */}
              <div className={`p-4 rounded-2xl border transition-all ${
                E_cell > 0 ? 'bg-emerald-500/15 border-emerald-400 text-emerald-200' : 'bg-red-500/15 border-red-400 text-red-200'
              }`}>
                <div className="flex justify-between items-center font-bold">
                  <span>Live Potential E_cell:</span>
                  <span className="text-xl">{E_cell >= 0 ? '+' : ''}{E_cell.toFixed(3)} V</span>
                </div>
                <div className="text-[11px] pt-1 space-y-0.5">
                  <div>Standard E°_cell: <strong>{E0_cell >= 0 ? '+' : ''}{E0_cell.toFixed(3)} V</strong></div>
                  <div>Gibbs Free Energy (ΔG): <strong>{deltaG_kJ.toFixed(1)} kJ/mol ({E_cell > 0 ? 'Spontaneous' : 'Non-spontaneous'})</strong></div>
                </div>
              </div>
            </div>

            {/* Right Galvanic Cell Animated Visualizer */}
            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-white/10 pb-3">
                <Zap className="w-4 h-4 text-yellow-400" />
                <span>Two-Compartment Galvanic Voltaic Cell</span>
              </h3>

              <div className="w-full bg-black/60 rounded-2xl p-4 border border-white/5">
                <svg viewBox="0 0 500 180" className="w-full h-auto select-none">
                  {/* Left Beaker (Anode) */}
                  <rect x="60" y="60" width="120" height="90" rx="4" fill="rgba(56, 189, 248, 0.1)" stroke="#38bdf8" strokeWidth="1.5" />
                  <rect x="100" y="40" width="20" height="80" fill={anodeCell.color} stroke="#ffffff" strokeWidth="1" />
                  <text x="110" y="168" textAnchor="middle" fill="#94a3b8" fontSize="8">Anode: {anodeCell.symbol}</text>

                  {/* Right Beaker (Cathode) */}
                  <rect x="320" y="60" width="120" height="90" rx="4" fill="rgba(249, 115, 22, 0.1)" stroke="#f97316" strokeWidth="1.5" />
                  <rect x="380" y="40" width="20" height="80" fill={cathodeCell.color} stroke="#ffffff" strokeWidth="1" />
                  <text x="390" y="168" textAnchor="middle" fill="#94a3b8" fontSize="8">Cathode: {cathodeCell.symbol}</text>

                  {/* Salt Bridge (Inverted U-tube) */}
                  <path d="M 140 90 L 140 40 L 360 40 L 360 90" fill="none" stroke="#a855f7" strokeWidth="12" strokeLinecap="round" opacity="0.6" />
                  <text x="250" y="32" textAnchor="middle" fill="#c084fc" fontSize="8" fontWeight="bold">KNO₃ Salt Bridge</text>

                  {/* External Circuit Wire & Voltmeter */}
                  <path d="M 110 40 L 110 15 L 230 15" fill="none" stroke="#facc15" strokeWidth="2" />
                  <path d="M 270 15 L 390 15 L 390 40" fill="none" stroke="#facc15" strokeWidth="2" />

                  {/* Voltmeter Dial */}
                  <circle cx="250" cy="15" r="16" fill="#0f172a" stroke="#facc15" strokeWidth="2" />
                  <text x="250" y="19" textAnchor="middle" fill="#facc15" fontSize="8" fontWeight="bold">
                    {E_cell.toFixed(2)}V
                  </text>

                  {/* Electron Flow Arrows */}
                  <text x="170" y="10" fill="#38bdf8" fontSize="8">e⁻ Flow →</text>
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 2. LITHIUM-ION BATTERY */}
      {/* ============================================================== */}
      {activeTab === 'battery' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-cyan-500/30 shadow-xl space-y-5">
              <span className="text-cyan-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2 border-b border-white/10 pb-3">
                <BatteryCharging className="w-4 h-4" />
                <span>Battery Chemistry & State-of-Charge (SOC)</span>
              </span>

              {/* Chemistries */}
              <div className="space-y-2">
                {(['nmc', 'lfp', 'solid-state'] as const).map((type) => (
                  <button
                    key={type}
                    onClick={() => setBatteryType(type)}
                    className={`w-full text-left p-3 rounded-xl border transition-all ${
                      batteryType === type
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 font-bold'
                        : 'bg-white/[0.02] border-white/5 text-slate-300 hover:bg-white/[0.05]'
                    }`}
                  >
                    <div className="font-bold">{batteryData[type].name}</div>
                    <div className="text-[10px] text-slate-400">Energy Density: {batteryData[type].energyDensity}</div>
                  </button>
                ))}
              </div>

              {/* SOC Slider */}
              <div className="space-y-2 pt-2 border-t border-white/5">
                <div className="flex justify-between">
                  <span className="text-slate-400">State of Charge (SOC):</span>
                  <span className="text-cyan-300 font-bold text-sm">{batterySOC}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={batterySOC}
                  onChange={(e) => setBatterySOC(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div className="p-4 rounded-2xl bg-black/60 border border-white/10 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Terminal Voltage:</span>
                  <span className="text-cyan-300 font-bold text-base">{currentBatV.toFixed(2)} V</span>
                </div>
                <div className="text-[11px] text-slate-400 font-sans pt-1">
                  Intercalation mechanism: Li⁺ shuttles between graphite anode Li_x C₆ and transition metal oxide cathode crystal lattice.
                </div>
              </div>
            </div>

            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-white/10 pb-3">
                <BatteryCharging className="w-4 h-4 text-cyan-400" />
                <span>Intercalation Li⁺ Ion Shuttle Simulation</span>
              </h3>
              <p className="text-slate-300 text-[11px] font-sans leading-relaxed">
                During discharge, lithium atoms in the graphite anode undergo oxidation Li_x C₆ → C₆ + x Li⁺ + x e⁻. Electrons travel through the external circuit to deliver electrical work while Li⁺ ions diffuse through the electrolyte separator to intercalate into the cathode CoO₂ lattice.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 3. FARADAY ELECTROLYSIS */}
      {/* ============================================================== */}
      {activeTab === 'electrolysis' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-amber-500/30 shadow-xl space-y-5">
              <span className="text-amber-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2 border-b border-white/10 pb-3">
                <Layers className="w-4 h-4" />
                <span>Faraday Plating Parameters</span>
              </span>

              {/* Metal Selection */}
              <div className="space-y-2">
                <label className="text-slate-400 uppercase text-[10px] block">Electroplating Target Metal:</label>
                <div className="grid grid-cols-2 gap-1.5">
                  {platingMetals.map((m) => (
                    <button
                      key={m.name}
                      onClick={() => setSelectedPlateMetal(m)}
                      className={`p-2.5 rounded-xl text-left border transition-all ${
                        selectedPlateMetal.name === m.name
                          ? 'bg-amber-500/20 border-amber-400 text-amber-300 font-bold'
                          : 'bg-white/[0.02] border-white/5 text-slate-300 hover:bg-white/[0.05]'
                      }`}
                    >
                      <div className="font-bold">{m.name}</div>
                      <div className="text-[10px] text-slate-400">z = {m.z}, M = {m.M} g/mol</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Current */}
              <div className="space-y-2 pt-2 border-t border-white/5">
                <div className="flex justify-between">
                  <span className="text-slate-400">Current (I):</span>
                  <span className="text-amber-300 font-bold">{currentAmps.toFixed(1)} A</span>
                </div>
                <input
                  type="range"
                  min={0.5}
                  max={10.0}
                  step={0.5}
                  value={currentAmps}
                  onChange={(e) => setCurrentAmps(parseFloat(e.target.value))}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>

              {/* Time */}
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Electrodeposition Time (t):</span>
                  <span className="text-cyan-300 font-bold">{timeMinutes} minutes ({timeSeconds} s)</span>
                </div>
                <input
                  type="range"
                  min={5}
                  max={120}
                  step={5}
                  value={timeMinutes}
                  onChange={(e) => setTimeMinutes(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Result Mass */}
              <div className="p-4 rounded-2xl bg-black/60 border border-white/10 space-y-2">
                <div className="flex justify-between items-center text-amber-300 font-bold text-base">
                  <span>Deposited Mass (m):</span>
                  <span>{massGrams.toFixed(3)} grams</span>
                </div>
                <div className="text-[10px] text-slate-400">
                  Charge passed Q = I · t = {(currentAmps * timeSeconds).toFixed(0)} Coulombs ({((currentAmps * timeSeconds) / F).toFixed(4)} mol e⁻).
                </div>
              </div>
            </div>

            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-white/10 pb-3">
                <Layers className="w-4 h-4 text-amber-400" />
                <span>Faraday’s First & Second Laws of Electrolysis</span>
              </h3>
              <p className="text-slate-300 text-[11px] font-sans leading-relaxed">
                Faraday's laws state that the mass of a substance altered at an electrode during electrolysis is directly proportional to the quantity of electricity transferred over the cell:
                <br /><br />
                <span className="text-amber-300 font-bold text-sm">m = (I · t · M) / (z · F)</span>
                <br /><br />
                where I is electric current (A), t is duration (s), M is molar mass (g/mol), z is electron stoichiometry, and F = 96,485.33 C/mol is Faraday's constant.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 4. CORROSION & CATHODIC PROTECTION */}
      {/* ============================================================== */}
      {activeTab === 'corrosion' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 rounded-3xl bg-[#090d16] border border-white/10 space-y-4">
              <h3 className="text-sm font-bold text-rose-400 flex items-center gap-2">
                <Shield className="w-4 h-4" />
                <span>Iron Rusting Redox Electrochemistry</span>
              </h3>
              <p className="text-slate-300 text-[11px] font-sans leading-relaxed">
                Corrosion is an electrochemical process where iron acts as anode:
                <br /><br />
                <strong>Anode (Oxidation):</strong> Fe(s) → Fe²⁺(aq) + 2e⁻ (E° = -0.44 V)<br />
                <strong>Cathode (Reduction):</strong> O₂(g) + 2 H₂O(l) + 4e⁻ → 4 OH⁻(aq) (E° = +0.40 V)<br />
                <strong>Overall Rust Formation:</strong> 2 Fe + O₂ + 2 H₂O → 2 Fe(OH)₂ → Fe₂O₃·xH₂O (Hydrated Iron Oxide)
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-[#090d16] border border-white/10 space-y-4">
              <h3 className="text-sm font-bold text-emerald-400 flex items-center gap-2">
                <Shield className="w-4 h-4" />
                <span>Sacrificial Anode (Cathodic Protection)</span>
              </h3>
              <p className="text-slate-300 text-[11px] font-sans leading-relaxed">
                By electrically connecting iron pipes or ship hulls to a more active metal with more negative reduction potential (e.g. Zinc E° = -0.76 V or Magnesium E° = -2.37 V), the sacrificial metal oxidizes preferentially, forcing the iron structure to act as the protected cathode.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
