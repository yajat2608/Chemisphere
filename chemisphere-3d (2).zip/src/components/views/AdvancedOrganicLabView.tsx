import React, { useState } from 'react';
import {
  Sparkles,
  ArrowRight,
  RotateCcw,
  CheckCircle2,
  Layers,
  Activity,
  Zap,
  HelpCircle,
  Eye,
  ChevronRight,
  BookOpen
} from 'lucide-react';
import { NavigationTab } from '../../types';

interface AdvancedOrganicLabViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

type OrganicSubTab = 'mechanisms' | 'retrosynthesis' | 'stereochemistry' | 'functional-groups';

export const AdvancedOrganicLabView: React.FC<AdvancedOrganicLabViewProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<OrganicSubTab>('mechanisms');

  // ==========================================
  // 1. REACTION MECHANISMS STATE
  // ==========================================
  const mechanisms = [
    {
      id: 'sn2',
      name: 'S_N2 (Bimolecular Nucleophilic Substitution)',
      subtitle: 'Concerted backside attack with Walden Inversion',
      rateLaw: 'Rate = k [Nu⁻] [R-X]',
      substrate: 'Primary / Secondary Haloalkane (e.g., CH₃-Br + OH⁻ → CH₃-OH + Br⁻)',
      steps: [
        { title: '1. Backside Attack', desc: 'Nucleophile (OH⁻) donates lone pair into the antibonding σ* C-Br orbital from 180° opposite the halogen leaving group.' },
        { title: '2. Pentacoordinate Transition State', desc: 'Carbon enters a trigonal bipyramidal transition state [HO···CH₃···Br]‡ with partial charges δ- on both oxygen and bromine.' },
        { title: '3. Departure & Inversion', desc: 'Bromide departs as Br⁻; the three hydrogen bonds flip like an umbrella in the wind (100% stereochemical inversion).' }
      ]
    },
    {
      id: 'sn1',
      name: 'S_N1 (Unimolecular Nucleophilic Substitution)',
      subtitle: 'Two-step mechanism via Planar Carbocation Intermediate',
      rateLaw: 'Rate = k [R-X]',
      substrate: 'Tertiary Haloalkane (e.g., (CH₃)₃C-Br + H₂O → (CH₃)₃C-OH + HBr)',
      steps: [
        { title: '1. Rate-Determining Ionization', desc: 'Heterolytic cleavage of the C-Br bond forms a planar, sp²-hybridized carbocation (CH₃)₃C⁺ with an empty p-orbital.' },
        { title: '2. Nucleophilic Attack', desc: 'Weak nucleophile (H₂O) attacks the carbocation from either top or bottom face with equal 50% probability (Racemization).' },
        { title: '3. Deprotonation', desc: 'Solvent water deprotonates the oxonium ion to yield the neutral tertiary alcohol product.' }
      ]
    },
    {
      id: 'eas',
      name: 'EAS (Electrophilic Aromatic Substitution: Nitration)',
      subtitle: 'Arenium / Wheland complex resonance stabilized intermediate',
      rateLaw: 'Rate = k [Ar-H] [NO₂⁺]',
      substrate: 'Benzene + HNO₃ / H₂SO₄ → Nitrobenzene + H₂O',
      steps: [
        { title: '1. Nitronium Ion Generation', desc: 'H₂SO₄ protonates HNO₃, which loses water to generate the potent electrophile NO₂⁺ (nitronium ion).' },
        { title: '2. Electrophilic Attack & Arenium Ion', desc: 'Benzene π-electrons attack NO₂⁺, breaking aromaticity to form a resonance-stabilized Wheland cyclohexadienyl carbocation.' },
        { title: '3. Rearomatization', desc: 'Conjugate base (HSO₄⁻) abstracts the proton from the sp³ carbon, restoring the 6-electron aromatic sextet.' }
      ]
    },
    {
      id: 'diels-alder',
      name: 'Diels-Alder [4+2] Pericyclic Cycloaddition',
      subtitle: 'Concerted suprafacial addition forming 6-membered cyclohexene',
      rateLaw: 'Rate = k [Diene] [Dienophile]',
      substrate: '1,3-Butadiene + Maleic Anhydride → Bicyclic Adduct',
      steps: [
        { title: '1. s-cis Diene Conformation', desc: 'Diene adopts s-cis planar conformation to permit overlap between diene HOMO and dienophile LUMO.' },
        { title: '2. Concerted 6-Electron Transition State', desc: 'Simultaneous reorganization of three pairs of π-electrons through an aromatic 6π transition state.' },
        { title: '3. Endo Stereoselectivity', desc: 'Secondary orbital overlap favors the endo kinetic transition state over the exo product.' }
      ]
    }
  ];
  const [selectedMech, setSelectedMech] = useState(mechanisms[0]);
  const [mechStepIndex, setMechStepIndex] = useState(0);

  // ==========================================
  // 2. RETROSYNTHESIS TARGETS
  // ==========================================
  const retroTargets = [
    {
      name: 'Aspirin (Acetylsalicylic Acid)',
      formula: 'C₉H₈O₄',
      targetSmiles: 'O=C(C)Oc1ccccc1C(=O)O',
      disconnection: 'Ester bond C-O disconnection $\\Rightarrow$ Salicylic Acid + Acetic Anhydride',
      synthons: ['Salicylate phenoxide donor', 'Acetyl cation (CH₃CO⁺) equivalent'],
      forwardReagents: 'Salicylic Acid + (CH₃CO)₂O in presence of H₃PO₄ catalyst at 85°C'
    },
    {
      name: 'Paracetamol (Acetaminophen)',
      formula: 'C₈H₉NO₂',
      targetSmiles: 'CC(=O)Nc1ccc(O)cc1',
      disconnection: 'Amide bond C-N disconnection $\\Rightarrow$ 4-Aminophenol + Acetic Anhydride',
      synthons: ['4-Aminophenol nucleophile', 'Acyl donor equivalent'],
      forwardReagents: '4-Aminophenol + Acetic Anhydride in aqueous buffer'
    },
    {
      name: 'Benzocaine (Local Anesthetic)',
      formula: 'C₉H₁₁NO₂',
      targetSmiles: 'CCOC(=O)c1ccc(N)cc1',
      disconnection: 'Ester disconnection $\\Rightarrow$ 4-Aminobenzoic acid (PABA) + Ethanol',
      synthons: ['PABA acyl donor', 'Ethanol alkoxide equivalent'],
      forwardReagents: '4-Aminobenzoic Acid + Absolute Ethanol + Concentrated H₂SO₄ (Fischer Esterification)'
    }
  ];
  const [selectedRetro, setSelectedRetro] = useState(retroTargets[0]);

  // ==========================================
  // 3. STEREOCHEMISTRY STATE
  // ==========================================
  const stereoisomers = [
    {
      name: 'L-Lactic Acid vs D-Lactic Acid',
      type: 'Enantiomers (Non-superimposable Mirror Images)',
      center: 'C2 is stereocenter (H, OH, CH₃, COOH)',
      cipPriority: '1: -OH, 2: -COOH, 3: -CH₃, 4: -H',
      opticalRotation: 'L-(+)-Lactic acid: +2.6°, D-(-)-Lactic acid: -2.6°'
    },
    {
      name: 'Tartaric Acid Stereoisomers',
      type: 'Enantiomers & Meso Compound (Internal Mirror Plane)',
      center: '(2R,3R)-Tartaric Acid vs (2S,3S) vs (2R,3S)-Meso-Tartaric Acid',
      cipPriority: 'Meso form has internal mirror plane σ, making it optically inactive (rotation = 0°)',
      opticalRotation: '(+)-form: +12.4°, (-)-form: -12.4°, Meso: 0.0°'
    }
  ];
  const [selectedStereo, setSelectedStereo] = useState(stereoisomers[0]);

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8 font-sans">
      {/* Header Banner */}
      <div className="relative rounded-3xl overflow-hidden border border-emerald-500/30 bg-[#06120d] p-6 sm:p-10 shadow-2xl">
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-20 -bottom-20 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-400/30 text-emerald-400 text-xs font-mono font-bold tracking-wide">
            <Sparkles className="w-3.5 h-3.5" />
            <span>ORGANIC SYNTHESIS • MECHANISMS • RETROSYNTHESIS • STEREOCHEMISTRY</span>
          </div>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-display-periodic">
                ADVANCED ORGANIC SYNTHESIS LAB
              </h1>
              <p className="text-slate-300 text-sm sm:text-base max-w-3xl mt-2 leading-relaxed font-sans">
                Master organic reactivity with <strong>Curved-Arrow Electron-Pushing Mechanisms</strong> (SN1, SN2, Electrophilic Aromatic Substitution, Diels-Alder [4+2]), <strong>Retrosynthetic Disconnections</strong> (⇒), <strong>CIP (R)/(S) Stereochemistry & Chirality</strong>, and functional group diagnostic test profiles.
              </p>
            </div>

            {onNavigate && (
              <button
                onClick={() => onNavigate('lab-directory')}
                className="px-4 py-2.5 rounded-2xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-slate-300 hover:text-white font-mono text-xs font-bold transition-all shrink-0 flex items-center gap-2"
              >
                <span>LAB DIRECTORY</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Sub Navigation */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-[#090d16] border border-white/10 overflow-x-auto font-mono text-xs">
        {[
          { id: 'mechanisms' as OrganicSubTab, label: '1. Curved-Arrow Mechanisms', icon: Zap, color: 'text-emerald-400' },
          { id: 'retrosynthesis' as OrganicSubTab, label: '2. Retrosynthetic Disconnections', icon: Layers, color: 'text-cyan-400' },
          { id: 'stereochemistry' as OrganicSubTab, label: '3. Chirality & CIP R/S Workbench', icon: Activity, color: 'text-purple-400' },
          { id: 'functional-groups' as OrganicSubTab, label: '4. Functional Group Profiler & Tests', icon: BookOpen, color: 'text-amber-400' }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2.5 rounded-xl font-bold flex items-center gap-2 whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-white/15 text-white border border-white/20 shadow-lg'
                  : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
              }`}
            >
              <Icon className={`w-4 h-4 ${tab.color}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ============================================================== */}
      {/* 1. CURVED-ARROW REACTION MECHANISMS */}
      {/* ============================================================== */}
      {activeTab === 'mechanisms' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-emerald-500/30 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-emerald-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Zap className="w-4 h-4" />
                  <span>Select Organic Mechanism</span>
                </span>
              </div>

              <div className="space-y-2">
                {mechanisms.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => {
                      setSelectedMech(m);
                      setMechStepIndex(0);
                    }}
                    className={`w-full text-left p-3 rounded-xl border transition-all ${
                      selectedMech.id === m.id
                        ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 font-bold'
                        : 'bg-white/[0.02] border-white/5 text-slate-300 hover:bg-white/[0.05]'
                    }`}
                  >
                    <div className="font-bold">{m.name}</div>
                    <div className="text-[10px] text-slate-400">{m.subtitle}</div>
                  </button>
                ))}
              </div>

              {/* Kinetic & Substrate Card */}
              <div className="p-4 rounded-2xl bg-black/60 border border-white/10 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Kinetic Rate Law:</span>
                  <span className="text-emerald-300 font-bold">{selectedMech.rateLaw}</span>
                </div>
                <div className="text-[11px] text-slate-400">
                  Substrate: <strong>{selectedMech.substrate}</strong>
                </div>
              </div>
            </div>

            {/* Right Step-by-Step Mechanism Player */}
            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Zap className="w-4 h-4 text-emerald-400" />
                    <span>{selectedMech.name}</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                    Step {mechStepIndex + 1} of {selectedMech.steps.length}: {selectedMech.steps[mechStepIndex].title}
                  </p>
                </div>

                <div className="flex items-center gap-1.5">
                  {selectedMech.steps.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setMechStepIndex(idx)}
                      className={`w-7 h-7 rounded-lg font-bold transition-all border ${
                        mechStepIndex === idx
                          ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                          : 'bg-white/[0.04] text-slate-400 border-white/10'
                      }`}
                    >
                      {idx + 1}
                    </button>
                  ))}
                </div>
              </div>

              {/* Visual Step Display */}
              <div className="p-6 rounded-2xl bg-emerald-500/10 border border-emerald-400/30 space-y-4">
                <h4 className="text-base font-bold text-emerald-300">
                  {selectedMech.steps[mechStepIndex].title}
                </h4>
                <p className="text-slate-200 text-sm font-sans leading-relaxed">
                  {selectedMech.steps[mechStepIndex].desc}
                </p>
              </div>

              {/* Navigation Controls */}
              <div className="flex justify-between items-center pt-2">
                <button
                  disabled={mechStepIndex === 0}
                  onClick={() => setMechStepIndex((i) => Math.max(0, i - 1))}
                  className="px-4 py-2 rounded-xl bg-white/[0.04] border border-white/10 disabled:opacity-30 text-slate-300 font-bold"
                >
                  ← PREVIOUS STEP
                </button>
                <button
                  disabled={mechStepIndex === selectedMech.steps.length - 1}
                  onClick={() => setMechStepIndex((i) => Math.min(selectedMech.steps.length - 1, i + 1))}
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 disabled:opacity-30 font-bold shadow-lg"
                >
                  NEXT STEP →
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 2. RETROSYNTHESIS TARGETS */}
      {/* ============================================================== */}
      {activeTab === 'retrosynthesis' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-cyan-500/30 shadow-xl space-y-5">
              <span className="text-cyan-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2 border-b border-white/10 pb-3">
                <Layers className="w-4 h-4" />
                <span>Select Target Molecule Disconnection</span>
              </span>

              <div className="space-y-2">
                {retroTargets.map((t) => (
                  <button
                    key={t.name}
                    onClick={() => setSelectedRetro(t)}
                    className={`w-full text-left p-3 rounded-xl border transition-all ${
                      selectedRetro.name === t.name
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 font-bold'
                        : 'bg-white/[0.02] border-white/5 text-slate-300 hover:bg-white/[0.05]'
                    }`}
                  >
                    <div className="font-bold">{t.name}</div>
                    <div className="text-[10px] text-slate-400">Formula: {t.formula}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-white/10 pb-3">
                <Layers className="w-4 h-4 text-cyan-400" />
                <span>Retrosynthetic Disconnection Tree for {selectedRetro.name}</span>
              </h3>

              <div className="p-4 rounded-2xl bg-black/60 border border-white/10 space-y-4">
                <div>
                  <span className="text-slate-400 text-[10px] uppercase block">Retrosynthetic Disconnection (⇒):</span>
                  <div className="text-cyan-300 font-bold text-sm mt-1">{selectedRetro.disconnection}</div>
                </div>

                <div className="pt-2 border-t border-white/5">
                  <span className="text-slate-400 text-[10px] uppercase block">Forward Synthesis Reagents:</span>
                  <div className="text-emerald-400 font-bold text-xs mt-1">{selectedRetro.forwardReagents}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 3. STEREOCHEMISTRY & CHIRALITY */}
      {/* ============================================================== */}
      {activeTab === 'stereochemistry' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-purple-500/30 shadow-xl space-y-5">
              <span className="text-purple-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2 border-b border-white/10 pb-3">
                <Activity className="w-4 h-4" />
                <span>Select Chiral Molecule Case</span>
              </span>

              <div className="space-y-2">
                {stereoisomers.map((s) => (
                  <button
                    key={s.name}
                    onClick={() => setSelectedStereo(s)}
                    className={`w-full text-left p-3 rounded-xl border transition-all ${
                      selectedStereo.name === s.name
                        ? 'bg-purple-500/20 border-purple-400 text-purple-300 font-bold'
                        : 'bg-white/[0.02] border-white/5 text-slate-300 hover:bg-white/[0.05]'
                    }`}
                  >
                    <div className="font-bold">{s.name}</div>
                    <div className="text-[10px] text-slate-400">{s.type}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-white/10 pb-3">
                <Activity className="w-4 h-4 text-purple-400" />
                <span>Cahn-Ingold-Prelog (CIP) Rules & Optical Activity</span>
              </h3>

              <div className="p-4 rounded-2xl bg-black/60 border border-white/10 space-y-3">
                <div>
                  <span className="text-slate-400 text-[10px] uppercase block">Stereocenter & Classification:</span>
                  <div className="text-purple-300 font-bold text-sm mt-1">{selectedStereo.center}</div>
                </div>
                <div className="pt-2 border-t border-white/5">
                  <span className="text-slate-400 text-[10px] uppercase block">CIP Priority Hierarchy:</span>
                  <div className="text-slate-200 text-xs mt-1">{selectedStereo.cipPriority}</div>
                </div>
                <div className="pt-2 border-t border-white/5">
                  <span className="text-slate-400 text-[10px] uppercase block">Specific Optical Rotation [α]:</span>
                  <div className="text-amber-400 font-bold text-xs mt-1">{selectedStereo.opticalRotation}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 4. FUNCTIONAL GROUP DIAGNOSTIC PROFILER */}
      {/* ============================================================== */}
      {activeTab === 'functional-groups' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { name: 'Aldehyde (-CHO)', test: 'Tollens Test (Silver Mirror)', positive: 'Ag⁺ reduced to metallic silver mirror Ag(s)', pKa: '17 (α-H)' },
              { name: 'Carboxylic Acid (-COOH)', test: 'Sodium Bicarbonate (NaHCO₃)', positive: 'Effervescence of CO₂(g) gas', pKa: '4 - 5' },
              { name: 'Phenol (Ar-OH)', test: 'Neutral FeCl₃ Test', positive: 'Violet / Purple coordination complex', pKa: '10' },
              { name: 'Aliphatic Alcohol (-OH)', test: 'Lucas Test (ZnCl₂ / HCl)', positive: '3° turbid immediately, 2° in 5 min, 1° no reaction at room temp', pKa: '16 - 18' },
              { name: 'Alkene / Alkyne (C=C / C≡C)', test: 'Bromine Water Test (Br₂ in CCl₄)', positive: 'Decolorization of orange-red bromine', pKa: '25 - 44' },
              { name: 'Carbonyl (Ketone / Aldehyde)', test: '2,4-DNP (Brady’s Reagent)', positive: 'Bright yellow/orange precipitate of hydrazone', pKa: '19 - 20 (α-H)' }
            ].map((fg) => (
              <div key={fg.name} className="p-4 rounded-2xl bg-[#090d16] border border-white/10 space-y-2">
                <div className="text-amber-400 font-bold text-sm">{fg.name}</div>
                <div className="text-slate-400 text-[11px]">Diagnostic Test: <strong>{fg.test}</strong></div>
                <div className="text-emerald-400 text-[11px]">Positive Result: <strong>{fg.positive}</strong></div>
                <div className="text-slate-500 text-[10px] pt-1 border-t border-white/5">Typical pKa: {fg.pKa}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
