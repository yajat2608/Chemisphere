import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Trophy,
  Sparkles,
  HelpCircle,
  CheckCircle2,
  XCircle,
  ArrowRight,
  RotateCcw,
  Clock,
  Zap,
  Flame,
  Atom,
  Dna,
  Activity,
  Bot,
  Layers,
  ChevronRight,
  Award,
  Filter,
  Check,
  Play,
  Pause,
  Boxes,
  Lock,
  Calendar,
  Compass,
  Scale
} from 'lucide-react';
import { NavigationTab } from '../../types';
import { userPassportStore } from '../../data/UserPassportStore';
import { LatexRenderer } from '../common/LatexRenderer';
import { ChemistryMarkdown } from '../common/ChemistryMarkdown';
import { ChemistryPuzzlesModal } from '../playgrounds/ChemistryPuzzlesModal';

interface QuestionItem {
  id: string;
  category: 'Olympiad' | 'Organic' | 'Physical' | 'Inorganic' | 'Quantum';
  difficulty: 'Foundation' | 'Intermediate' | 'Advanced' | 'Olympiad Gold';
  question: string;
  options: string[];
  correctIndex: number;
  hint: string;
  explanation: string;
  formula?: string;
  relatedLab: NavigationTab;
}

const PLAYGROUND_QUESTIONS: QuestionItem[] = [
  {
    id: 'q1',
    category: 'Quantum',
    difficulty: 'Advanced',
    question: 'For a 3d electron in a hydrogenic atom, how many total nodes (radial + angular) and how many nodal planes are present?',
    options: [
      'Total nodes = 2 (0 radial, 2 angular nodal planes)',
      'Total nodes = 3 (1 radial, 2 angular nodal planes)',
      'Total nodes = 1 (1 radial, 0 angular nodal planes)',
      'Total nodes = 4 (2 radial, 2 angular nodal planes)'
    ],
    correctIndex: 0,
    hint: 'Total nodes = (n - 1). Angular nodes (nodal planes) = l. Radial nodes = (n - l - 1).',
    explanation: 'For a 3d orbital, principal quantum number $n = 3$ and azimuthal quantum number $l = 2$. Total nodes = $n - 1 = 3 - 1 = 2$. Angular nodes = $l = 2$ (representing the two nodal cones or planar surfaces). Radial nodes = $n - l - 1 = 3 - 2 - 1 = 0$. Hence there are 0 radial nodes and 2 angular nodal planes.',
    formula: '\\text{Total Nodes} = n - 1, \\quad \\text{Radial Nodes} = n - l - 1, \\quad \\text{Angular Nodes} = l',
    relatedLab: 'orbital-atlas'
  },
  {
    id: 'q2',
    category: 'Organic',
    difficulty: 'Olympiad Gold',
    question: 'When (2R,3S)-2-bromo-3-methylpentane is reacted with concentrated sodium ethoxide (NaOEt) at 75°C, what is the major organic product and the operative mechanism?',
    options: [
      '(E)-3-methylpent-2-ene via anti-periplanar E2 elimination',
      '(Z)-3-methylpent-2-ene via E1 elimination',
      '3-methylpent-1-ene via Hofmann elimination',
      '(2R,3R)-3-methylpentan-2-ol via SN2 substitution'
    ],
    correctIndex: 0,
    hint: 'Strong, unhindered base (NaOEt) at elevated temperature favors Zaitsev E2 elimination requiring strict anti-periplanar coplanarity between H and Br.',
    explanation: 'NaOEt is a strong base; at elevated temperatures (75°C), E2 elimination strongly predominates over substitution. According to Zaitsev rule, the more substituted and thermodynamically stable alkene forms. The requirement for anti-periplanar transition state ($180^\\circ$ dihedral angle between C-H and C-Br) across the chiral centers locks the stereochemical outcome into the (E)-diastereomer: (E)-3-methylpent-2-ene.',
    formula: '\\text{Rate} = k[\\text{Substrate}][\\text{Base}], \\quad \\text{Stereochemistry: Anti-periplanar } (180^\\circ)',
    relatedLab: 'organic-chem'
  },
  {
    id: 'q3',
    category: 'Physical',
    difficulty: 'Advanced',
    question: 'For a reaction where the rate constant quadruples ($k_2 = 4k_1$) when the temperature rises from 300 K to 320 K, what is the approximate activation energy ($E_a$)? (Take R = 8.314 J/mol·K, ln 4 ≈ 1.386)',
    options: [
      '55.3 kJ/mol',
      '27.6 kJ/mol',
      '110.6 kJ/mol',
      '14.2 kJ/mol'
    ],
    correctIndex: 0,
    hint: 'Use the two-point Arrhenius equation: ln(k2/k1) = (Ea / R) * (1/T1 - 1/T2).',
    explanation: 'From the Arrhenius equation: $\\ln\\left(\\frac{k_2}{k_1}\\right) = \\frac{E_a}{R}\\left(\\frac{1}{T_1} - \\frac{1}{T_2}\\right)$.\n\n$$\\ln(4) = \\frac{E_a}{8.314} \\cdot \\left(\\frac{1}{300} - \\frac{1}{320}\\right) = \\frac{E_a}{8.314} \\cdot \\left(\\frac{20}{96000}\\right)$$\n\n$$E_a = \\frac{1.386 \\times 8.314 \\times 96000}{20} \\approx 55,310\\text{ J/mol} = 55.3\\text{ kJ/mol}.$$',
    formula: '\\ln\\left(\\frac{k_2}{k_1}\\right) = \\frac{E_a}{R} \\left(\\frac{T_2 - T_1}{T_1 T_2}\\right)',
    relatedLab: 'thermo-kinetics'
  },
  {
    id: 'q4',
    category: 'Inorganic',
    difficulty: 'Foundation',
    question: 'Which of the following molecules possesses a square planar geometry and zero net dipole moment according to VSEPR theory?',
    options: [
      'XeF₄ (Xenon tetrafluoride)',
      'SF₄ (Sulfur tetrafluoride)',
      'CH₄ (Methane)',
      'ClF₄⁺ (Chlorine tetrafluoride cation)'
    ],
    correctIndex: 0,
    hint: 'Look for an AX₄E₂ steric system where two lone pairs occupy opposite axial positions.',
    explanation: 'XeF₄ has 8 valence electrons from Xe + 4 from F = 12 electrons (6 pairs). Steric Number = 4 single bonds + 2 lone pairs = 6 (Octahedral electron geometry). To minimize lp-lp repulsion ($90^\\circ$), the two lone pairs occupy trans-axial positions ($180^\\circ$ apart), leaving the 4 fluorine atoms in a symmetrical Square Planar arrangement with individual bond dipoles canceling to $\\mu = 0\\text{ D}$.',
    formula: '\\text{AX}_4\\text{E}_2 \\implies \\text{Square Planar, } \\mu = 0\\text{ D}',
    relatedLab: 'vsepr-lab'
  },
  {
    id: 'q5',
    category: 'Olympiad',
    difficulty: 'Olympiad Gold',
    question: 'In a standard Daniell Voltaic Cell (Zn | Zn²⁺ || Cu²⁺ | Cu), if [Zn²⁺] is increased from 0.01 M to 1.0 M while [Cu²⁺] remains 1.0 M at 298 K, what happens to the cell potential (E_cell)?',
    options: [
      'Decreases by ~0.059 V',
      'Increases by ~0.059 V',
      'Remains unchanged at E° = 1.10 V',
      'Decreases by ~0.118 V'
    ],
    correctIndex: 0,
    hint: 'Use the Nernst Equation: E_cell = E°_cell - (0.0591/n) · log([Zn²⁺]/[Cu²⁺]) with n = 2.',
    explanation: 'Nernst equation: $E_{\\text{cell}} = E^\\circ - \\frac{0.0591}{2}\\log\\left(\\frac{[\\text{Zn}^{2+}]}{[\\text{Cu}^{2+}]}\\right)$.\n\nInitial: $E_1 = E^\\circ - 0.02955\\log(0.01/1) = E^\\circ + 0.0591\\text{ V}$.\n\nFinal: $E_2 = E^\\circ - 0.02955\\log(1/1) = E^\\circ$.\n\nChange $\\Delta E = E_2 - E_1 = -0.0591\\text{ V}$ (decreases by ~0.059 V).',
    formula: 'E_{\\text{cell}} = E^\\circ - \\frac{0.0592}{n} \\log Q, \\quad Q = \\frac{[\\text{Zn}^{2+}]}{[\\text{Cu}^{2+}]}',
    relatedLab: 'electrochemistry-lab'
  },
  {
    id: 'q6',
    category: 'Quantum',
    difficulty: 'Intermediate',
    question: 'What is the de Broglie wavelength of an electron traveling at 2.0 × 10⁶ m/s? (m_e = 9.11 × 10⁻³¹ kg, h = 6.626 × 10⁻³⁴ J·s)',
    options: [
      '0.364 nm (3.64 Å)',
      '0.728 nm (7.28 Å)',
      '0.182 nm (1.82 Å)',
      '1.092 nm (10.92 Å)'
    ],
    correctIndex: 0,
    hint: 'Apply λ = h / (m · v).',
    explanation: '$$\\lambda = \\frac{h}{p} = \\frac{h}{m_e v} = \\frac{6.626 \\times 10^{-34}\\text{ J}\\cdot\\text{s}}{(9.11 \\times 10^{-31}\\text{ kg})(2.0 \\times 10^6\\text{ m/s})} = 3.637 \\times 10^{-10}\\text{ m} = 0.364\\text{ nm}.$$',
    formula: '\\lambda = \\frac{h}{p} = \\frac{h}{m v}',
    relatedLab: 'quantum-lab'
  }
];

// Rapid-Fire Blitz Pool
const RAPID_FIRE_QUESTIONS = [
  { q: 'Which orbital possesses spherical symmetry?', opts: ['s orbital', 'p orbital', 'd orbital', 'f orbital'], ans: 0, hint: 'l = 0 has no angular dependence.' },
  { q: 'What is the oxidation state of Chromium in Cr₂O₇²⁻?', opts: ['+6', '+3', '+7', '+4'], ans: 0, hint: '2(Cr) + 7(-2) = -2 -> 2(Cr) = 12.' },
  { q: 'Which intermolecular force is strongest in pure liquid water?', opts: ['Hydrogen Bonding', 'London Dispersion', 'Dipole-Induced Dipole', 'Ion-Dipole'], ans: 0, hint: 'H bonded directly to electronegative O.' },
  { q: 'What is the pH of a 0.001 M HCl solution at 25°C?', opts: ['pH = 3.0', 'pH = 1.0', 'pH = 11.0', 'pH = 7.0'], ans: 0, hint: 'pH = -log[H+] = -log(10^-3).' },
  { q: 'Which noble gas has the highest first ionization energy?', opts: ['Helium (He)', 'Neon (Ne)', 'Argon (Ar)', 'Xenon (Xe)'], ans: 0, hint: 'Smallest atomic radius with tightly held 1s² duet.' },
  { q: 'What is the conjugate base of HSO₄⁻?', opts: ['SO₄²⁻', 'H₂SO₄', 'H₃O⁺', 'SO₃'], ans: 0, hint: 'Remove one proton (H⁺).' },
  { q: 'Which hybridization corresponds to a trigonal planar geometry?', opts: ['sp²', 'sp', 'sp³', 'sp³d'], ans: 0, hint: 'Steric number = 3.' },
  { q: 'What happens to the rate of an exothermic reaction when temperature is increased?', opts: ['Increases (rate constant k rises)', 'Decreases', 'Remains unchanged', 'Drops to zero'], ans: 0, hint: 'Higher T increases kinetic collisions & k via Arrhenius.' }
];

interface BalancingTrial {
  id: string;
  reactants: { formula: string; correctCoef: number }[];
  products: { formula: string; correctCoef: number }[];
  title: string;
  hint: string;
}

const BALANCING_TRIALS: BalancingTrial[] = [
  {
    id: 'b1',
    title: 'Combustion of Propane',
    hint: 'Balance Carbon first, then Hydrogen, and finally Oxygen.',
    reactants: [
      { formula: 'C₃H₈', correctCoef: 1 },
      { formula: 'O₂', correctCoef: 5 }
    ],
    products: [
      { formula: 'CO₂', correctCoef: 3 },
      { formula: 'H₂O', correctCoef: 4 }
    ]
  },
  {
    id: 'b2',
    title: 'Roasting of Pyrite (Iron Disulfide)',
    hint: 'Balance Fe, then S, and determine fractional O before clearing denominators.',
    reactants: [
      { formula: 'FeS₂', correctCoef: 4 },
      { formula: 'O₂', correctCoef: 11 }
    ],
    products: [
      { formula: 'Fe₂O₃', correctCoef: 2 },
      { formula: 'SO₂', correctCoef: 8 }
    ]
  },
  {
    id: 'b3',
    title: 'Redox: Potassium Permanganate + Hydrochloric Acid',
    hint: 'MnO4⁻ (Mn VII) reduces to Mn²⁺ (Mn II), while Cl⁻ oxidizes to Cl2 gas.',
    reactants: [
      { formula: 'KMnO₄', correctCoef: 2 },
      { formula: 'HCl', correctCoef: 16 }
    ],
    products: [
      { formula: 'KCl', correctCoef: 2 },
      { formula: 'MnCl₂', correctCoef: 2 },
      { formula: 'H₂O', correctCoef: 8 },
      { formula: 'Cl₂', correctCoef: 5 }
    ]
  }
];

interface QuestionsPlaygroundViewProps {
  onNavigate: (tab: NavigationTab) => void;
}

export const QuestionsPlaygroundView: React.FC<QuestionsPlaygroundViewProps> = ({ onNavigate }) => {
  const [activeMode, setActiveMode] = useState<'quizzes' | 'rapid' | 'daily' | 'balancing'>('quizzes');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('All');
  
  // Quiz state
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);

  // Rapid-Fire Blitz state
  const [rapidActive, setRapidActive] = useState(false);
  const [rapidTimeLeft, setRapidTimeLeft] = useState(60);
  const [rapidQIndex, setRapidQIndex] = useState(0);
  const [rapidScore, setRapidScore] = useState(0);
  const [rapidStreak, setRapidStreak] = useState(0);
  const [rapidGameOver, setRapidGameOver] = useState(false);
  const rapidTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Daily Challenge state
  const [dailyCompleted, setDailyCompleted] = useState(false);
  const [dailySelectedOpt, setDailySelectedOpt] = useState<number | null>(null);
  const [dailySubmitted, setDailySubmitted] = useState(false);

  // Balancing Speed Trial state
  const [trialIndex, setTrialIndex] = useState(0);
  const [reactantCoefs, setReactantCoefs] = useState<number[]>([1, 1]);
  const [productCoefs, setProductCoefs] = useState<number[]>([1, 1]);
  const [isBalancingSolved, setIsBalancingSolved] = useState(false);

  // Puzzles Modal state
  const [isPuzzlesModalOpen, setIsPuzzlesModalOpen] = useState(false);
  const [puzzleModalInitial, setPuzzleModalInitial] = useState<'escape-room' | 'molecular' | 'bond' | 'detective'>('escape-room');

  const currentTrial = BALANCING_TRIALS[trialIndex];

  useEffect(() => {
    if (currentTrial) {
      setReactantCoefs(currentTrial.reactants.map(() => 1));
      setProductCoefs(currentTrial.products.map(() => 1));
      setIsBalancingSolved(false);
    }
  }, [trialIndex]);

  // Rapid-fire timer countdown
  useEffect(() => {
    if (rapidActive && rapidTimeLeft > 0) {
      rapidTimerRef.current = setTimeout(() => {
        setRapidTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (rapidActive && rapidTimeLeft === 0) {
      setRapidActive(false);
      setRapidGameOver(true);
      userPassportStore.recordQuestionSolved(rapidScore, 'Rapid Fire Blitz');
      userPassportStore.unlockBadge('rapid_chemist');
    }
    return () => {
      if (rapidTimerRef.current) clearTimeout(rapidTimerRef.current);
    };
  }, [rapidActive, rapidTimeLeft, rapidScore]);

  const handleStartRapidFire = () => {
    setRapidActive(true);
    setRapidTimeLeft(60);
    setRapidQIndex(0);
    setRapidScore(0);
    setRapidStreak(0);
    setRapidGameOver(false);
  };

  const handleRapidAnswer = (optIdx: number) => {
    if (!rapidActive || rapidGameOver) return;
    const curQ = RAPID_FIRE_QUESTIONS[rapidQIndex % RAPID_FIRE_QUESTIONS.length];
    const isCorrect = optIdx === curQ.ans;

    if (isCorrect) {
      const multiplier = rapidStreak >= 4 ? 3 : rapidStreak >= 2 ? 2 : 1;
      const pts = 20 * multiplier;
      setRapidScore(prev => prev + pts);
      setRapidStreak(prev => prev + 1);
    } else {
      setRapidStreak(0);
    }

    setRapidQIndex(prev => prev + 1);
  };

  const filteredQuestions = PLAYGROUND_QUESTIONS.filter((q) => {
    const matchCat = selectedCategory === 'All' || q.category === selectedCategory;
    const matchDiff = selectedDifficulty === 'All' || q.difficulty === selectedDifficulty;
    return matchCat && matchDiff;
  });

  const activeQuestion = filteredQuestions[currentQIndex] || filteredQuestions[0] || PLAYGROUND_QUESTIONS[0];

  const handleSelectOption = (idx: number) => {
    if (isAnswerSubmitted) return;
    setSelectedOption(idx);
  };

  const handleSubmitAnswer = () => {
    if (selectedOption === null || isAnswerSubmitted) return;
    setIsAnswerSubmitted(true);

    const isCorrect = selectedOption === activeQuestion.correctIndex;
    if (isCorrect) {
      const multiplier = streak >= 3 ? 1.5 : 1;
      const pts = Math.round(25 * multiplier);
      setScore((prev) => prev + pts);
      setStreak((prev) => prev + 1);
      userPassportStore.recordQuestionSolved(pts, activeQuestion.category);
    } else {
      setStreak(0);
    }
  };

  const handleNextQuestion = () => {
    setSelectedOption(null);
    setIsAnswerSubmitted(false);
    setShowHint(false);
    setCurrentQIndex((prev) => (prev < filteredQuestions.length - 1 ? prev + 1 : 0));
  };

  const handleCheckBalancing = () => {
    const reactantsMatch = reactantCoefs.every((c, i) => c === currentTrial.reactants[i].correctCoef);
    const productsMatch = productCoefs.every((c, i) => c === currentTrial.products[i].correctCoef);

    if (reactantsMatch && productsMatch) {
      setIsBalancingSolved(true);
      setScore((prev) => prev + 35);
      userPassportStore.recordQuestionSolved(35, 'Stoichiometry');
      userPassportStore.unlockBadge('equation_master');
    }
  };

  const handleDailySubmit = () => {
    if (dailySelectedOpt === null || dailySubmitted) return;
    setDailySubmitted(true);
    if (dailySelectedOpt === 1) {
      setDailyCompleted(true);
      userPassportStore.recordQuestionSolved(100, 'Daily Challenge');
      userPassportStore.unlockBadge('daily_champion');
    }
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-300">
      {/* Top Banner & Live Stats */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-amber-950/30 via-slate-900 to-indigo-950/30 border border-amber-500/30 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>CHEMISTRY PLAYGROUND & ARENA</span>
          </div>
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight">
            Interactive Challenges & Mini-Games
          </h1>
          <p className="text-sm text-slate-300 font-sans max-w-2xl">
            Test your chemical intuition with 60-second speed blitzes, daily riddles, stoichiometry balancing trials, and the Alchemist Escape Room.
          </p>
        </div>

        {/* Live Score, Streak, and Escape Room Trigger */}
        <div className="flex flex-wrap items-center gap-3 font-mono shrink-0">
          <button
            onClick={() => {
              setPuzzleModalInitial('escape-room');
              setIsPuzzlesModalOpen(true);
            }}
            className="px-4 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-amber-500/20 transition-all"
          >
            <Lock className="w-4 h-4" />
            <span>Escape Room & Puzzles</span>
          </button>
          <div className="p-3 rounded-2xl bg-white/5 border border-amber-500/30 text-center min-w-[80px]">
            <div className="text-[10px] text-slate-400">Playground XP</div>
            <div className="text-lg font-extrabold text-amber-300">+{score}</div>
          </div>
          <div className="p-3 rounded-2xl bg-white/5 border border-orange-500/30 text-center min-w-[80px]">
            <div className="text-[10px] text-slate-400 flex items-center justify-center gap-1">
              <Flame className="w-3 h-3 text-orange-400" />
              <span>Streak</span>
            </div>
            <div className="text-lg font-extrabold text-orange-400">{streak} 🔥</div>
          </div>
        </div>
      </div>

      {/* Mode Switcher Tabs */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 rounded-2xl bg-white/5 border border-white/10 w-fit font-mono text-xs">
        <button
          onClick={() => setActiveMode('quizzes')}
          className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 ${
            activeMode === 'quizzes'
              ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Trophy className="w-4 h-4" />
          <span>Olympiad & Concept Arena</span>
        </button>

        <button
          onClick={() => setActiveMode('rapid')}
          className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 ${
            activeMode === 'rapid'
              ? 'bg-orange-500 text-slate-950 font-bold shadow-md shadow-orange-500/20'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Zap className="w-4 h-4" />
          <span>⚡ 60-Sec Rapid Blitz</span>
        </button>

        <button
          onClick={() => setActiveMode('daily')}
          className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 ${
            activeMode === 'daily'
              ? 'bg-purple-500 text-white font-bold shadow-md shadow-purple-500/20'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Daily Challenge</span>
        </button>

        <button
          onClick={() => setActiveMode('balancing')}
          className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 ${
            activeMode === 'balancing'
              ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Scale className="w-4 h-4" />
          <span>Stoichiometry Balancer</span>
        </button>
      </div>

      {/* ===================================================================== */}
      {/* MODE 1: OLYMPIAD & CONCEPT QUIZZES                                     */}
      {/* ===================================================================== */}
      {activeMode === 'quizzes' && activeQuestion && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono">
          {/* Question Card (2 Cols) */}
          <div className="lg:col-span-2 space-y-6">
            <div className="p-6 sm:p-8 rounded-3xl bg-[#090e1a] border border-cyan-500/20 shadow-xl space-y-6">
              {/* Category & Difficulty Header */}
              <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-white/10 text-xs">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold">
                    {activeQuestion.category}
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-purple-500/20 text-purple-300 border border-purple-500/40">
                    {activeQuestion.difficulty}
                  </span>
                </div>
                <span className="text-slate-400">
                  Question {currentQIndex + 1} of {filteredQuestions.length}
                </span>
              </div>

              {/* Question Text */}
              <div className="space-y-3">
                <h3 className="text-lg sm:text-xl font-bold text-white leading-relaxed font-sans">
                  {activeQuestion.question}
                </h3>
              </div>

              {/* Options */}
              <div className="space-y-3">
                {activeQuestion.options.map((opt, idx) => {
                  const isSelected = selectedOption === idx;
                  const isCorrect = idx === activeQuestion.correctIndex;
                  let optStyle = 'bg-white/[0.02] border-white/10 hover:border-white/20 text-slate-200 hover:bg-white/5';

                  if (isAnswerSubmitted) {
                    if (isCorrect) {
                      optStyle = 'bg-emerald-500/20 border-emerald-400 text-emerald-200 font-bold';
                    } else if (isSelected) {
                      optStyle = 'bg-red-500/20 border-red-400 text-red-200';
                    }
                  } else if (isSelected) {
                    optStyle = 'bg-cyan-500/20 border-cyan-400 text-cyan-200 font-bold shadow-md shadow-cyan-500/10';
                  }

                  return (
                    <div
                      key={idx}
                      onClick={() => handleSelectOption(idx)}
                      className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-center justify-between gap-3 ${optStyle}`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-6 h-6 rounded-lg bg-white/10 flex items-center justify-center text-xs font-bold shrink-0">
                          {String.fromCharCode(65 + idx)}
                        </span>
                        <span className="text-sm font-sans">{opt}</span>
                      </div>
                      {isAnswerSubmitted && isCorrect && (
                        <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                      )}
                      {isAnswerSubmitted && isSelected && !isCorrect && (
                        <XCircle className="w-5 h-5 text-red-400 shrink-0" />
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Actions & Hint Toggle */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-white/10">
                <button
                  onClick={() => setShowHint((prev) => !prev)}
                  className="px-3.5 py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-bold transition-colors flex items-center gap-1.5"
                >
                  <HelpCircle className="w-4 h-4" />
                  <span>{showHint ? 'Hide Hint' : 'Reveal Hint'}</span>
                </button>

                <div className="flex items-center gap-2">
                  {!isAnswerSubmitted ? (
                    <button
                      onClick={handleSubmitAnswer}
                      disabled={selectedOption === null}
                      className={`px-5 py-2.5 rounded-xl font-bold text-xs transition-all flex items-center gap-2 ${
                        selectedOption !== null
                          ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-lg shadow-cyan-500/20'
                          : 'bg-white/10 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      <span>Submit Answer</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={handleNextQuestion}
                      className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-all flex items-center gap-2 shadow-lg shadow-emerald-500/20"
                    >
                      <span>Next Challenge</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Hint Box */}
              {showHint && (
                <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs space-y-1 animate-in fade-in">
                  <div className="font-bold flex items-center gap-1.5 text-amber-300">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Scientific Clue:</span>
                  </div>
                  <p className="font-sans leading-relaxed">{activeQuestion.hint}</p>
                </div>
              )}

              {/* Stepwise LaTeX Solution & Derivation */}
              {isAnswerSubmitted && (
                <div className="p-5 rounded-2xl bg-slate-950 border border-cyan-500/30 space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between text-xs text-cyan-300 font-bold">
                    <span>Comprehensive Derivation & Solution:</span>
                    <button
                      onClick={() => onNavigate(activeQuestion.relatedLab)}
                      className="text-[11px] underline hover:text-cyan-200 flex items-center gap-1"
                    >
                      <span>Explore in {activeQuestion.relatedLab}</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div className="text-xs text-slate-300 font-sans leading-relaxed">
                    <ChemistryMarkdown content={activeQuestion.explanation} />
                  </div>
                  {activeQuestion.formula && (
                    <div className="p-3 rounded-xl bg-cyan-950/20 border border-cyan-500/20 text-center overflow-x-auto">
                      <LatexRenderer latex={activeQuestion.formula} displayMode={true} className="text-cyan-300 text-xs sm:text-sm" />
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Right Sidebar: Filters & Puzzles Hub */}
          <div className="space-y-6">
            {/* Category Filter */}
            <div className="p-5 rounded-3xl bg-white/[0.02] border border-white/10 space-y-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Filter className="w-3.5 h-3.5 text-cyan-400" />
                <span>Discipline Filter</span>
              </h4>
              <div className="flex flex-wrap gap-2 text-xs">
                {['All', 'Olympiad', 'Quantum', 'Organic', 'Physical', 'Inorganic'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => {
                      setSelectedCategory(cat);
                      setCurrentQIndex(0);
                      setSelectedOption(null);
                      setIsAnswerSubmitted(false);
                    }}
                    className={`px-3 py-1.5 rounded-xl transition-all ${
                      selectedCategory === cat
                        ? 'bg-cyan-500 text-slate-950 font-bold'
                        : 'bg-white/5 text-slate-400 hover:text-white'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Mini-Games Showcase */}
            <div className="p-5 rounded-3xl bg-gradient-to-br from-indigo-950/40 to-slate-900 border border-indigo-500/30 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-300">
                  <Boxes className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Chemical Puzzles Hub</h4>
                  <p className="text-[10px] text-slate-400">Interactive Mini-Games</p>
                </div>
              </div>
              <p className="text-xs text-slate-300 font-sans">
                Assemble organic molecules atom by atom, balance crystal lattices, and deduce mystery elements in periodic detective mode.
              </p>
              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => {
                    setPuzzleModalInitial('molecular');
                    setIsPuzzlesModalOpen(true);
                  }}
                  className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-indigo-500/30 text-indigo-200 text-xs font-bold text-center"
                >
                  Molecular Assembly
                </button>
                <button
                  onClick={() => {
                    setPuzzleModalInitial('detective');
                    setIsPuzzlesModalOpen(true);
                  }}
                  className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-indigo-500/30 text-indigo-200 text-xs font-bold text-center"
                >
                  Periodic Detective
                </button>
              </div>
            </div>

            {/* ChemoBot Quick Help Box */}
            <div className="p-5 rounded-3xl bg-gradient-to-br from-purple-950/40 to-slate-900 border border-purple-500/30 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-300">
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">ChemoBot AI Assistant</h4>
                  <p className="text-[10px] text-slate-400">Stepwise chemistry guidance</p>
                </div>
              </div>
              <p className="text-xs text-slate-300 font-sans">
                Need more help dissecting this problem? Ask ChemoBot for alternative mechanisms, molecular orbital drawings, or numerical shortcuts.
              </p>
              <button
                onClick={() => onNavigate('ai-tutor')}
                className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs transition-colors flex items-center justify-center gap-2 shadow-md shadow-purple-600/20"
              >
                <span>Ask ChemoBot AI</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODE 2: 60-SEC RAPID BLITZ                                             */}
      {/* ===================================================================== */}
      {activeMode === 'rapid' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-[#090e1a] border border-orange-500/30 shadow-2xl space-y-6 font-mono">
          {!rapidActive && !rapidGameOver && (
            <div className="text-center py-12 space-y-5 max-w-xl mx-auto">
              <div className="w-20 h-20 rounded-3xl bg-orange-500/20 border border-orange-400/50 flex items-center justify-center mx-auto text-orange-400 animate-pulse">
                <Zap className="w-10 h-10" />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-black text-white">60-Second Chemistry Blitz</h3>
                <p className="text-xs sm:text-sm text-slate-300 font-sans">
                  Answer as many rapid-fire chemistry questions as you can in 60 seconds. Consecutive correct answers build your multiplier combo up to 3x!
                </p>
              </div>
              <button
                onClick={handleStartRapidFire}
                className="px-8 py-3.5 rounded-2xl bg-orange-500 hover:bg-orange-400 text-slate-950 font-black text-sm tracking-wider shadow-lg shadow-orange-500/30 transition-all inline-flex items-center gap-2"
              >
                <Play className="w-5 h-5 fill-slate-950" />
                <span>START RAPID BLITZ (60s)</span>
              </button>
            </div>
          )}

          {rapidActive && (
            <div className="space-y-6">
              {/* Header Bar: Timer & Combo */}
              <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-950/80 border border-orange-500/30">
                <div className="flex items-center gap-3">
                  <Clock className={`w-6 h-6 ${rapidTimeLeft <= 10 ? 'text-red-400 animate-ping' : 'text-orange-400'}`} />
                  <div className="text-xl font-black text-white">
                    {rapidTimeLeft}s <span className="text-xs text-slate-400 font-normal">remaining</span>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-xs text-orange-300 font-bold bg-orange-500/20 px-3 py-1.5 rounded-xl border border-orange-500/40">
                    Combo: {rapidStreak}x {rapidStreak >= 2 && '🔥 MULTIPLIER ACTIVE'}
                  </div>
                  <div className="text-lg font-black text-amber-300 font-mono">
                    Score: {rapidScore} XP
                  </div>
                </div>
              </div>

              {/* Active Blitz Question */}
              {(() => {
                const cur = RAPID_FIRE_QUESTIONS[rapidQIndex % RAPID_FIRE_QUESTIONS.length];
                return (
                  <div className="p-6 sm:p-8 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-6">
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <span>Rapid Round #{rapidQIndex + 1}</span>
                      <span className="text-orange-300">Quick Recall</span>
                    </div>
                    <h3 className="text-lg sm:text-xl font-bold text-white font-sans">{cur.q}</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {cur.opts.map((opt, oIdx) => (
                        <button
                          key={oIdx}
                          onClick={() => handleRapidAnswer(oIdx)}
                          className="p-4 rounded-xl bg-slate-900 hover:bg-orange-500/20 border border-slate-700 hover:border-orange-400/60 text-left text-sm text-slate-100 font-sans transition-all flex items-center gap-3"
                        >
                          <span className="w-6 h-6 rounded bg-white/10 flex items-center justify-center text-xs font-mono font-bold shrink-0">
                            {String.fromCharCode(65 + oIdx)}
                          </span>
                          <span>{opt}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {rapidGameOver && (
            <div className="text-center py-10 space-y-5 max-w-lg mx-auto">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center mx-auto text-emerald-400">
                <Trophy className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold text-white">Blitz Round Completed!</h3>
              <p className="text-sm text-slate-300 font-sans">
                You scored <strong className="text-amber-300">{rapidScore} XP</strong> across {rapidQIndex} questions and earned the <strong>Rapid Chemist</strong> achievement!
              </p>
              <button
                onClick={handleStartRapidFire}
                className="px-6 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-400 text-slate-950 font-bold text-xs transition-all inline-flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                Play Again
              </button>
            </div>
          )}
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODE 3: DAILY CHEMISTRY CHALLENGE                                     */}
      {/* ===================================================================== */}
      {activeMode === 'daily' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-[#090e1a] border border-purple-500/30 shadow-2xl space-y-6 font-mono">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
            <div>
              <span className="text-[10px] uppercase tracking-wider px-2.5 py-1 rounded bg-purple-500/20 text-purple-300 border border-purple-500/40 font-bold">
                Daily Chemistry Challenge
              </span>
              <h3 className="text-xl font-bold text-white mt-1 font-sans">Mystery Reaction of the Day</h3>
            </div>
            <div className="text-xs text-amber-300 bg-amber-500/10 px-3 py-1.5 rounded-xl border border-amber-500/30 font-bold">
              Reward: +100 XP + Daily Streak
            </div>
          </div>

          <div className="space-y-4">
            <p className="text-sm text-slate-200 font-sans leading-relaxed">
              <strong>Scenario:</strong> An unknown white crystalline solid dissolves in water to form a colorless solution. When aqueous sodium hydroxide (NaOH) is added dropwise, a white precipitate forms that redissolves in excess NaOH to form a clear solution. When aqueous ammonia (NH₃) is added instead, a white precipitate forms that remains insoluble in excess ammonia. What is the metallic cation?
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-sans">
              {[
                'Zinc (Zn²⁺) — amphoteric hydroxide soluble in both excess NaOH and excess NH₃',
                'Aluminium (Al³⁺) — amphoteric Al(OH)₃ soluble in excess NaOH ([Al(OH)₄]⁻) but insoluble in excess NH₃',
                'Magnesium (Mg²⁺) — basic Mg(OH)₂ insoluble in both excess NaOH and excess NH₃',
                'Copper(II) (Cu²⁺) — blue precipitate soluble in excess NH₃ to form royal blue [Cu(NH₃)₄]²⁺'
              ].map((opt, idx) => {
                const isSelected = dailySelectedOpt === idx;
                let style = 'bg-slate-900 border-slate-800 text-slate-200 hover:border-slate-700';
                if (dailySubmitted) {
                  if (idx === 1) style = 'bg-emerald-500/20 border-emerald-400 text-emerald-200 font-bold';
                  else if (isSelected) style = 'bg-red-500/20 border-red-400 text-red-200';
                } else if (isSelected) {
                  style = 'bg-purple-500/20 border-purple-400 text-purple-200 font-bold';
                }

                return (
                  <div
                    key={idx}
                    onClick={() => !dailySubmitted && setDailySelectedOpt(idx)}
                    className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-start gap-3 ${style}`}
                  >
                    <span className="w-6 h-6 rounded-lg bg-white/10 flex items-center justify-center text-xs font-mono font-bold shrink-0 mt-0.5">
                      {String.fromCharCode(65 + idx)}
                    </span>
                    <span className="text-xs sm:text-sm">{opt}</span>
                  </div>
                );
              })}
            </div>

            {!dailySubmitted ? (
              <button
                onClick={handleDailySubmit}
                disabled={dailySelectedOpt === null}
                className="px-6 py-2.5 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-bold text-xs transition-all shadow-lg shadow-purple-500/20 disabled:opacity-40"
              >
                Submit Daily Deduction
              </button>
            ) : dailyCompleted ? (
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs sm:text-sm flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                <span>Spot on! Aluminium forms amphoteric aluminate [Al(OH)₄]⁻ in strong base, but ammonia is too weak a base to dissolve it (+100 XP).</span>
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs sm:text-sm flex items-center gap-3">
                <XCircle className="w-5 h-5 shrink-0" />
                <span>Incorrect. Review amphoteric hydroxide behavior with sodium hydroxide vs aqueous ammonia.</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODE 4: STOICHIOMETRIC BALANCING SPEED TRIAL                          */}
      {/* ===================================================================== */}
      {activeMode === 'balancing' && currentTrial && (
        <div className="p-6 sm:p-8 rounded-3xl bg-[#090e1a] border border-cyan-500/20 shadow-xl space-y-6 font-mono">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/10">
            <div className="space-y-1">
              <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold">
                Speed Trial {trialIndex + 1} of {BALANCING_TRIALS.length}
              </span>
              <h3 className="text-xl font-bold text-white">{currentTrial.title}</h3>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setTrialIndex((prev) => (prev > 0 ? prev - 1 : BALANCING_TRIALS.length - 1))}
                className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs border border-white/10"
              >
                Prev Trial
              </button>
              <button
                onClick={() => setTrialIndex((prev) => (prev < BALANCING_TRIALS.length - 1 ? prev + 1 : 0))}
                className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs border border-white/10"
              >
                Next Trial
              </button>
            </div>
          </div>

          <p className="text-xs text-slate-300 font-sans">
            Adjust the stoichiometric integer coefficients until the number of atoms for every element matches on both sides.
          </p>

          {/* Interactive Chemical Equation Bench */}
          <div className="p-6 rounded-2xl bg-slate-950/80 border border-cyan-500/30 flex flex-wrap items-center justify-center gap-4 text-base sm:text-lg text-white">
            {/* Reactants */}
            <div className="flex flex-wrap items-center gap-3">
              {currentTrial.reactants.map((r, rIdx) => (
                <div key={rIdx} className="flex items-center gap-2">
                  {rIdx > 0 && <span className="text-slate-400 font-bold">+</span>}
                  <div className="flex items-center gap-1 bg-white/5 border border-cyan-500/40 rounded-xl p-1">
                    <button
                      onClick={() => {
                        const copy = [...reactantCoefs];
                        copy[rIdx] = Math.max(1, copy[rIdx] - 1);
                        setReactantCoefs(copy);
                      }}
                      className="w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 text-cyan-300 text-sm font-bold flex items-center justify-center"
                    >
                      -
                    </button>
                    <span className="w-8 text-center font-bold text-cyan-300">{reactantCoefs[rIdx]}</span>
                    <button
                      onClick={() => {
                        const copy = [...reactantCoefs];
                        copy[rIdx] = copy[rIdx] + 1;
                        setReactantCoefs(copy);
                      }}
                      className="w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 text-cyan-300 text-sm font-bold flex items-center justify-center"
                    >
                      +
                    </button>
                  </div>
                  <span className="font-bold tracking-wide">{r.formula}</span>
                </div>
              ))}
            </div>

            {/* Reaction Arrow */}
            <div className="text-cyan-400 font-black text-2xl px-2">→</div>

            {/* Products */}
            <div className="flex flex-wrap items-center gap-3">
              {currentTrial.products.map((p, pIdx) => (
                <div key={pIdx} className="flex items-center gap-2">
                  {pIdx > 0 && <span className="text-slate-400 font-bold">+</span>}
                  <div className="flex items-center gap-1 bg-white/5 border border-purple-500/40 rounded-xl p-1">
                    <button
                      onClick={() => {
                        const copy = [...productCoefs];
                        copy[pIdx] = Math.max(1, copy[pIdx] - 1);
                        setProductCoefs(copy);
                      }}
                      className="w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 text-purple-300 text-sm font-bold flex items-center justify-center"
                    >
                      -
                    </button>
                    <span className="w-8 text-center font-bold text-purple-300">{productCoefs[pIdx]}</span>
                    <button
                      onClick={() => {
                        const copy = [...productCoefs];
                        copy[pIdx] = copy[pIdx] + 1;
                        setProductCoefs(copy);
                      }}
                      className="w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 text-purple-300 text-sm font-bold flex items-center justify-center"
                    >
                      +
                    </button>
                  </div>
                  <span className="font-bold tracking-wide">{p.formula}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Validation & Solution Status */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
            <div className="text-xs text-amber-300 font-sans flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Hint: {currentTrial.hint}</span>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={handleCheckBalancing}
                className="px-6 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all flex items-center gap-2 shadow-lg shadow-cyan-500/20"
              >
                <Check className="w-4 h-4" />
                <span>Verify Balanced Equation</span>
              </button>
            </div>
          </div>

          {/* Success Banner */}
          {isBalancingSolved && (
            <div className="p-5 rounded-2xl bg-emerald-950/50 border border-emerald-400 text-emerald-200 space-y-2 animate-in fade-in">
              <div className="flex items-center gap-2 font-bold text-sm text-emerald-300">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <span>Stoichiometrically Perfect! +35 XP Awarded</span>
              </div>
              <p className="text-xs text-emerald-200/90 font-sans">
                Every atom obeys the Law of Conservation of Mass (Mass of Reactants = Mass of Products).
              </p>
            </div>
          )}
        </div>
      )}

      {/* Puzzles Modal Component */}
      <ChemistryPuzzlesModal
        isOpen={isPuzzlesModalOpen}
        onClose={() => setIsPuzzlesModalOpen(false)}
        initialPuzzle={puzzleModalInitial}
        onNavigateToTab={onNavigate}
      />
    </div>
  );
};

