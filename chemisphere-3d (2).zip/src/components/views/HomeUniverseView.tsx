import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Atom,
  Grid3X3,
  Orbit,
  Boxes,
  Zap,
  Scale,
  FlaskConical,
  Sparkles,
  Calculator,
  ChevronRight,
  GraduationCap,
  Crown,
  Bot,
  Activity,
  Compass,
  Layers,
  Flame,
  Binary,
  Radio,
  Clock,
  ArrowUpRight,
  Sliders,
  CheckCircle2,
  ChevronDown,
  Trophy,
  Archive,
  UserCheck,
  Award,
  Map as MapIcon
} from 'lucide-react';
import { HeroParticleField3D } from '../3d/HeroParticleField3D';
import { NavigationTab, ChemicalElement } from '../../types';
import { MOLECULES_DATA } from '../../data/molecules';
import { getElementByNumber, ALL_118_ELEMENTS } from '../../data/elements';
import { getRecentLabs, RecentLabEntry } from '../../data/sessionHistory';
import { getUserProfile, UserProfile } from '../../data/userProfile';

interface HomeUniverseViewProps {
  onNavigate: (tab: NavigationTab) => void;
}

type ScientificDomainId =
  | 'all'
  | 'atomic'
  | 'quantum'
  | 'molecular'
  | 'physical'
  | 'analytical'
  | 'nuclear'
  | 'organic';

interface ScientificDomain {
  id: ScientificDomainId;
  name: string;
  discipline: string;
  tagline: string;
  themeColor: string;
  fontClass: string;
  accentBorder: string;
  accentBg: string;
  primaryLab: NavigationTab;
  modules: {
    tab: NavigationTab;
    title: string;
    description: string;
    instrument: string;
    icon: React.ComponentType<{ className?: string }>;
    metric: string;
  }[];
}

export const HomeUniverseView: React.FC<HomeUniverseViewProps> = ({ onNavigate }) => {
  const [selectedDomain, setSelectedDomain] = useState<ScientificDomainId>('all');
  const [recentLabs, setRecentLabs] = useState<RecentLabEntry[]>([]);
  const [userProfile, setUserProfileState] = useState<UserProfile>(() => getUserProfile());
  
  // Interactive Rydberg Bohr Jumper state
  const [rydbergN1, setRydbergN1] = useState<number>(2); // Balmer series base
  const [rydbergN2, setRydbergN2] = useState<number>(3); // Initial higher state
  
  // Interactive Quick Element Lens
  const [lensZ, setLensZ] = useState<number>(6); // Carbon default
  const activeElement = getElementByNumber(lensZ) || ALL_118_ELEMENTS[5];

  // Interactive VSEPR test
  const [vseprSteric, setVseprSteric] = useState<number>(4);
  const [vseprLonePairs, setVseprLonePairs] = useState<number>(0);

  // Load recent labs and listen to changes
  useEffect(() => {
    setRecentLabs(getRecentLabs());
    const handleUpdate = () => {
      setRecentLabs(getRecentLabs());
      setUserProfileState(getUserProfile());
    };
    window.addEventListener('chemisphere_history_updated', handleUpdate);
    window.addEventListener('chemisphere_profile_updated', handleUpdate);
    return () => {
      window.removeEventListener('chemisphere_history_updated', handleUpdate);
      window.removeEventListener('chemisphere_profile_updated', handleUpdate);
    };
  }, []);

  // Rydberg calculation: 1/lambda = R_H * (1/n1^2 - 1/n2^2) -> lambda in nm
  const rydbergWavelength = (() => {
    if (rydbergN2 <= rydbergN1) return 0;
    const R_H = 1.097373e7; // m^-1
    const invLambda = R_H * (1 / (rydbergN1 * rydbergN1) - 1 / (rydbergN2 * rydbergN2));
    const lambdaMeters = 1 / invLambda;
    return Math.round(lambdaMeters * 1e9 * 10) / 10; // nm
  })();

  const getSpectralColor = (nm: number) => {
    if (nm < 380) return { bg: 'bg-purple-950/80', border: 'border-purple-500', text: 'text-purple-300', label: 'UV (Invisible)' };
    if (nm < 440) return { bg: 'bg-violet-600', border: 'border-violet-400', text: 'text-violet-200', label: 'Violet Emission' };
    if (nm < 490) return { bg: 'bg-blue-600', border: 'border-blue-400', text: 'text-blue-200', label: 'Blue Emission' };
    if (nm < 560) return { bg: 'bg-emerald-600', border: 'border-emerald-400', text: 'text-emerald-200', label: 'Cyan-Green' };
    if (nm < 620) return { bg: 'bg-amber-500', border: 'border-amber-400', text: 'text-amber-100', label: 'Yellow-Orange' };
    if (nm <= 750) return { bg: 'bg-rose-600', border: 'border-rose-400', text: 'text-rose-200', label: 'Red Emission' };
    return { bg: 'bg-red-950/80', border: 'border-red-500', text: 'text-red-300', label: 'Infrared' };
  };

  const spectralInfo = getSpectralColor(rydbergWavelength);

  // VSEPR geometry mapping
  const getVseprGeometry = (steric: number, lp: number) => {
    const bp = steric - lp;
    if (steric === 2) return { name: 'Linear', angle: '180°', hyb: 'sp', formula: 'AX₂' };
    if (steric === 3) {
      if (lp === 1) return { name: 'Bent / Angular', angle: '< 120° (~118°)', hyb: 'sp²', formula: 'AX₂E' };
      return { name: 'Trigonal Planar', angle: '120°', hyb: 'sp²', formula: 'AX₃' };
    }
    if (steric === 4) {
      if (lp === 1) return { name: 'Trigonal Pyramidal', angle: '107.5°', hyb: 'sp³', formula: 'AX₃E (NH₃)' };
      if (lp === 2) return { name: 'Bent / V-Shaped', angle: '104.5°', hyb: 'sp³', formula: 'AX₂E₂ (H₂O)' };
      return { name: 'Tetrahedral', angle: '109.5°', hyb: 'sp³', formula: 'AX₄ (CH₄)' };
    }
    if (steric === 5) {
      if (lp === 1) return { name: 'Seesaw', angle: '90° & 120°', hyb: 'sp³d', formula: 'AX₄E (SF₄)' };
      if (lp === 2) return { name: 'T-Shaped', angle: '90°', hyb: 'sp³d', formula: 'AX₃E₂ (ClF₃)' };
      if (lp === 3) return { name: 'Linear', angle: '180°', hyb: 'sp³d', formula: 'AX₂E₃ (XeF₂)' };
      return { name: 'Trigonal Bipyramidal', angle: '90° & 120°', hyb: 'sp³d', formula: 'AX₅ (PCl₅)' };
    }
    if (steric === 6) {
      if (lp === 1) return { name: 'Square Pyramidal', angle: '90°', hyb: 'sp³d²', formula: 'AX₅E (BrF₅)' };
      if (lp === 2) return { name: 'Square Planar', angle: '90°', hyb: 'sp³d²', formula: 'AX₄E₂ (XeF₄)' };
      return { name: 'Octahedral', angle: '90°', hyb: 'sp³d²', formula: 'AX₆ (SF₆)' };
    }
    return { name: 'Linear', angle: '180°', hyb: 'sp', formula: 'AX₂' };
  };

  const currentVsepr = getVseprGeometry(vseprSteric, Math.min(vseprLonePairs, vseprSteric - 2));

  // Scientific Domains Definition with intentional typography and specific atmospheres
  const SCIENTIFIC_DOMAINS: ScientificDomain[] = [
    {
      id: 'atomic',
      name: 'Atomic Physics & Periodic Law',
      discipline: 'Atomic Physics',
      tagline: '118 Elements, Quantized Shells & Periodic Law',
      themeColor: 'cyan',
      fontClass: 'font-periodic',
      accentBorder: 'border-cyan-500/30 hover:border-cyan-400/60',
      accentBg: 'bg-cyan-500/5',
      primaryLab: 'periodic-table',
      modules: [
        {
          tab: 'periodic-table',
          title: 'Periodic Table (118 Elements)',
          description: 'High-density interactive matrix with electronegativity, ionization energy, atomic radius heatmaps, and state-of-matter slider.',
          instrument: 'IUPAC 2026 Registry',
          icon: Grid3X3,
          metric: '118 Verified Elements'
        },
        {
          tab: 'atomic-structure',
          title: 'History of Atomic Models',
          description: 'From Dalton and Thomson plum-pudding to Rutherford gold foil scattering, Bohr orbits, and modern wave mechanics.',
          instrument: 'Alpha Scattering Chamber',
          icon: Zap,
          metric: 'Quantized Bohr Shells'
        },
        {
          tab: 'stoichiometry',
          title: 'Stoichiometry & Reaction Balancer',
          description: 'Matrix algebra chemical equation balancer, limiting reactant determination, molar yield, and gas volume computations.',
          instrument: 'Linear Solver Engine',
          icon: Scale,
          metric: 'Real-time Matrix Balancer'
        }
      ]
    },
    {
      id: 'quantum',
      name: 'Quantum Mechanics & Spectroscopy',
      discipline: 'Quantum & Spectroscopy',
      tagline: 'Wavefunctions, Eigenstates & Spectral Fingerprints',
      themeColor: 'purple',
      fontClass: 'font-quantum',
      accentBorder: 'border-purple-500/30 hover:border-purple-400/60',
      accentBg: 'bg-purple-500/5',
      primaryLab: 'orbital-atlas',
      modules: [
        {
          tab: 'orbital-atlas',
          title: '3D Quantum Orbital Atlas',
          description: 'Exact Schrödinger wave equations for 1s, 2p, 3d, 4f subshells with probability density isosurfaces and angular nodal planes.',
          instrument: '3D WebGL Spherical Harmonics',
          icon: Orbit,
          metric: 's, p, d, f Hydrogenic Solvers'
        },
        {
          tab: 'atomic-spectra',
          title: 'Atomic Spectra & Flame Lab',
          description: 'Rydberg electron transition engine (Lyman, Balmer, Paschen, Brackett, Pfund) and Bunsen flame test analytical emission lines.',
          instrument: 'Precision Spectrometer',
          icon: Sparkles,
          metric: '1/λ = R_H(1/n₁² - 1/n₂²)'
        },
        {
          tab: 'spectroscopy-suite',
          title: 'Spectroscopy Suite (5 Instruments)',
          description: 'Beer-Lambert UV-Vis, FTIR functional groups, 1H-NMR chemical shift & spin coupling, Mass Spec m/z, and XRD Bragg diffraction.',
          instrument: 'Analytical Multi-Spectrometer',
          icon: Activity,
          metric: 'UV-Vis / FTIR / NMR / MS / XRD'
        },
        {
          tab: 'quantum-lab',
          title: 'Quantum Mechanics Laboratory',
          description: 'Particle-in-a-box ψ(x) & |ψ(x)|², wave packet potential barrier tunnelling, and photoelectric stopping potential.',
          instrument: 'Schrödinger Box Simulator',
          icon: Zap,
          metric: 'E_n = n²h² / (8mL²)'
        },
        {
          tab: 'waves-radiation',
          title: 'Waves & EM Radiation Lab',
          description: 'Traveling & standing wave harmonics, 2-source wave superposition, 3D orthogonal E-B fields, and 7-band EM spectrum.',
          instrument: 'Electromagnetic Field Engine',
          icon: Radio,
          metric: 'c = λν & E = hν'
        }
      ]
    },
    {
      id: 'molecular',
      name: 'Molecular Architecture & Bonding',
      discipline: 'Molecular Architecture',
      tagline: '3D CAD, Hybridization & Stereochemistry',
      themeColor: 'emerald',
      fontClass: 'font-organic',
      accentBorder: 'border-emerald-500/30 hover:border-emerald-400/60',
      accentBg: 'bg-emerald-500/5',
      primaryLab: 'molecules-3d',
      modules: [
        {
          tab: 'molecules-3d',
          title: '3D Molecular Simulator & CAD',
          description: 'Ball-and-stick and space-filling CPK molecular models with live bond distance measurement and dihedral angle inspection.',
          instrument: 'WebGL Coordinate Engine',
          icon: Boxes,
          metric: 'PDB / XYZ Molecular CAD'
        },
        {
          tab: 'vsepr-lab',
          title: 'VSEPR Theory & Hybridization',
          description: 'Valence Shell Electron Pair Repulsion simulator from Linear to Octahedral geometry with lone-pair angle distortions.',
          instrument: 'Electrostatic Repulsion Model',
          icon: Atom,
          metric: 'sp, sp², sp³, sp³d, sp³d²'
        },
        {
          tab: 'advanced-organic',
          title: 'Advanced Organic Synthesis Lab',
          description: 'Curved-arrow electron pushing mechanisms (SN1, SN2, EAS, Diels-Alder), retrosynthetic disconnections, and CIP stereocenters.',
          instrument: 'Curved Arrow Synthesis Studio',
          icon: Sparkles,
          metric: 'Chirality & Reaction Paths'
        }
      ]
    },
    {
      id: 'physical',
      name: 'Physical Chemistry & Kinetics',
      discipline: 'Thermodynamics & Rates',
      tagline: 'Reaction Energetics, Calorimetry & Phase Equilibria',
      themeColor: 'orange',
      fontClass: 'font-physical',
      accentBorder: 'border-orange-500/30 hover:border-orange-400/60',
      accentBg: 'bg-orange-500/5',
      primaryLab: 'thermo-kinetics',
      modules: [
        {
          tab: 'thermo-kinetics',
          title: 'Thermodynamics & Reaction Kinetics',
          description: 'Born-Haber cycles, bomb calorimetry, 2D particle collision kinetics, Arrhenius activation energy, and Le Chatelier shifts.',
          instrument: 'Calorimeter & Rate Engine',
          icon: Flame,
          metric: 'ΔG° = ΔH° - TΔS°'
        },
        {
          tab: 'physical-chem',
          title: 'Physical Chemistry Engine',
          description: 'Ideal vs van der Waals gas laws, Maxwell-Boltzmann velocity distributions, and Raoult solution colligative properties.',
          instrument: 'PVT Equation Simulator',
          icon: FlaskConical,
          metric: '(P + a/V²)(V - b) = RT'
        },
        {
          tab: 'formula-vault',
          title: 'Formula Vault & Constants',
          description: 'Interactive computational equations across chemistry with fundamental physical constants and stepwise metric conversion.',
          instrument: 'Computational Math Core',
          icon: Calculator,
          metric: '24 Stepwise Equation Engines'
        }
      ]
    },
    {
      id: 'analytical',
      name: 'Analytical & Electrochemistry',
      discipline: 'Analytical & Electrochemical',
      tagline: 'Potentiometry, Buffers & Quantitative Analysis',
      themeColor: 'teal',
      fontClass: 'font-spectroscopy',
      accentBorder: 'border-teal-500/30 hover:border-teal-400/60',
      accentBg: 'bg-teal-500/5',
      primaryLab: 'electrochemistry-lab',
      modules: [
        {
          tab: 'electrochemistry-lab',
          title: 'Electrochemistry & Battery Lab',
          description: 'Daniell Galvanic cell redox simulation, dynamic Nernst potential adjustments, and Li-ion intercalation battery cell mechanics.',
          instrument: 'Potentiostat Simulator',
          icon: Zap,
          metric: 'E = E° - (RT/nF)ln(Q)'
        },
        {
          tab: 'analytical-lab',
          title: 'Analytical & Environmental Chemistry',
          description: 'Acid-base titration curve analysis with indicator transition ranges, Henderson-Hasselbalch buffer calculations, and HPLC.',
          instrument: 'Digital Burette & Buffer Studio',
          icon: Scale,
          metric: 'pH = pKa + log([A⁻]/[HA])'
        }
      ]
    },
    {
      id: 'nuclear',
      name: 'Nuclear & Cosmic Chemistry',
      discipline: 'Nuclear & Astrochemistry',
      tagline: 'Stellar Nucleosynthesis, Decay & Exhibition',
      themeColor: 'rose',
      fontClass: 'font-beauty',
      accentBorder: 'border-rose-500/30 hover:border-rose-400/60',
      accentBg: 'bg-rose-500/5',
      primaryLab: 'beauty-of-chemistry',
      modules: [
        {
          tab: 'beauty-of-chemistry',
          title: 'The Beauty of Chemistry (Exhibition)',
          description: 'Thirteen-chapter cinematic scientific exhibition exploring cosmic nucleosynthesis, crystalline geometries, and harmonic acoustics.',
          instrument: 'Cinematic Exhibition Suite',
          icon: Sparkles,
          metric: '13 Master Chapters'
        },
        {
          tab: 'nuclear-chemistry',
          title: 'Nuclear Chemistry & Decay Lab',
          description: 'Monte Carlo stochastic nuclear decay simulator, Fe-56 binding energy curve, and D-T nuclear fusion / U-235 fission reactors.',
          instrument: 'Monte Carlo Decay Counter',
          icon: Atom,
          metric: 'N(t) = N₀ e^(-λt)'
        }
      ]
    }
  ];

  const displayedDomains = selectedDomain === 'all' 
    ? SCIENTIFIC_DOMAINS 
    : SCIENTIFIC_DOMAINS.filter(d => d.id === selectedDomain);

  return (
    <div className="relative min-h-screen pb-24 overflow-hidden">
      {/* 3D Ambient Particle Background */}
      <HeroParticleField3D />

      {/* Main Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-3.5 sm:px-6 pt-6 sm:pt-8 space-y-8">
        
        {/* ========================================================================= */}
        {/* SECTION 1: SCIENTIFIC COMMAND CENTER (HERO WORKSPACE)                     */}
        {/* ========================================================================= */}
        <section className="relative rounded-3xl bg-slate-900/60 dark:bg-slate-950/80 border border-slate-700/40 dark:border-white/10 p-6 sm:p-10 backdrop-blur-2xl shadow-2xl overflow-hidden">
          {/* Subtle Ambient Light Cone */}
          <div className="absolute -top-24 -right-24 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
            
            {/* Left: Scientific Purpose & Identity */}
            <div className="flex-1 space-y-4 max-w-2xl">
              {/* Scientific Tag */}
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-mono">
                <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,197,254,0.8)] animate-pulse" />
                <span className="font-bold tracking-wider">CHEMISPHERE 3D // SCIENTIFIC OS</span>
              </div>

              {/* Display Headline */}
              <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight font-home">
                Where Chemistry Becomes <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-purple-400">
                  Visible, Tactile & Computable.
                </span>
              </h1>

              {/* Subtext */}
              <p className="text-sm sm:text-base text-slate-300 font-light leading-relaxed">
                An interactive 3D laboratory spanning quantum wavefunctions, 118 periodic elements, 
                ball-and-stick molecular CAD, multi-instrument spectroscopy, and step-by-step AI reasoning.
              </p>

              {/* Quick Launch Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <motion.button
                  whileHover={{ scale: 1.02, y: -1 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => onNavigate('chemistry-map')}
                  className="bg-amber-400 hover:bg-amber-300 text-slate-950 px-5 py-2.5 rounded-xl text-xs font-bold font-mono tracking-wider shadow-lg shadow-amber-500/20 transition-all flex items-center gap-2"
                >
                  <MapIcon className="w-4 h-4 text-amber-950" />
                  <span>🗺️ CHEMISTRY WORLD MAP</span>
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.02, y: -1 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => onNavigate('periodic-table')}
                  className="bg-cyan-400 hover:bg-cyan-300 text-slate-950 px-4 sm:px-5 py-2.5 rounded-xl text-xs font-bold font-mono tracking-wider shadow-lg shadow-cyan-500/20 transition-all flex items-center gap-2"
                >
                  <Grid3X3 className="w-4 h-4" />
                  <span>118 ELEMENTS</span>
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.02, y: -1 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => onNavigate('orbital-atlas')}
                  className="bg-purple-600/30 hover:bg-purple-600/40 text-purple-200 border border-purple-400/40 px-4 sm:px-5 py-2.5 rounded-xl text-xs font-bold font-mono tracking-wider transition-all flex items-center gap-2"
                >
                  <Orbit className="w-4 h-4 text-purple-300" />
                  <span>3D ORBITALS</span>
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.02, y: -1 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => onNavigate('lab-directory')}
                  className="bg-white/5 hover:bg-white/10 border border-white/15 px-4 sm:px-5 py-2.5 rounded-xl text-slate-200 text-xs font-semibold font-mono tracking-wider transition-all flex items-center gap-2"
                >
                  <Compass className="w-4 h-4 text-cyan-400" />
                  <span>KNOWLEDGE MAP</span>
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.02, y: -1 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => onNavigate('ai-tutor')}
                  className="bg-purple-500/15 hover:bg-purple-500/25 border border-purple-500/30 px-4 sm:px-5 py-2.5 rounded-xl text-purple-300 text-xs font-semibold font-mono tracking-wider transition-all flex items-center gap-2"
                >
                  <Bot className="w-4 h-4 text-purple-400" />
                  <span>CHEMOBOT AI</span>
                </motion.button>
              </div>
            </div>

            {/* Right: Live Telemetry & Core Physics Indicator */}
            <div className="w-full lg:w-80 bg-slate-950/70 border border-white/10 rounded-2xl p-4.5 space-y-3 font-mono text-xs shadow-inner">
              <div className="flex items-center justify-between pb-2 border-b border-white/10 text-[11px] text-slate-400">
                <div className="flex items-center gap-2">
                  <img
                    src="/favicon-32x32.png"
                    alt="Chemisphere 3D"
                    className="w-5 h-5 object-contain rounded-md"
                    referrerPolicy="no-referrer"
                  />
                  <span className="text-cyan-300 font-bold">SYSTEM TELEMETRY</span>
                </div>
                <span className="text-emerald-400">ONLINE (60 FPS)</span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/5">
                  <div className="text-slate-400 text-[9px] uppercase">ELEMENT REGISTRY</div>
                  <div className="text-white font-bold text-sm mt-0.5">118 IUPAC</div>
                </div>
                <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/5">
                  <div className="text-slate-400 text-[9px] uppercase">3D HARMONICS</div>
                  <div className="text-purple-300 font-bold text-sm mt-0.5">s, p, d, f (N=4)</div>
                </div>
                <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/5">
                  <div className="text-slate-400 text-[9px] uppercase">SPECTROMETERS</div>
                  <div className="text-pink-300 font-bold text-sm mt-0.5">5 Instruments</div>
                </div>
                <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/5">
                  <div className="text-slate-400 text-[9px] uppercase">AI REASONING</div>
                  <div className="text-cyan-300 font-bold text-sm mt-0.5">ChemoBot Ready</div>
                </div>
              </div>

              <div className="pt-1 text-[10px] text-slate-400 leading-tight">
                Designed & Engineered by <span className="text-amber-300 font-bold">Yajat Sarkar</span> (KV Balaghat & Infinity Learn).
              </div>
            </div>

          </div>

          {/* Recently Explored Laboratories Strip */}
          {recentLabs.length > 0 && (
            <div className="mt-8 pt-5 border-t border-white/10">
              <div className="flex items-center justify-between mb-2.5">
                <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-cyan-400" /> RECENTLY ACCESSED LABORATORIES
                </span>
                <span className="text-[10px] font-mono text-slate-500">Live Session Cache</span>
              </div>
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                {recentLabs.map((lab) => (
                  <button
                    key={lab.tab}
                    onClick={() => onNavigate(lab.tab)}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-cyan-400/40 text-xs font-mono text-slate-200 transition-all shrink-0 group"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 group-hover:scale-125 transition-transform" />
                    <span className="font-medium">{lab.name}</span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-white/10 text-slate-400">{lab.category}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </section>

        {/* ========================================================================= */}
        {/* SECTION: PERSONALIZED CHEMIST WELCOME & INTERACTIVE ARENAS               */}
        {/* ========================================================================= */}
        <section className="p-6 rounded-3xl bg-gradient-to-r from-[#071322] via-[#0d1b2a] to-[#120e28] border border-cyan-500/30 backdrop-blur-xl shadow-xl space-y-5">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300 font-bold text-xl shadow-lg shadow-cyan-500/20">
                <UserCheck className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl sm:text-2xl font-extrabold text-white font-home">
                    Hello, {userProfile.name || 'Fellow Chemist'}!
                  </h2>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-mono uppercase">
                    Level {userProfile.level} Chemist
                  </span>
                </div>
                <p className="text-xs text-slate-300 font-light mt-0.5">
                  Focus Track: <span className="text-cyan-300 font-mono font-medium">{userProfile.primaryInterest}</span> • {userProfile.experienceScore} XP Earned
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate('profile')}
                className="px-3.5 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/40 text-cyan-200 text-xs font-mono font-semibold transition-all flex items-center gap-1.5"
              >
                <Award className="w-4 h-4 text-cyan-400" />
                <span>View Passport & XP</span>
              </button>
            </div>
          </div>

          {/* Featured Grand Portal: Historical Interactive Chemistry World Map */}
          <div
            onClick={() => onNavigate('chemistry-map')}
            className="p-5 rounded-2xl bg-gradient-to-r from-amber-950/40 via-[#1f160e]/60 to-amber-900/30 border border-amber-500/40 hover:border-amber-400 transition-all cursor-pointer group flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-lg shadow-amber-950/30"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center justify-center group-hover:scale-110 transition-transform">
                <MapIcon className="w-6 h-6 text-amber-400 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    New Interactive Module
                  </span>
                  <span className="text-xs text-amber-200/60 font-serif">Anno Domini • 9 Cartographic Continents</span>
                </div>
                <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-amber-300 transition-colors font-serif">
                  Interactive Historical World Map of Chemistry
                </h3>
                <p className="text-xs text-slate-300 font-light mt-0.5">
                  Embark on an antique cartographer's journey across Atomia, Organica, Thermoria, Spectralis and the Reaction Ocean.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 self-end md:self-center px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold font-mono tracking-wider transition-all shadow-md shrink-0">
              <span>EXPLORE MAP</span>
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>

          {/* 4 Interactive Feature Launch Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
            {/* Card 1: Questions Playground */}
            <div
              onClick={() => onNavigate('questions-playground')}
              className="p-4 rounded-2xl bg-white/[0.03] hover:bg-amber-500/10 border border-white/10 hover:border-amber-400/50 transition-all cursor-pointer group flex flex-col justify-between space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 group-hover:scale-110 transition-transform">
                  <Trophy className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/20">
                  Arena & Quizzes
                </span>
              </div>
              <div>
                <h3 className="text-sm font-bold text-white group-hover:text-amber-300 transition-colors">
                  Questions Playground
                </h3>
                <p className="text-[11px] text-slate-400 line-clamp-2 mt-1">
                  Olympiad-tier MCQs, equation balancing trials & competitive chem leaderboard.
                </p>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-white/5 text-[10px] font-mono text-amber-300">
                <span>Enter Arena</span>
                <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </div>
            </div>

            {/* Card 2: Virtual Chemistry Lab */}
            <div
              onClick={() => onNavigate('chemistry-lab')}
              className="p-4 rounded-2xl bg-white/[0.03] hover:bg-emerald-500/10 border border-white/10 hover:border-emerald-400/50 transition-all cursor-pointer group flex flex-col justify-between space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 group-hover:scale-110 transition-transform">
                  <FlaskConical className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                  Live Sandbox
                </span>
              </div>
              <div>
                <h3 className="text-sm font-bold text-white group-hover:text-emerald-300 transition-colors">
                  Virtual Chemistry Lab
                </h3>
                <p className="text-[11px] text-slate-400 line-clamp-2 mt-1">
                  Mix acids, bases, indicators & redox reagents with live temperature and pH simulation.
                </p>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-white/5 text-[10px] font-mono text-emerald-300">
                <span>Open Beaker</span>
                <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </div>
            </div>

            {/* Card 3: Scientific Archive & Vault */}
            <div
              onClick={() => onNavigate('archive')}
              className="p-4 rounded-2xl bg-white/[0.03] hover:bg-cyan-500/10 border border-white/10 hover:border-cyan-400/50 transition-all cursor-pointer group flex flex-col justify-between space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 group-hover:scale-110 transition-transform">
                  <Archive className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
                  Vault & GHS
                </span>
              </div>
              <div>
                <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                  Scientific Archive & Vault
                </h3>
                <p className="text-[11px] text-slate-400 line-clamp-2 mt-1">
                  Nobel chemistry timeline, spectroscopic spectral library & safety data sheets.
                </p>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-white/5 text-[10px] font-mono text-cyan-300">
                <span>Browse Vault</span>
                <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </div>
            </div>

            {/* Card 4: ChemoBot AI Copilot */}
            <div
              onClick={() => onNavigate('ai-tutor')}
              className="p-4 rounded-2xl bg-white/[0.03] hover:bg-purple-500/10 border border-white/10 hover:border-purple-400/50 transition-all cursor-pointer group flex flex-col justify-between space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="p-2 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/30 group-hover:scale-110 transition-transform">
                  <Bot className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/20">
                  AI Reasoner
                </span>
              </div>
              <div>
                <h3 className="text-sm font-bold text-white group-hover:text-purple-300 transition-colors">
                  ChemoBot Scientific Copilot
                </h3>
                <p className="text-[11px] text-slate-400 line-clamp-2 mt-1">
                  Personalized synthesis walkthroughs, mechanism step solver & IUPAC explanations.
                </p>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-white/5 text-[10px] font-mono text-purple-300">
                <span>Ask Question</span>
                <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </div>
            </div>
          </div>
        </section>

        {/* ========================================================================= */}
        {/* SECTION 2: LIVE INTERACTIVE SCIENTIFIC WORKSPACES EMBEDDED IN COMMAND DECK */}
        {/* ========================================================================= */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-home">
                Live Interactive Workbenches
              </h2>
              <p className="text-xs text-slate-400">
                Directly manipulate quantum energy jumps, VSEPR molecular bond repulsion, and element properties
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            
            {/* WORKBENCH 1: RYDBERG BOHR ELECTRON JUMPER */}
            <div className="p-5 rounded-3xl bg-slate-900/60 dark:bg-slate-950/80 border border-purple-500/30 backdrop-blur-xl flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono text-purple-400 uppercase tracking-widest font-bold flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" /> RYDBERG TRANSITION ENGINE
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/20">
                    Bohr Hydrogen
                  </span>
                </div>

                <h3 className="text-base font-bold text-white font-quantum">
                  Quantized Photon Emission: n={rydbergN2} → n={rydbergN1}
                </h3>
                <p className="text-xs text-slate-300 mt-1">
                  Adjust initial and final principal quantum numbers to calculate emission wavelength and photon color.
                </p>

                {/* Interactive Controls */}
                <div className="grid grid-cols-2 gap-3 mt-3 font-mono text-xs">
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">FINAL LEVEL (n₁): {rydbergN1}</label>
                    <div className="flex gap-1">
                      {[1, 2, 3].map((n) => (
                        <button
                          key={n}
                          onClick={() => {
                            setRydbergN1(n);
                            if (rydbergN2 <= n) setRydbergN2(n + 1);
                          }}
                          className={`flex-1 py-1 rounded-lg text-xs font-bold transition-all ${
                            rydbergN1 === n
                              ? 'bg-purple-600 text-white shadow-md'
                              : 'bg-white/5 text-slate-300 hover:bg-white/10'
                          }`}
                        >
                          n={n} {n === 1 ? '(Lyman)' : n === 2 ? '(Balmer)' : '(Paschen)'}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">INITIAL LEVEL (n₂): {rydbergN2}</label>
                    <div className="flex gap-1">
                      {[rydbergN1 + 1, rydbergN1 + 2, rydbergN1 + 3, rydbergN1 + 4].map((n) => (
                        <button
                          key={n}
                          onClick={() => setRydbergN2(n)}
                          className={`flex-1 py-1 rounded-lg text-xs font-bold transition-all ${
                            rydbergN2 === n
                              ? 'bg-cyan-500 text-slate-950 shadow-md'
                              : 'bg-white/5 text-slate-300 hover:bg-white/10'
                          }`}
                        >
                          n={n}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Spectral Output Bar */}
                <div className="mt-4 p-3 rounded-2xl bg-white/[0.03] border border-white/10 space-y-2">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400">EMISSION WAVELENGTH:</span>
                    <span className="text-white font-bold">{rydbergWavelength} nm</span>
                  </div>

                  <div className="h-6 rounded-xl border border-white/15 overflow-hidden flex items-center justify-center font-mono text-[10px] font-bold text-white shadow-inner relative"
                       style={{ background: spectralInfo.bg }}>
                    <span>{spectralInfo.label} ({rydbergWavelength} nm)</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => onNavigate('atomic-spectra')}
                className="w-full py-2 rounded-xl bg-purple-500/15 hover:bg-purple-500/25 border border-purple-500/30 text-purple-300 text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition-colors"
              >
                <span>Full Atomic Spectra & Flame Lab</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* WORKBENCH 2: INTERACTIVE VSEPR GEOMETRY ANALYZER */}
            <div className="p-5 rounded-3xl bg-slate-900/60 dark:bg-slate-950/80 border border-emerald-500/30 backdrop-blur-xl flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest font-bold flex items-center gap-1.5">
                    <Boxes className="w-3.5 h-3.5" /> VSEPR BOND REPULSION WORKBENCH
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                    Steric Repulsion
                  </span>
                </div>

                <h3 className="text-base font-bold text-white font-organic">
                  Geometry: <span className="text-emerald-300">{currentVsepr.name}</span>
                </h3>
                <p className="text-xs text-slate-300 mt-1">
                  Adjust steric number (bonding pairs + lone pairs) to calculate predicted bond angles and hybridization.
                </p>

                {/* Steric Number & Lone Pair Selectors */}
                <div className="grid grid-cols-2 gap-3 mt-3 font-mono text-xs">
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">TOTAL STERIC NUMBER: {vseprSteric}</label>
                    <div className="flex gap-1">
                      {[2, 3, 4, 5, 6].map((s) => (
                        <button
                          key={s}
                          onClick={() => {
                            setVseprSteric(s);
                            if (vseprLonePairs >= s - 1) setVseprLonePairs(0);
                          }}
                          className={`flex-1 py-1 rounded-lg text-xs font-bold transition-all ${
                            vseprSteric === s
                              ? 'bg-emerald-500 text-slate-950 shadow-md'
                              : 'bg-white/5 text-slate-300 hover:bg-white/10'
                          }`}
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">LONE PAIRS: {vseprLonePairs}</label>
                    <div className="flex gap-1">
                      {[0, 1, 2, 3].map((lp) => {
                        const disabled = lp >= vseprSteric - 1;
                        return (
                          <button
                            key={lp}
                            disabled={disabled}
                            onClick={() => setVseprLonePairs(lp)}
                            className={`flex-1 py-1 rounded-lg text-xs font-bold transition-all ${
                              disabled
                                ? 'opacity-20 cursor-not-allowed bg-white/5'
                                : vseprLonePairs === lp
                                ? 'bg-amber-500 text-slate-950 shadow-md'
                                : 'bg-white/5 text-slate-300 hover:bg-white/10'
                            }`}
                          >
                            {lp}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* VSEPR Readout Data Box */}
                <div className="grid grid-cols-3 gap-2 mt-4 text-xs font-mono">
                  <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/10">
                    <div className="text-[9px] text-slate-400 uppercase">FORMULA</div>
                    <div className="text-white font-bold mt-0.5">{currentVsepr.formula}</div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/10">
                    <div className="text-[9px] text-slate-400 uppercase">BOND ANGLE</div>
                    <div className="text-cyan-300 font-bold mt-0.5">{currentVsepr.angle}</div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/10">
                    <div className="text-[9px] text-slate-400 uppercase">HYBRID</div>
                    <div className="text-emerald-300 font-bold mt-0.5">{currentVsepr.hyb}</div>
                  </div>
                </div>
              </div>

              <button
                onClick={() => onNavigate('vsepr-lab')}
                className="w-full py-2 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition-colors"
              >
                <span>Open 3D VSEPR & Hybridization Lab</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* WORKBENCH 3: REAL PERIODIC ELEMENT QUICK-INSPECT LENS */}
            <div className="p-5 rounded-3xl bg-slate-900/60 dark:bg-slate-950/80 border border-cyan-500/30 backdrop-blur-xl flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest font-bold flex items-center gap-1.5">
                    <Grid3X3 className="w-3.5 h-3.5" /> PERIODIC ELEMENT LENS
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
                    Z={activeElement.number}
                  </span>
                </div>

                <div className="flex items-center gap-4 mt-2">
                  <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/40 flex flex-col items-center justify-center font-mono text-white shrink-0">
                    <span className="text-[10px] text-cyan-400">{activeElement.number}</span>
                    <span className="text-2xl font-bold">{activeElement.symbol}</span>
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white font-periodic">
                      {activeElement.name}
                    </h3>
                    <div className="text-xs font-mono text-slate-300">
                      {activeElement.category} • {activeElement.block}-block
                    </div>
                    <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                      Config: {activeElement.electronConfiguration}
                    </div>
                  </div>
                </div>

                {/* Quick Element Switcher Slider / Buttons */}
                <div className="mt-3 space-y-2">
                  <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                    <span>QUICK SELECT ELEMENT (Z=1 to 118):</span>
                    <span className="text-cyan-300 font-bold">{activeElement.symbol} (Z={lensZ})</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="118"
                    value={lensZ}
                    onChange={(e) => setLensZ(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                  <div className="flex gap-1 pt-1 font-mono text-[10px]">
                    {[1, 6, 8, 11, 26, 79, 92].map((z) => (
                      <button
                        key={z}
                        onClick={() => setLensZ(z)}
                        className={`flex-1 py-0.5 rounded text-center transition-all ${
                          lensZ === z ? 'bg-cyan-400 text-slate-950 font-bold' : 'bg-white/5 text-slate-400 hover:text-white'
                        }`}
                      >
                        {getElementByNumber(z)?.symbol}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Atomic Properties Readout */}
                <div className="grid grid-cols-3 gap-2 mt-3 text-xs font-mono">
                  <div className="p-2 rounded-xl bg-white/[0.03] border border-white/10">
                    <div className="text-[9px] text-slate-400 uppercase">MASS</div>
                    <div className="text-white font-bold mt-0.5">{activeElement.atomicMass.toFixed(1)} u</div>
                  </div>
                  <div className="p-2 rounded-xl bg-white/[0.03] border border-white/10">
                    <div className="text-[9px] text-slate-400 uppercase">E-NEG</div>
                    <div className="text-cyan-300 font-bold mt-0.5">{activeElement.electronegativity || 'N/A'}</div>
                  </div>
                  <div className="p-2 rounded-xl bg-white/[0.03] border border-white/10">
                    <div className="text-[9px] text-slate-400 uppercase">1st IE</div>
                    <div className="text-purple-300 font-bold mt-0.5">{activeElement.ionizationEnergy} kJ/mol</div>
                  </div>
                </div>
              </div>

              <button
                onClick={() => onNavigate('periodic-table')}
                className="w-full py-2 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition-colors"
              >
                <span>Inspect in 118-Element Periodic Table</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>
        </section>

        {/* ========================================================================= */}
        {/* SECTION 3: SCIENTIFIC KNOWLEDGE DOMAINS (ARCHITECTURAL EXPLORER)         */}
        {/* ========================================================================= */}
        <section className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-home">
                Chemisphere Knowledge Domains
              </h2>
              <p className="text-xs text-slate-400">
                Organized by core scientific disciplines with dedicated laboratories and mathematical solvers
              </p>
            </div>

            {/* Discipline Filter Tabs */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none">
              {[
                { id: 'all', label: 'All Domains' },
                { id: 'atomic', label: 'Atomic & Periodic' },
                { id: 'quantum', label: 'Quantum & Waves' },
                { id: 'molecular', label: 'Molecules & CAD' },
                { id: 'physical', label: 'Physical & Thermo' },
                { id: 'analytical', label: 'Analytical & Electro' },
                { id: 'nuclear', label: 'Nuclear & Astro' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setSelectedDomain(tab.id as ScientificDomainId)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-mono font-medium transition-all shrink-0 ${
                    selectedDomain === tab.id
                      ? 'bg-cyan-400 text-slate-950 font-bold shadow-md'
                      : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Domains Grid */}
          <div className="space-y-8">
            {displayedDomains.map((domain) => (
              <div
                key={domain.id}
                className={`p-6 sm:p-8 rounded-3xl bg-slate-900/60 dark:bg-slate-950/80 border ${domain.accentBorder} backdrop-blur-xl space-y-6 transition-all`}
              >
                {/* Domain Header Banner */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono uppercase tracking-widest px-2 py-0.5 rounded-full bg-white/10 text-slate-300 font-bold">
                        {domain.discipline}
                      </span>
                      <span className="text-xs text-slate-400 font-mono">
                        {domain.modules.length} Specialized Modules
                      </span>
                    </div>
                    <h3 className={`text-2xl sm:text-3xl font-bold text-white mt-1 ${domain.fontClass}`}>
                      {domain.name}
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
                      {domain.tagline}
                    </p>
                  </div>

                  <button
                    onClick={() => onNavigate(domain.primaryLab)}
                    className="self-start sm:self-center px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-xs font-mono font-bold text-slate-200 flex items-center gap-1.5 transition-all"
                  >
                    <span>Launch Primary Lab</span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-cyan-400" />
                  </button>
                </div>

                {/* Domain Specialized Modules */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {domain.modules.map((mod) => {
                    const Icon = mod.icon;
                    return (
                      <motion.div
                        key={mod.tab}
                        whileHover={{ y: -3, scale: 1.01 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => onNavigate(mod.tab)}
                        className="p-5 rounded-2xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/10 hover:border-cyan-400/40 cursor-pointer transition-all flex flex-col justify-between group shadow-sm"
                      >
                        <div className="space-y-2.5">
                          <div className="flex items-center justify-between">
                            <div className="p-2 rounded-xl bg-white/5 border border-white/10 text-cyan-300 group-hover:scale-110 transition-transform">
                              <Icon className="w-4 h-4" />
                            </div>
                            <span className="text-[10px] font-mono text-slate-400 px-2 py-0.5 rounded bg-white/5">
                              {mod.instrument}
                            </span>
                          </div>

                          <div>
                            <h4 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                              {mod.title}
                            </h4>
                            <p className="text-xs text-slate-300 font-light leading-relaxed mt-1">
                              {mod.description}
                            </p>
                          </div>
                        </div>

                        <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-xs font-mono">
                          <span className="text-[10px] text-slate-400 truncate max-w-[180px]">
                            {mod.metric}
                          </span>
                          <span className="text-cyan-400 font-bold group-hover:translate-x-1 transition-transform flex items-center gap-0.5">
                            <span>Open</span>
                            <ChevronRight className="w-3 h-3" />
                          </span>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* ========================================================================= */}
        {/* SECTION 4: INTEGRATED CHEMOBOT COPILOT WORKSPACE                          */}
        {/* ========================================================================= */}
        <section className="relative rounded-3xl bg-gradient-to-br from-purple-950/40 via-slate-900/60 to-slate-950/80 border border-purple-500/30 p-6 sm:p-8 backdrop-blur-2xl shadow-xl overflow-hidden">
          <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
            <div className="space-y-3 max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-300 text-xs font-mono">
                <Bot className="w-3.5 h-3.5" />
                <span className="font-bold">CHEMOBOT AI // STEPWISE SCIENTIFIC REASONING</span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-bold text-white font-home">
                Have a Complex Chemistry or Quantum Physics Problem?
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 font-light leading-relaxed">
                ChemoBot provides step-by-step mathematical derivations, balancing procedures, 
                VSEPR hybridizations, and spectroscopy interpretation grounded in authentic chemical principles.
              </p>

              <div className="flex flex-wrap gap-2 pt-1">
                {[
                  'Calculate Balmer photon wavelength for n=4 to n=2',
                  'Predict geometry & hybridization of XeF4',
                  'Derive Henderson-Hasselbalch equation for buffer pH',
                  'Explain Le Chatelier shift in Haber process'
                ].map((prompt, idx) => (
                  <button
                    key={idx}
                    onClick={() => onNavigate('ai-tutor')}
                    className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-purple-500/20 border border-white/10 text-[11px] font-mono text-purple-200 transition-all text-left"
                  >
                    "{prompt}"
                  </button>
                ))}
              </div>
            </div>

            <div className="shrink-0 w-full lg:w-auto">
              <button
                onClick={() => onNavigate('ai-tutor')}
                className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs font-mono tracking-wider shadow-lg shadow-purple-500/25 flex items-center justify-center gap-2 transition-all"
              >
                <Bot className="w-4 h-4" />
                <span>LAUNCH STEPWISE COPILOT</span>
              </button>
            </div>
          </div>
        </section>

        {/* ========================================================================= */}
        {/* SECTION 5: EDITORIAL CREATOR PORTFOLIO SPOTLIGHT                          */}
        {/* ========================================================================= */}
        <section className="relative rounded-3xl bg-slate-900/60 dark:bg-slate-950/80 border border-amber-500/30 p-6 sm:p-8 backdrop-blur-2xl shadow-xl overflow-hidden">
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex flex-col sm:flex-row items-center gap-5 text-center sm:text-left">
              {/* Creator Monogram */}
              <div className="relative w-20 h-20 rounded-2xl bg-gradient-to-br from-amber-400 via-cyan-400 to-purple-500 p-0.5 shrink-0 shadow-lg shadow-amber-500/20">
                <div className="w-full h-full rounded-[14px] bg-slate-950 flex items-center justify-center border border-white/10 font-bold font-mono text-2xl text-transparent bg-clip-text bg-gradient-to-br from-amber-300 via-white to-cyan-300">
                  YS
                </div>
                <div className="absolute -bottom-1 -right-1 p-1 rounded-full bg-slate-950 border border-amber-400 text-amber-400 shadow">
                  <Crown className="w-3 h-3" />
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-1.5">
                  <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30 font-bold">
                    LEAD ARCHITECT
                  </span>
                  <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                    98% CBSE Class 10
                  </span>
                  <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/30">
                    Governor Awardee
                  </span>
                </div>

                <h3 className="text-xl sm:text-2xl font-bold text-white font-home">
                  Yajat Sarkar
                </h3>

                <p className="text-xs text-slate-300 max-w-xl leading-relaxed font-light">
                  Class 11 CBSE Science Scholar & School Vice Captain at <strong className="text-white">PM Shri KV Balaghat</strong>. 
                  Enrolled at <strong className="text-white">Infinity Learn</strong>. Architect of <strong className="text-cyan-300">Vriddhi-AI</strong> & Chemisphere 3D.
                </p>
              </div>
            </div>

            <button
              onClick={() => onNavigate('creator')}
              className="px-5 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold text-xs font-mono tracking-wider flex items-center gap-2 shadow-lg shadow-amber-500/20 transition-all shrink-0"
            >
              <GraduationCap className="w-4 h-4 text-slate-950" />
              <span>EXPLORE CREATOR DOSSIER</span>
            </button>
          </div>
        </section>

      </div>
    </div>
  );
};
