import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Boxes,
  FlaskConical,
  Trophy,
  BookOpen,
  Calculator,
  Wrench,
  Activity,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Search,
  Zap,
  Atom,
  Orbit,
  Flame,
  Layers,
  Scale,
  RefreshCw,
  Copy,
  Check
} from 'lucide-react';
import { NavigationTab } from '../../types';

interface ChemistryToolsMasterViewProps {
  onNavigateToTab: (tab: NavigationTab) => void;
  onOpenChembotWithContext?: (query: string, context?: any) => void;
}

type ToolCategory = 'all' | 'practice' | 'experiment' | 'reference' | 'calculators' | 'builders' | 'analysis';

interface ToolItem {
  id: string;
  name: string;
  category: 'practice' | 'experiment' | 'reference' | 'calculators' | 'builders' | 'analysis';
  badge: string;
  icon: string;
  shortDesc: string;
  purpose: string;
  whatYouCanDo: string[];
  inputs: string[];
  outputs: string[];
  example: string;
  relatedTabs: { label: string; tab: NavigationTab }[];
  directTab?: NavigationTab;
  hasInteractiveWidget?: boolean;
}

const TOOLS_DATABASE: ToolItem[] = [
  // 1. PRACTICE
  {
    id: 'questions-playground',
    name: 'Questions Playground & Challenges',
    category: 'practice',
    badge: 'Competitive Problem Solving',
    icon: 'Trophy',
    shortDesc: 'Solve multi-step Olympiad (IChO, JEE Advanced, NEET, AP Chemistry) questions with instant derivations.',
    purpose: 'Test deep chemistry comprehension across physical, organic, and inorganic chemistry with progressive difficulty and XP rewards.',
    whatYouCanDo: [
      'Filter by topic: Organic Synthesis, Quantum Mechanics, Thermodynamics, Electrochemistry',
      'Solve timed Olympiad & Competitive exam challenges',
      'View complete mathematical LaTeX derivations and mechanistic steps',
      'Earn chemist mastery points and unlock level badges'
    ],
    inputs: ['Topic selection', 'Difficulty level (Foundation, Intermediate, Olympiad Master)', 'User answer selection'],
    outputs: ['Instant correctness feedback', 'Detailed step-by-step mathematical derivation', 'Earned XP & leaderboard score'],
    example: 'Calculate the pH of 0.1 M ammonium acetate given Ka = 1.8e-5 and Kb = 1.8e-5.',
    relatedTabs: [
      { label: 'AI Chemistry Tutor', tab: 'ai-tutor' },
      { label: 'Formula Vault', tab: 'formula-vault' }
    ],
    directTab: 'questions-playground'
  },
  {
    id: 'stoichiometry-speed-balancer',
    name: 'Stoichiometry & Reaction Balancer',
    category: 'practice',
    badge: 'Equation Balancer',
    icon: 'Scale',
    shortDesc: 'Balance complex redox and organic combustion reactions with automated matrix solvers.',
    purpose: 'Rapidly verify stoichiometric coefficients, calculate mole ratios, and find limiting reagents.',
    whatYouCanDo: [
      'Input unbalanced chemical formulas like KMnO4 + H2C2O4 + H2SO4',
      'Calculate mole-to-gram conversions',
      'Identify limiting reagent and calculate theoretical percent yields'
    ],
    inputs: ['Unbalanced reaction string', 'Reactant starting masses (g/mol)'],
    outputs: ['Balanced chemical equation', 'Molar mass of all species', 'Theoretical yield (g)'],
    example: 'Balance C8H18 + O2 -> CO2 + H2O and compute yield for 100g Octane.',
    relatedTabs: [
      { label: 'Stoichiometry Lab', tab: 'stoichiometry' },
      { label: 'Virtual Lab', tab: 'chemistry-lab' }
    ],
    directTab: 'stoichiometry'
  },

  // 2. EXPERIMENT
  {
    id: 'chemistry-lab',
    name: 'Virtual Chemistry Laboratory',
    category: 'experiment',
    badge: 'Hands-on Reaction Sandbox',
    icon: 'FlaskConical',
    shortDesc: 'Interactive glassware sandbox with chemical reagent mixing, color shifts, precipitate formation, and pH tracking.',
    purpose: 'Safely conduct wet-chemistry experiments with real thermodynamic heat exchanges, gas evolution, and indicator color changes.',
    whatYouCanDo: [
      'Mix 30+ chemical solutions (Acids, Bases, Transition metal salts, Redox pairs)',
      'Monitor real-time beaker temperature and solution pH',
      'Observe vibrant precipitate formation (e.g. PbI2 golden rain, Cu(OH)2 blue gel)',
      'Add acid-base indicators (Phenolphthalein, Universal, Methyl Orange)'
    ],
    inputs: ['Reagent addition order and volume (mL)', 'Concentration (M)', 'Bunsen burner heating rate'],
    outputs: ['Live beaker visual with color transitions', 'Real-time solution pH and temperature graphs', 'Precipitate mass and gas volume'],
    example: 'Mix 0.1 M AgNO3 with 0.1 M NaCl to precipitate 1.43g of white AgCl curd.',
    relatedTabs: [
      { label: 'Analytical Lab', tab: 'analytical-lab' },
      { label: 'Electrochemistry', tab: 'electrochemistry-lab' }
    ],
    directTab: 'chemistry-lab'
  },

  // 3. REFERENCE
  {
    id: 'archive',
    name: 'Chemisphere Archive & Historical Dossier',
    category: 'reference',
    badge: 'Encyclopedia & History',
    icon: 'BookOpen',
    shortDesc: 'Comprehensive historical timeline of chemistry discoveries, Nobel laureates, spectral charts, and deep literature references.',
    purpose: 'Provide contextual scientific history from Alchemy and Lavoisier to Quantum Mechanics and modern CRIPSR/materials discovery.',
    whatYouCanDo: [
      'Browse historical timeline of chemical discoveries (1669 to 2025)',
      'Inspect Nobel prize breakthroughs in Chemistry and Physics',
      'Search scientific literature references and spectroscopy database cards'
    ],
    inputs: ['Search keyword', 'Historical century filter', 'Discipline tag'],
    outputs: ['Illustrated historical breakthrough dossiers', 'Original scientist biographical profiles', 'Key experimental diagrams'],
    example: 'Explore Mendeleev’s 1869 periodic prediction of Gallium (Eka-aluminum) and Germanium.',
    relatedTabs: [
      { label: 'Atomic History', tab: 'atomic-structure' },
      { label: 'Periodic Table', tab: 'periodic-table' }
    ],
    directTab: 'archive'
  },
  {
    id: 'formula-vault',
    name: 'Universal Formula Vault & Physical Constants',
    category: 'reference',
    badge: 'Reference Database',
    icon: 'BookOpen',
    shortDesc: 'Encyclopedic repository of 100+ fundamental chemical equations, derivation steps, and exact physical constants.',
    purpose: 'Provide instant access to standard formulas (Nernst, Arrhenius, Henderson-Hasselbalch, Schrödinger, Rydberg) with interactive parameter solvers.',
    whatYouCanDo: [
      'Search chemistry equations across Thermodynamics, Kinetics, Quantum, and Solutions',
      'Inspect SI units, variable definitions, and derivation outlines',
      'Access exact CODATA physical constants (R, F, h, c, k_B, N_A)'
    ],
    inputs: ['Formula name or variable keyword'],
    outputs: ['LaTeX mathematical representation', 'Physical constants tables', 'Interactive calculation widget'],
    example: 'Look up the Van \'t Hoff equation d(ln K)/dT = ΔH° / (RT²) for equilibrium shifts.',
    relatedTabs: [
      { label: 'Physical Chemistry Suite', tab: 'physical-chem' },
      { label: 'Universal Calculator', tab: 'universal-calc-graph' }
    ],
    directTab: 'formula-vault'
  },

  // 4. CALCULATORS
  {
    id: 'calc-ph-buffer',
    name: 'pH, pOH & Buffer Solution Calculator',
    category: 'calculators',
    badge: 'Equilibrium Calculator',
    icon: 'Calculator',
    shortDesc: 'Calculate pH, pOH, [H+], [OH-], and buffer capacity using the Henderson-Hasselbalch equation.',
    purpose: 'Compute exact acidity and basicity for strong acids, strong bases, weak electrolytes, and conjugate acid-base buffer mixtures.',
    whatYouCanDo: [
      'Calculate pH of strong acids (HCl, HNO3) and strong bases (NaOH, KOH)',
      'Calculate pH of weak acids using Ka and quadratic equilibrium solver',
      'Design buffer solutions (e.g. Acetic Acid + Sodium Acetate) at specific target pH',
      'Calculate buffer capacity when small amounts of strong acid/base are added'
    ],
    inputs: ['Solution type (Strong Acid, Weak Acid, Buffer)', 'Concentration [HA] and [A-]', 'Acid dissociation constant Ka (or pKa)'],
    outputs: ['Solution pH and pOH', 'Hydronium [H3O+] and Hydroxide [OH-] concentrations', 'Equilibrium ionization fraction α'],
    example: 'Calculate pH of a buffer with 0.20 M CH3COOH and 0.15 M CH3COONa (pKa = 4.75). Result: pH = 4.63.',
    relatedTabs: [
      { label: 'Analytical Lab', tab: 'analytical-lab' },
      { label: 'Formula Vault', tab: 'formula-vault' }
    ],
    hasInteractiveWidget: true
  },
  {
    id: 'calc-gas-laws',
    name: 'Ideal & Real Gas Law Solver',
    category: 'calculators',
    badge: 'Thermodynamics Calculator',
    icon: 'Flame',
    shortDesc: 'Solve Ideal Gas Law (PV = nRT) and Van der Waals Real Gas equations with compressibility factors.',
    purpose: 'Model behavior of gases across varying temperatures, pressures, and volumes, comparing ideal assumptions with non-ideal molecular interactions.',
    whatYouCanDo: [
      'Solve for any variable: Pressure (P), Volume (V), Moles (n), or Temperature (T)',
      'Apply Van der Waals corrections: (P + an²/V²)(V - nb) = nRT for CO2, N2, He, H2',
      'Calculate gas density (ρ = PM / RT) and root-mean-square molecular speed (v_rms)'
    ],
    inputs: ['Gas species (Ideal, CO2, N2, O2, He)', 'Pressure (atm/kPa)', 'Volume (L)', 'Temperature (K/°C)', 'Molar amount (mol)'],
    outputs: ['Target calculated parameter', 'Compressibility factor Z = PV/(nRT)', 'v_rms speed in m/s'],
    example: 'Calculate pressure of 2.0 mol of CO2 in a 5.0 L container at 300 K using Van der Waals equation.',
    relatedTabs: [
      { label: 'Thermodynamics', tab: 'thermo-kinetics' },
      { label: 'Formula Vault', tab: 'formula-vault' }
    ],
    hasInteractiveWidget: true
  },
  {
    id: 'calc-nernst-potentials',
    name: 'Nernst & Cell Potential Engine',
    category: 'calculators',
    badge: 'Electrochemistry Calculator',
    icon: 'Zap',
    shortDesc: 'Compute non-standard electrochemical cell voltage E_cell using the Nernst equation.',
    purpose: 'Predict spontaneity and electrical output of galvanic cells under non-standard ion concentrations and temperatures.',
    whatYouCanDo: [
      'Select standard half-cell reactions from electrochemical series table',
      'Calculate standard cell potential E°cell = E°cathode - E°anode',
      'Calculate non-standard voltage: E = E° - (RT/nF) ln Q',
      'Determine reaction quotient Q and equilibrium constant K'
    ],
    inputs: ['Anode half-reaction', 'Cathode half-reaction', 'Ion concentrations [Anode]/[Cathode]', 'Temperature (K)'],
    outputs: ['E°cell (Standard)', 'E_cell (Actual)', 'Number of electrons transferred n', 'Free energy change ΔG = -nFE'],
    example: 'Daniell cell Zn/Zn²⁺(0.01 M) || Cu²⁺(1.0 M)/Cu at 298 K gives E_cell = 1.16 V.',
    relatedTabs: [
      { label: 'Electrochemistry Lab', tab: 'electrochemistry-lab' },
      { label: 'Physical Chemistry Suite', tab: 'physical-chem' }
    ],
    hasInteractiveWidget: true
  },

  // 5. BUILDERS
  {
    id: 'builder-lewis-structure',
    name: 'Lewis Structure & Valence Electron Builder',
    category: 'builders',
    badge: 'Structure Generator',
    icon: 'Atom',
    shortDesc: 'Interactive Lewis dot structure solver predicting bonding pairs, lone pairs, and formal charges.',
    purpose: 'Generate valid octet/expanded octet electron distributions for molecules and polyatomic ions.',
    whatYouCanDo: [
      'Input molecular formulas (CO2, NH3, H2O, SO4²⁻, SF6, PCl5, O3)',
      'Calculate total valence electrons and skeletal sigma bonds',
      'Distribute lone pairs to satisfy the octet rule',
      'Calculate formal charge on every constituent atom: FC = V - N - (B/2)'
    ],
    inputs: ['Chemical formula or ion (e.g. CO3^2-, BF3, NO3-)'],
    outputs: ['Lewis structure representation', 'Formal charge breakdown', 'Octet satisfaction status', 'Resonance structures count'],
    example: 'Build Nitrate ion (NO3⁻): 24 valence electrons, nitrogen has +1 formal charge, oxygens have -2/3 resonance charge.',
    relatedTabs: [
      { label: 'VSEPR Lab', tab: 'vsepr-lab' },
      { label: '3D Molecules', tab: 'molecules-3d' }
    ],
    hasInteractiveWidget: true
  },
  {
    id: 'builder-electron-config',
    name: 'Electron Configuration & Quantum State Finder',
    category: 'builders',
    badge: 'Quantum State Generator',
    icon: 'Orbit',
    shortDesc: 'Generates full and noble-gas condensed electron configurations with orbital box diagrams and Hund\'s rule spin.',
    purpose: 'Predict ground-state and excited electronic configurations for any element (1-118) and their common ions.',
    whatYouCanDo: [
      'Generate full spdf notation: e.g. 1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d⁶ for Iron (Fe)',
      'Generate noble-gas condensed notation: [Ar] 3d⁶ 4s²',
      'Account for Aufbau exceptions (Chromium [Ar] 3d⁵ 4s¹, Copper [Ar] 3d¹⁰ 4s¹)',
      'Calculate paramagnetic unpaired electrons and magnetic moment μ = √(n(n+2)) BM'
    ],
    inputs: ['Element symbol/atomic number (1-118)', 'Ion charge (+1, +2, +3, -1, -2)'],
    outputs: ['Condensed electron configuration', 'Orbital box diagram with ↑↓ spins', 'Unpaired electron count', 'Magnetic property (Diamagnetic / Paramagnetic)'],
    example: 'Inspect Fe³⁺ (Z=26, charge +3): [Ar] 3d⁵ with 5 unpaired electrons (highly paramagnetic).',
    relatedTabs: [
      { label: 'Orbital Atlas', tab: 'orbital-atlas' },
      { label: 'Periodic Table', tab: 'periodic-table' }
    ],
    hasInteractiveWidget: true
  },

  // 6. ANALYSIS
  {
    id: 'analysis-grapher',
    name: 'Scientific Grapher & Chemical Curve Fitter',
    category: 'analysis',
    badge: 'Analytical Tool',
    icon: 'Activity',
    shortDesc: 'Plot kinetics rate orders, Arrhenius linearizations (ln k vs 1/T), and titration curves with regression fitting.',
    purpose: 'Analyze experimental data sets, extract reaction rate orders, and calculate activation energies and rate constants.',
    whatYouCanDo: [
      'Plot Zero-order ([A] vs t), First-order (ln[A] vs t), and Second-order (1/[A] vs t) plots',
      'Fit linear regressions to compute slope = -k or slope = -Ea/R',
      'Extract R² correlation coefficient and kinetic half-life t1/2'
    ],
    inputs: ['Time vs Concentration data table', 'Temperature vs Rate constant data table'],
    outputs: ['Interactive SVG graph with best-fit trendline', 'Linear equation y = mx + b', 'Reaction order determination', 'Activation energy Ea in kJ/mol'],
    example: 'Input decomposition of N2O5 over time; linear fit on ln[N2O5] confirms 1st-order kinetics with k = 0.0052 s⁻¹.',
    relatedTabs: [
      { label: 'Thermodynamics & Kinetics', tab: 'thermo-kinetics' },
      { label: 'Analytical Lab', tab: 'analytical-lab' }
    ],
    hasInteractiveWidget: true
  }
];

export const ChemistryToolsMasterView: React.FC<ChemistryToolsMasterViewProps> = ({
  onNavigateToTab,
  onOpenChembotWithContext
}) => {
  const [activeCategory, setActiveCategory] = useState<ToolCategory>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedPurposeCards, setExpandedPurposeCards] = useState<Record<string, boolean>>({});

  // Interactive Widgets Local State
  // 1. pH Calculator State
  const [phMode, setPhMode] = useState<'strong-acid' | 'weak-acid' | 'buffer'>('buffer');
  const [acidConc, setAcidConc] = useState<number>(0.1);
  const [baseConc, setBaseConc] = useState<number>(0.1);
  const [pKa, setPka] = useState<number>(4.75);

  // 2. Gas Law Calculator State
  const [gasMoles, setGasMoles] = useState<number>(1.0);
  const [gasTemp, setGasTemp] = useState<number>(298.15);
  const [gasVolume, setGasVolume] = useState<number>(24.45);

  // 3. Electron Config State
  const [configElement, setConfigElement] = useState<string>('Fe');
  const [configCharge, setConfigCharge] = useState<number>(0);

  // 4. Copied feedback
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const togglePurposeCard = (toolId: string) => {
    setExpandedPurposeCards((prev) => ({
      ...prev,
      [toolId]: !prev[toolId]
    }));
  };

  const filteredTools = TOOLS_DATABASE.filter((tool) => {
    const matchesCategory = activeCategory === 'all' || tool.category === activeCategory;
    const matchesSearch =
      tool.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tool.shortDesc.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tool.purpose.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Calculate live pH
  const calculateLivePh = () => {
    if (phMode === 'strong-acid') {
      const conc = Math.max(1e-7, acidConc);
      const val = -Math.log10(conc);
      return { ph: val.toFixed(2), poh: (14 - val).toFixed(2), h: conc.toExponential(2) };
    }
    if (phMode === 'weak-acid') {
      const ka = Math.pow(10, -pKa);
      // [H+] = sqrt(Ka * C) approx
      const hConc = Math.sqrt(ka * Math.max(1e-6, acidConc));
      const val = -Math.log10(hConc);
      return { ph: val.toFixed(2), poh: (14 - val).toFixed(2), h: hConc.toExponential(2) };
    }
    // Buffer: pH = pKa + log([A-]/[HA])
    const ratio = Math.max(1e-4, baseConc) / Math.max(1e-4, acidConc);
    const val = pKa + Math.log10(ratio);
    return { ph: val.toFixed(2), poh: (14 - val).toFixed(2), h: Math.pow(10, -val).toExponential(2) };
  };

  // Calculate live Gas Law Pressure: P = nRT / V
  const calculateLivePressure = () => {
    const R = 0.08206; // L atm / (mol K)
    const p = (gasMoles * R * gasTemp) / Math.max(0.1, gasVolume);
    return p.toFixed(3);
  };

  // Compute live electron config
  const calculateConfig = (sym: string, charge: number) => {
    const configs: Record<string, { z: number; name: string; full: string; condensed: string; unpaired: number }> = {
      H: { z: 1, name: 'Hydrogen', full: '1s¹', condensed: '1s¹', unpaired: 1 },
      He: { z: 2, name: 'Helium', full: '1s²', condensed: '[He]', unpaired: 0 },
      C: { z: 6, name: 'Carbon', full: '1s² 2s² 2p²', condensed: '[He] 2s² 2p²', unpaired: 2 },
      N: { z: 7, name: 'Nitrogen', full: '1s² 2s² 2p³', condensed: '[He] 2s² 2p³', unpaired: 3 },
      O: { z: 8, name: 'Oxygen', full: '1s² 2s² 2p⁴', condensed: '[He] 2s² 2p⁴', unpaired: 2 },
      Na: { z: 11, name: 'Sodium', full: '1s² 2s² 2p⁶ 3s¹', condensed: '[Ne] 3s¹', unpaired: 1 },
      Cl: { z: 17, name: 'Chlorine', full: '1s² 2s² 2p⁶ 3s² 3p⁵', condensed: '[Ne] 3s² 3p⁵', unpaired: 1 },
      Cr: { z: 24, name: 'Chromium', full: '1s² 2s² 2p⁶ 3s² 3p⁶ 3d⁵ 4s¹', condensed: '[Ar] 3d⁵ 4s¹', unpaired: 6 },
      Fe: { z: 26, name: 'Iron', full: '1s² 2s² 2p⁶ 3s² 3p⁶ 3d⁶ 4s²', condensed: '[Ar] 3d⁶ 4s²', unpaired: 4 },
      Cu: { z: 29, name: 'Copper', full: '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s¹', condensed: '[Ar] 3d¹⁰ 4s¹', unpaired: 1 },
      Zn: { z: 30, name: 'Zinc', full: '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s²', condensed: '[Ar] 3d¹⁰ 4s²', unpaired: 0 }
    };

    const target = configs[sym] || configs['Fe'];
    if (charge === 2 && sym === 'Fe') {
      return { ...target, condensed: '[Ar] 3d⁶', unpaired: 4, label: 'Fe²⁺' };
    }
    if (charge === 3 && sym === 'Fe') {
      return { ...target, condensed: '[Ar] 3d⁵', unpaired: 5, label: 'Fe³⁺' };
    }
    return { ...target, label: sym };
  };

  const copyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const currentPhResult = calculateLivePh();
  const currentPressure = calculateLivePressure();
  const currentConfigResult = calculateConfig(configElement, configCharge);

  return (
    <div className="space-y-6 pb-12 animate-in fade-in">
      {/* Top Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#091122] via-[#0b162c] to-[#080d1a] border border-cyan-500/30 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 space-y-3 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 text-xs font-mono">
            <Boxes className="w-3.5 h-3.5 text-cyan-400" />
            <span>Chemisphere Tools & Discover Area</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight font-display-periodic">
            Chemistry Tools, Calculators & Sandboxes
          </h1>

          <p className="text-sm sm:text-base text-slate-300 font-sans leading-relaxed">
            A comprehensive suite of specialized calculators, chemical equation solvers, molecular builders, and reference archives. Every tool includes a detailed Purpose Card with mathematical derivations and direct curriculum bridges.
          </p>
        </div>

        {/* Quick Search & Category Filters */}
        <div className="mt-6 pt-6 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4 relative z-10">
          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 no-scrollbar text-xs font-mono">
            {[
              { id: 'all', label: 'All Tools', count: TOOLS_DATABASE.length },
              { id: 'practice', label: 'Practice', count: 2 },
              { id: 'experiment', label: 'Experiment', count: 1 },
              { id: 'reference', label: 'Reference', count: 2 },
              { id: 'calculators', label: 'Calculators', count: 3 },
              { id: 'builders', label: 'Builders', count: 2 },
              { id: 'analysis', label: 'Analysis', count: 1 }
            ].map((cat) => {
              const isSelected = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id as any)}
                  className={`px-3 py-1.5 rounded-xl border whitespace-nowrap transition-all flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200 shadow-sm font-bold'
                      : 'bg-white/[0.02] border-white/10 text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <span>{cat.label}</span>
                  <span className="text-[10px] opacity-60">({cat.count})</span>
                </button>
              );
            })}
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-72">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search tools, formulas, solvers..."
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-white/5 border border-white/10 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/30"
            />
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
          </div>
        </div>
      </div>

      {/* Tool Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {filteredTools.map((tool) => {
          const isExpanded = !!expandedPurposeCards[tool.id];

          return (
            <div
              key={tool.id}
              className="p-5 sm:p-6 rounded-3xl bg-[#080d18]/90 border border-white/10 hover:border-cyan-500/40 transition-all flex flex-col justify-between space-y-4 shadow-lg backdrop-blur-md"
            >
              {/* Card Top Section */}
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 flex items-center justify-center shrink-0">
                      {tool.icon === 'Trophy' && <Trophy className="w-5 h-5" />}
                      {tool.icon === 'Scale' && <Scale className="w-5 h-5" />}
                      {tool.icon === 'FlaskConical' && <FlaskConical className="w-5 h-5" />}
                      {tool.icon === 'BookOpen' && <BookOpen className="w-5 h-5" />}
                      {tool.icon === 'Calculator' && <Calculator className="w-5 h-5" />}
                      {tool.icon === 'Flame' && <Flame className="w-5 h-5" />}
                      {tool.icon === 'Zap' && <Zap className="w-5 h-5" />}
                      {tool.icon === 'Atom' && <Atom className="w-5 h-5" />}
                      {tool.icon === 'Orbit' && <Orbit className="w-5 h-5" />}
                      {tool.icon === 'Activity' && <Activity className="w-5 h-5" />}
                    </div>
                    <div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/5 text-cyan-300 border border-cyan-500/20 uppercase tracking-wider">
                        {tool.badge}
                      </span>
                      <h3 className="text-lg font-bold text-white font-display-periodic mt-0.5">
                        {tool.name}
                      </h3>
                    </div>
                  </div>

                  {tool.directTab && (
                    <button
                      onClick={() => onNavigateToTab(tool.directTab!)}
                      className="p-2 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 transition-colors"
                      title="Launch standalone workspace"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <p className="text-xs sm:text-sm text-slate-300 font-sans leading-relaxed">
                  {tool.shortDesc}
                </p>
              </div>

              {/* Embedded Live Widget if available */}
              {tool.id === 'calc-ph-buffer' && (
                <div className="p-4 rounded-2xl bg-cyan-950/20 border border-cyan-500/30 space-y-3 font-mono text-xs">
                  <div className="flex items-center justify-between text-cyan-300 font-bold">
                    <span className="flex items-center gap-1.5">
                      <Calculator className="w-3.5 h-3.5" /> Interactive pH & Buffer Engine
                    </span>
                    <div className="flex items-center gap-1">
                      {(['buffer', 'weak-acid', 'strong-acid'] as const).map((m) => (
                        <button
                          key={m}
                          onClick={() => setPhMode(m)}
                          className={`px-2 py-0.5 rounded text-[10px] border ${
                            phMode === m
                              ? 'bg-cyan-500/30 border-cyan-400 text-white'
                              : 'bg-white/5 border-white/10 text-slate-400'
                          }`}
                        >
                          {m === 'buffer' ? 'Buffer' : m === 'weak-acid' ? 'Weak Acid' : 'Strong Acid'}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <div className="text-[10px] text-slate-400">[HA] Acid Conc (M):</div>
                      <input
                        type="number"
                        step="0.01"
                        value={acidConc}
                        onChange={(e) => setAcidConc(parseFloat(e.target.value) || 0.01)}
                        className="w-full px-2 py-1 rounded bg-black/40 border border-white/10 text-white text-xs"
                      />
                    </div>

                    {phMode === 'buffer' && (
                      <div>
                        <div className="text-[10px] text-slate-400">[A⁻] Base Conc (M):</div>
                        <input
                          type="number"
                          step="0.01"
                          value={baseConc}
                          onChange={(e) => setBaseConc(parseFloat(e.target.value) || 0.01)}
                          className="w-full px-2 py-1 rounded bg-black/40 border border-white/10 text-white text-xs"
                        />
                      </div>
                    )}

                    {phMode !== 'strong-acid' && (
                      <div>
                        <div className="text-[10px] text-slate-400">pKa of Acid:</div>
                        <input
                          type="number"
                          step="0.05"
                          value={pKa}
                          onChange={(e) => setPka(parseFloat(e.target.value) || 4.75)}
                          className="w-full px-2 py-1 rounded bg-black/40 border border-white/10 text-white text-xs"
                        />
                      </div>
                    )}
                  </div>

                  {/* Calculated Output Box */}
                  <div className="p-3 rounded-xl bg-black/50 border border-cyan-500/30 flex items-center justify-between">
                    <div>
                      <span className="text-slate-400 text-[11px]">Calculated pH: </span>
                      <span className="text-base font-extrabold text-cyan-300 ml-1">
                        {currentPhResult.ph}
                      </span>
                      <span className="text-slate-500 text-[10px] ml-2">(pOH = {currentPhResult.poh})</span>
                    </div>
                    <div className="text-[11px] text-slate-300 font-mono">
                      [H⁺] = {currentPhResult.h} M
                    </div>
                  </div>
                </div>
              )}

              {tool.id === 'calc-gas-laws' && (
                <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-500/30 space-y-3 font-mono text-xs">
                  <div className="flex items-center justify-between text-amber-300 font-bold">
                    <span className="flex items-center gap-1.5">
                      <Flame className="w-3.5 h-3.5" /> Ideal Gas Solver (PV = nRT)
                    </span>
                    <span className="text-[10px] text-slate-400">R = 0.08206 L·atm/(mol·K)</span>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <div className="text-[10px] text-slate-400">Moles n (mol):</div>
                      <input
                        type="number"
                        step="0.1"
                        value={gasMoles}
                        onChange={(e) => setGasMoles(parseFloat(e.target.value) || 1)}
                        className="w-full px-2 py-1 rounded bg-black/40 border border-white/10 text-white text-xs"
                      />
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-400">Temp T (K):</div>
                      <input
                        type="number"
                        step="5"
                        value={gasTemp}
                        onChange={(e) => setGasTemp(parseFloat(e.target.value) || 298.15)}
                        className="w-full px-2 py-1 rounded bg-black/40 border border-white/10 text-white text-xs"
                      />
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-400">Volume V (L):</div>
                      <input
                        type="number"
                        step="1"
                        value={gasVolume}
                        onChange={(e) => setGasVolume(parseFloat(e.target.value) || 24.45)}
                        className="w-full px-2 py-1 rounded bg-black/40 border border-white/10 text-white text-xs"
                      />
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-black/50 border border-amber-500/30 flex items-center justify-between">
                    <div>
                      <span className="text-slate-400 text-[11px]">Pressure P: </span>
                      <span className="text-base font-extrabold text-amber-300 ml-1">
                        {currentPressure} atm
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400">
                      ≈ {(parseFloat(currentPressure) * 101.325).toFixed(1)} kPa
                    </span>
                  </div>
                </div>
              )}

              {tool.id === 'builder-electron-config' && (
                <div className="p-4 rounded-2xl bg-purple-950/20 border border-purple-500/30 space-y-3 font-mono text-xs">
                  <div className="flex items-center justify-between text-purple-300 font-bold">
                    <span className="flex items-center gap-1.5">
                      <Orbit className="w-3.5 h-3.5" /> Quantum Electron Configuration
                    </span>
                    <div className="flex items-center gap-1">
                      {['H', 'C', 'N', 'O', 'Cr', 'Fe', 'Cu'].map((sym) => (
                        <button
                          key={sym}
                          onClick={() => setConfigElement(sym)}
                          className={`px-1.5 py-0.5 rounded text-[10px] border ${
                            configElement === sym
                              ? 'bg-purple-500/40 border-purple-300 text-white font-bold'
                              : 'bg-white/5 border-white/10 text-slate-400'
                          }`}
                        >
                          {sym}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-black/50 border border-purple-500/30 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-white font-bold">
                        {currentConfigResult.name} (Z = {currentConfigResult.z})
                      </span>
                      <span className="text-[10px] text-purple-300 bg-purple-500/20 px-2 py-0.5 rounded-full">
                        {currentConfigResult.unpaired} Unpaired e⁻ (Paramagnetic)
                      </span>
                    </div>
                    <div className="text-cyan-300 font-mono text-xs">
                      Condensed: {currentConfigResult.condensed}
                    </div>
                    <div className="text-slate-400 font-mono text-[10px] truncate">
                      Full: {currentConfigResult.full}
                    </div>
                  </div>
                </div>
              )}

              {/* Purpose Card Toggle & Drawer */}
              <div className="space-y-3 pt-2 border-t border-white/10">
                <button
                  onClick={() => togglePurposeCard(tool.id)}
                  className="w-full py-2 px-3 rounded-xl bg-white/[0.03] hover:bg-white/[0.07] border border-white/10 text-xs font-mono text-cyan-300 hover:text-white flex items-center justify-between transition-colors"
                >
                  <span className="flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{isExpanded ? 'Hide Purpose Card' : 'View Purpose Card & Derivations'}</span>
                  </span>
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-slate-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  )}
                </button>

                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="overflow-hidden space-y-3 pt-1 text-xs font-mono"
                    >
                      {/* Purpose */}
                      <div className="p-3 rounded-xl bg-black/40 border border-white/10 space-y-1">
                        <div className="text-cyan-400 font-bold text-[11px]">🎯 Purpose & Role:</div>
                        <p className="text-slate-300 font-sans text-xs leading-relaxed">
                          {tool.purpose}
                        </p>
                      </div>

                      {/* Capabilities */}
                      <div className="p-3 rounded-xl bg-black/40 border border-white/10 space-y-1">
                        <div className="text-purple-400 font-bold text-[11px]">⚙️ What You Can Do:</div>
                        <ul className="text-slate-300 pl-4 list-disc space-y-1 text-[11px] font-sans">
                          {tool.whatYouCanDo.map((cap, cIdx) => (
                            <li key={cIdx}>{cap}</li>
                          ))}
                        </ul>
                      </div>

                      {/* Inputs & Outputs Grid */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                        <div className="p-2.5 rounded-xl bg-black/30 border border-white/5">
                          <div className="text-amber-300 font-bold mb-1">Inputs Required:</div>
                          <ul className="text-slate-400 pl-3 list-disc space-y-0.5 font-sans">
                            {tool.inputs.map((inp, idx) => (
                              <li key={idx}>{inp}</li>
                            ))}
                          </ul>
                        </div>

                        <div className="p-2.5 rounded-xl bg-black/30 border border-white/5">
                          <div className="text-emerald-300 font-bold mb-1">Outputs Produced:</div>
                          <ul className="text-slate-400 pl-3 list-disc space-y-0.5 font-sans">
                            {tool.outputs.map((out, idx) => (
                              <li key={idx}>{out}</li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      {/* Concrete Example */}
                      <div className="p-2.5 rounded-xl bg-cyan-950/30 border border-cyan-500/20 text-cyan-200 text-[11px] font-sans">
                        <strong className="font-mono text-cyan-300">💡 Concrete Example: </strong>
                        {tool.example}
                      </div>

                      {/* Related Modules Badges */}
                      <div className="flex flex-wrap items-center gap-1.5 pt-1">
                        <span className="text-[10px] text-slate-500">Related Modules:</span>
                        {tool.relatedTabs.map((rel, rIdx) => (
                          <button
                            key={rIdx}
                            onClick={() => onNavigateToTab(rel.tab)}
                            className="px-2 py-0.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-[10px] transition-colors flex items-center gap-1"
                          >
                            <span>{rel.label}</span>
                            <ArrowRight className="w-2.5 h-2.5" />
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Footer Launcher */}
              <div className="pt-3 border-t border-white/10 flex items-center justify-between">
                {tool.directTab ? (
                  <button
                    onClick={() => onNavigateToTab(tool.directTab!)}
                    className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold font-mono text-xs transition-all flex items-center justify-center gap-2 shadow-md shadow-cyan-500/20"
                  >
                    <span>Open {tool.name}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <div className="w-full flex items-center justify-between text-xs font-mono text-slate-400">
                    <span>Tool ready for calculations</span>
                    <button
                      onClick={() => onOpenChembotWithContext?.(`Explain how to calculate ${tool.name}`, { tool: tool.id })}
                      className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                    >
                      <Sparkles className="w-3.5 h-3.5" /> Ask ChemoBot
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
