import React, { useState } from 'react';
import { Boxes, Ruler, Sparkles, RefreshCw, Layers, Sliders, Info, CheckCircle2 } from 'lucide-react';
import { MoleculeViewer3D } from '../3d/MoleculeViewer3D';
import { MOLECULES_DATA } from '../../data/molecules';
import { Molecule3DData, AtomCoordinate, NavigationTab } from '../../types';

interface MoleculeLabViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

export const MoleculeLabView: React.FC<MoleculeLabViewProps> = ({ onNavigate }) => {
  const [selectedMolecule, setSelectedMolecule] = useState<Molecule3DData>(MOLECULES_DATA[4]); // Benzene default
  const [displayMode, setDisplayMode] = useState<'ball-and-stick' | 'space-filling' | 'wireframe' | 'electron-density'>('ball-and-stick');
  const [measurementMode, setMeasurementMode] = useState<'none' | 'distance' | 'angle'>('none');
  const [measurementResult, setMeasurementResult] = useState<string | null>(null);
  const [selectedAtom, setSelectedAtom] = useState<AtomCoordinate | null>(null);
  const [autoRotate, setAutoRotate] = useState<boolean>(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = ['all', 'inorganic', 'organic', 'biomolecule', 'pharmaceutical'];

  const filteredMolecules = MOLECULES_DATA.filter((m) =>
    selectedCategory === 'all' ? true : m.category === selectedCategory
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 rounded-3xl bg-white/[0.03] border border-white/10 backdrop-blur-xl shadow-xl">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <span>3D Molecular Simulator & CAD</span>
            <span className="text-xs px-3 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-mono">
              WebGL Real-Time
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1 font-light">
            Interact with organic and inorganic geometries in CPK space-filling, ball-and-stick, and measure bond lengths & angles.
          </p>
        </div>

        {/* Display Mode Switcher */}
        <div className="flex items-center rounded-full bg-white/5 border border-white/10 p-1 font-mono text-xs backdrop-blur-md">
          {[
            { id: 'ball-and-stick', label: 'Ball & Stick' },
            { id: 'space-filling', label: 'CPK Space' },
            { id: 'wireframe', label: 'Wireframe' },
            { id: 'electron-density', label: 'Density' }
          ].map((mode) => (
            <button
              key={mode.id}
              onClick={() => setDisplayMode(mode.id as any)}
              className={`px-3.5 py-1.5 rounded-full transition-all ${
                displayMode === mode.id
                  ? 'bg-white/20 text-white font-bold border border-white/20 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {mode.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main 3D Canvas & Molecule Catalog */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 3D WebGL Canvas */}
        <div className="lg:col-span-2 rounded-3xl bg-white/[0.03] border border-white/10 p-6 flex flex-col justify-between backdrop-blur-2xl relative shadow-2xl">
          <div className="flex flex-wrap items-center justify-between gap-2 z-10">
            <div className="flex items-center gap-2">
              <span className="text-base font-bold text-white font-mono">{selectedMolecule.name}</span>
              <span className="text-xs px-3 py-0.5 rounded-full bg-white/10 text-cyan-300 font-mono border border-white/10">
                {selectedMolecule.formula}
              </span>
            </div>

            {/* Measurement & Tool Controls */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setAutoRotate(!autoRotate)}
                className={`p-2 rounded-full text-xs font-mono border transition-all ${
                  autoRotate ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' : 'bg-white/5 text-slate-400 border-white/10 hover:bg-white/10'
                }`}
                title="Toggle Auto-Rotation"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${autoRotate ? 'animate-spin-slow' : ''}`} />
              </button>

              <button
                onClick={() => {
                  setMeasurementMode(measurementMode === 'distance' ? 'none' : 'distance');
                  setMeasurementResult(null);
                }}
                className={`px-3.5 py-1.5 rounded-full text-xs font-mono border transition-all flex items-center gap-1.5 ${
                  measurementMode === 'distance'
                    ? 'bg-cyan-400 text-black font-bold border-cyan-300 shadow-md shadow-cyan-500/30'
                    : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
                }`}
              >
                <Ruler className="w-3.5 h-3.5" />
                <span>Measure Distance</span>
              </button>

              <button
                onClick={() => {
                  setMeasurementMode(measurementMode === 'angle' ? 'none' : 'angle');
                  setMeasurementResult(null);
                }}
                className={`px-3.5 py-1.5 rounded-full text-xs font-mono border transition-all flex items-center gap-1.5 ${
                  measurementMode === 'angle'
                    ? 'bg-purple-500 text-white font-bold border-purple-400 shadow-md shadow-purple-500/30'
                    : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Measure Angle</span>
              </button>
            </div>
          </div>

          {/* WebGL Viewer */}
          <div className="w-full h-[450px] my-2">
            <MoleculeViewer3D
              molecule={selectedMolecule}
              displayMode={displayMode}
              showLabels={true}
              autoRotate={autoRotate}
              onSelectAtom={(atom) => setSelectedAtom(atom)}
              measurementMode={measurementMode}
              onMeasurementResult={(res) => setMeasurementResult(res)}
            />
          </div>

          {/* Measurement Indicator or Instructions Bar */}
          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between text-xs font-mono z-10 backdrop-blur-md">
            {measurementMode === 'none' && (
              <span className="text-slate-400">
                Tip: Drag to rotate 3D structure. Click any atom to inspect atomic properties.
              </span>
            )}
            {measurementMode === 'distance' && (
              <span className="text-cyan-400 font-semibold">
                {measurementResult || 'Click 2 consecutive atoms in the viewport to compute bond length.'}
              </span>
            )}
            {measurementMode === 'angle' && (
              <span className="text-purple-400 font-semibold">
                {measurementResult || 'Click 3 atoms (Terminal — Vertex — Terminal) to compute bond angle.'}
              </span>
            )}
          </div>
        </div>

        {/* Molecule Catalog & Chemical Characteristics */}
        <div className="space-y-4">
          {/* Catalog selector */}
          <div className="p-6 rounded-3xl bg-white/[0.03] border border-white/10 backdrop-blur-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-mono text-slate-400 uppercase tracking-wider font-semibold">
                Molecular Library
              </h3>
              {/* Category Filter */}
              <div className="flex gap-1">
                {['all', 'organic', 'biomolecule'].map((c) => (
                  <button
                    key={c}
                    onClick={() => setSelectedCategory(c)}
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono capitalize transition-all ${
                      selectedCategory === c ? 'bg-white/20 text-white font-bold border border-white/20' : 'text-slate-500 hover:text-slate-300'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 max-h-[220px] overflow-y-auto pr-1">
              {filteredMolecules.map((m) => (
                <button
                  key={m.id}
                  onClick={() => {
                    setSelectedMolecule(m);
                    setSelectedAtom(null);
                    setMeasurementResult(null);
                  }}
                  className={`p-3 rounded-2xl border text-left transition-all font-mono text-xs ${
                    selectedMolecule.id === m.id
                      ? 'bg-white/15 border-white/30 text-white shadow-md'
                      : 'bg-white/5 border-white/10 text-slate-400 hover:border-white/20 hover:text-white'
                  }`}
                >
                  <div className="font-bold text-white truncate">{m.name}</div>
                  <div className="text-[10px] text-cyan-400 mt-0.5">{m.formula}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Molecule Properties Card */}
          <div className="p-6 rounded-3xl bg-white/[0.03] border border-white/10 backdrop-blur-xl space-y-4">
            <h3 className="text-xs font-mono text-emerald-400 uppercase tracking-wider font-bold">
              Molecular Physical & Chemical Parameters
            </h3>

            <div className="grid grid-cols-2 gap-2.5 font-mono text-xs">
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="text-[10px] text-slate-400">MOLAR MASS</div>
                <div className="text-sm font-bold text-white mt-0.5">{selectedMolecule.molarMass} g/mol</div>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="text-[10px] text-slate-400">DIPOLE MOMENT</div>
                <div className="text-sm font-bold text-white mt-0.5 truncate">{selectedMolecule.dipoleMoment}</div>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="text-[10px] text-slate-400">GEOMETRY</div>
                <div className="text-sm font-bold text-cyan-300 mt-0.5">{selectedMolecule.geometry}</div>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="text-[10px] text-slate-400">HYBRIDIZATION</div>
                <div className="text-sm font-bold text-purple-300 mt-0.5">{selectedMolecule.hybridization}</div>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed font-light pt-1">
              {selectedMolecule.description}
            </p>

            {/* Selected Atom Inspector */}
            {selectedAtom && (
              <div className="p-3.5 rounded-2xl bg-white/5 border border-cyan-400/30 font-mono text-xs space-y-1 mt-2 backdrop-blur-md">
                <div className="text-cyan-400 font-bold">Inspected Atom: {selectedAtom.id} ({selectedAtom.element})</div>
                <div className="text-slate-400 text-[11px]">
                  Coordinates: X: {selectedAtom.x}, Y: {selectedAtom.y}, Z: {selectedAtom.z}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
