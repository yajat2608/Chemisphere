import React, { useState, useEffect, useRef } from 'react';
import * as THREE from 'three';
import {
  Sparkles,
  ArrowRight,
  Layers,
  Zap,
  BookOpen,
  Search,
  Atom,
  RotateCcw,
  Sliders,
  CheckCircle2,
  ChevronRight,
  FlaskConical,
  Flame,
  Compass
} from 'lucide-react';
import { ORGANIC_REACTION_MAP, OrganicTransformationNode, OrganicReactionEdge } from '../../data/reactions';
import {
  NAME_REACTIONS_DB,
  NameReaction,
  ORGANIC_FUNDAMENTALS,
  OrganicFundamentalItem,
  ORGANIC_MOLECULES_3D,
  OrganicMolecule3D
} from '../../data/organicData';
import { LatexRenderer } from '../common/LatexRenderer';
import { NavigationTab } from '../../types';

interface OrganicChemViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

export const OrganicChemView: React.FC<OrganicChemViewProps> = ({ onNavigate }) => {
  const [activeSubTab, setActiveSubTab] = useState<'highway' | 'reactions' | 'fundamentals' | 'explorer3d'>('highway');

  // Highway State
  const [selectedNode, setSelectedNode] = useState<OrganicTransformationNode>(ORGANIC_REACTION_MAP.nodes[3]);
  const [selectedEdge, setSelectedEdge] = useState<OrganicReactionEdge>(ORGANIC_REACTION_MAP.edges[3]);

  // Name Reactions State
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedReactionCategory, setSelectedReactionCategory] = useState<string>('All');
  const [selectedReaction, setSelectedReaction] = useState<NameReaction>(NAME_REACTIONS_DB[0]);

  // Fundamentals State
  const [selectedFundamental, setSelectedFundamental] = useState<OrganicFundamentalItem>(ORGANIC_FUNDAMENTALS[0]);
  const [fundamentalCategory, setFundamentalCategory] = useState<string>('All');

  // 3D Structure Explorer State
  const [selectedMolecule, setSelectedMolecule] = useState<OrganicMolecule3D>(ORGANIC_MOLECULES_3D[3]); // Benzene default
  const [renderMode, setRenderMode] = useState<'ball-stick' | 'spacefill' | 'wireframe'>('ball-stick');

  // 3D Canvas Refs
  const canvasContainerRef = useRef<HTMLDivElement | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const moleculeGroupRef = useRef<THREE.Group | null>(null);
  const isDraggingRef = useRef<boolean>(false);
  const prevMousePos = useRef({ x: 0, y: 0 });
  const frameIdRef = useRef<number>(0);

  // Initialize 3D Molecule Canvas
  useEffect(() => {
    if (activeSubTab !== 'explorer3d') return;
    const container = canvasContainerRef.current;
    if (!container) return;

    const width = container.clientWidth || 500;
    const height = container.clientHeight || 400;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 0, 7);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Lights
    const ambLight = new THREE.AmbientLight(0xffffff, 0.85);
    scene.add(ambLight);

    const dirLight1 = new THREE.DirectionalLight(0xf59e0b, 1.6);
    dirLight1.position.set(5, 8, 10);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x38bdf8, 1.2);
    dirLight2.position.set(-5, -6, -4);
    scene.add(dirLight2);

    const molGroup = new THREE.Group();
    moleculeGroupRef.current = molGroup;
    scene.add(molGroup);

    // Build 3D Molecule Geometry
    const atomRadiusMult = renderMode === 'spacefill' ? 1.8 : renderMode === 'wireframe' ? 0.4 : 1.0;
    const showBonds = renderMode !== 'spacefill';

    selectedMolecule.atoms.forEach((atom) => {
      const atomGeom = new THREE.SphereGeometry(atom.radius * atomRadiusMult, 24, 24);
      const atomMat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(atom.color),
        roughness: 0.3,
        metalness: 0.1
      });
      const atomMesh = new THREE.Mesh(atomGeom, atomMat);
      atomMesh.position.set(atom.x, atom.y, atom.z);
      molGroup.add(atomMesh);
    });

    if (showBonds) {
      selectedMolecule.bonds.forEach((bond) => {
        const atomA = selectedMolecule.atoms[bond.source];
        const atomB = selectedMolecule.atoms[bond.target];
        if (!atomA || !atomB) return;

        const posA = new THREE.Vector3(atomA.x, atomA.y, atomA.z);
        const posB = new THREE.Vector3(atomB.x, atomB.y, atomB.z);
        const dist = posA.distanceTo(posB);
        const midPoint = new THREE.Vector3().addVectors(posA, posB).multiplyScalar(0.5);

        const bondRadius = renderMode === 'wireframe' ? 0.02 : bond.order === 3 ? 0.05 : bond.order === 2 ? 0.06 : 0.07;
        const bondGeom = new THREE.CylinderGeometry(bondRadius, bondRadius, dist, 16);
        const bondMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.4 });
        const bondMesh = new THREE.Mesh(bondGeom, bondMat);

        bondMesh.position.copy(midPoint);
        bondMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3().subVectors(posB, posA).normalize());
        molGroup.add(bondMesh);
      });
    }

    const handleResize = () => {
      if (!container || !rendererRef.current) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      rendererRef.current.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    const animate = () => {
      if (molGroup && !isDraggingRef.current) {
        molGroup.rotation.y += 0.005;
        molGroup.rotation.x += 0.002;
      }
      renderer.render(scene, camera);
      frameIdRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameIdRef.current);
      renderer.dispose();
    };
  }, [activeSubTab, selectedMolecule, renderMode]);

  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current || !moleculeGroupRef.current) return;
    const dx = e.clientX - prevMousePos.current.x;
    const dy = e.clientY - prevMousePos.current.y;
    moleculeGroupRef.current.rotation.y += dx * 0.01;
    moleculeGroupRef.current.rotation.x += dy * 0.01;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  // Filter Name Reactions
  const filteredReactions = NAME_REACTIONS_DB.filter((rxn) => {
    const matchesCategory = selectedReactionCategory === 'All' || rxn.category === selectedReactionCategory;
    const matchesSearch =
      rxn.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rxn.reagents.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rxn.reactants.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Filter Fundamentals
  const filteredFundamentals = ORGANIC_FUNDAMENTALS.filter(
    (item) => fundamentalCategory === 'All' || item.category === fundamentalCategory
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6 bg-lab-organic min-h-screen text-slate-100">
      {/* Organic Lab Suite Header */}
      <div className="p-6 rounded-3xl bg-[#090d16]/90 border border-amber-500/20 backdrop-blur-xl shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30 font-mono">
              LABORATORY // ORGANIC CHEMISTRY
            </span>
            <span className="text-xs text-slate-400 font-mono">CARBON DYNAMICS & SYNTHESIS</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-display-organic text-white tracking-tight mt-1">
            Organic Synthesis & Reaction Networks
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Explore functional group interconversions, named reactions, pericyclic mechanisms, and 3D molecular conformations.
          </p>
        </div>

        {/* Lab Sub-module Navigation */}
        <div className="flex flex-wrap items-center gap-1.5 p-1.5 rounded-2xl bg-black/40 border border-white/10 font-mono text-xs">
          {[
            { id: 'highway', label: 'The Organic Highway', icon: Compass },
            { id: 'reactions', label: 'Name Reactions Database', icon: FlaskConical },
            { id: 'fundamentals', label: 'Fundamentals & Effects', icon: Zap },
            { id: 'explorer3d', label: '3D Structure Explorer', icon: Atom }
          ].map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeSubTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveSubTab(tab.id as any)}
                className={`px-3.5 py-2 rounded-xl transition-all flex items-center gap-2 ${
                  isSelected
                    ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-400/40 shadow-lg shadow-amber-500/10'
                    : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* MODULE 1: THE ORGANIC HIGHWAY */}
      {activeSubTab === 'highway' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Node and Highway Graph Directory */}
          <div className="lg:col-span-7 p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-mono text-amber-400 uppercase tracking-wider flex items-center gap-2">
                <Compass className="w-4 h-4" />
                <span>Functional Group Hubs</span>
              </h2>
              <span className="text-[11px] text-slate-400 font-mono">Select a group to trace synthesis routes</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {ORGANIC_REACTION_MAP.nodes.map((node) => {
                const isSelected = selectedNode.id === node.id;
                return (
                  <div
                    key={node.id}
                    onClick={() => setSelectedNode(node)}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer font-mono text-xs flex flex-col justify-between h-24 ${
                      isSelected
                        ? 'bg-amber-500/20 border-amber-400 text-white shadow-lg shadow-amber-500/10'
                        : 'bg-white/[0.02] border-white/5 text-slate-300 hover:border-white/20'
                    }`}
                  >
                    <span className="text-[10px] text-amber-400/80 font-bold uppercase truncate">{node.functionalGroup}</span>
                    <div>
                      <div className="font-bold text-white text-xs truncate">{node.name.split(' ')[0]}</div>
                      <div className="text-[11px] text-cyan-300">{node.formula}</div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Transformations Flow List */}
            <div className="space-y-3 pt-2">
              <h3 className="text-xs font-mono text-slate-400 uppercase tracking-wider">
                Synthesis Highways & Reaction Steps
              </h3>

              <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
                {ORGANIC_REACTION_MAP.edges.map((edge, idx) => {
                  const isSelected = selectedEdge === edge;
                  const fromNode = ORGANIC_REACTION_MAP.nodes.find((n) => n.id === edge.from);
                  const toNode = ORGANIC_REACTION_MAP.nodes.find((n) => n.id === edge.to);

                  return (
                    <div
                      key={idx}
                      onClick={() => setSelectedEdge(edge)}
                      className={`p-3 rounded-2xl border transition-all cursor-pointer font-mono text-xs flex items-center justify-between gap-3 ${
                        isSelected
                          ? 'bg-amber-500/20 border-amber-400 text-white shadow-md'
                          : 'bg-white/[0.02] border-white/5 text-slate-300 hover:border-white/20'
                      }`}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="font-bold text-amber-300 shrink-0">{fromNode?.name.split(' ')[0]}</span>
                        <ArrowRight className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                        <span className="font-bold text-cyan-300 shrink-0">{toNode?.name.split(' ')[0]}</span>
                        <span className="text-slate-400 text-[10px] truncate hidden sm:inline">
                          ({edge.mechanism})
                        </span>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded-lg bg-black/40 text-amber-200 border border-amber-500/20 shrink-0">
                        {edge.reagent}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Detailed Transformation Dossier */}
          <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-4 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <span className="text-amber-400 font-bold uppercase tracking-wider text-xs">
                Reaction Dossier
              </span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                {selectedEdge.type}
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-black/40 border border-white/5 space-y-2">
              <span className="text-slate-500 uppercase text-[10px] tracking-wider block">Chemical Transformation</span>
              <div className="text-sm font-bold text-white flex items-center gap-2">
                <span>{ORGANIC_REACTION_MAP.nodes.find((n) => n.id === selectedEdge.from)?.formula}</span>
                <ArrowRight className="w-4 h-4 text-amber-400" />
                <span>{ORGANIC_REACTION_MAP.nodes.find((n) => n.id === selectedEdge.to)?.formula}</span>
              </div>
            </div>

            <div className="space-y-2.5 text-slate-300">
              <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
                <span className="text-slate-500 text-[10px] uppercase">Reagents:</span>
                <div className="text-amber-300 font-bold">{selectedEdge.reagent}</div>
              </div>

              <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
                <span className="text-slate-500 text-[10px] uppercase">Conditions:</span>
                <div className="text-white">{selectedEdge.conditions}</div>
              </div>

              <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
                <span className="text-slate-500 text-[10px] uppercase">Mechanism:</span>
                <div className="text-cyan-300 font-bold">{selectedEdge.mechanism}</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODULE 2: NAME REACTIONS DATABASE */}
      {activeSubTab === 'reactions' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Reaction Directory & Filter Sidebar */}
          <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-4 font-mono text-xs">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search name reactions, reagents..."
                className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-black/40 border border-white/10 text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap gap-1.5">
              {['All', 'Carbon-Carbon Bond', 'Carbonyl & Carboxylic', 'Reductions & Oxidations', 'Aromatic & Halides', 'Rearrangements & Nitrogen'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedReactionCategory(cat)}
                  className={`px-2.5 py-1 rounded-xl text-[11px] transition-all ${
                    selectedReactionCategory === cat
                      ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-400/40'
                      : 'bg-white/[0.02] text-slate-400 hover:text-white border border-white/5'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Reaction List */}
            <div className="space-y-2 max-h-[460px] overflow-y-auto pr-1">
              {filteredReactions.map((rxn) => {
                const isSelected = selectedReaction.id === rxn.id;
                return (
                  <div
                    key={rxn.id}
                    onClick={() => setSelectedReaction(rxn)}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-500/20 border-amber-400 text-white shadow-md'
                        : 'bg-white/[0.02] border-white/5 text-slate-300 hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-xs">{rxn.name}</span>
                      <span className="text-[10px] text-amber-400/80">{rxn.category.split(' ')[0]}</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 truncate">{rxn.reagents}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Selected Reaction Deep Dive */}
          <div className="lg:col-span-7 p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-5 font-mono text-xs">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-white/10 pb-4">
              <div>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30">
                  {selectedReaction.category}
                </span>
                <h2 className="text-xl font-bold font-display-organic text-white mt-1">
                  {selectedReaction.name}
                </h2>
              </div>
            </div>

            {/* LaTeX Equation Display Card */}
            <div className="p-4 rounded-2xl bg-black/50 border border-amber-500/20 space-y-2">
              <span className="text-slate-500 uppercase text-[10px] tracking-wider block">Chemical Equation</span>
              <div className="text-sm text-amber-200 py-1 overflow-x-auto">
                <LatexRenderer latex={selectedReaction.equationLatex} />
              </div>
            </div>

            {/* Reagents & Conditions Matrix */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
                <span className="text-slate-500 text-[10px] uppercase">Starting Reactants:</span>
                <div className="text-white font-bold">{selectedReaction.reactants}</div>
              </div>
              <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
                <span className="text-slate-500 text-[10px] uppercase">Reagents & Catalysts:</span>
                <div className="text-amber-300 font-bold">{selectedReaction.reagents}</div>
              </div>
            </div>

            {/* Mechanism & Intermediate */}
            <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2">
              <span className="text-cyan-400 font-bold uppercase text-[11px] block">
                Reactive Intermediate & Transition State
              </span>
              <div className="text-slate-200 font-bold text-xs bg-black/40 p-2.5 rounded-xl border border-white/5">
                {selectedReaction.intermediate}
              </div>
            </div>

            {/* Mechanism Step Breakdown */}
            <div className="space-y-2">
              <span className="text-slate-400 font-bold uppercase text-[11px] block">
                Step-by-Step Mechanism Pathway
              </span>
              <div className="space-y-2">
                {selectedReaction.mechanismSteps.map((step, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-2xl bg-white/[0.02] border border-white/5 text-slate-300 text-[11px] leading-relaxed flex items-start gap-2.5"
                  >
                    <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <span>{step}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Applications */}
            <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
              <span className="text-slate-500 text-[10px] uppercase">Synthetic & Pharmaceutical Utility:</span>
              <p className="text-slate-300 text-xs leading-relaxed">{selectedReaction.applications}</p>
            </div>
          </div>
        </div>
      )}

      {/* MODULE 3: ORGANIC FUNDAMENTALS & ELECTRONIC EFFECTS */}
      {activeSubTab === 'fundamentals' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 font-mono text-xs">
          {/* Concept Navigation */}
          <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-4">
            <div className="flex flex-wrap gap-1.5">
              {['All', 'Hybridization', 'Electronic Effects', 'Aromaticity'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setFundamentalCategory(cat)}
                  className={`px-3 py-1 rounded-xl text-[11px] transition-all ${
                    fundamentalCategory === cat
                      ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-400/40'
                      : 'bg-white/[0.02] text-slate-400 hover:text-white border border-white/5'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="space-y-2 max-h-[480px] overflow-y-auto pr-1">
              {filteredFundamentals.map((item) => {
                const isSelected = selectedFundamental.id === item.id;
                return (
                  <div
                    key={item.id}
                    onClick={() => setSelectedFundamental(item)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-500/20 border-amber-400 text-white shadow-md'
                        : 'bg-white/[0.02] border-white/5 text-slate-300 hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-xs">{item.name}</span>
                      <span className="text-[10px] text-amber-400">{item.category}</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">{item.concept}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Concept Deep Dive */}
          <div className="lg:col-span-7 p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-5">
            <div>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30">
                {selectedFundamental.category}
              </span>
              <h2 className="text-xl font-bold font-display-organic text-white mt-1">
                {selectedFundamental.name}
              </h2>
            </div>

            <div className="p-4 rounded-2xl bg-black/40 border border-white/5 space-y-1">
              <span className="text-slate-500 uppercase text-[10px]">Core Definition & Physics</span>
              <p className="text-slate-200 text-xs leading-relaxed">{selectedFundamental.concept}</p>
            </div>

            <div className="p-4 rounded-2xl bg-black/50 border border-amber-500/20 space-y-1">
              <span className="text-slate-500 uppercase text-[10px]">Mathematical Formula / Orbital Model</span>
              <div className="text-amber-200 py-1 overflow-x-auto">
                <LatexRenderer latex={selectedFundamental.formula} />
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2">
              <span className="text-cyan-400 font-bold uppercase text-[11px] block">
                Electronic Details & Chemical Impact
              </span>
              <p className="text-slate-300 text-xs leading-relaxed">{selectedFundamental.details}</p>
            </div>

            <div className="space-y-2">
              <span className="text-slate-400 font-bold uppercase text-[11px] block">Key Molecule Examples</span>
              <div className="grid grid-cols-2 gap-2">
                {selectedFundamental.examples.map((ex, i) => (
                  <div key={i} className="p-2.5 rounded-xl bg-white/[0.02] border border-white/5 text-slate-300">
                    {ex}
                  </div>
                ))}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200">
              <span className="font-bold block text-[11px] mb-1">KEY TAKEAWAY:</span>
              <span>{selectedFundamental.keyTakeaway}</span>
            </div>
          </div>
        </div>
      )}

      {/* MODULE 4: 3D ORGANIC STRUCTURE EXPLORER */}
      {activeSubTab === 'explorer3d' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 font-mono text-xs">
          {/* 3D Canvas Viewport */}
          <div className="lg:col-span-8 relative h-[450px] rounded-3xl bg-black/50 border border-white/10 overflow-hidden flex items-center justify-center select-none">
            <div
              ref={canvasContainerRef}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
              className="w-full h-full cursor-grab active:cursor-grabbing"
            />

            {/* Overlay Molecule Picker */}
            <div className="absolute top-4 left-4 flex flex-wrap gap-1.5 max-w-md">
              {ORGANIC_MOLECULES_3D.map((mol) => (
                <button
                  key={mol.id}
                  onClick={() => setSelectedMolecule(mol)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    selectedMolecule.id === mol.id
                      ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/20'
                      : 'bg-black/60 border border-white/10 text-slate-300 hover:text-white'
                  }`}
                >
                  {mol.formula}
                </button>
              ))}
            </div>

            {/* Rendering Modes */}
            <div className="absolute bottom-4 right-4 flex items-center gap-1.5 bg-black/70 p-1.5 rounded-2xl border border-white/10">
              {(['ball-stick', 'spacefill', 'wireframe'] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => setRenderMode(m)}
                  className={`px-2.5 py-1 rounded-xl text-[11px] uppercase font-bold transition-all ${
                    renderMode === m
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {m.replace('-', ' ')}
                </button>
              ))}
            </div>
          </div>

          {/* Molecule Dossier Sidebar */}
          <div className="lg:col-span-4 p-6 rounded-3xl bg-[#090d16]/90 border border-white/10 backdrop-blur-md space-y-4">
            <div>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30">
                {selectedMolecule.hybridization} HYBRIDIZATION
              </span>
              <h2 className="text-xl font-bold font-display-organic text-white mt-1">
                {selectedMolecule.name}
              </h2>
              <div className="text-xs text-slate-400 mt-0.5">IUPAC: {selectedMolecule.iupacName}</div>
            </div>

            <div className="space-y-2 text-slate-300">
              <div className="flex justify-between p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                <span>Molecular Formula:</span>
                <span className="text-amber-300 font-bold">{selectedMolecule.formula}</span>
              </div>
              <div className="flex justify-between p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                <span>Molar Mass:</span>
                <span className="text-white font-bold">{selectedMolecule.molarMass} g/mol</span>
              </div>
              <div className="flex justify-between p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                <span>Geometry:</span>
                <span className="text-cyan-300 font-bold">{selectedMolecule.geometry}</span>
              </div>
            </div>

            <p className="text-slate-300 text-xs leading-relaxed pt-2 border-t border-white/10">
              {selectedMolecule.description}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
