import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  Send,
  Bot,
  User,
  RefreshCw,
  Atom,
  Flame,
  Zap,
  Scale,
  Cpu,
  Volume2,
  VolumeX,
  Copy,
  Check,
  Download,
  ArrowRight,
  HelpCircle,
  BookOpen,
  FlaskConical,
  Compass,
  Boxes,
  Orbit,
  Grid3X3,
  Layers,
  GraduationCap,
  Trophy,
  Archive,
  ShieldAlert,
  UserCheck
} from 'lucide-react';
import { LatexRenderer } from '../common/LatexRenderer';
import { ChemistryMarkdown } from '../common/ChemistryMarkdown';
import { NavigationTab } from '../../types';
import { getUserProfile, UserProfile } from '../../data/userProfile';

interface AiTutorViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

export interface StructuredAnswer {
  concept: string;
  answer: string;
  formula?: string;
  steps?: string[];
  result: string;
  visualTarget?: NavigationTab | string | null;
  visualExplanation?: string;
  suggestedQuestions?: string[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string | StructuredAnswer;
  timestamp: string;
  copied?: boolean;
}

export const AiTutorView: React.FC<AiTutorViewProps> = ({ onNavigate }) => {
  const [profile, setProfile] = useState<UserProfile>(() => getUserProfile());

  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'welcome-msg',
      role: 'assistant',
      content: {
        concept: 'Chemisphere 3D Autonomous Scientific AI',
        answer: `Hello **${getUserProfile().name || 'Chemist'}**! Welcome to **ChemoBot AI** — your next-generation chemistry copilot and research assistant. I can help you formulate reaction mechanisms, balance equations, derive quantum wavefunctions, analyze spectra, or guide you through any of the **Chemisphere 3D** simulation modules.`,
        formula: '\\hat{H}\\Psi = E\\Psi, \\quad \\Delta G = \\Delta H - T\\Delta S',
        steps: [
          'Select any preset topic from below or type any chemical question or equation.',
          'ChemoBot will provide the core concept, step-by-step mechanism/derivation, and LaTeX mathematical proof.',
          'Whenever applicable, ChemoBot will provide a direct 3D visual link to the relevant laboratory simulator.'
        ],
        result: 'ChemoBot AI is online and ready for scientific reasoning.',
        visualTarget: 'questions-playground',
        visualExplanation: 'Try testing your intuition in the Questions Playground or conducting live reactions in the Chemistry Lab.',
        suggestedQuestions: [
          'Why is the bond angle in H₂O 104.5° instead of 109.5°?',
          'Explain why 4s fills before 3d in the Aufbau principle',
          'How does the Golden Rain (PbI₂) reaction work?',
          'Differentiate SN1 vs SN2 stereochemistry with mechanisms'
        ]
      },
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const [inputQuery, setInputQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isSpeaking, setIsSpeaking] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const chatBottomRef = useRef<HTMLDivElement | null>(null);

  const categories = [
    { id: 'all', label: 'All Topics', icon: Sparkles },
    { id: 'playground', label: 'Playground & Olympiad', icon: Trophy },
    { id: 'lab', label: 'Reaction Sandbox', icon: FlaskConical },
    { id: 'quantum', label: 'Quantum & Orbitals', icon: Orbit },
    { id: 'vsepr', label: 'VSEPR & Bonding', icon: Atom },
    { id: 'organic', label: 'Organic Mechanisms', icon: Flame },
    { id: 'physical', label: 'Thermodynamics & Kinetics', icon: Zap },
    { id: 'archive', label: 'Archive & Reference', icon: Archive }
  ];

  const presetQuestions = [
    {
      cat: 'playground',
      icon: Trophy,
      title: 'Olympiad: Nernst Cell Potential',
      query: 'In a Daniell Voltaic Cell (Zn | Zn²⁺ || Cu²⁺ | Cu), how does increasing [Zn²⁺] from 0.01M to 1.0M affect E_cell?'
    },
    {
      cat: 'lab',
      icon: FlaskConical,
      title: 'Golden Rain & Coordination',
      query: 'Explain the chemistry and solubility equilibrium of the Golden Rain reaction (Pb(NO₃)₂ + KI → PbI₂).'
    },
    {
      cat: 'vsepr',
      icon: Atom,
      title: 'Water Bond Angle & VSEPR',
      query: 'Why is the bond angle in H₂O 104.5° instead of 109.5° tetrahedral?'
    },
    {
      cat: 'quantum',
      icon: Orbit,
      title: 'Aufbau 4s vs 3d Filling Order',
      query: 'Explain why 4s fills before 3d in the Aufbau principle and energy degenerate exceptions.'
    },
    {
      cat: 'organic',
      icon: Flame,
      title: 'SN1 vs SN2 Stereochemistry',
      query: 'Differentiate SN1 vs SN2 stereochemistry with carbocation rearrangement pathways.'
    },
    {
      cat: 'archive',
      icon: Archive,
      title: 'FTIR Carbonyl vs Alcohol Shifts',
      query: 'How do you distinguish an aldehyde from a carboxylic acid using FTIR and ¹H NMR spectroscopy?'
    }
  ];

  const filteredPresets = selectedCategory === 'all'
    ? presetQuestions
    : presetQuestions.filter((p) => p.cat === selectedCategory);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Clean up speech on unmount
  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const handleSpeak = (msgId: string, textToSpeak: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    if (isSpeaking === msgId) {
      window.speechSynthesis.cancel();
      setIsSpeaking(null);
      return;
    }

    window.speechSynthesis.cancel();
    // Clean text of markdown and LaTeX symbols for clear audio readout
    const cleanedText = textToSpeak
      .replace(/\$\$[^\$]+\$\$/g, ' mathematical equation ')
      .replace(/\$[^\$]+\$/g, ' chemical formula ')
      .replace(/[*#_`]/g, '')
      .replace(/\\rightarrow/g, ' yields ')
      .replace(/\\Delta/g, ' delta ');

    const utterance = new SpeechSynthesisUtterance(cleanedText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.onend = () => setIsSpeaking(null);
    utterance.onerror = () => setIsSpeaking(null);

    setIsSpeaking(msgId);
    window.speechSynthesis.speak(utterance);
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleExportTranscript = () => {
    let transcript = `# ChemBot AI Chemistry Consultation Transcript\nDate: ${new Date().toLocaleString()}\nPlatform: Chemisphere 3D\n\n`;
    messages.forEach((msg) => {
      const isAssistant = msg.role === 'assistant';
      transcript += `### [${msg.timestamp}] ${isAssistant ? 'ChemBot AI' : 'User'}\n`;
      if (typeof msg.content === 'string') {
        transcript += `${msg.content}\n\n`;
      } else {
        transcript += `**Concept:** ${msg.content.concept}\n\n`;
        transcript += `${msg.content.answer}\n\n`;
        if (msg.content.formula) transcript += `**Formula:** $$${msg.content.formula}$$\n\n`;
        if (msg.content.result) transcript += `**Result:** ${msg.content.result}\n\n`;
      }
    });

    const blob = new Blob([transcript], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `chembot-transcript-${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSendMessage = async (textToSend?: string) => {
    const query = textToSend || inputQuery.trim();
    if (!query || isLoading) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputQuery('');
    setIsLoading(true);

    try {
      // Build conversation history payload
      const historyPayload = messages.slice(-6).map((m) => ({
        role: m.role,
        content: typeof m.content === 'string' ? m.content : `${m.content.concept}: ${m.content.result}`
      }));

      const response = await fetch('/api/ai/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: query,
          context: { source: 'chemisphere-3d-main-tutor', module: 'chembot-ai' },
          history: historyPayload
        })
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      const rawAnswer = data.answer;

      const assistantMessage: ChatMessage = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        content: rawAnswer || 'Response synthesized.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err: any) {
      console.error('ChemBot query error:', err);
      const fallbackMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'assistant',
        content: {
          concept: 'Physical & Molecular Reasoning',
          answer: `Regarding your query **"${query}"**:\n\nChemBot analyzed the chemical and physical relationships. In quantum and physical chemistry, reaction spontaneity is determined by Gibbs Free Energy ($\\Delta G = \\Delta H - T\\Delta S$), while molecular shape is governed by electron pair repulsion forces.`,
          formula: '\\Delta G = \\Delta H - T\\Delta S, \\quad PV = nRT',
          steps: [
            '1. Examine valence electrons and spatial hybridization.',
            '2. Calculate thermodynamic or kinetic driving forces.',
            '3. Use the corresponding 3D interactive simulator for real-time verification.'
          ],
          result: 'Consult the 3D simulators across Chemisphere 3D for interactive visual proofs.',
          visualTarget: 'vsepr-lab',
          visualExplanation: 'Explore molecular shapes and electron orbitals in 3D.',
          suggestedQuestions: [
            'How do lone pairs change bond angles?',
            'What is the difference between ΔG and ΔG°?'
          ]
        },
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const getTargetIcon = (target?: string | null) => {
    switch (target) {
      case 'questions-playground': return Trophy;
      case 'chemistry-lab': return FlaskConical;
      case 'archive': return Archive;
      case 'profile': return UserCheck;
      case 'periodic-table': return Grid3X3;
      case 'orbital-atlas': return Orbit;
      case 'molecules-3d': return Boxes;
      case 'vsepr-lab': return Atom;
      case 'atomic-structure': return Zap;
      case 'stoichiometry': return Scale;
      case 'organic-chem': return Flame;
      case 'physical-chem': return FlaskConical;
      case 'formula-vault': return BookOpen;
      case 'practice': return Layers;
      case 'creator': return GraduationCap;
      default: return Compass;
    }
  };

  const getTargetName = (target?: string | null) => {
    switch (target) {
      case 'questions-playground': return 'Questions Playground & Arena';
      case 'chemistry-lab': return 'Virtual Chemistry Lab';
      case 'archive': return 'Scientific Archive & Vault';
      case 'profile': return 'User Chemist Passport';
      case 'periodic-table': return 'Periodic Table & Trends';
      case 'orbital-atlas': return '3D Quantum Orbital Atlas';
      case 'molecules-3d': return '3D Molecular Simulator';
      case 'vsepr-lab': return '3D VSEPR Bonding Lab';
      case 'atomic-structure': return 'Atomic Structure History';
      case 'stoichiometry': return 'Stoichiometry Engine';
      case 'organic-chem': return 'Organic Reaction Highway';
      case 'physical-chem': return 'Physical Chemistry Suite';
      case 'formula-vault': return 'Formula Vault & Constants';
      case 'practice': return 'Practice Arena';
      case 'creator': return 'Creator Portfolio';
      default: return 'Explore Simulator';
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-3.5 sm:px-6 py-6 space-y-6">
      {/* Header Banner */}
      <div className="p-5 sm:p-7 rounded-3xl bg-[#090d16]/90 border border-purple-500/30 backdrop-blur-2xl shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Scientific Research Assistant Header Banner */}
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[10px] font-mono px-3 py-1 rounded-full bg-violet-500/15 text-violet-300 border border-violet-500/30 font-bold flex items-center gap-1.5">
                <Sparkles className="w-3 h-3 text-violet-400" />
                <span>SCIENTIFIC RESEARCH ASSISTANT</span>
              </span>
              <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                CHEMISTRY INTELLIGENCE COPILOT
              </span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-bold font-editorial text-white tracking-tight flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-violet-600 via-indigo-600 to-cyan-600 flex items-center justify-center text-white shadow-lg shadow-violet-500/20 border border-white/10">
                <Atom className="w-5 h-5 text-cyan-200 animate-spin-slow" />
              </div>
              <span>ChemoBot Research Assistant</span>
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl font-editorial italic leading-relaxed">
              Autonomous chemical reasoning copilot. Solves complex reaction mechanisms, balances redox equations, computes thermodynamic parameters, and guides you through 3D simulations.
            </p>
          </div>

          {/* Action Tools */}
          <div className="flex items-center gap-2.5 shrink-0 self-end md:self-center">
            <button
              onClick={handleExportTranscript}
              className="px-3.5 py-2 rounded-2xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 text-xs font-mono transition-all flex items-center gap-2"
              title="Download chat as Markdown"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Export Transcript</span>
            </button>

            <button
              onClick={() =>
                setMessages([
                  {
                    id: `reset-${Date.now()}`,
                    role: 'assistant',
                    content: {
                      concept: 'Research Consultation Reset',
                      answer: 'Chat session reset! What chemical reaction, quantum concept, or equation shall we solve next?',
                      result: 'Ready for new questions.',
                      suggestedQuestions: [
                        'What is the hybridization of SF₆ and XeF₄?',
                        'Calculate the ΔG for a reaction with ΔH = -50 kJ and ΔS = 100 J/K at 298 K',
                        'Explain the mechanism of acid-catalyzed esterification'
                      ]
                    },
                    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                  }
                ])
              }
              className="px-3.5 py-2 rounded-2xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 text-xs font-mono transition-all flex items-center gap-2"
              title="Reset conversation"
            >
              <RefreshCw className="w-3.5 h-3.5 text-violet-400" />
              <span>Reset</span>
            </button>
          </div>
        </div>
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        {categories.map((cat) => {
          const Icon = cat.icon;
          const isActive = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3.5 py-2 rounded-2xl text-xs font-mono font-medium transition-all flex items-center gap-2 whitespace-nowrap border ${
                isActive
                  ? 'bg-purple-500 text-white border-purple-400 shadow-lg shadow-purple-500/25'
                  : 'bg-white/5 hover:bg-white/10 text-slate-400 hover:text-slate-200 border-white/10'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Suggested Prompt Starters */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
        {filteredPresets.map((starter, i) => {
          const Icon = starter.icon;
          return (
            <motion.button
              key={i}
              whileHover={{ scale: 1.015, y: -2 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleSendMessage(starter.query)}
              className="p-3 sm:p-3.5 rounded-2xl bg-white/[0.03] hover:bg-purple-500/[0.08] border border-white/10 hover:border-purple-500/40 text-left transition-all group flex flex-col justify-between backdrop-blur-md"
            >
              <div className="flex items-center gap-2 text-purple-300 font-bold text-xs">
                <Icon className="w-4 h-4 text-purple-400 group-hover:scale-110 transition-transform shrink-0" />
                <span className="truncate">{starter.title}</span>
              </div>
              <p className="text-[11px] text-slate-400 line-clamp-1 mt-1 font-mono">
                {starter.query}
              </p>
            </motion.button>
          );
        })}
      </div>

      {/* Chat Messages Stream */}
      <div className="p-4 sm:p-6 rounded-3xl bg-[#080d19]/95 border border-white/10 backdrop-blur-2xl min-h-[460px] max-h-[640px] overflow-y-auto space-y-4 shadow-2xl">
        <AnimatePresence initial={false}>
          {messages.map((msg) => {
            const isAssistant = msg.role === 'assistant';
            const isStructured = typeof msg.content === 'object' && msg.content !== null;
            const structured: StructuredAnswer | null = isStructured ? (msg.content as StructuredAnswer) : null;
            const plainText = typeof msg.content === 'string' ? msg.content : (structured?.answer || '');

            const TargetIcon = getTargetIcon(structured?.visualTarget);

            return (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className={`flex gap-3 ${isAssistant ? 'justify-start' : 'justify-end'}`}
              >
                {isAssistant && (
                  <div className="w-8 h-8 rounded-2xl bg-gradient-to-br from-purple-600 to-indigo-600 border border-purple-400/40 flex items-center justify-center text-white shrink-0 mt-1 shadow-md shadow-purple-600/20">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-3xl w-full p-4 sm:p-5 rounded-3xl border text-xs leading-relaxed space-y-3.5 ${
                    isAssistant
                      ? 'bg-white/[0.03] border-white/10 text-slate-200 shadow-xl backdrop-blur-xl'
                      : 'bg-purple-600/30 border-purple-500/40 text-white shadow-lg shadow-purple-600/10 ml-12'
                  }`}
                >
                  {/* Top Message Meta Bar */}
                  <div className="flex items-center justify-between gap-4 pb-2 border-b border-white/5 text-[11px] font-mono text-slate-400">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white">
                        {isAssistant ? (structured?.concept || 'ChemBot AI Reasoning') : 'Researcher'}
                      </span>
                      {isAssistant && structured?.concept && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                          {structured.concept}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <span>{msg.timestamp}</span>
                      {isAssistant && (
                        <>
                          <button
                            onClick={() => handleSpeak(msg.id, plainText)}
                            className="p-1 rounded-lg hover:bg-white/10 text-slate-400 hover:text-cyan-300 transition-colors"
                            title={isSpeaking === msg.id ? 'Stop reading' : 'Read aloud with AI speech'}
                          >
                            {isSpeaking === msg.id ? (
                              <VolumeX className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
                            ) : (
                              <Volume2 className="w-3.5 h-3.5" />
                            )}
                          </button>

                          <button
                            onClick={() => handleCopy(msg.id, plainText)}
                            className="p-1 rounded-lg hover:bg-white/10 text-slate-400 hover:text-cyan-300 transition-colors"
                            title="Copy answer"
                          >
                            {copiedId === msg.id ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="space-y-3">
                    {/* Primary Answer Markdown */}
                    <ChemistryMarkdown content={plainText} />

                    {/* Formula Card if available */}
                    {structured?.formula && (
                      <div className="p-3.5 rounded-2xl bg-cyan-950/20 border border-cyan-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 overflow-x-auto">
                        <div className="flex items-center gap-2 text-cyan-400 font-mono text-[11px] font-bold uppercase tracking-wider shrink-0">
                          <Atom className="w-3.5 h-3.5" />
                          <span>Key Governing Equation</span>
                        </div>
                        <div className="py-1">
                          <LatexRenderer latex={structured.formula} displayMode={true} className="text-cyan-300 text-xs sm:text-sm" />
                        </div>
                      </div>
                    )}

                    {/* Step-by-Step Breakdown */}
                    {structured?.steps && structured.steps.length > 0 && (
                      <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/10 space-y-2">
                        <div className="text-[10px] font-mono uppercase tracking-wider text-purple-400 font-bold flex items-center gap-1.5">
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Mechanism & Calculation Steps</span>
                        </div>
                        <div className="space-y-1.5 font-mono text-[11px] text-slate-300">
                          {structured.steps.map((step, idx) => (
                            <div key={idx} className="flex items-start gap-2">
                              <span className="text-purple-400 font-bold shrink-0">•</span>
                              <span className="leading-relaxed">{step}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Definitive Result Badge */}
                    {structured?.result && (
                      <div className="p-3 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 flex items-start gap-2.5 text-emerald-300">
                        <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-500/20 border border-emerald-500/40 uppercase shrink-0 mt-0.5">
                          Result
                        </span>
                        <div className="text-xs leading-relaxed font-sans text-emerald-200">
                          {structured.result}
                        </div>
                      </div>
                    )}

                    {/* Interactive 3D Visual Simulator Action Button */}
                    {structured?.visualTarget && onNavigate && (
                      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-transparent border border-cyan-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mt-2">
                        <div className="space-y-0.5">
                          <div className="text-[10px] font-mono uppercase tracking-wider text-cyan-400 font-bold flex items-center gap-1.5">
                            <TargetIcon className="w-3.5 h-3.5" />
                            <span>Interactive Chemisphere 3D Laboratory</span>
                          </div>
                          <p className="text-[11px] text-slate-300 font-light">
                            {structured.visualExplanation || 'Launch the interactive 3D simulation to experiment with this concept in real-time.'}
                          </p>
                        </div>

                        <motion.button
                          whileHover={{ scale: 1.03 }}
                          whileTap={{ scale: 0.97 }}
                          onClick={() => onNavigate(structured.visualTarget as NavigationTab)}
                          className="px-4 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs font-mono shadow-md shadow-cyan-400/20 flex items-center gap-2 shrink-0 transition-all"
                        >
                          <span>Open {getTargetName(structured.visualTarget)}</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </motion.button>
                      </div>
                    )}

                    {/* Suggested Follow-up Prompts */}
                    {structured?.suggestedQuestions && structured.suggestedQuestions.length > 0 && (
                      <div className="pt-2 border-t border-white/5 space-y-1.5">
                        <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
                          Suggested Explorations:
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {structured.suggestedQuestions.map((sq, sqIdx) => (
                            <button
                              key={sqIdx}
                              onClick={() => handleSendMessage(sq)}
                              className="px-2.5 py-1 rounded-xl bg-white/5 hover:bg-purple-500/20 border border-white/10 hover:border-purple-400/40 text-[11px] text-slate-300 hover:text-white transition-all text-left font-mono"
                            >
                              {sq} →
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {!isAssistant && (
                  <div className="w-8 h-8 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 border border-cyan-400/40 flex items-center justify-center text-white shrink-0 mt-1 shadow-md shadow-cyan-500/20">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </motion.div>
            );
          })}
        </AnimatePresence>

        {isLoading && (
          <motion.div
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-3 text-purple-300 text-xs font-mono p-4 rounded-2xl bg-purple-500/10 border border-purple-500/30 max-w-md backdrop-blur-md shadow-lg"
          >
            <Cpu className="w-5 h-5 animate-spin text-purple-400" />
            <div>
              <div className="font-bold text-white">ChemBot Deep Reasoning Active</div>
              <div className="text-[11px] text-purple-300/80 mt-0.5">Synthesizing quantum wavefunctions, balancing reactions & compiling LaTeX...</div>
            </div>
          </motion.div>
        )}

        <div ref={chatBottomRef} />
      </div>

      {/* Input Prompt Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }}
        className="flex items-center gap-2 p-2 rounded-3xl bg-[#080d19]/95 border border-white/15 shadow-2xl backdrop-blur-2xl focus-within:border-purple-500/60 transition-all"
      >
        <div className="pl-3 text-purple-400 shrink-0">
          <Bot className="w-5 h-5" />
        </div>
        <input
          type="text"
          value={inputQuery}
          onChange={(e) => setInputQuery(e.target.value)}
          placeholder="Ask ChemBot any chemistry question, equation balance, organic mechanism, or website feature..."
          className="flex-1 px-3 py-3 bg-transparent text-white placeholder:text-slate-500 focus:outline-none text-xs sm:text-sm font-mono"
        />
        <button
          type="submit"
          disabled={!inputQuery.trim() || isLoading}
          className="px-5 py-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-40 text-white font-bold font-mono text-xs transition-all flex items-center gap-2 shadow-lg shadow-purple-600/30 shrink-0"
        >
          <span>Ask ChemBot</span>
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
};
