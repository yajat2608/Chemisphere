import React, { useState, useEffect, useRef } from 'react';
import {
  Atom,
  Flame,
  Zap,
  Activity,
  Play,
  Pause,
  RotateCcw,
  Shield,
  Layers,
  ArrowRight,
  BarChart3,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { NavigationTab } from '../../types';

interface NuclearChemistryViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

type NuclearSubTab = 'half-life' | 'decay-modes' | 'binding-energy' | 'fission-fusion';

export const NuclearChemistryView: React.FC<NuclearChemistryViewProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<NuclearSubTab>('half-life');

  // ==========================================
  // 1. HALF-LIFE STOCHASTIC SIMULATOR STATE
  // ==========================================
  const isotopes = [
    { name: 'Carbon-14 (¹⁴C)', halfLifeSec: 5.73, realHalfLife: '5,730 years', mode: 'β⁻ decay', daughter: 'Nitrogen-14 (¹⁴N)', color: '#38bdf8' },
    { name: 'Iodine-131 (¹³¹I)', halfLifeSec: 4.0, realHalfLife: '8.02 days', mode: 'β⁻ / γ decay', daughter: 'Xenon-131 (¹³¹Xe)', color: '#a855f7' },
    { name: 'Cobalt-60 (⁶⁰Co)', halfLifeSec: 5.27, realHalfLife: '5.27 years', mode: 'β⁻ / γ decay', daughter: 'Nickel-60 (⁶⁰Ni)', color: '#f59e0b' },
    { name: 'Radon-222 (²²²Rn)', halfLifeSec: 3.82, realHalfLife: '3.82 days', mode: 'α decay', daughter: 'Polonium-218 (²¹⁸Po)', color: '#ef4444' },
    { name: 'Tritium (³H)', halfLifeSec: 6.0, realHalfLife: '12.32 years', mode: 'β⁻ decay', daughter: 'Helium-3 (³He)', color: '#10b981' }
  ];
  const [selectedIsotope, setSelectedIsotope] = useState(isotopes[0]);
  const [initialNuclei] = useState(400);
  const [nucleiGrid, setNucleiGrid] = useState<boolean[]>(() => Array(400).fill(true)); // true = parent, false = decayed
  const [simTime, setSimTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [history, setHistory] = useState<{ t: number; count: number }[]>([{ t: 0, count: 400 }]);

  // Stochastic decay animation loop
  useEffect(() => {
    let timer: any = null;
    if (isRunning) {
      timer = setInterval(() => {
        setSimTime((prevT) => {
          const newT = prevT + 0.2;
          const lambda = Math.LN2 / selectedIsotope.halfLifeSec;
          const pDecay = 1 - Math.exp(-lambda * 0.2);

          setNucleiGrid((prevGrid) => {
            let active = 0;
            const nextGrid = prevGrid.map((alive) => {
              if (!alive) return false;
              if (Math.random() < pDecay) {
                return false;
              }
              active++;
              return true;
            });
            setHistory((prevH) => [...prevH, { t: parseFloat(newT.toFixed(1)), count: active }]);
            if (active === 0) setIsRunning(false);
            return nextGrid;
          });

          return newT;
        });
      }, 200);
    }
    return () => clearInterval(timer);
  }, [isRunning, selectedIsotope]);

  const handleReset = () => {
    setIsRunning(false);
    setSimTime(0);
    setNucleiGrid(Array(400).fill(true));
    setHistory([{ t: 0, count: 400 }]);
  };

  const activeCount = nucleiGrid.filter(Boolean).length;
  const decayedCount = 400 - activeCount;
  const theoreticalCount = 400 * Math.pow(0.5, simTime / selectedIsotope.halfLifeSec);

  // ==========================================
  // 2. DECAY MODES & PENETRATION SHIELDING
  // ==========================================
  const decayTypes = [
    {
      id: 'alpha',
      name: 'Alpha (α) Decay',
      particle: '⁴₂He nucleus (2p + 2n)',
      charge: '+2e',
      mass: '4.0015 u',
      eqn: '²³⁸₉₂U → ²³⁴₉₀Th + ⁴₂α + 4.27 MeV',
      stoppedBy: 'Sheet of Paper / Outer skin layer',
      danger: 'High internal hazard if ingested/inhaled'
    },
    {
      id: 'beta-minus',
      name: 'Beta-Minus (β⁻) Decay',
      particle: 'High-speed electron (e⁻) + antineutrino',
      charge: '-1e',
      mass: '0.000548 u',
      eqn: '¹⁴₆C → ¹⁴₇N + e⁻ + ν̄_e + 0.156 MeV (n → p + e⁻ + ν̄_e)',
      stoppedBy: 'Few mm of Aluminum or Plastic',
      danger: 'Moderate tissue penetration'
    },
    {
      id: 'beta-plus',
      name: 'Beta-Plus (β⁺ / Positron) Decay',
      particle: 'Positron (e⁺) + neutrino',
      charge: '+1e',
      mass: '0.000548 u',
      eqn: '¹⁸₉F → ¹⁸₈O + e⁺ + ν_e + 0.63 MeV (p → n + e⁺ + ν_e)',
      stoppedBy: 'Annihilates with e⁻ to produce twin 511 keV γ rays (PET Scan)',
      danger: 'Used in medical imaging'
    },
    {
      id: 'gamma',
      name: 'Gamma (γ) Ray Emission',
      particle: 'High-energy electromagnetic photon',
      charge: '0',
      mass: '0 (massless)',
      eqn: '⁹⁹ᵐ₄₃Tc → ⁹⁹₄₃Tc + γ (140.5 keV)',
      stoppedBy: 'Thick Lead (Pb) bricks / Dense concrete',
      danger: 'Deeply penetrating external whole-body radiation'
    }
  ];
  const [selectedDecayType, setSelectedDecayType] = useState(decayTypes[0]);

  // ==========================================
  // 3. NUCLEAR BINDING ENERGY STATE
  // ==========================================
  const bindingData = [
    { symbol: '¹H', A: 1, Eb: 0.0 },
    { symbol: '²H', A: 2, Eb: 1.11 },
    { symbol: '⁴He', A: 4, Eb: 7.07 },
    { symbol: '¹²C', A: 12, Eb: 7.68 },
    { symbol: '¹⁶O', A: 16, Eb: 7.98 },
    { symbol: '⁵⁶Fe', A: 56, Eb: 8.79 }, // Maximum stability peak
    { symbol: '⁸⁴Kr', A: 84, Eb: 8.71 },
    { symbol: '¹⁴¹Ba', A: 141, Eb: 8.33 },
    { symbol: '²⁰⁸Pb', A: 208, Eb: 7.87 },
    { symbol: '²³⁵U', A: 235, Eb: 7.59 },
    { symbol: '²³⁸U', A: 238, Eb: 7.57 }
  ];
  const [selectedNuclide, setSelectedNuclide] = useState(bindingData[5]); // Fe-56

  // ==========================================
  // 4. FISSION & FUSION STATE
  // ==========================================
  const [controlRodInsertion, setControlRodInsertion] = useState<number>(50); // %
  const kMultiplication = 1.0 + (50 - controlRodInsertion) * 0.008;

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8 font-sans">
      {/* Header Banner */}
      <div className="relative rounded-3xl overflow-hidden border border-rose-500/30 bg-[#12080d] p-6 sm:p-10 shadow-2xl">
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-20 -bottom-20 w-80 h-80 bg-red-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-400/30 text-rose-400 text-xs font-mono font-bold tracking-wide">
            <Atom className="w-3.5 h-3.5" />
            <span>NUCLEAR CHEMISTRY & RADIOACTIVITY LABORATORY</span>
          </div>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-display-periodic">
                NUCLEAR CHEMISTRY LAB
              </h1>
              <p className="text-slate-300 text-sm sm:text-base max-w-3xl mt-2 leading-relaxed font-sans">
                Simulate <strong>Stochastic Radioactive Half-Life</strong> with active particle lattices, inspect <strong>Alpha, Beta, and Gamma</strong> decay mechanisms with penetration shielding, analyze the <strong>Nuclear Binding Energy per Nucleon</strong> curve ($E_b/A$), and test nuclear fission chain multiplication.
              </p>
            </div>

            {onNavigate && (
              <button
                onClick={() => onNavigate('lab-directory')}
                className="px-4 py-2.5 rounded-2xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-slate-300 hover:text-white font-mono text-xs font-bold transition-all shrink-0 flex items-center gap-2"
              >
                <span>LAB DIRECTORY</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Sub Navigation */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-[#090d16] border border-white/10 overflow-x-auto font-mono text-xs">
        {[
          { id: 'half-life' as NuclearSubTab, label: '1. Stochastic Half-Life Simulator', icon: Activity, color: 'text-rose-400' },
          { id: 'decay-modes' as NuclearSubTab, label: '2. α / β / γ Decay & Shielding', icon: Shield, color: 'text-amber-400' },
          { id: 'binding-energy' as NuclearSubTab, label: '3. Binding Energy & Fe-56 Peak', icon: Layers, color: 'text-cyan-400' },
          { id: 'fission-fusion' as NuclearSubTab, label: '4. Fission Chain & Thermonuclear Fusion', icon: Flame, color: 'text-purple-400' }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2.5 rounded-xl font-bold flex items-center gap-2 whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-white/15 text-white border border-white/20 shadow-lg'
                  : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
              }`}
            >
              <Icon className={`w-4 h-4 ${tab.color}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ============================================================== */}
      {/* 1. STOCHASTIC RADIOACTIVE HALF-LIFE SIMULATOR */}
      {/* ============================================================== */}
      {activeTab === 'half-life' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Controls & Grid Visualizer */}
            <div className="lg:col-span-6 p-6 rounded-3xl bg-[#090d16] border border-rose-500/30 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-rose-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Activity className="w-4 h-4" />
                  <span>Stochastic 400-Nuclei Grid (N vs Time)</span>
                </span>
                <span className="text-slate-400 text-[10px]">N(t) = N₀ · (1/2)^(t/t₁/₂)</span>
              </div>

              {/* Select Isotope */}
              <div className="space-y-2">
                <label className="text-slate-400 uppercase text-[10px] block">Select Radioisotope:</label>
                <div className="grid grid-cols-2 gap-2">
                  {isotopes.map((iso) => (
                    <button
                      key={iso.name}
                      onClick={() => {
                        setSelectedIsotope(iso);
                        handleReset();
                      }}
                      className={`p-2.5 rounded-xl text-left border transition-all ${
                        selectedIsotope.name === iso.name
                          ? 'bg-rose-500/20 border-rose-400 text-rose-300 font-bold'
                          : 'bg-white/[0.02] border-white/5 text-slate-300 hover:bg-white/[0.05]'
                      }`}
                    >
                      <div className="font-bold">{iso.name}</div>
                      <div className="text-[10px] text-slate-400">t₁/₂ = {iso.realHalfLife}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Simulation Action Controls */}
              <div className="flex items-center gap-2 pt-2">
                <button
                  onClick={() => setIsRunning(!isRunning)}
                  className={`flex-1 py-3 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all ${
                    isRunning
                      ? 'bg-amber-500 text-slate-950 shadow-lg'
                      : 'bg-rose-500 hover:bg-rose-400 text-slate-950 shadow-lg shadow-rose-500/20'
                  }`}
                >
                  {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  <span>{isRunning ? 'PAUSE SIMULATION' : 'START STOCHASTIC DECAY'}</span>
                </button>
                <button
                  onClick={handleReset}
                  className="p-3 rounded-2xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-slate-300"
                  title="Reset Sample"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>

              {/* Live 400-Nuclei Grid */}
              <div className="p-4 rounded-2xl bg-black/60 border border-white/10 space-y-3">
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-400">Active Parent ({selectedIsotope.name}): <strong className="text-rose-400">{activeCount}</strong></span>
                  <span className="text-slate-400">Decayed Daughter ({selectedIsotope.daughter}): <strong className="text-emerald-400">{decayedCount}</strong></span>
                </div>
                <div className="grid grid-cols-20 gap-1 p-2 bg-slate-950 rounded-xl border border-white/5">
                  {nucleiGrid.map((alive, idx) => (
                    <div
                      key={idx}
                      className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                        alive ? 'bg-rose-500 shadow-sm shadow-rose-500/50' : 'bg-emerald-500/30'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Right Live N vs Time Plot */}
            <div className="lg:col-span-6 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-rose-400" />
                    <span>Real-Time Decay Curve (N vs Elapsed Time)</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                    Comparing experimental stochastic curve against theoretical exponential decay
                  </p>
                </div>
              </div>

              {/* SVG Decay Plot */}
              <div className="w-full bg-black/60 rounded-2xl p-4 border border-white/5">
                <svg viewBox="0 0 500 180" className="w-full h-auto select-none">
                  {/* Grid Lines */}
                  {[400, 300, 200, 100, 0].map((n) => {
                    const y = 30 + ((400 - n) / 400) * 120;
                    return (
                      <g key={n}>
                        <line x1="40" y1={y} x2="470" y2={y} stroke="rgba(255,255,255,0.06)" strokeDasharray="3 3" />
                        <text x="32" y={y + 3} textAnchor="end" fill="#64748b" fontSize="8" fontFamily="monospace">{n}</text>
                      </g>
                    );
                  })}

                  {/* Theoretical Curve (White dotted) */}
                  {(() => {
                    const pts = [];
                    for (let t = 0; t <= 30; t += 0.5) {
                      const x = 40 + (t / 30) * 430;
                      const nTheo = 400 * Math.pow(0.5, t / selectedIsotope.halfLifeSec);
                      const y = 30 + ((400 - nTheo) / 400) * 120;
                      pts.push(`${x.toFixed(1)},${y.toFixed(1)}`);
                    }
                    return <path d={`M ${pts.join(' L ')}`} fill="none" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5" strokeDasharray="3 3" />;
                  })()}

                  {/* Experimental Stochastic History */}
                  {history.length > 1 && (() => {
                    const pts = history.map((pt) => {
                      const x = 40 + (Math.min(30, pt.t) / 30) * 430;
                      const y = 30 + ((400 - pt.count) / 400) * 120;
                      return `${x.toFixed(1)},${y.toFixed(1)}`;
                    });
                    return <path d={`M ${pts.join(' L ')}`} fill="none" stroke="#f43f5e" strokeWidth="2.5" />;
                  })()}

                  <line x1="40" y1="150" x2="470" y2="150" stroke="rgba(255,255,255,0.2)" />
                  <text x="255" y="170" textAnchor="middle" fill="#94a3b8" fontSize="9">Simulation Time (seconds) →</text>
                </svg>
              </div>

              {/* Summary Metrics */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5">
                  <span className="text-slate-500 text-[10px] block">Active Nuclei Remaining</span>
                  <span className="text-lg font-bold text-rose-400">{activeCount} / 400</span>
                </div>
                <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5">
                  <span className="text-slate-500 text-[10px] block">Theoretical Expected N</span>
                  <span className="text-lg font-bold text-slate-300">{theoreticalCount.toFixed(1)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 2. DECAY MODES & SHIELDING PENETRATION */}
      {/* ============================================================== */}
      {activeTab === 'decay-modes' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-amber-500/30 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-amber-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Shield className="w-4 h-4" />
                  <span>Select Nuclear Radiation Mode</span>
                </span>
              </div>

              <div className="space-y-2">
                {decayTypes.map((d) => (
                  <button
                    key={d.id}
                    onClick={() => setSelectedDecayType(d)}
                    className={`w-full text-left p-3 rounded-xl border transition-all ${
                      selectedDecayType.id === d.id
                        ? 'bg-amber-500/20 border-amber-400 text-amber-300 font-bold'
                        : 'bg-white/[0.02] border-white/5 text-slate-300 hover:bg-white/[0.05]'
                    }`}
                  >
                    <div className="font-bold">{d.name}</div>
                    <div className="text-[10px] text-slate-400">{d.particle}</div>
                  </button>
                ))}
              </div>

              {/* Active Equation Box */}
              <div className="p-4 rounded-2xl bg-black/60 border border-white/10 space-y-2">
                <span className="text-[10px] text-slate-400 uppercase block">Nuclear Reaction Equation:</span>
                <div className="p-2.5 rounded-xl bg-slate-950 border border-amber-500/30 text-amber-300 font-bold text-[11px]">
                  {selectedDecayType.eqn}
                </div>
                <div className="text-slate-300 text-[11px] font-sans pt-1">
                  <strong>Shielding Barrier:</strong> {selectedDecayType.stoppedBy}.
                </div>
              </div>
            </div>

            {/* Right Shielding Animation Visualizer */}
            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-white/10 pb-3">
                <Shield className="w-4 h-4 text-amber-400" />
                <span>Radiation Shielding Penetration Barrier Matrix</span>
              </h3>

              <div className="w-full bg-black/60 rounded-2xl p-4 border border-white/5">
                <svg viewBox="0 0 500 180" className="w-full h-auto select-none">
                  {/* Radioactive Source */}
                  <rect x="20" y="30" width="30" height="120" rx="6" fill="#e11d48" stroke="#ffffff" strokeWidth="1" />
                  <text x="35" y="95" textAnchor="middle" fill="#ffffff" fontSize="9" fontWeight="bold">Source</text>

                  {/* Barrier 1: Paper */}
                  <rect x="140" y="20" width="10" height="140" fill="#f8fafc" />
                  <text x="145" y="172" textAnchor="middle" fill="#94a3b8" fontSize="8">Paper</text>

                  {/* Barrier 2: Aluminum */}
                  <rect x="260" y="20" width="20" height="140" fill="#94a3b8" />
                  <text x="270" y="172" textAnchor="middle" fill="#94a3b8" fontSize="8">Aluminum</text>

                  {/* Barrier 3: Lead */}
                  <rect x="390" y="20" width="40" height="140" fill="#475569" />
                  <text x="410" y="172" textAnchor="middle" fill="#94a3b8" fontSize="8">Lead (Pb)</text>

                  {/* Alpha Ray (Stopped by paper) */}
                  <line x1="50" y1="50" x2="140" y2="50" stroke="#f59e0b" strokeWidth="3" />
                  <circle cx="140" cy="50" r="4" fill="#ef4444" />
                  <text x="60" y="44" fill="#f59e0b" fontSize="8" fontWeight="bold">α Particles (Stopped by Paper)</text>

                  {/* Beta Ray (Passes paper, stopped by Al) */}
                  <line x1="50" y1="90" x2="260" y2="90" stroke="#38bdf8" strokeWidth="2.5" />
                  <circle cx="260" cy="90" r="4" fill="#ef4444" />
                  <text x="60" y="84" fill="#38bdf8" fontSize="8" fontWeight="bold">β Particles (Stopped by Aluminum)</text>

                  {/* Gamma Ray (Passes paper & Al, attenuated by Pb) */}
                  <line x1="50" y1="130" x2="410" y2="130" stroke="#c084fc" strokeWidth="2" strokeDasharray="3 2" />
                  <circle cx="410" cy="130" r="4" fill="#ef4444" />
                  <text x="60" y="124" fill="#c084fc" fontSize="8" fontWeight="bold">γ Photons (Attenuated by Lead)</text>
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 3. NUCLEAR BINDING ENERGY PER NUCLEON */}
      {/* ============================================================== */}
      {activeTab === 'binding-energy' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 p-6 rounded-3xl bg-[#090d16] border border-cyan-500/30 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-cyan-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                  <Layers className="w-4 h-4" />
                  <span>Binding Energy per Nucleon (E_b / A)</span>
                </span>
                <span className="text-slate-400 text-[10px]">Δm · c²</span>
              </div>

              <div className="space-y-2">
                <label className="text-slate-400 uppercase text-[10px] block">Select Nuclide on Curve:</label>
                <div className="grid grid-cols-2 gap-1.5 max-h-48 overflow-y-auto pr-1">
                  {bindingData.map((n) => (
                    <button
                      key={n.symbol}
                      onClick={() => setSelectedNuclide(n)}
                      className={`p-2 rounded-xl text-left border transition-all ${
                        selectedNuclide.symbol === n.symbol
                          ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 font-bold'
                          : 'bg-white/[0.02] border-white/5 text-slate-300 hover:bg-white/[0.05]'
                      }`}
                    >
                      <div className="font-bold">{n.symbol} (A = {n.A})</div>
                      <div className="text-[10px] text-slate-400">{n.Eb.toFixed(2)} MeV/nucleon</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Stability Diagnostics */}
              <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-400/30 space-y-2">
                <div className="flex justify-between items-center text-cyan-300 font-bold">
                  <span>Selected: {selectedNuclide.symbol}</span>
                  <span>E_b / A = {selectedNuclide.Eb.toFixed(2)} MeV</span>
                </div>
                <p className="text-slate-300 text-[11px] font-sans leading-relaxed">
                  <strong>Thermodynamic Driving Force:</strong> Iron-56 (⁵⁶Fe) sits at the peak of the binding energy curve (8.79 MeV/nucleon). Fusion of light nuclei (A &lt; 56) and Fission of heavy nuclei (A &gt; 56) both increase binding energy per nucleon, releasing mass defect energy ΔE = Δm · c².
                </p>
              </div>
            </div>

            {/* Right Binding Energy Curve */}
            <div className="lg:col-span-7 p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-5">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-white/10 pb-3">
                <Layers className="w-4 h-4 text-cyan-400" />
                <span>Binding Energy per Nucleon Curve (E_b / A vs Mass Number A)</span>
              </h3>

              <div className="w-full bg-black/60 rounded-2xl p-4 border border-white/5">
                <svg viewBox="0 0 500 180" className="w-full h-auto select-none">
                  {/* Grid Lines */}
                  {[9, 8, 6, 4, 2, 0].map((eb) => {
                    const y = 30 + ((9 - eb) / 9) * 120;
                    return (
                      <g key={eb}>
                        <line x1="40" y1={y} x2="470" y2={y} stroke="rgba(255,255,255,0.06)" strokeDasharray="3 3" />
                        <text x="32" y={y + 3} textAnchor="end" fill="#64748b" fontSize="8" fontFamily="monospace">{eb}</text>
                      </g>
                    );
                  })}

                  {/* Curve Line */}
                  {(() => {
                    const pts = bindingData.map((d) => {
                      const x = 40 + (d.A / 240) * 430;
                      const y = 30 + ((9 - d.Eb) / 9) * 120;
                      return `${x.toFixed(1)},${y.toFixed(1)}`;
                    });
                    return <path d={`M ${pts.join(' L ')}`} fill="none" stroke="#38bdf8" strokeWidth="2.5" />;
                  })()}

                  {/* Points */}
                  {bindingData.map((d) => {
                    const x = 40 + (d.A / 240) * 430;
                    const y = 30 + ((9 - d.Eb) / 9) * 120;
                    const isSel = selectedNuclide.symbol === d.symbol;
                    return (
                      <g key={d.symbol} className="cursor-pointer" onClick={() => setSelectedNuclide(d)}>
                        <circle cx={x} cy={y} r={isSel ? 6 : 3.5} fill={isSel ? '#ffffff' : '#38bdf8'} />
                        <text x={x} y={y - 8} textAnchor="middle" fill={isSel ? '#ffffff' : '#94a3b8'} fontSize="8" fontWeight="bold">
                          {d.symbol}
                        </text>
                      </g>
                    );
                  })}

                  {/* Fusion & Fission Regions Labels */}
                  <text x="90" y="160" fill="#10b981" fontSize="9" fontWeight="bold">← FUSION EXOTHERMIC</text>
                  <text x="380" y="160" fill="#f59e0b" fontSize="9" fontWeight="bold">FISSION EXOTHERMIC →</text>
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 4. FISSION CHAIN & THERMONUCLEAR FUSION */}
      {/* ============================================================== */}
      {activeTab === 'fission-fusion' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-6 p-6 rounded-3xl bg-[#090d16] border border-purple-500/30 shadow-xl space-y-5">
              <h3 className="text-purple-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2 border-b border-white/10 pb-3">
                <Flame className="w-4 h-4" />
                <span>Uranium-235 Fission Reactor Simulation</span>
              </h3>

              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Control Rod Insertion (Boron/Cadmium):</span>
                  <span className="text-purple-300 font-bold">{controlRodInsertion}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={controlRodInsertion}
                  onChange={(e) => setControlRodInsertion(parseInt(e.target.value))}
                  className="w-full accent-purple-400 cursor-pointer"
                />
              </div>

              <div className={`p-4 rounded-2xl border transition-all ${
                kMultiplication > 1.05
                  ? 'bg-red-500/20 border-red-400 text-red-200'
                  : kMultiplication >= 0.98
                  ? 'bg-emerald-500/20 border-emerald-400 text-emerald-200'
                  : 'bg-blue-500/20 border-blue-400 text-blue-200'
              }`}>
                <div className="flex justify-between items-center font-bold">
                  <span>Neutron Multiplication (k): {kMultiplication.toFixed(3)}</span>
                  <span>{kMultiplication > 1.05 ? 'SUPERCRITICAL (POWER RISING)' : kMultiplication >= 0.98 ? 'CRITICAL (STEADY STATE)' : 'SUBCRITICAL'}</span>
                </div>
                <div className="pt-2 text-[11px]">
                  Equation: ¹₀n + ²³⁵₉₂U → ¹⁴¹₅₆Ba + ⁹²₃₆Kr + 3 ¹₀n + 200 MeV
                </div>
              </div>
            </div>

            <div className="lg:col-span-6 p-6 rounded-3xl bg-[#090d16] border border-amber-500/30 shadow-xl space-y-5">
              <h3 className="text-amber-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2 border-b border-white/10 pb-3">
                <Flame className="w-4 h-4" />
                <span>Thermonuclear D-T Fusion Tokamak</span>
              </h3>
              <p className="text-slate-300 text-[11px] font-sans leading-relaxed">
                <strong>Reaction:</strong> ²₁H (Deuterium) + ³₁H (Tritium) → ⁴₂He + ¹₀n + 17.6 MeV<br /><br />
                Requires overcoming Coulomb electrostatic repulsion with ion temperatures T &gt; 150 million Kelvin (150 × 10⁶ K) and satisfying the Lawson criterion (n · τ_E ≥ 10²⁰ m⁻³·s).
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
