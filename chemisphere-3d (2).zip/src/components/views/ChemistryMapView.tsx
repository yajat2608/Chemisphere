import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Compass,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Search,
  Filter,
  MapPin,
  Sparkles,
  Layers,
  Scroll,
  Sun,
  Moon,
  Crosshair,
  CheckCircle2,
  Award,
  Navigation,
  ArrowRight,
  Eye,
  Info,
  RotateCcw,
  Bot
} from 'lucide-react';
import {
  MAP_DIMENSIONS,
  MAP_REGIONS,
  MAP_LANDMARKS,
  GEOGRAPHIC_FEATURES,
  CARTOGRAPHIC_SHIPS,
  CARTOGRAPHIC_ANNOTATIONS,
  MapRegion,
  MapLandmark,
  GeographicFeature
} from '../../data/chemistryMapData';
import { NavigationTab } from '../../types';
import { useUserPassport } from '../../data/UserPassportStore';
import { MapCompassRose } from '../map/MapCompassRose';
import { MapLandmarkDocket } from '../map/MapLandmarkDocket';
import { MapScrollUnfurlIntro } from '../map/MapScrollUnfurlIntro';

interface ChemistryMapViewProps {
  onNavigate: (tab: NavigationTab) => void;
  onConsultAi?: (query: string, context?: any) => void;
}

export const ChemistryMapView: React.FC<ChemistryMapViewProps> = ({
  onNavigate,
  onConsultAi
}) => {
  const { passport, stats, recordTabVisit } = useUserPassport();
  const [themeMode, setThemeMode] = useState<'parchment' | 'nocturnal'>('parchment');
  const [isUnfurled, setIsUnfurled] = useState<boolean>(true);
  const [showIntroRoll, setShowIntroRoll] = useState<boolean>(false);
  const [selectedLandmark, setSelectedLandmark] = useState<MapLandmark | null>(null);
  const [hoveredLandmark, setHoveredLandmark] = useState<MapLandmark | null>(null);
  const [activeRegionFilter, setActiveRegionFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [loupeActive, setLoupeActive] = useState<boolean>(false);
  const [mousePos, setMousePos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [geoCoordinates, setGeoCoordinates] = useState<string>('30°N 15°E • Equilibrium Meridian');

  // Pan & Zoom Engine State
  const [transform, setTransform] = useState<{ x: number; y: number; scale: number }>({
    x: 0,
    y: 0,
    scale: 0.65
  });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const dragStartRef = useRef<{ x: number; y: number; startTransformX: number; startTransformY: number }>({
    x: 0,
    y: 0,
    startTransformX: 0,
    startTransformY: 0
  });

  const containerRef = useRef<HTMLDivElement>(null);

  // Initialize view centered nicely
  useEffect(() => {
    if (containerRef.current) {
      const { clientWidth, clientHeight } = containerRef.current;
      const initialScale = Math.max(0.45, Math.min(1.0, clientWidth / 2400));
      const initialX = (clientWidth - 2400 * initialScale) / 2;
      const initialY = (clientHeight - 1500 * initialScale) / 2;
      setTransform({ x: initialX, y: initialY, scale: initialScale });
    }
  }, []);

  // Compute landmark discovery status using user passport
  const getLandmarkStatus = useCallback(
    (landmark: MapLandmark): 'unvisited' | 'visited' | 'exploring' | 'completed' => {
      const isVisited = passport.visitedTabs.includes(landmark.tab);
      const visitStat = passport.disciplineStats[landmark.discipline];
      const hasManyVisits = visitStat && visitStat.count >= 3;

      if (hasManyVisits || (isVisited && (passport.score > 200 || passport.questionsSolved > 3))) {
        return 'completed';
      }
      if (isVisited) {
        return 'visited';
      }
      return 'unvisited';
    },
    [passport]
  );

  // Calculate overall exploration progress
  const explorationStats = useMemo(() => {
    const total = MAP_LANDMARKS.length;
    let visited = 0;
    let mastered = 0;
    MAP_LANDMARKS.forEach((lm) => {
      const st = getLandmarkStatus(lm);
      if (st === 'visited' || st === 'exploring' || st === 'completed') visited++;
      if (st === 'completed') mastered++;
    });
    const percent = Math.round((visited / total) * 100);
    return { total, visited, mastered, percent };
  }, [getLandmarkStatus]);

  // Zoom controls
  const handleZoom = (delta: number) => {
    setTransform((prev) => {
      const newScale = Math.max(0.35, Math.min(2.2, prev.scale + delta));
      if (!containerRef.current) return { ...prev, scale: newScale };
      const { clientWidth, clientHeight } = containerRef.current;
      // Zoom towards center
      const factor = newScale / prev.scale;
      const newX = clientWidth / 2 - (clientWidth / 2 - prev.x) * factor;
      const newY = clientHeight / 2 - (clientHeight / 2 - prev.y) * factor;
      return { x: newX, y: newY, scale: newScale };
    });
  };

  const handleResetView = () => {
    if (!containerRef.current) return;
    const { clientWidth, clientHeight } = containerRef.current;
    const scale = Math.max(0.45, Math.min(1.0, clientWidth / 2400));
    const x = (clientWidth - 2400 * scale) / 2;
    const y = (clientHeight - 1500 * scale) / 2;
    setTransform({ x, y, scale });
  };

  // Pan to a specific region / landmark
  const handlePanToCoordinates = (cx: number, cy: number, zoomLevel = 1.1) => {
    if (!containerRef.current) return;
    const { clientWidth, clientHeight } = containerRef.current;
    const newX = clientWidth / 2 - cx * zoomLevel;
    const newY = clientHeight / 2 - cy * zoomLevel;
    setTransform({ x: newX, y: newY, scale: zoomLevel });
  };

  // Mouse wheel zoom
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 0.08 : -0.08;
    setTransform((prev) => {
      const newScale = Math.max(0.35, Math.min(2.2, prev.scale + zoomFactor));
      if (!containerRef.current) return { ...prev, scale: newScale };
      const rect = containerRef.current.getBoundingClientRect();
      const mouseRelX = e.clientX - rect.left;
      const mouseRelY = e.clientY - rect.top;
      const factor = newScale / prev.scale;
      const newX = mouseRelX - (mouseRelX - prev.x) * factor;
      const newY = mouseRelY - (mouseRelY - prev.y) * factor;
      return { x: newX, y: newY, scale: newScale };
    });
  };

  // Mouse dragging for panning
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return; // only left click
    setIsDragging(true);
    dragStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      startTransformX: transform.x,
      startTransformY: transform.y
    };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const clientX = e.clientX - rect.left;
      const clientY = e.clientY - rect.top;
      setMousePos({ x: clientX, y: clientY });

      // Calculate chemical latitude/longitude for authentic explorer feel
      const mapWorldX = (clientX - transform.x) / transform.scale;
      const mapWorldY = (clientY - transform.y) / transform.scale;
      const lat = Math.round(90 - (mapWorldY / 1500) * 180);
      const lon = Math.round((mapWorldX / 2400) * 360 - 180);
      const latStr = lat >= 0 ? `${lat}°N` : `${Math.abs(lat)}°S`;
      const lonStr = lon >= 0 ? `${lon}°E` : `${Math.abs(lon)}°W`;
      setGeoCoordinates(`${latStr} ${lonStr} • Chemical Graticule`);
    }

    if (!isDragging) return;
    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;
    setTransform((prev) => ({
      ...prev,
      x: dragStartRef.current.startTransformX + dx,
      y: dragStartRef.current.startTransformY + dy
    }));
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Touch handlers for mobile
  const touchStartRef = useRef<{ x: number; y: number; dist: number }>({ x: 0, y: 0, dist: 0 });

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setIsDragging(true);
      dragStartRef.current = {
        x: e.touches[0].clientX,
        y: e.touches[0].clientY,
        startTransformX: transform.x,
        startTransformY: transform.y
      };
    } else if (e.touches.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      touchStartRef.current.dist = Math.hypot(dx, dy);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 1 && isDragging) {
      const dx = e.touches[0].clientX - dragStartRef.current.x;
      const dy = e.touches[0].clientY - dragStartRef.current.y;
      setTransform((prev) => ({
        ...prev,
        x: dragStartRef.current.startTransformX + dx,
        y: dragStartRef.current.startTransformY + dy
      }));
    } else if (e.touches.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const dist = Math.hypot(dx, dy);
      if (touchStartRef.current.dist > 0) {
        const factor = dist / touchStartRef.current.dist;
        setTransform((prev) => ({
          ...prev,
          scale: Math.max(0.35, Math.min(2.2, prev.scale * factor))
        }));
      }
      touchStartRef.current.dist = dist;
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
    touchStartRef.current.dist = 0;
  };

  // Filtered landmarks for search & category
  const filteredLandmarks = useMemo(() => {
    return MAP_LANDMARKS.filter((lm) => {
      const matchesRegion = activeRegionFilter === 'all' || lm.regionId === activeRegionFilter;
      const matchesSearch =
        !searchQuery ||
        lm.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        lm.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        lm.discipline.toLowerCase().includes(searchQuery.toLowerCase()) ||
        lm.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesRegion && matchesSearch;
    });
  }, [activeRegionFilter, searchQuery]);

  const isParchment = themeMode === 'parchment';

  return (
    <div className="relative w-full h-[calc(100vh-4rem)] flex flex-col overflow-hidden select-none bg-[#120a06]">
      {/* Scroll Unfurling Opening Intro Modal if requested */}
      <AnimatePresence>
        {showIntroRoll && (
          <MapScrollUnfurlIntro
            theme={themeMode}
            onComplete={() => {
              setShowIntroRoll(false);
              setIsUnfurled(true);
            }}
          />
        )}
      </AnimatePresence>

      {/* Top Explorer Navigation & Control Bar */}
      <div
        className={`z-20 w-full px-3 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3 border-b shadow-md transition-colors ${
          isParchment
            ? 'bg-[#f5ebd2] border-[#855828]/50 text-[#3d2410]'
            : 'bg-[#0a0f1d] border-cyan-900/40 text-slate-100'
        }`}
      >
        {/* Left: Atlas Title & Explorer Coordinates */}
        <div className="flex items-center gap-3">
          <div
            className={`w-9 h-9 rounded-xl flex items-center justify-center border shadow-sm ${
              isParchment
                ? 'bg-[#e8d5ae] border-[#b89c72] text-[#6d431c]'
                : 'bg-cyan-950 border-cyan-800 text-cyan-400'
            }`}
          >
            <Compass className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-serif font-bold tracking-tight">
                Cartographic World of Chemistry
              </h1>
              <span className="hidden md:inline-block px-2 py-0.5 rounded text-[11px] font-mono border bg-black/5 border-black/10">
                Anno Domini • 9 Continents
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs font-mono opacity-75">
              <Crosshair className="w-3 h-3 text-amber-600" />
              <span>{geoCoordinates}</span>
            </div>
          </div>
        </div>

        {/* Center: Search & Continent Fast-Travel */}
        <div className="flex items-center gap-2 flex-1 max-w-md mx-auto">
          {/* Fast-Travel Continent Selector */}
          <select
            value={activeRegionFilter}
            onChange={(e) => {
              const val = e.target.value;
              setActiveRegionFilter(val);
              if (val !== 'all') {
                const reg = MAP_REGIONS.find((r) => r.id === val);
                if (reg) handlePanToCoordinates(reg.center.x, reg.center.y, 0.95);
              } else {
                handleResetView();
              }
            }}
            className={`text-xs sm:text-sm font-serif px-2.5 py-1.5 rounded-lg border focus:outline-none transition-colors ${
              isParchment
                ? 'bg-[#fcf8ec] border-[#b89c72] text-[#3d2410]'
                : 'bg-slate-900 border-slate-700 text-slate-200'
            }`}
          >
            <option value="all">🗺️ Entire World (All Realms)</option>
            {MAP_REGIONS.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name} — {r.discipline}
              </option>
            ))}
          </select>

          {/* Quick Search */}
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 opacity-50" />
            <input
              type="text"
              placeholder="Search landmarks, oceans..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full text-xs sm:text-sm font-serif pl-8 pr-2.5 py-1.5 rounded-lg border focus:outline-none transition-colors ${
                isParchment
                  ? 'bg-[#fcf8ec] border-[#b89c72] text-[#3d2410] placeholder-[#855828]/50'
                  : 'bg-slate-900 border-slate-700 text-slate-200 placeholder-slate-500'
              }`}
            />
          </div>
        </div>

        {/* Right: Progress Ledger & Controls */}
        <div className="flex items-center gap-2">
          {/* Progress Capsule */}
          <div
            className={`hidden lg:flex items-center gap-2 px-3 py-1 rounded-full border text-xs font-serif ${
              isParchment
                ? 'bg-[#e8d5ae]/80 border-[#b89c72] text-[#4a2e16]'
                : 'bg-slate-900 border-cyan-900/60 text-cyan-300'
            }`}
            title={`${explorationStats.visited} of ${explorationStats.total} module landmarks discovered`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>
              {explorationStats.visited}/{explorationStats.total} Charted ({explorationStats.percent}%)
            </span>
          </div>

          {/* Roll Up Map Action */}
          <button
            onClick={() => setShowIntroRoll(true)}
            title="Roll Up Parchment Map"
            className={`px-2.5 py-1.5 rounded-lg border text-xs font-serif flex items-center gap-1.5 transition-colors ${
              isParchment
                ? 'bg-[#e8d5ae] hover:bg-[#d8c29d] border-[#b89c72] text-[#4a2e16]'
                : 'bg-slate-900 hover:bg-slate-800 border-slate-700 text-slate-300'
            }`}
          >
            <Scroll className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Roll Scroll</span>
          </button>

          {/* Theme Toggle (Parchment vs Nocturnal) */}
          <button
            onClick={() => setThemeMode(isParchment ? 'nocturnal' : 'parchment')}
            title={isParchment ? 'Switch to Nocturnal Sky Navigator' : 'Switch to Antique Parchment'}
            className={`p-1.5 rounded-lg border transition-colors ${
              isParchment
                ? 'bg-[#e8d5ae] hover:bg-[#d8c29d] border-[#b89c72] text-[#4a2e16]'
                : 'bg-slate-900 hover:bg-slate-800 border-slate-700 text-amber-400'
            }`}
          >
            {isParchment ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Main Interactive Map Viewport Canvas */}
      <div
        ref={containerRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onWheel={handleWheel}
        className={`relative flex-1 w-full h-full overflow-hidden cursor-grab active:cursor-grabbing ${
          isParchment ? 'bg-[#e3d0ab]' : 'bg-[#050a14]'
        }`}
      >
        {/* SVG Cartographic Master Surface */}
        <div
          className="absolute origin-top-left will-change-transform"
          style={{
            transform: `translate3d(${transform.x}px, ${transform.y}px, 0px) scale(${transform.scale})`,
            width: MAP_DIMENSIONS.width,
            height: MAP_DIMENSIONS.height
          }}
        >
          <svg
            viewBox={MAP_DIMENSIONS.viewBox}
            width={MAP_DIMENSIONS.width}
            height={MAP_DIMENSIONS.height}
            className="w-full h-full drop-shadow-2xl select-none"
          >
            <defs>
              {/* Parchment Ocean Texture & Gradients */}
              <radialGradient id="parchmentOcean" cx="50%" cy="50%" r="65%">
                <stop offset="0%" stopColor="#f3e8cf" />
                <stop offset="50%" stopColor="#e8d8b4" />
                <stop offset="100%" stopColor="#d2bc90" />
              </radialGradient>

              <radialGradient id="nocturnalOcean" cx="50%" cy="50%" r="65%">
                <stop offset="0%" stopColor="#08101e" />
                <stop offset="60%" stopColor="#040810" />
                <stop offset="100%" stopColor="#020408" />
              </radialGradient>

              {/* Continent Landmass Patterns & Gradients */}
              <linearGradient id="parchmentLand" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#fdfbf5" />
                <stop offset="50%" stopColor="#f9f2dc" />
                <stop offset="100%" stopColor="#efe0bd" />
              </linearGradient>

              <linearGradient id="nocturnalLand" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#0e172a" />
                <stop offset="60%" stopColor="#0a0f1d" />
                <stop offset="100%" stopColor="#060912" />
              </linearGradient>

              {/* Mountain Shading */}
              <filter id="cartoGlow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feComposite in="SourceGraphic" in2="blur" operator="over" />
              </filter>
            </defs>

            {/* Background Ocean Realm */}
            <rect
              x="0"
              y="0"
              width={MAP_DIMENSIONS.width}
              height={MAP_DIMENSIONS.height}
              fill={isParchment ? 'url(#parchmentOcean)' : 'url(#nocturnalOcean)'}
            />

            {/* Ocean Nautical Rhumb Lines & Graticule Meridian Arcs */}
            <g
              opacity={isParchment ? 0.35 : 0.25}
              stroke={isParchment ? '#855828' : '#38bdf8'}
              strokeWidth="0.75"
            >
              {/* Latitude Parallels */}
              {[200, 400, 600, 750, 900, 1100, 1300].map((y) => (
                <line key={`lat-${y}`} x1="0" y1={y} x2="2400" y2={y} strokeDasharray="6 6" />
              ))}
              {/* Longitude Meridians */}
              {[300, 600, 900, 1200, 1500, 1800, 2100].map((x) => (
                <line key={`lon-${x}`} x1={x} y1="0" x2={x} y2="1500" strokeDasharray="6 6" />
              ))}

              {/* Central Nautical Rhumb Radii */}
              <circle cx="1200" cy="750" r="600" fill="none" strokeDasharray="3 3" />
              <circle cx="1200" cy="750" r="1000" fill="none" strokeDasharray="4 4" />
              <line x1="0" y1="0" x2="2400" y2="1500" strokeDasharray="2 4" />
              <line x1="2400" y1="0" x2="0" y2="1500" strokeDasharray="2 4" />
            </g>

            {/* Coastline Stippling & Shorelines Buffer */}
            {MAP_REGIONS.map((reg) => (
              <g key={`coastal-${reg.id}`}>
                {/* Coastal Outer Water Halo */}
                <path
                  d={reg.path}
                  fill="none"
                  stroke={isParchment ? '#c5dbdf' : '#0369a1'}
                  strokeWidth="28"
                  opacity={isParchment ? 0.5 : 0.3}
                  strokeLinejoin="round"
                />
                <path
                  d={reg.path}
                  fill="none"
                  stroke={isParchment ? '#9ec7cf' : '#0891b2'}
                  strokeWidth="12"
                  opacity={isParchment ? 0.6 : 0.4}
                  strokeLinejoin="round"
                />
                {reg.secondaryPaths?.map((sp, idx) => (
                  <path
                    key={`sec-coast-${idx}`}
                    d={sp}
                    fill="none"
                    stroke={isParchment ? '#9ec7cf' : '#0891b2'}
                    strokeWidth="8"
                    opacity={0.5}
                  />
                ))}
              </g>
            ))}

            {/* Continents & Landmasses */}
            {MAP_REGIONS.map((reg) => {
              const isSelected = activeRegionFilter === reg.id;
              return (
                <g
                  key={`land-${reg.id}`}
                  className="cursor-pointer transition-opacity"
                  onClick={() => {
                    setActiveRegionFilter(reg.id);
                    handlePanToCoordinates(reg.center.x, reg.center.y, 1.05);
                  }}
                >
                  {/* Primary Continent Fill */}
                  <path
                    d={reg.path}
                    fill={isParchment ? 'url(#parchmentLand)' : 'url(#nocturnalLand)'}
                    stroke={isParchment ? '#5c3815' : reg.borderColor}
                    strokeWidth={isSelected ? 4 : 2.5}
                    strokeLinejoin="round"
                    className="transition-all hover:brightness-105"
                  />

                  {/* Secondary Islands */}
                  {reg.secondaryPaths?.map((sp, idx) => (
                    <path
                      key={`island-${idx}`}
                      d={sp}
                      fill={isParchment ? 'url(#parchmentLand)' : 'url(#nocturnalLand)'}
                      stroke={isParchment ? '#5c3815' : reg.borderColor}
                      strokeWidth="2"
                    />
                  ))}

                  {/* Mountain Ranges Hand-Drawn Contour Paths */}
                  {reg.mountainRanges?.map((m, idx) => (
                    <g key={`mtn-${idx}`}>
                      <path
                        d={m.path}
                        fill="none"
                        stroke={isParchment ? '#855828' : '#64748b'}
                        strokeWidth="5"
                        strokeLinecap="round"
                        opacity={0.85}
                      />
                      <text
                        x={m.x}
                        y={m.y}
                        textAnchor="middle"
                        fontSize="13"
                        fontFamily="serif"
                        fontStyle="italic"
                        fill={isParchment ? '#6d431c' : '#94a3b8'}
                        className="tracking-wider"
                      >
                        ▲ {m.name}
                      </text>
                    </g>
                  ))}

                  {/* Continental Rivers */}
                  {reg.rivers?.map((r, idx) => (
                    <path
                      key={`river-${idx}`}
                      d={r.path}
                      fill="none"
                      stroke={isParchment ? '#2b6cb0' : '#38bdf8'}
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      opacity={0.7}
                    />
                  ))}

                  {/* Continent Grand Banner Name */}
                  <g transform={`translate(${reg.center.x}, ${reg.bounds.minY + 40})`}>
                    <text
                      textAnchor="middle"
                      fontSize="28"
                      fontFamily="serif"
                      fontWeight="bold"
                      letterSpacing="4"
                      fill={isParchment ? '#3d2410' : reg.textColor}
                      className="uppercase drop-shadow-sm pointer-events-none"
                    >
                      {reg.name}
                    </text>
                    <text
                      y="18"
                      textAnchor="middle"
                      fontSize="12"
                      fontFamily="serif"
                      fontStyle="italic"
                      fill={isParchment ? '#7c592a' : '#94a3b8'}
                      className="pointer-events-none"
                    >
                      {reg.subtitle}
                    </text>
                  </g>
                </g>
              );
            })}

            {/* Historical Cartographic Sailing Caravels */}
            {CARTOGRAPHIC_SHIPS.map((ship) => (
              <g key={ship.id} className="pointer-events-none">
                <motion.g
                  initial={{ x: ship.startPos.x, y: ship.startPos.y }}
                  animate={{
                    x: [ship.startPos.x, ship.endPos.x, ship.startPos.x],
                    y: [ship.startPos.y, ship.endPos.y, ship.startPos.y]
                  }}
                  transition={{
                    duration: ship.durationSec,
                    repeat: Infinity,
                    ease: 'easeInOut'
                  }}
                >
                  {/* Caravel Icon & Wake */}
                  <circle
                    cx="0"
                    cy="0"
                    r="14"
                    fill={isParchment ? '#f4ecd8' : '#0f172a'}
                    stroke={isParchment ? '#855828' : '#38bdf8'}
                    strokeWidth="1.5"
                  />
                  <text x="0" y="4" textAnchor="middle" fontSize="13">
                    ⛵
                  </text>
                  <text
                    x="0"
                    y="22"
                    textAnchor="middle"
                    fontSize="10"
                    fontFamily="serif"
                    fontWeight="bold"
                    fill={isParchment ? '#5c3815' : '#93c5fd'}
                  >
                    {ship.name}
                  </text>
                </motion.g>
              </g>
            ))}

            {/* Geographical Oceans & Seas Titles */}
            {GEOGRAPHIC_FEATURES.map((geo) => (
              <g
                key={geo.id}
                transform={`translate(${geo.coordinates.x}, ${geo.coordinates.y}) rotate(${geo.rotation || 0})`}
                className="pointer-events-none"
              >
                <text
                  textAnchor="middle"
                  fontSize="20"
                  fontFamily="serif"
                  fontWeight="bold"
                  letterSpacing="6"
                  fill={isParchment ? '#7c592a' : '#0284c7'}
                  opacity={isParchment ? 0.65 : 0.75}
                  className="uppercase"
                >
                  ~ {geo.name} ~
                </text>
              </g>
            ))}

            {/* Latin & Alchemical Annotations */}
            {CARTOGRAPHIC_ANNOTATIONS.map((ann) => (
              <text
                key={ann.id}
                x={ann.coordinates.x}
                y={ann.coordinates.y}
                textAnchor="middle"
                fontSize="11"
                fontFamily="serif"
                fontStyle="italic"
                letterSpacing="1"
                fill={isParchment ? '#855828' : '#64748b'}
                opacity={0.7}
                className="pointer-events-none"
              >
                📜 {ann.text}
              </text>
            ))}

            {/* Module Landmarks (Interactive Beacons) */}
            {filteredLandmarks.map((landmark) => {
              const status = getLandmarkStatus(landmark);
              const isHovered = hoveredLandmark?.id === landmark.id;
              const isMastered = status === 'completed';
              const isVisited = status === 'visited';

              // Visual marker colors
              let markerFill = isParchment ? '#855828' : '#475569';
              let markerGlow = '#eab308';
              let symbolIcon = '📍';

              if (isMastered) {
                markerFill = '#f59e0b';
                markerGlow = '#fbbf24';
                symbolIcon = '✦';
              } else if (isVisited) {
                markerFill = '#10b981';
                markerGlow = '#34d399';
                symbolIcon = '●';
              }

              return (
                <g
                  key={landmark.id}
                  transform={`translate(${landmark.coordinates.x}, ${landmark.coordinates.y})`}
                  className="cursor-pointer group"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedLandmark(landmark);
                  }}
                  onMouseEnter={() => setHoveredLandmark(landmark)}
                  onMouseLeave={() => setHoveredLandmark(null)}
                >
                  {/* Subtle Beacon Radiating Radar Wave */}
                  {(isVisited || isMastered || isHovered) && (
                    <circle
                      cx="0"
                      cy="0"
                      r={isHovered ? 26 : 18}
                      fill="none"
                      stroke={markerGlow}
                      strokeWidth="1.5"
                      opacity={0.7}
                      className="animate-ping"
                      style={{ animationDuration: '3s' }}
                    />
                  )}

                  {/* Landmark Brass Base Pedestal */}
                  <circle
                    cx="0"
                    cy="0"
                    r={isHovered ? 15 : 12}
                    fill={isParchment ? '#fcf8ec' : '#090d16'}
                    stroke={markerFill}
                    strokeWidth={isHovered ? 3 : 2}
                    className="transition-all drop-shadow-md"
                  />

                  {/* Inner Symbol Badge */}
                  <circle
                    cx="0"
                    cy="0"
                    r={isHovered ? 9 : 7}
                    fill={markerFill}
                    className="transition-all"
                  />

                  {/* Landmark Label Plate */}
                  <g transform="translate(0, 22)">
                    <rect
                      x={-(landmark.name.length * 4.2)}
                      y="-12"
                      width={landmark.name.length * 8.4}
                      height="18"
                      rx="4"
                      fill={isParchment ? '#f7edd7' : '#0f172a'}
                      stroke={isParchment ? '#b89c72' : '#334155'}
                      strokeWidth="1"
                      opacity={isHovered ? 1 : 0.85}
                      className="drop-shadow-sm"
                    />
                    <text
                      x="0"
                      y="1"
                      textAnchor="middle"
                      fontSize="11"
                      fontFamily="serif"
                      fontWeight="bold"
                      fill={isParchment ? '#2b1810' : '#f8fafc'}
                    >
                      {landmark.name}
                    </text>
                  </g>
                </g>
              );
            })}

            {/* Decorative Antique Double Border & Corner Ornaments */}
            <rect
              x="20"
              y="20"
              width="2360"
              height="1460"
              fill="none"
              stroke={isParchment ? '#5c3815' : '#38bdf8'}
              strokeWidth="6"
            />
            <rect
              x="30"
              y="30"
              width="2340"
              height="1440"
              fill="none"
              stroke={isParchment ? '#855828' : '#0369a1'}
              strokeWidth="1.5"
              strokeDasharray="4 4"
            />

            {/* Corner Alchemical Flourishes */}
            {[
              { x: 35, y: 35 },
              { x: 2365, y: 35 },
              { x: 35, y: 1465 },
              { x: 2365, y: 1465 }
            ].map((pt, idx) => (
              <g key={`corner-${idx}`} transform={`translate(${pt.x}, ${pt.y})`}>
                <circle
                  cx="0"
                  cy="0"
                  r="12"
                  fill={isParchment ? '#e8d5ae' : '#0f172a'}
                  stroke={isParchment ? '#5c3815' : '#38bdf8'}
                  strokeWidth="2"
                />
                <text x="0" y="4" textAnchor="middle" fontSize="10">
                  ✦
                </text>
              </g>
            ))}

            {/* Authentic Nautical Compass Rose Embedded in the Sea */}
            <g transform="translate(2150, 180)">
              <MapCompassRose theme={themeMode} />
            </g>
          </svg>
        </div>

        {/* Floating Quick Landmark Hover Tooltip */}
        {hoveredLandmark && !selectedLandmark && (
          <div
            className={`pointer-events-none fixed z-30 px-3 py-2 rounded-xl shadow-xl border backdrop-blur-md transition-all -translate-x-1/2 -translate-y-16 ${
              isParchment
                ? 'bg-[#fcf8ec]/95 border-[#855828] text-[#2b1810]'
                : 'bg-[#0b1120]/95 border-cyan-500/40 text-slate-100'
            }`}
            style={{ left: mousePos.x, top: mousePos.y }}
          >
            <div className="flex items-center gap-1.5 text-xs font-serif font-bold">
              <MapPin className="w-3.5 h-3.5 text-amber-500" />
              <span>{hoveredLandmark.name}</span>
            </div>
            <div className="text-[11px] font-serif italic text-amber-700 dark:text-cyan-300">
              {hoveredLandmark.subtitle}
            </div>
            <div className="text-[10px] font-mono opacity-70 mt-0.5">
              Click to inspect ledger & embark →
            </div>
          </div>
        )}

        {/* Floating Cartographic HUD Controls Overlay */}
        <div className="absolute bottom-6 right-6 z-20 flex flex-col gap-2">
          {/* Zoom In */}
          <button
            onClick={() => handleZoom(0.2)}
            title="Zoom In (+)"
            className={`w-10 h-10 rounded-xl shadow-lg border flex items-center justify-center transition-all active:scale-95 ${
              isParchment
                ? 'bg-[#fcf8ec] hover:bg-[#f0dfbc] border-[#b89c72] text-[#5c3815]'
                : 'bg-slate-900/90 hover:bg-slate-800 border-slate-700 text-slate-200'
            }`}
          >
            <ZoomIn className="w-5 h-5" />
          </button>

          {/* Zoom Out */}
          <button
            onClick={() => handleZoom(-0.2)}
            title="Zoom Out (-)"
            className={`w-10 h-10 rounded-xl shadow-lg border flex items-center justify-center transition-all active:scale-95 ${
              isParchment
                ? 'bg-[#fcf8ec] hover:bg-[#f0dfbc] border-[#b89c72] text-[#5c3815]'
                : 'bg-slate-900/90 hover:bg-slate-800 border-slate-700 text-slate-200'
            }`}
          >
            <ZoomOut className="w-5 h-5" />
          </button>

          {/* Reset / Fit View */}
          <button
            onClick={handleResetView}
            title="Fit Entire Map"
            className={`w-10 h-10 rounded-xl shadow-lg border flex items-center justify-center transition-all active:scale-95 ${
              isParchment
                ? 'bg-[#fcf8ec] hover:bg-[#f0dfbc] border-[#b89c72] text-[#5c3815]'
                : 'bg-slate-900/90 hover:bg-slate-800 border-slate-700 text-slate-200'
            }`}
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Bottom-Left Cartographic Legend */}
        <div
          className={`hidden sm:flex absolute bottom-6 left-6 z-20 px-3.5 py-2.5 rounded-xl shadow-lg border backdrop-blur-md flex-col gap-1.5 text-xs font-serif ${
            isParchment
              ? 'bg-[#fcf8ec]/90 border-[#855828]/50 text-[#3d2410]'
              : 'bg-slate-900/90 border-slate-800 text-slate-200'
          }`}
        >
          <div className="font-bold text-[11px] tracking-wider uppercase opacity-80 flex items-center gap-1.5">
            <Compass className="w-3.5 h-3.5 text-amber-500" />
            <span>Map Cartography Legend</span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-400 border border-slate-600 inline-block" />
              <span>⚪ Unvisited</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 border border-emerald-600 inline-block" />
              <span>🟢 Visited</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 border border-amber-600 inline-block" />
              <span>✦ Mastered</span>
            </span>
          </div>
        </div>
      </div>

      {/* Selected Landmark Inspector Ledger / Docket Modal */}
      {selectedLandmark && (
        <MapLandmarkDocket
          landmark={selectedLandmark}
          region={MAP_REGIONS.find((r) => r.id === selectedLandmark.regionId)}
          status={getLandmarkStatus(selectedLandmark)}
          theme={themeMode}
          onClose={() => setSelectedLandmark(null)}
          onNavigate={onNavigate}
          onConsultAi={onConsultAi}
        />
      )}
    </div>
  );
};
