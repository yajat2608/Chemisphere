import React, { useState } from 'react';
import { Calculator, Zap, BookOpen, Layers, Sparkles, Sliders } from 'lucide-react';
import { CHEMICAL_FORMULAS, FUNDAMENTAL_CONSTANTS, FormulaItem } from '../../data/formulas';
import { LatexRenderer } from '../common/LatexRenderer';
import { NavigationTab } from '../../types';

interface FormulaVaultViewProps {
  onNavigate?: (tab: NavigationTab) => void;
}

export const FormulaVaultView: React.FC<FormulaVaultViewProps> = ({ onNavigate }) => {
  const [selectedFormula, setSelectedFormula] = useState<FormulaItem>(CHEMICAL_FORMULAS[0]); // Ideal Gas
  const [activeCategory, setActiveCategory] = useState<string>('all');

  // Interactive Calculator State for Ideal Gas
  const [gasP, setGasP] = useState<number>(1.0); // atm
  const [gasV, setGasV] = useState<number>(22.414); // L
  const [gasT, setGasT] = useState<number>(273.15); // K
  const [calcTarget, setCalcTarget] = useState<'n' | 'P' | 'V' | 'T'>('n');
  const R_gas = 0.082057; // L atm / (mol K)

  let calculatedOutput = '';
  if (calcTarget === 'n') {
    const n = (gasP * gasV) / (R_gas * gasT);
    calculatedOutput = `Moles (n) = ${n.toFixed(4)} mol`;
  } else if (calcTarget === 'P') {
    const p = (1.0 * R_gas * gasT) / gasV;
    calculatedOutput = `Pressure (P) = ${p.toFixed(4)} atm`;
  }

  // Interactive Dilution Calculator M1V1 = M2V2
  const [m1, setM1] = useState<number>(12.0); // M stock
  const [v1, setV1] = useState<number>(10.0); // mL stock
  const [v2, setV2] = useState<number>(100.0); // mL final
  const m2 = (m1 * v1) / (v2 || 1);

  const categories = ['all', 'thermodynamics', 'atomic', 'kinetics', 'solutions', 'electrochemistry'];

  const filteredFormulas = CHEMICAL_FORMULAS.filter((f) =>
    activeCategory === 'all' ? true : f.category === activeCategory
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-[#090d16]/90 border border-slate-800 backdrop-blur-md">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <span>Chemical Formula Vault & Constants</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-lime-950 text-lime-400 border border-lime-800 font-mono">
              SI Reference Standards
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Access fundamental physical chemistry constants, mathematical equations, and live interactive solvers.
          </p>
        </div>

        {/* Category switcher */}
        <div className="flex items-center rounded-xl bg-slate-900 border border-slate-800 p-1 font-mono text-xs overflow-x-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-lg capitalize transition-all whitespace-nowrap ${
                activeCategory === cat
                  ? 'bg-lime-600 text-slate-950 font-bold shadow-md shadow-lime-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Fundamental Constants Matrix */}
      <div className="p-5 rounded-2xl bg-[#090d16]/90 border border-slate-800 backdrop-blur-md">
        <h2 className="text-xs font-mono text-lime-400 uppercase tracking-wider mb-3">
          Fundamental Physical Constants (CODATA Recommended)
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {FUNDAMENTAL_CONSTANTS.map((c) => (
            <div key={c.name} className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1 font-mono">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-white">{c.name}</span>
                <span className="text-cyan-400 font-bold">
                  <LatexRenderer latex={c.symbol} />
                </span>
              </div>
              <div className="text-sm font-bold text-lime-300">
                <LatexRenderer latex={c.value} />
              </div>
              <div className="text-[10px] text-slate-400">
                <LatexRenderer latex={c.unit} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Formula Explorer & Solvers */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Formula Catalog List */}
        <div className="p-4 rounded-2xl bg-[#090d16]/90 border border-slate-800 backdrop-blur-md space-y-2">
          <h3 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">
            Formula Library ({filteredFormulas.length})
          </h3>

          <div className="space-y-2 max-h-[480px] overflow-y-auto pr-1">
            {filteredFormulas.map((form) => {
              const isSelected = selectedFormula.id === form.id;
              return (
                <button
                  key={form.id}
                  onClick={() => setSelectedFormula(form)}
                  className={`w-full p-3 rounded-xl border text-left transition-all font-mono text-xs ${
                    isSelected
                      ? 'bg-lime-950/60 border-lime-400 text-white shadow-md shadow-lime-950'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white'
                  }`}
                >
                  <div className="font-bold text-white text-sm">{form.name}</div>
                  <div className="text-cyan-400 mt-1 py-0.5 overflow-hidden">
                    <LatexRenderer latex={form.equationLatex} />
                  </div>
                  <div className="text-[10px] text-slate-400 capitalize mt-1">{form.category}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Formula Inspector & Live Solver */}
        <div className="lg:col-span-2 space-y-4">
          <div className="p-6 rounded-2xl bg-[#090d16]/95 border border-slate-800 backdrop-blur-md space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-white">{selectedFormula.name}</h2>
                <div className="text-xs text-slate-400 font-mono capitalize mt-0.5">
                  Category: {selectedFormula.category}
                </div>
              </div>
              <span className="text-xs px-3 py-1 rounded-full bg-lime-950 text-lime-300 font-mono border border-lime-800">
                Formula ID: {selectedFormula.id}
              </span>
            </div>

            {/* LaTeX Display Card */}
            <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 text-center text-xl text-cyan-300 py-6">
              <LatexRenderer latex={selectedFormula.equationLatex} displayMode />
            </div>

            {/* Variables Breakdown */}
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
              <div className="text-xs font-mono text-lime-400 font-bold">Variable Definitions:</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
                {selectedFormula.variables.map((v, i) => (
                  <div key={i} className="flex items-center gap-2 p-1.5 rounded bg-slate-800/60 text-slate-300">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                    <span>{v}</span>
                  </div>
                ))}
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              {selectedFormula.description}
            </p>
          </div>

          {/* Interactive Gas / Dilution Quick Solvers */}
          <div className="p-5 rounded-2xl bg-[#090d16]/90 border border-slate-800 backdrop-blur-md space-y-4">
            <h3 className="text-sm font-bold text-white font-mono text-cyan-400">
              Live Molarity & Solution Dilution Solver (M₁V₁ = M₂V₂)
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs">
              <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1.5">
                <label className="text-slate-400 text-[10px]">STOCK MOLARITY (M₁)</label>
                <input
                  type="number"
                  step="0.1"
                  value={m1}
                  onChange={(e) => setM1(parseFloat(e.target.value) || 0)}
                  className="w-full px-2.5 py-1.5 rounded bg-slate-800 border border-slate-700 text-white"
                />
                <span className="text-[10px] text-slate-500">Molar (mol/L)</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1.5">
                <label className="text-slate-400 text-[10px]">STOCK VOLUME (V₁)</label>
                <input
                  type="number"
                  step="1"
                  value={v1}
                  onChange={(e) => setV1(parseFloat(e.target.value) || 0)}
                  className="w-full px-2.5 py-1.5 rounded bg-slate-800 border border-slate-700 text-white"
                />
                <span className="text-[10px] text-slate-500">Milliliters (mL)</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1.5">
                <label className="text-slate-400 text-[10px]">FINAL VOLUME (V₂)</label>
                <input
                  type="number"
                  step="1"
                  value={v2}
                  onChange={(e) => setV2(parseFloat(e.target.value) || 0)}
                  className="w-full px-2.5 py-1.5 rounded bg-slate-800 border border-slate-700 text-white"
                />
                <span className="text-[10px] text-slate-500">Milliliters (mL)</span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-cyan-900/50 flex items-center justify-between font-mono text-xs">
              <span className="text-slate-300">Diluted Final Molarity (M₂):</span>
              <span className="text-lg font-bold text-cyan-400">{m2.toFixed(3)} M</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
