import React, { useState, useEffect } from 'react';
import {
  Search,
  X,
  Atom,
  Orbit,
  Boxes,
  Calculator,
  Sparkles,
  Zap,
  GraduationCap,
  Trophy,
  FlaskConical,
  Archive,
  UserCheck,
  Compass,
  Map as MapIcon
} from 'lucide-react';
import { ALL_118_ELEMENTS } from '../../data/elements';
import { ORBITALS_DATA } from '../../data/orbitals';
import { MOLECULES_DATA } from '../../data/molecules';
import { FORMULAS_DATA } from '../../data/formulas';
import { NavigationTab, ChemicalElement } from '../../types';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: NavigationTab) => void;
  onSelectElement?: (element: ChemicalElement) => void;
}

const TOOL_SHORTCUTS: { id: NavigationTab; name: string; desc: string; icon: React.FC<{ className?: string }>; color: string }[] = [
  { id: 'chemistry-map', name: 'Interactive Chemistry World Map', desc: 'Historical geographical map & 9 fictional continents', icon: MapIcon, color: '#f59e0b' },
  { id: 'questions-playground', name: 'Questions Playground & Arena', desc: 'Olympiad multiple-choice quizzes & speed trials', icon: Trophy, color: '#f59e0b' },
  { id: 'chemistry-lab', name: 'Virtual Chemistry Lab', desc: 'Interactive chemical reagents & beaker sandbox', icon: FlaskConical, color: '#10b981' },
  { id: 'archive', name: 'Scientific Archive & Vault', desc: 'Nobel timeline, FTIR/NMR reference & GHS safety', icon: Archive, color: '#06b6d4' },
  { id: 'profile', name: 'User Chemist Passport', desc: 'Personal progress, XP score & badge passport', icon: UserCheck, color: '#a855f7' }
];

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onNavigate,
  onSelectElement
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else onClose(); // parent handles toggle
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const isCreatorMatch =
    'yajat sarkar creator portfolio vriddhi agribot kv balaghat infinity learn scouts nukaizen'
      .toLowerCase()
      .includes(query.toLowerCase()) && query.trim().length > 1;

  const filteredTools = TOOL_SHORTCUTS.filter(
    (t) =>
      t.name.toLowerCase().includes(query.toLowerCase()) ||
      t.desc.toLowerCase().includes(query.toLowerCase())
  );

  const filteredElements = ALL_118_ELEMENTS.filter(
    (el) =>
      el.name.toLowerCase().includes(query.toLowerCase()) ||
      el.symbol.toLowerCase().includes(query.toLowerCase()) ||
      el.number.toString() === query
  ).slice(0, 5);

  const filteredOrbitals = ORBITALS_DATA.filter((orb) =>
    orb.name.toLowerCase().includes(query.toLowerCase())
  ).slice(0, 3);

  const filteredMolecules = MOLECULES_DATA.filter((mol) =>
    mol.name.toLowerCase().includes(query.toLowerCase()) ||
    mol.formula.toLowerCase().includes(query.toLowerCase())
  ).slice(0, 3);

  const filteredFormulas = FORMULAS_DATA.filter((f) =>
    f.name.toLowerCase().includes(query.toLowerCase()) ||
    f.category.toLowerCase().includes(query.toLowerCase())
  ).slice(0, 3);

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-20 px-3 sm:px-4 bg-black/70 backdrop-blur-xl animate-fade-in">
      <div className="w-full max-w-2xl bg-[#080d19]/95 border border-white/15 rounded-3xl shadow-2xl overflow-hidden shadow-black/80 backdrop-blur-2xl glass-panel-card">
        {/* Search Input Bar */}
        <div className="flex items-center gap-3 px-4 sm:px-5 py-3.5 sm:py-4 border-b border-white/10 bg-white/[0.02]">
          <Search className="w-5 h-5 text-cyan-400 shrink-0" />
          <input
            autoFocus
            type="text"
            placeholder="Search elements, orbitals, molecules, creator profile..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 bg-transparent text-sm text-white placeholder:text-slate-400 focus:outline-none font-mono"
          />
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-[60vh] overflow-y-auto p-3 sm:p-4 space-y-3 sm:space-y-4">
          {/* Creator Profile Direct Hit */}
          {isCreatorMatch && (
            <div>
              <div className="text-[10px] sm:text-[11px] font-mono text-amber-400 px-2 py-1 uppercase tracking-wider font-bold">
                Creator & Architect Profile
              </div>
              <div
                onClick={() => {
                  onNavigate('creator');
                  onClose();
                }}
                className="flex items-center justify-between p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 hover:border-amber-400/60 cursor-pointer transition-all backdrop-blur-md mt-1"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center font-bold text-amber-300 shrink-0">
                    <GraduationCap className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white flex items-center gap-2">
                      <span>Yajat Sarkar</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-mono">
                        Creator Profile
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-300">
                      Class 11 Science • PM Shri KV Balaghat • Infinity Learn Scholar • Vriddhi-AI
                    </div>
                  </div>
                </div>
                <div className="text-xs font-mono text-amber-300 font-bold hidden sm:block">Open Portfolio →</div>
              </div>
            </div>
          )}

          {/* Tool Matches */}
          {query !== '' && filteredTools.length > 0 && (
            <div>
              <div className="text-[10px] sm:text-[11px] font-mono text-cyan-400 px-2 py-1 uppercase tracking-wider font-bold">
                Interactive Chemistry Tools & Arenas
              </div>
              <div className="space-y-1.5 mt-1">
                {filteredTools.map((t) => {
                  const Icon = t.icon;
                  return (
                    <div
                      key={t.id}
                      onClick={() => {
                        onNavigate(t.id);
                        onClose();
                      }}
                      className="flex items-center justify-between p-2.5 sm:p-3 rounded-2xl bg-white/5 border border-white/10 hover:border-cyan-400/50 hover:bg-white/10 cursor-pointer transition-all backdrop-blur-md"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
                          style={{ backgroundColor: `${t.color}20`, color: t.color }}
                        >
                          <Icon className="w-4 h-4" />
                        </div>
                        <div>
                          <span className="text-xs font-semibold text-white">{t.name}</span>
                          <div className="text-[11px] text-slate-400">{t.desc}</div>
                        </div>
                      </div>
                      <span className="text-xs font-mono text-cyan-400">Launch →</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Quick Navigation Targets */}
          {query === '' && (
            <div>
              <div className="text-[10px] sm:text-[11px] font-mono text-slate-400 px-2 py-1 uppercase tracking-wider font-bold">
                Discovery Launchpads
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 mt-1">
                {[
                  { tab: 'questions-playground' as NavigationTab, label: 'Questions Playground & Arena', icon: Trophy },
                  { tab: 'chemistry-lab' as NavigationTab, label: 'Virtual Chemistry Lab', icon: FlaskConical },
                  { tab: 'archive' as NavigationTab, label: 'Scientific Archive & Vault', icon: Archive },
                  { tab: 'profile' as NavigationTab, label: 'Chemist User Passport', icon: UserCheck },
                  { tab: 'beauty-of-chemistry' as NavigationTab, label: 'Beauty of Chemistry', icon: Sparkles },
                  { tab: 'lab-directory' as NavigationTab, label: 'Laboratory Directory (All 14 Labs)', icon: Sparkles },
                  { tab: 'atomic-spectra' as NavigationTab, label: 'Atomic Spectra & Emission Lab', icon: Sparkles },
                  { tab: 'waves-radiation' as NavigationTab, label: 'Waves & EM Radiation Lab', icon: Zap },
                  { tab: 'spectroscopy-suite' as NavigationTab, label: 'Spectroscopy Suite (UV/IR/NMR)', icon: Sparkles },
                  { tab: 'quantum-lab' as NavigationTab, label: 'Quantum Mechanics Lab', icon: Zap },
                  { tab: 'nuclear-chemistry' as NavigationTab, label: 'Nuclear Chemistry Lab', icon: Atom },
                  { tab: 'thermo-kinetics' as NavigationTab, label: 'Thermo & Kinetics Lab', icon: Calculator },
                  { tab: 'advanced-organic' as NavigationTab, label: 'Advanced Organic Synthesis', icon: Sparkles },
                  { tab: 'analytical-lab' as NavigationTab, label: 'Analytical & Environmental Lab', icon: Calculator },
                  { tab: 'electrochemistry-lab' as NavigationTab, label: 'Electrochemistry & Battery Lab', icon: Zap },
                  { tab: 'periodic-table' as NavigationTab, label: 'Periodic Table (118 Elements)', icon: Atom },
                  { tab: 'orbital-atlas' as NavigationTab, label: '3D Quantum Orbitals', icon: Orbit },
                  { tab: 'molecules-3d' as NavigationTab, label: '3D Molecular Viewer', icon: Boxes },
                  { tab: 'creator' as NavigationTab, label: 'Creator (Yajat Sarkar)', icon: GraduationCap },
                  { tab: 'ai-tutor' as NavigationTab, label: 'ChemoBot AI Tutor', icon: Sparkles }
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.tab}
                      onClick={() => {
                        onNavigate(item.tab);
                        onClose();
                      }}
                      className="flex items-center gap-2 p-2.5 sm:p-3 rounded-2xl bg-white/5 border border-white/10 hover:border-cyan-400/40 hover:bg-white/10 text-left transition-all group backdrop-blur-md"
                    >
                      <Icon className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform shrink-0" />
                      <span className="text-xs text-slate-300 group-hover:text-white font-medium truncate">
                        {item.label}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Elements */}
          {filteredElements.length > 0 && (
            <div>
              <div className="text-[10px] sm:text-[11px] font-mono text-cyan-400 px-2 py-1 uppercase tracking-wider font-bold">
                Chemical Elements
              </div>
              <div className="space-y-1.5 mt-1">
                {filteredElements.map((el) => (
                  <div
                    key={el.symbol}
                    onClick={() => {
                      onNavigate('periodic-table');
                      if (onSelectElement) onSelectElement(el);
                      onClose();
                    }}
                    className="flex items-center justify-between p-2.5 sm:p-3 rounded-2xl bg-white/5 border border-white/10 hover:border-cyan-400/50 hover:bg-white/10 cursor-pointer transition-all backdrop-blur-md"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center font-mono font-bold text-xs text-cyan-300 shrink-0">
                        {el.symbol}
                      </div>
                      <div>
                        <div className="text-xs font-semibold text-white">
                          {el.name} <span className="text-slate-400 text-[11px]">Z = {el.number}</span>
                        </div>
                        <div className="text-[11px] text-slate-400">{el.category} • {el.atomicMass.toFixed(2)} u</div>
                      </div>
                    </div>
                    <div className="text-xs font-mono text-cyan-400/80 hidden sm:block">{el.electronConfiguration}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 3D Orbitals */}
          {filteredOrbitals.length > 0 && (
            <div>
              <div className="text-[10px] sm:text-[11px] font-mono text-purple-400 px-2 py-1 uppercase tracking-wider font-bold">
                Quantum Orbitals
              </div>
              <div className="space-y-1.5 mt-1">
                {filteredOrbitals.map((orb) => (
                  <div
                    key={orb.id}
                    onClick={() => {
                      onNavigate('orbital-atlas');
                      onClose();
                    }}
                    className="flex items-center justify-between p-2.5 sm:p-3 rounded-2xl bg-white/5 border border-white/10 hover:border-purple-400/50 hover:bg-white/10 cursor-pointer transition-all backdrop-blur-md"
                  >
                    <div className="flex items-center gap-3">
                      <Orbit className="w-4 h-4 text-purple-400 shrink-0" />
                      <span className="text-xs font-semibold text-white">{orb.name}</span>
                    </div>
                    <span className="text-xs font-mono text-slate-400">n={orb.n}, l={orb.l}, ml={orb.ml}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 3D Molecules */}
          {filteredMolecules.length > 0 && (
            <div>
              <div className="text-[10px] sm:text-[11px] font-mono text-emerald-400 px-2 py-1 uppercase tracking-wider font-bold">
                3D Molecules
              </div>
              <div className="space-y-1.5 mt-1">
                {filteredMolecules.map((mol) => (
                  <div
                    key={mol.id}
                    onClick={() => {
                      onNavigate('molecules-3d');
                      onClose();
                    }}
                    className="flex items-center justify-between p-2.5 sm:p-3 rounded-2xl bg-white/5 border border-white/10 hover:border-emerald-400/50 hover:bg-white/10 cursor-pointer transition-all backdrop-blur-md"
                  >
                    <div className="flex items-center gap-3">
                      <Boxes className="w-4 h-4 text-emerald-400 shrink-0" />
                      <div>
                        <span className="text-xs font-semibold text-white">{mol.name} ({mol.formula})</span>
                        <div className="text-[11px] text-slate-400">{mol.geometry}</div>
                      </div>
                    </div>
                    <span className="text-xs font-mono text-emerald-400">{mol.molarMass} g/mol</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Formulas */}
          {filteredFormulas.length > 0 && (
            <div>
              <div className="text-[10px] sm:text-[11px] font-mono text-amber-400 px-2 py-1 uppercase tracking-wider font-bold">
                Formula Vault Calculators
              </div>
              <div className="space-y-1.5 mt-1">
                {filteredFormulas.map((f) => (
                  <div
                    key={f.id}
                    onClick={() => {
                      onNavigate('formula-vault');
                      onClose();
                    }}
                    className="flex items-center justify-between p-2.5 sm:p-3 rounded-2xl bg-white/5 border border-white/10 hover:border-amber-400/50 hover:bg-white/10 cursor-pointer transition-all backdrop-blur-md"
                  >
                    <div className="flex items-center gap-3">
                      <Calculator className="w-4 h-4 text-amber-400 shrink-0" />
                      <span className="text-xs font-semibold text-white">{f.name}</span>
                    </div>
                    <span className="text-xs font-mono text-amber-400">{f.category}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="px-4 py-2.5 bg-black/40 border-t border-white/10 flex items-center justify-between text-[10px] sm:text-[11px] font-mono text-slate-400">
          <div>Use ↑↓ to navigate • ↵ to select • ESC to exit</div>
          <div className="text-cyan-400 font-semibold">Chemisphere 3D</div>
        </div>
      </div>
    </div>
  );
};
