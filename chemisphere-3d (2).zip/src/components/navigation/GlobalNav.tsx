import React, { useState } from 'react';
import {
  Atom,
  Grid3X3,
  Orbit,
  Sparkles,
  FlaskConical,
  Scale,
  Calculator,
  Compass,
  GraduationCap,
  Search,
  BookOpen,
  Boxes,
  Zap,
  Bot,
  Menu,
  X,
  ChevronRight,
  ChevronDown,
  Sun,
  Moon,
  Activity,
  Layers,
  Gauge,
  Dna,
  Flame,
  Radio,
  Trophy,
  Archive,
  UserCheck,
  HelpCircle,
  Map as MapIcon
} from 'lucide-react';
import { NavigationTab } from '../../types';
import { useUserPassport } from '../../data/UserPassportStore';

interface GlobalNavProps {
  activeTab: NavigationTab;
  onTabChange: (tab: NavigationTab) => void;
  onOpenCommandPalette: () => void;
  onOpenTutorial?: () => void;
  theme?: 'dark' | 'light';
  onToggleTheme?: () => void;
  motionIntensity?: 'minimal' | 'balanced' | 'dynamic';
  onCycleMotion?: () => void;
}

interface DisciplineNavGroup {
  name: string;
  shortName: string;
  icon: React.FC<{ className?: string }>;
  accentColor: string;
  items: { label: string; tab: NavigationTab; sub: string }[];
}

export const DISCIPLINE_NAV_GROUPS: DisciplineNavGroup[] = [
  {
    name: 'Tools & Discover Area',
    shortName: 'Tools & Discover',
    icon: Boxes,
    accentColor: '#06b6d4',
    items: [
      { label: 'Interactive Chemistry World Map', tab: 'chemistry-map', sub: 'Historical explorer cartography of 9 realms' },
      { label: 'Chemistry Tools & Calculators', tab: 'tools', sub: 'Comprehensive solvers & Purpose Cards' },
      { label: 'Questions Playground & Arena', tab: 'questions-playground', sub: 'Olympiad MCQs & balancing trials' },
      { label: 'Virtual Chemistry Lab', tab: 'chemistry-lab', sub: 'Beaker reaction sandbox & probes' },
      { label: 'Scientific Archive & Vault', tab: 'archive', sub: 'Nobel timeline, FTIR/NMR & GHS' },
      { label: 'Chemist User Passport', tab: 'profile', sub: 'XP metrics, badges & passport' }
    ]
  },
  {
    name: 'Inorganic Chemistry',
    shortName: 'Inorganic',
    icon: Grid3X3,
    accentColor: '#38bdf8',
    items: [
      { label: 'Periodic Table (118 Elements)', tab: 'periodic-table', sub: 'Interactive grid & electron configs' },
      { label: 'Periodic Trends Engine', tab: 'periodic-table', sub: 'Continuous SVG grapher' }
    ]
  },
  {
    name: 'Atomic & Quantum Chemistry',
    shortName: 'Atomic & Quantum',
    icon: Orbit,
    accentColor: '#a855f7',
    items: [
      { label: 'Atomic Structure History', tab: 'atomic-structure', sub: 'Rutherford & historical models' },
      { label: 'Quantum Mechanics Lab', tab: 'quantum-lab', sub: 'Particle-in-box, tunnelling & photoelectric' },
      { label: '3D Quantum Orbital Atlas', tab: 'orbital-atlas', sub: '1s, 2p, 3d, 4f spherical harmonics' }
    ]
  },
  {
    name: 'Spectroscopy & Spectral Science',
    shortName: 'Spectroscopy',
    icon: Activity,
    accentColor: '#ec4899',
    items: [
      { label: 'Spectroscopy Suite (5 Instruments)', tab: 'spectroscopy-suite', sub: 'UV-Vis, FTIR, NMR, MS, XRD' },
      { label: 'Atomic Spectra & Emission Lab', tab: 'atomic-spectra', sub: 'Rydberg Bohr series & flame tests' }
    ]
  },
  {
    name: 'Physical Chemistry & Kinetics',
    shortName: 'Physical Chem',
    icon: Flame,
    accentColor: '#f97316',
    items: [
      { label: 'Thermodynamics & Kinetics Lab', tab: 'thermo-kinetics', sub: 'ΔG, Arrhenius, Calorimetry & Equilibrium' },
      { label: 'Physical Chem Engine & Gas Laws', tab: 'physical-chem', sub: 'PV=nRT & Maxwell-Boltzmann' }
    ]
  },
  {
    name: 'Electrochemistry',
    shortName: 'Electrochemistry',
    icon: Zap,
    accentColor: '#10b981',
    items: [
      { label: 'Electrochemistry & Battery Lab', tab: 'electrochemistry-lab', sub: 'Nernst solver & Li-ion cells' },
      { label: 'Electrochemistry & Solutions', tab: 'electro-solutions', sub: 'Daniell cells & titration' }
    ]
  },
  {
    name: 'Organic Chemistry',
    shortName: 'Organic Chem',
    icon: Dna,
    accentColor: '#c084fc',
    items: [
      { label: 'Organic Reaction Highway', tab: 'organic-chem', sub: 'Synthesis pathways & functional groups' },
      { label: 'Organic Mechanisms Lab', tab: 'organic-mechanisms', sub: 'SN1, SN2, E1, E2 & 3D chirality' },
      { label: 'Advanced Organic Synthesis', tab: 'advanced-organic', sub: 'Retrosynthesis & named reactions' }
    ]
  },
  {
    name: 'Molecular & Chemical Bonding',
    shortName: 'Molecular & Bonding',
    icon: Boxes,
    accentColor: '#6366f1',
    items: [
      { label: '3D Molecular Simulator & CAD', tab: 'molecules-3d', sub: 'Ball-and-stick & dipole vectors' },
      { label: 'VSEPR & Hybridization Lab', tab: 'vsepr-lab', sub: 'Steric domain repulsion & angles' }
    ]
  },
  {
    name: 'Stoichiometry & Calculations',
    shortName: 'Stoichiometry',
    icon: Scale,
    accentColor: '#84cc16',
    items: [
      { label: 'Stoichiometry & Balancer Engine', tab: 'stoichiometry', sub: 'Matrix balancing, moles & yield' }
    ]
  },
  {
    name: 'Analytical & Materials Chemistry',
    shortName: 'Analytical & Materials',
    icon: FlaskConical,
    accentColor: '#14b8a6',
    items: [
      { label: 'Analytical Chromatography & Materials', tab: 'analytical-materials', sub: 'TLC, unit cells & crystals' },
      { label: 'Analytical & Environmental Wet Lab', tab: 'analytical-lab', sub: 'Titration curves & HPLC' }
    ]
  },
  {
    name: 'Nuclear Chemistry',
    shortName: 'Nuclear Chem',
    icon: Atom,
    accentColor: '#f43f5e',
    items: [
      { label: 'Nuclear Chemistry & Decay Lab', tab: 'nuclear-lab', sub: 'Monte Carlo decay & fission' },
      { label: 'Cosmic Nucleosynthesis', tab: 'nuclear-chemistry', sub: 'Stellar fusion & isotope chains' }
    ]
  },
  {
    name: 'Waves & Radiation',
    shortName: 'Waves & Radiation',
    icon: Radio,
    accentColor: '#eab308',
    items: [
      { label: 'Waves & EM Radiation Lab', tab: 'waves-radiation', sub: 'Harmonics & 7-band EM spectrum' }
    ]
  },
  {
    name: 'Calculators & Knowledge System',
    shortName: 'Tools & AI',
    icon: Calculator,
    accentColor: '#f59e0b',
    items: [
      { label: 'Universal Chemistry Calculator', tab: 'universal-calc-graph', sub: '24 Stepwise solvers & grapher' },
      { label: 'Formula Vault & Constants', tab: 'formula-vault', sub: 'Equations & SI reference' },
      { label: 'ChemoBot AI Copilot', tab: 'ai-tutor', sub: 'Real-time scientific reasoning' }
    ]
  }
];

export const GlobalNav: React.FC<GlobalNavProps> = ({
  activeTab,
  onTabChange,
  onOpenCommandPalette,
  onOpenTutorial,
  theme = 'dark',
  onToggleTheme,
  motionIntensity = 'balanced',
  onCycleMotion
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [curriculumDropdownOpen, setCurriculumDropdownOpen] = useState(false);
  const [expandedMobileDiscipline, setExpandedMobileDiscipline] = useState<string | null>(null);
  const { passport, stats } = useUserPassport();

  const primaryNavItems: { id: NavigationTab; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'home', label: 'Command Deck', icon: Atom },
    { id: 'chemistry-map', label: 'World Map', icon: MapIcon },
    { id: 'tools', label: 'Tools', icon: Boxes },
    { id: 'questions-playground', label: 'Playground', icon: Trophy },
    { id: 'chemistry-lab', label: 'Lab Sandbox', icon: FlaskConical },
    { id: 'archive', label: 'Archive', icon: Archive },
    { id: 'periodic-table', label: 'Inorganic', icon: Grid3X3 },
    { id: 'orbital-atlas', label: 'Quantum', icon: Orbit },
    { id: 'molecules-3d', label: 'Molecules', icon: Boxes },
    { id: 'spectroscopy-suite', label: 'Spectroscopy', icon: Activity },
    { id: 'thermo-kinetics', label: 'Physical', icon: Flame },
    { id: 'organic-chem', label: 'Organic', icon: Dna }
  ];

  const handleMobileNav = (tab: NavigationTab) => {
    onTabChange(tab);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/10 bg-[#050505]/95 backdrop-blur-2xl transition-all">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 flex items-center justify-between h-14 sm:h-16 gap-2">
        {/* Brand Identity */}
        <div
          onClick={() => {
            onTabChange('home');
            setMobileMenuOpen(false);
          }}
          className="flex items-center gap-2.5 sm:gap-3 cursor-pointer group min-w-0 select-none"
        >
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600 p-[1px] shadow-md shadow-cyan-500/20 shrink-0 overflow-hidden">
            <div className="w-full h-full bg-[#070b14] rounded-[11px] flex items-center justify-center group-hover:bg-white/10 transition-colors backdrop-blur-md overflow-hidden p-0.5">
              <img
                src="/favicon-32x32.png"
                alt="Chemisphere 3D"
                className="w-full h-full object-contain rounded-lg"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <span className="font-extrabold text-xs sm:text-base tracking-tight text-white group-hover:text-cyan-300 transition-colors font-home truncate">
                CHEMISPHERE 3D
              </span>
              <span className="hidden min-[420px]:inline-flex text-[9px] sm:text-[10px] px-1.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 font-mono shrink-0">
                SCIENTIFIC OS
              </span>
            </div>
            <p className="text-[10px] sm:text-[11px] text-slate-400 font-mono tracking-tight truncate">
              <span className="hidden sm:inline">14 Chemistry Disciplines • </span>
              <span
                onClick={(e) => {
                  e.stopPropagation();
                  onTabChange('creator');
                  setMobileMenuOpen(false);
                }}
                className="text-cyan-300 font-semibold hover:underline cursor-pointer"
              >
                By Yajat Sarkar
              </span>
            </p>
          </div>
        </div>

        {/* Desktop Navigation Items (xl+) */}
        <nav className="hidden xl:flex items-center gap-1 relative">
          {primaryNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-white/15 text-cyan-300 border border-white/20 shadow-md font-bold'
                    : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}

          {/* Curriculum Explorer Dropdown Menu */}
          <div className="relative">
            <button
              onClick={() => setCurriculumDropdownOpen(!curriculumDropdownOpen)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                curriculumDropdownOpen
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold'
                  : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
              }`}
            >
              <Compass className="w-3.5 h-3.5 text-cyan-400" />
              <span>Disciplines</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform ${curriculumDropdownOpen ? 'rotate-180 text-cyan-400' : ''}`} />
            </button>

            {curriculumDropdownOpen && (
              <div
                onMouseLeave={() => setCurriculumDropdownOpen(false)}
                className="absolute right-0 top-full mt-2 w-[740px] p-4 rounded-3xl bg-[#080d19]/95 border border-white/15 shadow-2xl backdrop-blur-2xl grid grid-cols-3 gap-3 text-xs font-mono z-50 animate-in fade-in zoom-in-95 duration-150"
              >
                {DISCIPLINE_NAV_GROUPS.map((group, idx) => {
                  const Icon = group.icon;
                  return (
                    <div
                      key={idx}
                      className="p-2.5 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2 hover:border-white/15 transition-all"
                    >
                      <div className="flex items-center gap-2 pb-1 border-b border-white/5">
                        <span style={{ color: group.accentColor }}>
                          <Icon className="w-3.5 h-3.5" />
                        </span>
                        <span className="font-bold text-[11px] truncate text-white" style={{ color: group.accentColor }}>
                          {group.shortName}
                        </span>
                      </div>
                      <div className="space-y-1">
                        {group.items.map((item, iIdx) => (
                          <div
                            key={iIdx}
                            onClick={() => {
                              onTabChange(item.tab);
                              setCurriculumDropdownOpen(false);
                            }}
                            className="p-1.5 rounded-lg hover:bg-white/10 text-slate-300 hover:text-cyan-300 transition-colors cursor-pointer"
                          >
                            <div className="text-[11px] font-medium truncate">{item.label}</div>
                            <div className="text-[9px] text-slate-500 truncate">{item.sub}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </nav>

        {/* Right Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Motion Intensity Cycle Pill */}
          {onCycleMotion && (
            <button
              onClick={onCycleMotion}
              className="hidden lg:flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-white/5 border border-white/10 text-[11px] font-mono text-slate-300 hover:border-white/20 hover:text-white transition-all"
              title={`Motion Intensity: ${motionIntensity.toUpperCase()} (Click to toggle Minimal / Balanced / Dynamic)`}
            >
              <Gauge className="w-3.5 h-3.5 text-cyan-400" />
              <span className="capitalize">{motionIntensity}</span>
            </button>
          )}

          {/* Light / Dark Mode Toggle Button */}
          {onToggleTheme && (
            <button
              onClick={onToggleTheme}
              className={`p-2 sm:px-2.5 sm:py-1.5 rounded-xl border transition-all flex items-center gap-1.5 text-xs shadow-inner backdrop-blur-md ${
                theme === 'light'
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-600 hover:bg-amber-500/20'
                  : 'bg-white/5 border-white/10 text-yellow-300 hover:border-yellow-400/40 hover:bg-white/10'
              }`}
              title={theme === 'light' ? 'Switch to Dark Laboratory Theme' : 'Switch to Light Pearl Theme'}
              aria-label="Toggle Dark/Light Theme"
            >
              {theme === 'light' ? (
                <Moon className="w-3.5 h-3.5 text-indigo-600 fill-indigo-600/20 transition-transform hover:rotate-12" />
              ) : (
                <Sun className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400/20 transition-transform hover:rotate-45" />
              )}
              <span className="hidden lg:inline font-mono text-[11px] font-medium">
                {theme === 'light' ? 'Dark' : 'Light'}
              </span>
            </button>
          )}

          {/* Quick Search / Command Palette Button */}
          <button
            onClick={onOpenCommandPalette}
            className="flex items-center gap-1.5 sm:gap-2 p-2 sm:px-3 sm:py-1.5 rounded-xl bg-white/5 border border-white/10 text-xs text-slate-300 hover:border-white/20 hover:text-white transition-all shadow-inner backdrop-blur-md"
            title="Search elements, molecules, or creator (Cmd+K)"
          >
            <Search className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden md:inline font-mono text-slate-400">Search</span>
            <kbd className="hidden sm:inline px-1.5 py-0.5 rounded-md bg-white/10 text-[10px] font-mono text-slate-300 border border-white/10">
              ⌘K
            </kbd>
          </button>

          {/* Guided Tutorial / Tour Button */}
          {onOpenTutorial && (
            <button
              onClick={onOpenTutorial}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-mono transition-all"
              title="Launch Guided Website Tour & Onboarding"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden lg:inline">Tutorial</span>
            </button>
          )}

          {/* User Profile / Chemist Passport Button */}
          <button
            onClick={() => {
              onTabChange('profile');
              setMobileMenuOpen(false);
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
              activeTab === 'profile'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-lg shadow-emerald-500/20 border border-emerald-400'
                : 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/20'
            }`}
            title={`Open User Chemist Passport • Level ${stats.level} (${passport.score || 0} XP)`}
          >
            <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-mono font-bold hidden sm:inline">Passport</span>
            <span className="hidden min-[1200px]:inline text-[10px] font-mono px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Lv.{stats.level}
            </span>
          </button>

          {/* Creator Profile Direct Button (md+) */}
          <button
            onClick={() => {
              onTabChange('creator');
              setMobileMenuOpen(false);
            }}
            className={`hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
              activeTab === 'creator'
                ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-bold shadow-lg shadow-amber-500/20 border border-amber-400'
                : 'bg-amber-500/10 border border-amber-500/30 text-amber-300 hover:bg-amber-500/20'
            }`}
          >
            <GraduationCap className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-mono font-bold">Creator</span>
          </button>

          {/* ChemoBot Highlight Pill (sm+) */}
          <button
            onClick={() => {
              onTabChange('ai-tutor');
              setMobileMenuOpen(false);
            }}
            className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
              activeTab === 'ai-tutor'
                ? 'bg-purple-500 text-white font-bold shadow-xl shadow-purple-500/20'
                : 'bg-purple-500/10 backdrop-blur-xl border border-purple-500/30 text-purple-300 hover:bg-purple-500/20'
            }`}
          >
            <Bot className="w-3.5 h-3.5 text-purple-400" />
            <span className="font-mono">ChemoBot</span>
          </button>

          {/* Mobile Menu Toggle Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className={`xl:hidden p-2 rounded-xl transition-all flex items-center justify-center ${
              mobileMenuOpen
                ? 'bg-cyan-500/20 border border-cyan-500/40 text-cyan-300'
                : 'bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white'
            }`}
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Mobile Structured Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-t border-white/10 bg-[#070b14]/98 backdrop-blur-3xl max-h-[85vh] overflow-y-auto px-3.5 py-4 space-y-4 shadow-2xl animate-in fade-in slide-in-from-top-2 duration-200">
          {/* Top Quick Actions Grid */}
          <div className="grid grid-cols-2 gap-2.5">
            {/* ChemoBot AI */}
            <button
              onClick={() => handleMobileNav('ai-tutor')}
              className={`p-3 rounded-2xl border text-left transition-all flex flex-col justify-between gap-2 ${
                activeTab === 'ai-tutor'
                  ? 'bg-purple-600/30 border-purple-400 text-white shadow-lg shadow-purple-500/20'
                  : 'bg-purple-500/10 border-purple-500/25 hover:bg-purple-500/20 text-purple-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="p-1.5 rounded-lg bg-purple-500/20 text-purple-300">
                  <Bot className="w-4 h-4" />
                </div>
                <span className="text-[9px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded bg-purple-500/30 text-purple-200 font-bold">
                  AI Tutor
                </span>
              </div>
              <div>
                <div className="text-xs font-bold text-white">ChemoBot AI</div>
                <div className="text-[10px] text-purple-300/80">Step-by-step reasoning</div>
              </div>
            </button>

            {/* Creator Profile */}
            <button
              onClick={() => handleMobileNav('creator')}
              className={`p-3 rounded-2xl border text-left transition-all flex flex-col justify-between gap-2 ${
                activeTab === 'creator'
                  ? 'bg-amber-600/30 border-amber-400 text-white shadow-lg shadow-amber-500/20'
                  : 'bg-amber-500/10 border-amber-500/25 hover:bg-amber-500/20 text-amber-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-300">
                  <GraduationCap className="w-4 h-4" />
                </div>
                <span className="text-[9px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded bg-amber-500/30 text-amber-200 font-bold">
                  Profile
                </span>
              </div>
              <div>
                <div className="text-xs font-bold text-white">Yajat Sarkar</div>
                <div className="text-[10px] text-amber-300/80">KV Bgt & Infinity Learn</div>
              </div>
            </button>
          </div>

          {/* Section: Chemistry Disciplines Curriculum Hierarchy */}
          <div className="space-y-2">
            <div className="text-[10px] font-mono uppercase tracking-wider text-cyan-400 px-2 font-bold flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                <span>Chemistry Disciplines Curriculum</span>
              </span>
              <button
                onClick={() => handleMobileNav('lab-directory')}
                className="text-[10px] text-cyan-300 underline font-normal"
              >
                View Full Map
              </button>
            </div>

            <div className="space-y-1.5 font-mono text-xs">
              {DISCIPLINE_NAV_GROUPS.map((group, idx) => {
                const isExpanded = expandedMobileDiscipline === group.name;
                const Icon = group.icon;
                return (
                  <div key={idx} className="rounded-xl border border-white/5 bg-white/[0.02] overflow-hidden">
                    <div
                      onClick={() => setExpandedMobileDiscipline(isExpanded ? null : group.name)}
                      className="p-3 flex items-center justify-between cursor-pointer hover:bg-white/5 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <span style={{ color: group.accentColor }}>
                          <Icon className="w-4 h-4" />
                        </span>
                        <span className="font-bold text-white text-xs">{group.name}</span>
                      </div>
                      <ChevronDown
                        className={`w-3.5 h-3.5 text-slate-400 transition-transform ${isExpanded ? 'rotate-180 text-cyan-400' : ''}`}
                      />
                    </div>

                    {isExpanded && (
                      <div className="p-2 space-y-1 bg-black/40 border-t border-white/5">
                        {group.items.map((sub, sIdx) => {
                          const isActive = activeTab === sub.tab;
                          return (
                            <button
                              key={sIdx}
                              onClick={() => handleMobileNav(sub.tab)}
                              className={`w-full text-left p-2 rounded-lg flex items-center justify-between transition-colors ${
                                isActive ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'hover:bg-white/10 text-slate-300'
                              }`}
                            >
                              <div>
                                <div className="text-xs">{sub.label}</div>
                                <div className="text-[10px] text-slate-500 font-sans">{sub.sub}</div>
                              </div>
                              <ChevronRight className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Bottom Actions Row: Theme & Motion Controls */}
          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/10">
            {onToggleTheme && (
              <button
                onClick={onToggleTheme}
                className={`py-2.5 px-3 rounded-xl border text-xs font-mono flex items-center justify-center gap-2 transition-colors ${
                  theme === 'light'
                    ? 'bg-amber-500/10 border-amber-500/30 text-amber-700'
                    : 'bg-white/5 border-white/10 text-yellow-300'
                }`}
              >
                {theme === 'light' ? (
                  <>
                    <Moon className="w-4 h-4 text-indigo-600" />
                    <span>Dark Mode</span>
                  </>
                ) : (
                  <>
                    <Sun className="w-4 h-4 text-yellow-400" />
                    <span>Light Mode</span>
                  </>
                )}
              </button>
            )}

            {onCycleMotion && (
              <button
                onClick={onCycleMotion}
                className="py-2.5 px-3 rounded-xl bg-white/5 border border-white/10 text-xs font-mono text-slate-300 flex items-center justify-center gap-2 hover:bg-white/10 transition-colors"
              >
                <Gauge className="w-3.5 h-3.5 text-cyan-400" />
                <span className="capitalize">{motionIntensity} Motion</span>
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
