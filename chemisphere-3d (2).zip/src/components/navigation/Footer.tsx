import React from 'react';
import { Atom, Boxes, GraduationCap, BookOpen, Trophy, FlaskConical, ExternalLink, Sparkles, Activity, ShieldCheck } from 'lucide-react';
import { NavigationTab } from '../../types';

interface FooterProps {
  onNavigate: (tab: NavigationTab) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="w-full border-t border-white/10 bg-[#06080e]/95 backdrop-blur-2xl py-12 px-4 sm:px-8 relative z-10 text-stone-300">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-10 text-xs">
        {/* Col 1: Chemisphere 3D Identity & Creator */}
        <div className="space-y-4">
          <div
            onClick={() => onNavigate('home')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500 via-indigo-600 to-purple-600 p-[1px] shadow-lg shadow-cyan-500/20">
              <div className="w-full h-full bg-[#070b14] rounded-[11px] flex items-center justify-center">
                <Atom className="w-5 h-5 text-cyan-300 animate-spin-slow" />
              </div>
            </div>
            <div>
              <div className="font-bold text-base text-white tracking-tight font-library group-hover:text-cyan-300 transition-colors">
                CHEMISPHERE 3D
              </div>
              <div className="text-[10px] text-cyan-400 font-mono">Interactive Scientific OS</div>
            </div>
          </div>

          <p className="text-xs text-stone-400 font-editorial italic leading-relaxed">
            An open scientific encyclopedia, interactive 3D laboratory suite, and historical chemistry archive engineered for students, researchers, and olympiad competitors.
          </p>

          <div
            onClick={() => onNavigate('creator')}
            className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 cursor-pointer hover:bg-amber-500/15 transition-all group"
          >
            <div className="text-[10px] font-mono text-amber-300 font-bold uppercase tracking-wider flex items-center gap-1.5">
              <GraduationCap className="w-3.5 h-3.5 text-amber-400" />
              <span>Created & Engineered By</span>
            </div>
            <div className="text-xs font-bold text-white group-hover:text-amber-300 transition-colors font-library mt-0.5">
              Yajat Sarkar
            </div>
          </div>
        </div>

        {/* Col 2: 3D Laboratories */}
        <div className="space-y-3">
          <div className="text-[11px] font-mono uppercase tracking-widest text-cyan-400 font-bold">
            Interactive Laboratories
          </div>
          <ul className="space-y-2 text-stone-400 font-sans">
            <li>
              <button onClick={() => onNavigate('periodic-table')} className="hover:text-cyan-300 transition-colors text-left">
                Periodic Table & 118 Elements
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('orbital-atlas')} className="hover:text-cyan-300 transition-colors text-left">
                3D Quantum Orbital Atlas ($\Psi$)
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('molecules-3d')} className="hover:text-cyan-300 transition-colors text-left">
                Molecular Geometry & VSEPR
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('spectroscopy-suite')} className="hover:text-cyan-300 transition-colors text-left">
                Spectroscopy Suite (UV-Vis, FTIR, NMR)
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('thermo-kinetics')} className="hover:text-cyan-300 transition-colors text-left">
                Thermodynamics & Kinetics
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('organic-chem')} className="hover:text-cyan-300 transition-colors text-left">
                Organic Reaction Highway
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('nuclear-chemistry')} className="hover:text-cyan-300 transition-colors text-left">
                Nuclear Chemistry & Decay Modes
              </button>
            </li>
          </ul>
        </div>

        {/* Col 3: Research Tools & Library */}
        <div className="space-y-3">
          <div className="text-[11px] font-mono uppercase tracking-widest text-amber-400 font-bold">
            Research & Archive
          </div>
          <ul className="space-y-2 text-stone-400 font-sans">
            <li>
              <button onClick={() => onNavigate('archive')} className="hover:text-amber-300 transition-colors text-left flex items-center gap-1.5 font-bold text-amber-200">
                <BookOpen className="w-3.5 h-3.5 text-amber-400" />
                <span>Digital Chemistry Library</span>
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('tools')} className="hover:text-cyan-300 transition-colors text-left flex items-center gap-1.5">
                <Boxes className="w-3.5 h-3.5 text-cyan-400" />
                <span>Chemistry Tools & Solvers</span>
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('questions-playground')} className="hover:text-yellow-300 transition-colors text-left flex items-center gap-1.5">
                <Trophy className="w-3.5 h-3.5 text-yellow-400" />
                <span>Questions Playground</span>
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('chemistry-lab')} className="hover:text-emerald-300 transition-colors text-left flex items-center gap-1.5">
                <FlaskConical className="w-3.5 h-3.5 text-emerald-400" />
                <span>Virtual Wet-Lab Sandbox</span>
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('profile')} className="hover:text-cyan-300 transition-colors text-left">
                Chemist Passport & Progress
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('ai-tutor')} className="hover:text-violet-300 transition-colors text-left flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-violet-400" />
                <span>ChemoBot AI Assistant</span>
              </button>
            </li>
          </ul>
        </div>

        {/* Col 4: Citations & Public Domain Attribution */}
        <div className="space-y-3">
          <div className="text-[11px] font-mono uppercase tracking-widest text-purple-400 font-bold">
            Sources & Attribution
          </div>
          <p className="text-stone-400 leading-relaxed font-editorial italic">
            Historical imagery, manuscripts, and portraits are curated from Wikimedia Commons and Public Domain archives with full scholarly attribution.
          </p>
          <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/10 space-y-1.5 text-[10px] font-mono text-stone-400">
            <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Scientific Data Standards</span>
            </div>
            <div>• IUPAC Gold Book 2024</div>
            <div>• NIST Chemistry WebBook</div>
            <div>• CODATA Fundamental Physical Constants</div>
          </div>
        </div>
      </div>

      {/* Bottom Copyright & Status Strip */}
      <div className="max-w-7xl mx-auto pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-stone-500">
        <div>
          © {new Date().getFullYear()} Chemisphere 3D. Engineered for science and education.
        </div>
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>All 14 Simulation Engines Active</span>
          </span>
        </div>
      </div>
    </footer>
  );
};
