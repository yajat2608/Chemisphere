import React from 'react';

interface MapCompassRoseProps {
  rotation?: number;
  className?: string;
  theme?: 'parchment' | 'nocturnal';
  onResetBearing?: () => void;
}

export const MapCompassRose: React.FC<MapCompassRoseProps> = ({
  rotation = 0,
  className = '',
  theme = 'parchment',
  onResetBearing
}) => {
  const isParchment = theme === 'parchment';

  return (
    <div
      onClick={onResetBearing}
      title="Nautical Compass Rose (Click to reset orientation)"
      className={`relative select-none cursor-pointer transition-transform duration-300 hover:scale-105 ${className}`}
    >
      <svg
        viewBox="0 0 160 160"
        className="w-24 h-24 sm:w-28 sm:h-28 drop-shadow-md"
        style={{ transform: `rotate(${rotation}deg)` }}
      >
        <defs>
          <radialGradient id="compassBgGrad" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor={isParchment ? '#f4ecd8' : '#0f172a'} stopOpacity="0.95" />
            <stop offset="85%" stopColor={isParchment ? '#e3d4b6' : '#090d16'} stopOpacity="0.95" />
            <stop offset="100%" stopColor={isParchment ? '#b89c72' : '#020617'} stopOpacity="1" />
          </radialGradient>

          <linearGradient id="goldBrassGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fef08a" />
            <stop offset="50%" stopColor="#ca8a04" />
            <stop offset="100%" stopColor="#78350f" />
          </linearGradient>

          <linearGradient id="northNeedleLight" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#dc2626" />
            <stop offset="100%" stopColor="#991b1b" />
          </linearGradient>

          <linearGradient id="northNeedleDark" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ef4444" />
            <stop offset="100%" stopColor="#b91c1c" />
          </linearGradient>
        </defs>

        {/* Outer Ring */}
        <circle
          cx="80"
          cy="80"
          r="74"
          fill="url(#compassBgGrad)"
          stroke={isParchment ? '#855828' : '#38bdf8'}
          strokeWidth="2"
        />

        {/* Secondary Inner Ring */}
        <circle
          cx="80"
          cy="80"
          r="66"
          fill="none"
          stroke={isParchment ? '#b3824d' : '#1e293b'}
          strokeWidth="1.2"
          strokeDasharray="2 2"
        />

        <circle
          cx="80"
          cy="80"
          r="48"
          fill="none"
          stroke={isParchment ? '#855828' : '#0284c7'}
          strokeWidth="0.8"
        />

        {/* Degree Ticks around the perimeter */}
        {Array.from({ length: 36 }).map((_, i) => {
          const angle = i * 10;
          const isMajor = i % 9 === 0;
          const isMedium = i % 3 === 0;
          const r1 = 66;
          const r2 = isMajor ? 58 : isMedium ? 61 : 63;
          const rad = (angle * Math.PI) / 180;
          const x1 = 80 + r1 * Math.sin(rad);
          const y1 = 80 - r1 * Math.cos(rad);
          const x2 = 80 + r2 * Math.sin(rad);
          const y2 = 80 - r2 * Math.cos(rad);

          return (
            <line
              key={i}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke={isParchment ? (isMajor ? '#5c3815' : '#8c5f32') : isMajor ? '#38bdf8' : '#64748b'}
              strokeWidth={isMajor ? 1.5 : 0.75}
            />
          );
        })}

        {/* 16-point Nautical Star (Subtle Rhumb Points) */}
        {/* Secondary NW, NE, SW, SE */}
        <polygon
          points="80,80 75,55 80,24 85,55"
          fill={isParchment ? '#a88350' : '#0369a1'}
          opacity="0.8"
          transform="rotate(45 80 80)"
        />
        <polygon
          points="80,80 75,55 80,24 85,55"
          fill={isParchment ? '#7c592a' : '#0c4a6e'}
          opacity="0.8"
          transform="rotate(135 80 80)"
        />
        <polygon
          points="80,80 75,55 80,24 85,55"
          fill={isParchment ? '#a88350' : '#0369a1'}
          opacity="0.8"
          transform="rotate(225 80 80)"
        />
        <polygon
          points="80,80 75,55 80,24 85,55"
          fill={isParchment ? '#7c592a' : '#0c4a6e'}
          opacity="0.8"
          transform="rotate(315 80 80)"
        />

        {/* Primary Cardinal Points: South, East, West */}
        {/* East */}
        <polygon points="80,80 115,75 142,80 115,85" fill={isParchment ? '#c29b63' : '#38bdf8'} />
        <polygon points="80,80 115,85 142,80 80,80" fill={isParchment ? '#855828' : '#0284c7'} />

        {/* South */}
        <polygon points="80,80 75,115 80,142 85,115" fill={isParchment ? '#c29b63' : '#38bdf8'} />
        <polygon points="80,80 85,115 80,142 80,80" fill={isParchment ? '#855828' : '#0284c7'} />

        {/* West */}
        <polygon points="80,80 45,85 18,80 45,75" fill={isParchment ? '#c29b63' : '#38bdf8'} />
        <polygon points="80,80 45,75 18,80 80,80" fill={isParchment ? '#855828' : '#0284c7'} />

        {/* North Primary Fleur-de-lis / Red Arrow */}
        <polygon points="80,80 74,45 80,14 80,80" fill="url(#northNeedleDark)" />
        <polygon points="80,80 80,14 86,45 80,80" fill="url(#northNeedleLight)" />

        {/* Center Brass Cap */}
        <circle cx="80" cy="80" r="7" fill="url(#goldBrassGrad)" stroke="#451a03" strokeWidth="1" />
        <circle cx="80" cy="80" r="3" fill="#ffffff" opacity="0.6" />

        {/* Cardinal Lettering */}
        <text
          x="80"
          y="10"
          textAnchor="middle"
          fontSize="11"
          fontWeight="bold"
          fontFamily="serif"
          fill={isParchment ? '#991b1b' : '#ef4444'}
          className="tracking-widest"
        >
          N
        </text>
        <text
          x="152"
          y="84"
          textAnchor="middle"
          fontSize="10"
          fontWeight="bold"
          fontFamily="serif"
          fill={isParchment ? '#5c3815' : '#93c5fd'}
        >
          E
        </text>
        <text
          x="80"
          y="155"
          textAnchor="middle"
          fontSize="10"
          fontWeight="bold"
          fontFamily="serif"
          fill={isParchment ? '#5c3815' : '#93c5fd'}
        >
          S
        </text>
        <text
          x="8"
          y="84"
          textAnchor="middle"
          fontSize="10"
          fontWeight="bold"
          fontFamily="serif"
          fill={isParchment ? '#5c3815' : '#93c5fd'}
        >
          W
        </text>
      </svg>
    </div>
  );
};
