import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Compass, Sparkles, MapPin, Feather, Eye } from 'lucide-react';

interface MapScrollUnfurlIntroProps {
  onComplete: () => void;
  theme?: 'parchment' | 'nocturnal';
}

export const MapScrollUnfurlIntro: React.FC<MapScrollUnfurlIntroProps> = ({
  onComplete,
  theme = 'parchment'
}) => {
  const [unfurlStep, setUnfurlStep] = useState<number>(0); // 0: Sealed Scroll, 1: Seal Breaks & Unrolls, 2: Continents Drawing, 3: Completed
  const isParchment = theme === 'parchment';

  const handleStartUnroll = () => {
    setUnfurlStep(1);
    const t1 = setTimeout(() => setUnfurlStep(2), 700);
    const t2 = setTimeout(() => {
      setUnfurlStep(3);
      onComplete();
    }, 1600);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.4 }}
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-8 backdrop-blur-md ${
        isParchment ? 'bg-[#2b1810]/85 text-[#fcf8ec]' : 'bg-[#030712]/90 text-[#f8fafc]'
      }`}
    >
      {/* Background Cartographic Vignette */}
      <div className="absolute inset-0 pointer-events-none opacity-30 bg-[radial-gradient(circle_at_center,_transparent_20%,_#000000_100%)]" />

      {/* Skip Button */}
      <button
        onClick={onComplete}
        className="absolute top-6 right-6 z-30 px-3.5 py-1.5 rounded-full text-xs font-serif tracking-wider uppercase border border-amber-500/40 bg-black/40 hover:bg-amber-500/20 text-amber-200 transition-all flex items-center gap-1.5"
      >
        <Eye className="w-3.5 h-3.5" />
        Skip Intro & Open World
      </button>

      {/* Main Unfolding Scroll Stage */}
      <div className="relative w-full max-w-2xl flex flex-col items-center justify-center">
        {unfurlStep === 0 && (
          <motion.div
            initial={{ scale: 0.85, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 1.1, opacity: 0 }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
            className="flex flex-col items-center text-center relative"
          >
            {/* Rolled Parchment Cylinder Container */}
            <div className="relative w-72 sm:w-96 h-28 sm:h-32 rounded-lg bg-gradient-to-r from-[#d4b98b] via-[#f7e6c4] to-[#c7a775] shadow-2xl border-y-4 border-[#855828] flex items-center justify-center overflow-hidden mb-8">
              {/* Wood / Brass Scroll Handles on Left & Right */}
              <div className="absolute left-0 top-0 bottom-0 w-5 bg-gradient-to-r from-[#5c3815] to-[#8c5f32] rounded-l-md border-r border-[#451a03] shadow-inner" />
              <div className="absolute right-0 top-0 bottom-0 w-5 bg-gradient-to-l from-[#5c3815] to-[#8c5f32] rounded-r-md border-l border-[#451a03] shadow-inner" />

              {/* Scroll Ribbon with Wax Seal */}
              <div className="absolute inset-y-0 w-12 bg-gradient-to-r from-red-900 via-red-700 to-red-950 shadow-md flex items-center justify-center">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-red-600 via-red-800 to-red-950 border-2 border-amber-300 shadow-xl flex items-center justify-center p-1">
                  <div className="w-full h-full rounded-full border border-dashed border-amber-200/60 flex items-center justify-center text-amber-200 font-serif font-bold text-lg">
                    ⚛
                  </div>
                </div>
              </div>

              {/* Antique Paper Crease Shadows */}
              <div className="absolute inset-0 bg-[linear-gradient(to_bottom,_rgba(0,0,0,0.15)_0%,_transparent_30%,_transparent_70%,_rgba(0,0,0,0.25)_100%)] pointer-events-none" />
            </div>

            {/* Title Ledger */}
            <div className="space-y-2 mb-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-serif uppercase tracking-widest bg-amber-500/10 border border-amber-500/30 text-amber-300">
                <Compass className="w-3.5 h-3.5" />
                Royal Alchemical & Quantum Atlas
              </div>
              <h2 className="text-3xl sm:text-4xl font-serif font-bold tracking-wide text-amber-100 drop-shadow-md">
                Map of the Known World of Chemistry
              </h2>
              <p className="text-sm sm:text-base font-serif italic text-amber-200/80 max-w-lg mx-auto">
                “Charted across the nine continents of Atomia, Organica, Thermoria, Spectralis, Analytica, Electrona, Nucleara, Bioterra, and Crystallia.”
              </p>
            </div>

            {/* Unroll Action Button */}
            <button
              onClick={handleStartUnroll}
              className="group relative px-8 py-3.5 rounded-xl font-serif text-base sm:text-lg font-bold tracking-wider text-amber-950 bg-gradient-to-r from-amber-200 via-amber-300 to-amber-400 hover:from-amber-100 hover:to-amber-300 shadow-xl shadow-amber-900/40 border border-amber-100 active:scale-95 transition-all flex items-center gap-3 cursor-pointer"
            >
              <Feather className="w-5 h-5 text-amber-900 group-hover:rotate-12 transition-transform" />
              <span>Break Wax Seal & Unroll Atlas</span>
              <Sparkles className="w-4 h-4 text-amber-800 animate-pulse" />
            </button>
          </motion.div>
        )}

        {unfurlStep === 1 && (
          <motion.div
            initial={{ scaleX: 0.2, scaleY: 0.6, opacity: 0.8 }}
            animate={{ scaleX: 1, scaleY: 1, opacity: 1 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="w-full h-80 rounded-2xl bg-gradient-to-br from-[#fbf4e2] via-[#f5e7c8] to-[#e8d5ae] shadow-2xl border-4 border-[#855828] flex flex-col items-center justify-center p-8 text-center text-[#451a03] relative overflow-hidden"
          >
            {/* Animated Parchment Cracking & Unrolling */}
            <motion.div
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2, duration: 0.4 }}
              className="flex flex-col items-center gap-3"
            >
              <Compass className="w-12 h-12 text-[#855828] animate-spin" style={{ animationDuration: '6s' }} />
              <h3 className="text-2xl font-serif font-bold text-[#5c3815]">Unrolling Continents & Graticules...</h3>
              <p className="text-sm font-serif italic text-[#7c592a]">Tracing coastlines of Atomia, Organica, and the Reaction Ocean</p>
            </motion.div>

            {/* Subtle Expanding Ink Ring */}
            <motion.div
              initial={{ scale: 0.1, opacity: 0.8 }}
              animate={{ scale: 2.5, opacity: 0 }}
              transition={{ duration: 0.8, ease: 'easeOut' }}
              className="absolute w-40 h-40 rounded-full border-2 border-[#855828] pointer-events-none"
            />
          </motion.div>
        )}

        {unfurlStep === 2 && (
          <motion.div
            initial={{ opacity: 0.5 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center gap-2 text-center"
          >
            <div className="flex items-center gap-2 text-amber-300 font-serif text-sm">
              <MapPin className="w-4 h-4 animate-bounce text-amber-400" />
              <span>Illuminating 30+ Module Landmarks & Navigational Beacons...</span>
            </div>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
};
