import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Compass,
  Sparkles,
  ArrowRight,
  Bot,
  CheckCircle2,
  Award,
  Scroll,
  BookOpen,
  Atom,
  Flame,
  Zap,
  Dna,
  Activity,
  Layers,
  MapPin,
  ExternalLink
} from 'lucide-react';
import { MapLandmark, MapRegion } from '../../data/chemistryMapData';
import { NavigationTab } from '../../types';

interface MapLandmarkDocketProps {
  landmark: MapLandmark | null;
  region?: MapRegion;
  onClose: () => void;
  onNavigate: (tab: NavigationTab) => void;
  onConsultAi?: (query: string, context?: any) => void;
  status: 'unvisited' | 'visited' | 'exploring' | 'completed';
  theme?: 'parchment' | 'nocturnal';
}

export const MapLandmarkDocket: React.FC<MapLandmarkDocketProps> = ({
  landmark,
  region,
  onClose,
  onNavigate,
  onConsultAi,
  status,
  theme = 'parchment'
}) => {
  if (!landmark) return null;
  const isParchment = theme === 'parchment';

  const getStatusBadge = () => {
    switch (status) {
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-serif font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/40">
            <Award className="w-3.5 h-3.5 text-amber-400" />
            Mastered Landmark (✦ Completed)
          </span>
        );
      case 'exploring':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-serif font-bold uppercase tracking-wider bg-yellow-500/20 text-yellow-300 border border-yellow-500/40">
            <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
            Currently Surveying (🟡 Exploring)
          </span>
        );
      case 'visited':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-serif font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            Cartographed (🟢 Visited)
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-serif font-medium uppercase tracking-wider bg-slate-500/20 text-slate-300 border border-slate-500/40">
            <Compass className="w-3.5 h-3.5 text-slate-400" />
            Unexplored Territory (⚪ Unvisited)
          </span>
        );
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-sm">
        {/* Backdrop click to close */}
        <div className="absolute inset-0" onClick={onClose} />

        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 15 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
          className={`relative w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-2xl shadow-2xl border-4 ${
            isParchment
              ? 'bg-[#fcf8ec] text-[#2b1810] border-[#855828] shadow-[#2b1810]/40'
              : 'bg-[#0b1120] text-[#f1f5f9] border-[#38bdf8]/40 shadow-cyan-950/60'
          }`}
        >
          {/* Antique Docket Header Flourish */}
          <div
            className={`p-5 sm:p-6 border-b ${
              isParchment
                ? 'border-[#d4b98b] bg-gradient-to-b from-[#f5ebd2] to-[#fcf8ec]'
                : 'border-white/10 bg-gradient-to-b from-[#0f172a] to-[#0b1120]'
            }`}
          >
            {/* Top Bar with Status & Close */}
            <div className="flex items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2 flex-wrap">
                {getStatusBadge()}
                {region && (
                  <span
                    className="text-xs font-serif px-2.5 py-0.5 rounded-md border font-medium"
                    style={{
                      backgroundColor: `${region.color}15`,
                      color: region.textColor,
                      borderColor: `${region.color}40`
                    }}
                  >
                    Realm of {region.name}
                  </span>
                )}
              </div>

              <button
                onClick={onClose}
                className={`p-1.5 rounded-full transition-colors ${
                  isParchment
                    ? 'hover:bg-[#e8d5ae] text-[#5c3815]'
                    : 'hover:bg-white/10 text-slate-400 hover:text-white'
                }`}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Landmark Title */}
            <div className="flex items-start gap-3">
              <div
                className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 border ${
                  isParchment
                    ? 'bg-[#f0dfbc] border-[#b89c72] text-[#5c3815]'
                    : 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400'
                }`}
              >
                <MapPin className="w-6 h-6" />
              </div>

              <div>
                <h3 className="text-xl sm:text-2xl font-serif font-bold tracking-tight">
                  {landmark.name}
                </h3>
                <p
                  className={`text-sm font-serif italic ${
                    isParchment ? 'text-[#7c592a]' : 'text-cyan-300/80'
                  }`}
                >
                  {landmark.subtitle}
                </p>
              </div>
            </div>

            {/* Geographic Coordinates Bar */}
            <div
              className={`mt-3 flex items-center gap-4 text-xs font-mono px-3 py-1.5 rounded-lg border ${
                isParchment
                  ? 'bg-[#f7ede0] border-[#d8c29d] text-[#6d431c]'
                  : 'bg-slate-900/60 border-slate-800 text-cyan-400/90'
              }`}
            >
              <div className="flex items-center gap-1">
                <Compass className="w-3.5 h-3.5 text-amber-500" />
                <span>{landmark.geographicLocation}</span>
              </div>
              <div className="hidden sm:inline-block ml-auto text-amber-600 font-serif font-medium">
                Reward: +{landmark.xpReward} XP
              </div>
            </div>
          </div>

          {/* Docket Content Body */}
          <div className="p-5 sm:p-6 space-y-5">
            {/* Overview Section */}
            <div className="space-y-1.5">
              <h4
                className={`text-xs font-serif uppercase tracking-widest font-bold ${
                  isParchment ? 'text-[#855828]' : 'text-slate-400'
                }`}
              >
                Cartographic Description
              </h4>
              <p
                className={`text-sm sm:text-base leading-relaxed ${
                  isParchment ? 'text-[#3d2410]' : 'text-slate-200'
                }`}
              >
                {landmark.shortDesc}
              </p>
            </div>

            {/* Deep Lore & Scientific Ledger */}
            <div
              className={`p-4 rounded-xl border space-y-2 ${
                isParchment
                  ? 'bg-[#f5ebd2]/70 border-[#d8c29d]'
                  : 'bg-slate-900/50 border-slate-800'
              }`}
            >
              <div className="flex items-center gap-2">
                <Scroll className="w-4 h-4 text-amber-600" />
                <h4
                  className={`text-xs font-serif uppercase tracking-wider font-bold ${
                    isParchment ? 'text-[#5c3815]' : 'text-amber-400'
                  }`}
                >
                  Explorer\'s Field Ledger & Scientific Lore
                </h4>
              </div>
              <p
                className={`text-sm leading-relaxed ${
                  isParchment ? 'text-[#4a2e16]' : 'text-slate-300'
                }`}
              >
                {landmark.detailedLore}
              </p>
              <div
                className={`text-xs font-serif italic pt-1 border-t ${
                  isParchment
                    ? 'border-[#d4b98b] text-[#7c592a]'
                    : 'border-slate-800 text-slate-400'
                }`}
              >
                📝 {landmark.fieldNotes}
              </div>
            </div>

            {/* Tags / Knowledge Index */}
            <div className="flex flex-wrap gap-1.5 items-center">
              <span
                className={`text-xs font-serif mr-1 ${
                  isParchment ? 'text-[#855828]' : 'text-slate-400'
                }`}
              >
                Discipline Index:
              </span>
              {landmark.tags.map((tag, idx) => (
                <span
                  key={idx}
                  className={`text-xs px-2.5 py-1 rounded-md border font-serif ${
                    isParchment
                      ? 'bg-[#f0e2c8] border-[#cbb18a] text-[#5c3815]'
                      : 'bg-slate-800/80 border-slate-700 text-slate-300'
                  }`}
                >
                  {tag}
                </span>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-col sm:flex-row gap-3">
              <button
                onClick={() => {
                  onClose();
                  onNavigate(landmark.tab);
                }}
                className="flex-1 py-3 px-5 rounded-xl font-serif font-bold text-base bg-gradient-to-r from-amber-600 via-amber-500 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white shadow-lg shadow-amber-900/30 flex items-center justify-center gap-2 cursor-pointer active:scale-98 transition-all"
              >
                <span>Embark to {landmark.name}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {onConsultAi && (
                <button
                  onClick={() => {
                    onClose();
                    onConsultAi(
                      `Explain the scientific concepts, formulas, and history behind ${landmark.name} (${landmark.subtitle}) in Chemisphere.`,
                      { landmark: landmark.name, tab: landmark.tab, discipline: landmark.discipline }
                    );
                  }}
                  className={`py-3 px-4 rounded-xl font-serif text-sm border flex items-center justify-center gap-2 transition-all ${
                    isParchment
                      ? 'bg-[#f0dfbc] hover:bg-[#e6d2a8] border-[#b89c72] text-[#5c3815]'
                      : 'bg-cyan-950/40 hover:bg-cyan-900/40 border-cyan-800 text-cyan-300'
                  }`}
                >
                  <Bot className="w-4 h-4" />
                  <span>Consult ChemoBot AI</span>
                </button>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
