import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitalData } from '../../types';
import { ORBITALS_DATA, getOrbitalById, getOrbitalByType } from '../../data/orbitals';

interface OrbitalCanvas3DProps {
  orbital?: OrbitalData;
  orbitalType?: string;
  probabilityThreshold?: number; // 10 to 99
  showNodalPlanes?: boolean;
  showAxes?: boolean;
  wireframe?: boolean;
  autoRotate?: boolean;
}

export const OrbitalCanvas3D: React.FC<OrbitalCanvas3DProps> = ({
  orbital: orbitalProp,
  orbitalType,
  probabilityThreshold = 90,
  showNodalPlanes = false,
  showAxes = true,
  wireframe = false,
  autoRotate = true
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const orbitalGroupRef = useRef<THREE.Group | null>(null);
  const nodalGroupRef = useRef<THREE.Group | null>(null);
  const axesGroupRef = useRef<THREE.Group | null>(null);
  const frameIdRef = useRef<number>(0);
  const isDraggingRef = useRef(false);
  const prevMousePos = useRef({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);

  // Safely resolve the active orbital data
  const orbital: OrbitalData =
    orbitalProp ||
    (orbitalType ? getOrbitalById(orbitalType) || getOrbitalByType(orbitalType) : undefined) ||
    ORBITALS_DATA[0];

  // Initialize Three.js Scene
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth || 600;
    const height = container.clientHeight || 450;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(5, 4, 7);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0x38bdf8, 1.8);
    dirLight1.position.set(10, 15, 10);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0xd946ef, 1.4);
    dirLight2.position.set(-10, -10, -10);
    scene.add(dirLight2);

    const pointLight = new THREE.PointLight(0xffffff, 1, 20);
    pointLight.position.set(0, 0, 0);
    scene.add(pointLight);

    // Groups
    const orbitalGroup = new THREE.Group();
    orbitalGroupRef.current = orbitalGroup;
    scene.add(orbitalGroup);

    const nodalGroup = new THREE.Group();
    nodalGroupRef.current = nodalGroup;
    scene.add(nodalGroup);

    const axesGroup = new THREE.Group();
    axesGroupRef.current = axesGroup;
    scene.add(axesGroup);

    // Build Axes
    const axisLen = 4;
    const axesHelper = new THREE.AxesHelper(axisLen);
    axesGroup.add(axesHelper);

    // Resize handler
    const handleResize = () => {
      if (!container || !renderer) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    // Animation Loop
    const animate = () => {
      if (orbitalGroupRef.current && autoRotate && !isDraggingRef.current) {
        orbitalGroupRef.current.rotation.y += 0.006;
        orbitalGroupRef.current.rotation.x += 0.002;
        if (nodalGroupRef.current) {
          nodalGroupRef.current.rotation.copy(orbitalGroupRef.current.rotation);
        }
        if (axesGroupRef.current) {
          axesGroupRef.current.rotation.copy(orbitalGroupRef.current.rotation);
        }
      }
      renderer.render(scene, camera);
      frameIdRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameIdRef.current);
      renderer.dispose();
    };
  }, []);

  // Update Geometry whenever orbital, threshold, nodal, axes, wireframe changes
  useEffect(() => {
    const orbitalGroup = orbitalGroupRef.current;
    const nodalGroup = nodalGroupRef.current;
    const axesGroup = axesGroupRef.current;
    if (!orbitalGroup || !nodalGroup || !axesGroup) return;

    // Clear previous geometries
    while (orbitalGroup.children.length > 0) {
      const obj = orbitalGroup.children[0] as THREE.Mesh;
      if (obj.geometry) obj.geometry.dispose();
      orbitalGroup.remove(obj);
    }
    while (nodalGroup.children.length > 0) {
      const obj = nodalGroup.children[0] as THREE.Mesh;
      if (obj.geometry) obj.geometry.dispose();
      nodalGroup.remove(obj);
    }

    axesGroup.visible = showAxes;
    nodalGroup.visible = showNodalPlanes;

    // Scale factor based on probability threshold (10% -> 99%)
    const probScale = 0.6 + (probabilityThreshold / 100) * 0.9;
    const opacity = 0.85;

    // Materials: Cyan (+ phase) and Magenta/Violet (- phase)
    const posMat = new THREE.MeshPhysicalMaterial({
      color: 0x06b6d4, // Cyan
      emissive: 0x083344,
      roughness: 0.2,
      metalness: 0.1,
      transmission: 0.4,
      transparent: true,
      opacity: opacity,
      wireframe: wireframe,
      side: THREE.DoubleSide
    });

    const negMat = new THREE.MeshPhysicalMaterial({
      color: 0xd946ef, // Magenta
      emissive: 0x4a044e,
      roughness: 0.2,
      metalness: 0.1,
      transmission: 0.4,
      transparent: true,
      opacity: opacity,
      wireframe: wireframe,
      side: THREE.DoubleSide
    });

    const nodalPlaneMat = new THREE.MeshBasicMaterial({
      color: 0x94a3b8,
      transparent: true,
      opacity: 0.25,
      side: THREE.DoubleSide,
      wireframe: true
    });

    // Nucleus
    const nucleusGeo = new THREE.SphereGeometry(0.12, 16, 16);
    const nucleusMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const nucleus = new THREE.Mesh(nucleusGeo, nucleusMat);
    orbitalGroup.add(nucleus);

    // Build specific orbital representations
    const id = orbital.id;

    if (orbital.type === 's') {
      // s orbital (spheres with radial nodes)
      const baseR = (1.5 + orbital.n * 0.4) * probScale;
      const sphereGeo = new THREE.SphereGeometry(baseR, 48, 48);
      const sMesh = new THREE.Mesh(sphereGeo, posMat);
      orbitalGroup.add(sMesh);

      if (orbital.radialNodes >= 1) {
        // Inner shell with inverted phase
        const innerR = baseR * 0.5;
        const innerGeo = new THREE.SphereGeometry(innerR, 36, 36);
        const innerMesh = new THREE.Mesh(innerGeo, negMat);
        orbitalGroup.add(innerMesh);

        // Nodal sphere indicator
        const nodalGeo = new THREE.SphereGeometry(baseR * 0.72, 24, 24);
        const nodalMesh = new THREE.Mesh(nodalGeo, nodalPlaneMat);
        nodalGroup.add(nodalMesh);
      }

      if (orbital.radialNodes >= 2) {
        const innermostR = baseR * 0.25;
        const innermostGeo = new THREE.SphereGeometry(innermostR, 24, 24);
        const innermostMesh = new THREE.Mesh(innermostGeo, posMat);
        orbitalGroup.add(innermostMesh);
      }
    } else if (orbital.type === 'p') {
      // p orbital (2 teardrop/dumbbell lobes along axis)
      const lobeLen = (2.2 + orbital.n * 0.25) * probScale;
      const lobeRad = (0.9 + orbital.n * 0.1) * probScale;

      // Create elongated lobe geometry
      const createLobe = (isPositive: boolean, dir: THREE.Vector3) => {
        const geo = new THREE.SphereGeometry(lobeRad, 36, 36);
        geo.scale(0.8, 1.8, 0.8);
        const mesh = new THREE.Mesh(geo, isPositive ? posMat : negMat);
        
        // Position lobe along direction
        const pos = dir.clone().multiplyScalar(lobeLen * 0.65);
        mesh.position.copy(pos);

        // Orient lobe towards direction
        const up = new THREE.Vector3(0, 1, 0);
        mesh.quaternion.setFromUnitVectors(up, dir);
        return mesh;
      };

      let dir = new THREE.Vector3(0, 1, 0); // pz default
      if (id.includes('px')) dir = new THREE.Vector3(1, 0, 0);
      if (id.includes('py')) dir = new THREE.Vector3(0, 0, 1);
      if (id.includes('pz')) dir = new THREE.Vector3(0, 1, 0);

      orbitalGroup.add(createLobe(true, dir));
      orbitalGroup.add(createLobe(false, dir.clone().negate()));

      // Nodal plane perpendicular to axis
      const planeGeo = new THREE.PlaneGeometry(5, 5);
      const planeMesh = new THREE.Mesh(planeGeo, nodalPlaneMat);
      if (id.includes('px')) planeMesh.rotation.y = Math.PI / 2;
      if (id.includes('py')) planeMesh.rotation.x = Math.PI / 2;
      if (id.includes('pz')) planeMesh.rotation.x = 0;
      nodalGroup.add(planeMesh);
    } else if (orbital.type === 'd') {
      if (id === '3dz2') {
        // dz²: 2 lobes along z + equatorial torus ring
        const lobeLen = 2.4 * probScale;
        const lobeRad = 0.8 * probScale;

        const geoZ = new THREE.SphereGeometry(lobeRad, 32, 32);
        geoZ.scale(0.75, 1.9, 0.75);

        const posLobe = new THREE.Mesh(geoZ, posMat);
        posLobe.position.set(0, lobeLen * 0.6, 0);
        orbitalGroup.add(posLobe);

        const posLobeB = new THREE.Mesh(geoZ.clone(), posMat);
        posLobeB.position.set(0, -lobeLen * 0.6, 0);
        orbitalGroup.add(posLobeB);

        // Donut Torus (negative phase)
        const torusGeo = new THREE.TorusGeometry(1.2 * probScale, 0.35 * probScale, 24, 48);
        torusGeo.rotateX(Math.PI / 2);
        const torusMesh = new THREE.Mesh(torusGeo, negMat);
        orbitalGroup.add(torusMesh);
      } else {
        // Cloverleaf 4-lobed d orbitals
        const lobeRad = 0.75 * probScale;
        const dist = 1.4 * probScale;

        const createCloverLobe = (isPositive: boolean, x: number, y: number, z: number) => {
          const geo = new THREE.SphereGeometry(lobeRad, 28, 28);
          geo.scale(1.2, 1.2, 1.2);
          const mesh = new THREE.Mesh(geo, isPositive ? posMat : negMat);
          mesh.position.set(x, y, z);
          return mesh;
        };

        if (id === '3dx2-y2') {
          // On x and y axes
          orbitalGroup.add(createCloverLobe(true, dist, 0, 0));
          orbitalGroup.add(createCloverLobe(true, -dist, 0, 0));
          orbitalGroup.add(createCloverLobe(false, 0, dist, 0));
          orbitalGroup.add(createCloverLobe(false, 0, -dist, 0));
        } else if (id === '3dxy') {
          // Between x and y (45°)
          const d45 = dist * 0.707;
          orbitalGroup.add(createCloverLobe(true, d45, d45, 0));
          orbitalGroup.add(createCloverLobe(true, -d45, -d45, 0));
          orbitalGroup.add(createCloverLobe(false, -d45, d45, 0));
          orbitalGroup.add(createCloverLobe(false, d45, -d45, 0));
        } else if (id === '3dxz') {
          const d45 = dist * 0.707;
          orbitalGroup.add(createCloverLobe(true, d45, 0, d45));
          orbitalGroup.add(createCloverLobe(true, -d45, 0, -d45));
          orbitalGroup.add(createCloverLobe(false, -d45, 0, d45));
          orbitalGroup.add(createCloverLobe(false, d45, 0, -d45));
        } else if (id === '3dyz') {
          const d45 = dist * 0.707;
          orbitalGroup.add(createCloverLobe(true, 0, d45, d45));
          orbitalGroup.add(createCloverLobe(true, 0, -d45, -d45));
          orbitalGroup.add(createCloverLobe(false, 0, -d45, d45));
          orbitalGroup.add(createCloverLobe(false, 0, d45, -d45));
        }
      }
    } else if (orbital.type === 'f') {
      // 8 Octant / Multi-lobe f orbital
      const lobeRad = 0.55 * probScale;
      const d = 1.2 * probScale;
      for (let sx of [-1, 1]) {
        for (let sy of [-1, 1]) {
          for (let sz of [-1, 1]) {
            const isPos = (sx * sy * sz) > 0;
            const geo = new THREE.SphereGeometry(lobeRad, 24, 24);
            const mesh = new THREE.Mesh(geo, isPos ? posMat : negMat);
            mesh.position.set(sx * d, sy * d, sz * d);
            orbitalGroup.add(mesh);
          }
        }
      }
    }
  }, [orbital, probabilityThreshold, showNodalPlanes, showAxes, wireframe]);

  // Mouse drag & zoom handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current || !orbitalGroupRef.current) return;
    const dx = e.clientX - prevMousePos.current.x;
    const dy = e.clientY - prevMousePos.current.y;
    orbitalGroupRef.current.rotation.y += dx * 0.01;
    orbitalGroupRef.current.rotation.x += dy * 0.01;
    if (nodalGroupRef.current) nodalGroupRef.current.rotation.copy(orbitalGroupRef.current.rotation);
    if (axesGroupRef.current) axesGroupRef.current.rotation.copy(orbitalGroupRef.current.rotation);
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  return (
    <div
      ref={containerRef}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      className="w-full h-full min-h-[380px] relative cursor-grab active:cursor-grabbing select-none rounded-xl overflow-hidden"
    />
  );
};
