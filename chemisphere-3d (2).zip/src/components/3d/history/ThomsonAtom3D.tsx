import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Zap, PlusCircle, Radio, Sparkles } from 'lucide-react';

export const ThomsonAtom3D: React.FC = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const mainGroupRef = useRef<THREE.Group | null>(null);
  const electronsGroupRef = useRef<THREE.Group | null>(null);
  const isDraggingRef = useRef(false);
  const prevMousePos = useRef({ x: 0, y: 0 });
  const frameIdRef = useRef<number>(0);

  const [electronCount, setElectronCount] = useState<number>(8);
  const [showCRTBeam, setShowCRTBeam] = useState<boolean>(false);
  const [selectedElectron, setSelectedElectron] = useState<number | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth || 500;
    const height = container.clientHeight || 380;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 0, 7.5);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Archival ambient + cyan cathode glow
    const ambLight = new THREE.AmbientLight(0xffedd5, 0.8);
    scene.add(ambLight);

    const dirLight1 = new THREE.DirectionalLight(0xf97316, 1.8);
    dirLight1.position.set(5, 8, 7);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x06b6d4, 1.2);
    dirLight2.position.set(-6, -4, -4);
    scene.add(dirLight2);

    const mainGroup = new THREE.Group();
    mainGroupRef.current = mainGroup;
    scene.add(mainGroup);

    // 1. Positive Fluid Sphere ("Pudding")
    const puddingRadius = 2.2;
    const puddingGeo = new THREE.SphereGeometry(puddingRadius, 48, 48);
    const puddingMat = new THREE.MeshPhysicalMaterial({
      color: 0xef4444,
      emissive: 0x7f1d1d,
      emissiveIntensity: 0.6,
      roughness: 0.15,
      metalness: 0.1,
      transmission: 0.75,
      transparent: true,
      opacity: 0.55
    });
    const puddingMesh = new THREE.Mesh(puddingGeo, puddingMat);
    mainGroup.add(puddingMesh);

    // Wireframe lattice of positive field
    const gridMat = new THREE.MeshBasicMaterial({
      color: 0xfca5a5,
      wireframe: true,
      transparent: true,
      opacity: 0.2
    });
    const gridMesh = new THREE.Mesh(new THREE.SphereGeometry(puddingRadius * 1.01, 24, 24), gridMat);
    mainGroup.add(gridMesh);

    // 2. Embedded Electrons ("Plums")
    const electronsGroup = new THREE.Group();
    electronsGroupRef.current = electronsGroup;
    mainGroup.add(electronsGroup);

    const goldenRatio = (1 + Math.sqrt(5)) / 2;
    const electronPositions: THREE.Vector3[] = [];

    for (let i = 0; i < electronCount; i++) {
      // Fibonacci sphere distribution inside volume (r ~ 0.5 to 1.7)
      const theta = 2 * Math.PI * i / goldenRatio;
      const phi = Math.acos(1 - 2 * (i + 0.5) / electronCount);
      const r = 0.6 + Math.pow((i + 1) / electronCount, 0.5) * 1.1;

      const x = r * Math.sin(phi) * Math.cos(theta);
      const y = r * Math.sin(phi) * Math.sin(theta);
      const z = r * Math.cos(phi);
      const pos = new THREE.Vector3(x, y, z);
      electronPositions.push(pos);

      const elecGeo = new THREE.SphereGeometry(0.24, 24, 24);
      const elecMat = new THREE.MeshStandardMaterial({
        color: selectedElectron === i ? 0x38bdf8 : 0x0284c7,
        emissive: 0x0369a1,
        emissiveIntensity: 0.6,
        roughness: 0.2,
        metalness: 0.4
      });
      const elecMesh = new THREE.Mesh(elecGeo, elecMat);
      elecMesh.position.copy(pos);
      elecMesh.userData = { electronIndex: i };
      electronsGroup.add(elecMesh);

      // Negative sign halo
      const ringGeo = new THREE.RingGeometry(0.28, 0.34, 16);
      const ringMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, side: THREE.DoubleSide });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.position.copy(pos);
      ringMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), pos.clone().normalize());
      electronsGroup.add(ringMesh);
    }

    // 3. CRT Cathode Ray Stream (if enabled)
    if (showCRTBeam) {
      const curve = new THREE.CubicBezierCurve3(
        new THREE.Vector3(-4.5, 0, 0),
        new THREE.Vector3(-1.5, 0.5, 0),
        new THREE.Vector3(1.5, 1.2, 0),
        new THREE.Vector3(4.5, 2.0, 0)
      );
      const tubeGeo = new THREE.TubeGeometry(curve, 32, 0.08, 12, false);
      const tubeMat = new THREE.MeshBasicMaterial({
        color: 0x22d3ee,
        transparent: true,
        opacity: 0.85
      });
      const tubeMesh = new THREE.Mesh(tubeGeo, tubeMat);
      mainGroup.add(tubeMesh);
    }

    const handleResize = () => {
      if (!container || !renderer) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    let t = 0;
    const animate = () => {
      t += 0.015;
      if (mainGroupRef.current && !isDraggingRef.current) {
        mainGroupRef.current.rotation.y += 0.007;
        mainGroupRef.current.rotation.x += 0.002;
      }

      // Small jitter/vibration for embedded corpuscles
      if (electronsGroupRef.current) {
        electronsGroupRef.current.children.forEach((child, idx) => {
          if (child instanceof THREE.Mesh && child.userData?.electronIndex !== undefined) {
            const base = electronPositions[child.userData.electronIndex];
            if (base) {
              child.position.x = base.x + Math.sin(t * 3 + idx) * 0.04;
              child.position.y = base.y + Math.cos(t * 2 + idx) * 0.04;
            }
          }
        });
      }

      renderer.render(scene, camera);
      frameIdRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameIdRef.current);
      renderer.dispose();
    };
  }, [electronCount, showCRTBeam, selectedElectron]);

  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current || !mainGroupRef.current) return;
    const dx = e.clientX - prevMousePos.current.x;
    const dy = e.clientY - prevMousePos.current.y;
    mainGroupRef.current.rotation.y += dx * 0.01;
    mainGroupRef.current.rotation.x += dy * 0.01;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  return (
    <div className="relative w-full h-[420px] rounded-2xl overflow-hidden bg-gradient-to-b from-[#19100e] to-[#0c0807] border border-rose-900/30">
      {/* Archival CRT scanline grid */}
      <div className="absolute inset-0 bg-[radial-gradient(#e11d48_1px,transparent_1px)] [background-size:24px_24px] opacity-10 pointer-events-none" />

      {/* 3D Canvas */}
      <div
        ref={containerRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="w-full h-full cursor-grab active:cursor-grabbing select-none"
      />

      {/* Top Banner */}
      <div className="absolute top-4 left-4 pointer-events-none">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-rose-950/80 border border-rose-800/50 backdrop-blur-md">
          <Zap className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-xs font-serif font-bold text-rose-200 tracking-wider">
            PLUM PUDDING MODEL (1897) — ELECTRONS IN POSITIVE SPHERE
          </span>
        </div>
      </div>

      {/* Bottom Controls */}
      <div className="absolute bottom-4 left-4 right-4 flex flex-wrap items-center justify-between gap-2 p-3 rounded-xl bg-[#140b0a]/90 border border-rose-900/40 backdrop-blur-md text-xs">
        {/* Electron Count Slider */}
        <div className="flex items-center gap-2 font-serif text-rose-300">
          <span>Corpuscles:</span>
          {[4, 8, 12, 18].map((count) => (
            <button
              key={count}
              onClick={() => setElectronCount(count)}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition-all ${
                electronCount === count
                  ? 'bg-rose-700 text-white shadow-md shadow-rose-900/50'
                  : 'bg-rose-950/40 text-rose-300/70 hover:text-white'
              }`}
            >
              {count} e⁻
            </button>
          ))}
        </div>

        {/* CRT Beam Toggle */}
        <button
          onClick={() => setShowCRTBeam(!showCRTBeam)}
          className={`px-3 py-1 rounded-lg border font-serif text-[11px] transition-all ${
            showCRTBeam
              ? 'bg-cyan-950/80 border-cyan-400 text-cyan-200'
              : 'border-rose-900/50 text-rose-400 hover:border-rose-700'
          }`}
        >
          Cathode Ray Deflection
        </button>
      </div>
    </div>
  );
};
