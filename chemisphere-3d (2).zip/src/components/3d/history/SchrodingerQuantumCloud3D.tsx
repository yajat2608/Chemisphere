import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Sparkles, Orbit, Layers, RefreshCw, BarChart2 } from 'lucide-react';

export const SchrodingerQuantumCloud3D: React.FC = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cloudPointsRef = useRef<THREE.Points | null>(null);
  const orbitLineRef = useRef<THREE.Line | null>(null);
  const mainGroupRef = useRef<THREE.Group | null>(null);
  const isDraggingRef = useRef(false);
  const prevMousePos = useRef({ x: 0, y: 0 });
  const frameIdRef = useRef<number>(0);

  const [orbitalType, setOrbitalType] = useState<'1s' | '2p' | '3d' | 'hybrid_sp3'>('2p');
  const [morphMode, setMorphMode] = useState<'cloud' | 'orbit' | 'hybrid'>('cloud');
  const [isovolumeDensity, setIsovolumeDensity] = useState<number>(0.85);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth || 500;
    const height = container.clientHeight || 380;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 0, 7.5);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const ambLight = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambLight);

    const dirLight = new THREE.DirectionalLight(0x06b6d4, 1.4);
    dirLight.position.set(4, 6, 8);
    scene.add(dirLight);

    const mainGroup = new THREE.Group();
    mainGroupRef.current = mainGroup;
    scene.add(mainGroup);

    // 1. Central Proton Nucleus
    const nuc = new THREE.Mesh(
      new THREE.SphereGeometry(0.2, 24, 24),
      new THREE.MeshStandardMaterial({ color: 0xef4444, emissive: 0x991b1b, emissiveIntensity: 0.8 })
    );
    mainGroup.add(nuc);

    // 2. Classical Bohr Orbit (for comparison morph)
    const orbitPts: THREE.Vector3[] = [];
    for (let i = 0; i <= 64; i++) {
      const a = (i / 64) * Math.PI * 2;
      orbitPts.push(new THREE.Vector3(Math.cos(a) * 2.2, Math.sin(a) * 2.2, 0));
    }
    const orbitLine = new THREE.Line(
      new THREE.BufferGeometry().setFromPoints(orbitPts),
      new THREE.LineBasicMaterial({ color: 0xf59e0b, transparent: true, opacity: 0.8, linewidth: 2 })
    );
    orbitLineRef.current = orbitLine;
    orbitLine.visible = morphMode === 'orbit' || morphMode === 'hybrid';
    mainGroup.add(orbitLine);

    // 3. Quantum Probability Cloud (Monte-Carlo sampled by orbital wavefunctions $\psi_{nlm}(r,\theta,\phi)$)
    const particleCount = 7000;
    const geo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    let idx = 0;
    while (idx < particleCount) {
      // Rejection sampling for orbital probability $|\psi|^2$
      const x = (Math.random() - 0.5) * 5.5;
      const y = (Math.random() - 0.5) * 5.5;
      const z = (Math.random() - 0.5) * 5.5;
      const r = Math.sqrt(x * x + y * y + z * z);
      if (r < 0.05) continue;

      const cosTheta = z / r;
      let prob = 0;
      let phaseSign = 1;

      if (orbitalType === '1s') {
        // psi_1s ~ exp(-r)
        prob = Math.exp(-2 * r);
      } else if (orbitalType === '2p') {
        // psi_2pz ~ z * exp(-r/2)
        prob = Math.pow(z * Math.exp(-r / 1.6), 2);
        phaseSign = z > 0 ? 1 : -1;
      } else if (orbitalType === '3d') {
        // psi_3dz2 ~ (3z^2 - r^2) * exp(-r/3)
        const dTerm = (3 * z * z - r * r);
        prob = Math.pow(dTerm * Math.exp(-r / 2.2), 2);
        phaseSign = dTerm > 0 ? 1 : -1;
      } else {
        // hybrid sp3 lobe
        const sp3 = (x + y + z) / Math.sqrt(3);
        prob = Math.pow(Math.max(0, sp3) * Math.exp(-r / 1.8), 2);
      }

      if (Math.random() < prob * 3.5 * isovolumeDensity) {
        positions[idx * 3] = x;
        positions[idx * 3 + 1] = y;
        positions[idx * 3 + 2] = z;

        if (phaseSign > 0) {
          // Cyan lobe (+)
          colors[idx * 3] = 0.22;
          colors[idx * 3 + 1] = 0.74;
          colors[idx * 3 + 2] = 0.97;
        } else {
          // Purple/Orange lobe (-)
          colors[idx * 3] = 0.96;
          colors[idx * 3 + 1] = 0.45;
          colors[idx * 3 + 2] = 0.2;
        }
        idx++;
      }
    }

    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const cloudMat = new THREE.PointsMaterial({
      size: 0.075,
      vertexColors: true,
      transparent: true,
      opacity: morphMode === 'orbit' ? 0.15 : 0.85,
      blending: THREE.AdditiveBlending
    });

    const cloudPoints = new THREE.Points(geo, cloudMat);
    cloudPointsRef.current = cloudPoints;
    mainGroup.add(cloudPoints);

    const handleResize = () => {
      if (!container || !renderer) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    const animate = () => {
      if (mainGroupRef.current && !isDraggingRef.current) {
        mainGroupRef.current.rotation.y += 0.006;
        mainGroupRef.current.rotation.x += 0.002;
      }
      renderer.render(scene, camera);
      frameIdRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameIdRef.current);
      renderer.dispose();
    };
  }, [orbitalType, morphMode, isovolumeDensity]);

  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current || !mainGroupRef.current) return;
    const dx = e.clientX - prevMousePos.current.x;
    const dy = e.clientY - prevMousePos.current.y;
    mainGroupRef.current.rotation.y += dx * 0.01;
    mainGroupRef.current.rotation.x += dy * 0.01;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  return (
    <div className="relative w-full h-[420px] rounded-2xl overflow-hidden bg-gradient-to-b from-[#0e1622] to-[#070b12] border border-cyan-900/30">
      {/* Archival Wave Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(#06b6d4_1px,transparent_1px)] [background-size:24px_24px] opacity-10 pointer-events-none" />

      {/* 3D Canvas */}
      <div
        ref={containerRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="w-full h-full cursor-grab active:cursor-grabbing select-none"
      />

      {/* Top Banner */}
      <div className="absolute top-4 left-4 pointer-events-none">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-cyan-950/80 border border-cyan-800/50 backdrop-blur-md">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-xs font-serif font-bold text-cyan-200 tracking-wider">
            SCHRÖDINGER QUANTUM MECHANICAL CLOUD (1926) — |Ψ|²
          </span>
        </div>
      </div>

      {/* Mode Selector Top Right */}
      <div className="absolute top-4 right-4 flex items-center gap-1 p-1 rounded-xl bg-slate-950/80 border border-cyan-900/60 backdrop-blur-md text-xs font-serif">
        {(['cloud', 'orbit', 'hybrid'] as const).map((m) => (
          <button
            key={m}
            onClick={() => setMorphMode(m)}
            className={`px-2.5 py-1 rounded-lg capitalize transition-all ${
              morphMode === m
                ? 'bg-cyan-700 text-white font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {m}
          </button>
        ))}
      </div>

      {/* Bottom Controls */}
      <div className="absolute bottom-4 left-4 right-4 flex flex-wrap items-center justify-between gap-2 p-3 rounded-xl bg-[#0c131e]/90 border border-cyan-900/40 backdrop-blur-md text-xs">
        {/* Orbital Buttons */}
        <div className="flex items-center gap-1.5 font-mono">
          {(['1s', '2p', '3d', 'hybrid_sp3'] as const).map((orb) => (
            <button
              key={orb}
              onClick={() => setOrbitalType(orb)}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                orbitalType === orb
                  ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/50'
                  : 'bg-slate-900/70 text-slate-400 hover:text-white'
              }`}
            >
              {orb === 'hybrid_sp3' ? 'sp³' : orb}
            </button>
          ))}
        </div>

        {/* Probability Density Threshold Slider */}
        <div className="flex items-center gap-2 text-[11px] font-serif text-slate-300">
          <span>Density:</span>
          <input
            type="range"
            min="0.4"
            max="1.5"
            step="0.1"
            value={isovolumeDensity}
            onChange={(e) => setIsovolumeDensity(parseFloat(e.target.value))}
            className="w-24 accent-cyan-500"
          />
          <span className="font-mono text-cyan-300">{Math.round(isovolumeDensity * 100)}%</span>
        </div>
      </div>
    </div>
  );
};
