import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Zap, Sparkles, Orbit, Flame, ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface SpectralTransition {
  nInitial: number;
  nFinal: number;
  deltaE: number;
  wavelength: number;
  series: string;
  region: string;
  color: string;
}

export const BohrAtomInteractive3D: React.FC = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const mainGroupRef = useRef<THREE.Group | null>(null);
  const electronMeshRef = useRef<THREE.Mesh | null>(null);
  const photonPulseGroupRef = useRef<THREE.Group | null>(null);
  const isDraggingRef = useRef(false);
  const prevMousePos = useRef({ x: 0, y: 0 });
  const frameIdRef = useRef<number>(0);

  const [currentN, setCurrentN] = useState<number>(1);
  const [targetN, setTargetN] = useState<number>(3);
  const [lastTransition, setLastTransition] = useState<SpectralTransition | null>(null);
  const [isTransitioning, setIsTransitioning] = useState<boolean>(false);

  const shells = [
    { n: 1, label: 'K (n=1)', r: 1.2, energy: -13.6 },
    { n: 2, label: 'L (n=2)', r: 2.0, energy: -3.4 },
    { n: 3, label: 'M (n=3)', r: 2.9, energy: -1.51 },
    { n: 4, label: 'N (n=4)', r: 3.8, energy: -0.85 },
    { n: 5, label: 'O (n=5)', r: 4.6, energy: -0.54 },
    { n: 6, label: 'P (n=6)', r: 5.3, energy: -0.38 }
  ];

  const calculateTransition = (n1: number, n2: number): SpectralTransition => {
    const lower = Math.min(n1, n2);
    const upper = Math.max(n1, n2);

    const E_lower = -13.6 / (lower * lower);
    const E_upper = -13.6 / (upper * upper);
    const deltaE = Math.abs(E_upper - E_lower);

    // 1/lambda = R_H * (1/n1^2 - 1/n2^2), R_H = 1.097373e7 m^-1
    const invLambda = 1.097373e7 * (1 / (lower * lower) - 1 / (upper * upper));
    const lambdaNm = (1 / invLambda) * 1e9;

    let series = 'Lyman';
    let region = 'Ultraviolet';
    let color = '#c084fc';

    if (lower === 1) {
      series = 'Lyman Series';
      region = 'Ultraviolet (UV)';
      color = '#a855f7';
    } else if (lower === 2) {
      series = 'Balmer Series';
      region = 'Visible Light';
      if (upper === 3) color = '#ef4444'; // H-alpha (656 nm)
      else if (upper === 4) color = '#06b6d4'; // H-beta (486 nm)
      else if (upper === 5) color = '#3b82f6'; // H-gamma (434 nm)
      else color = '#8b5cf6'; // H-delta (410 nm)
    } else if (lower === 3) {
      series = 'Paschen Series';
      region = 'Near Infrared';
      color = '#f97316';
    } else if (lower === 4) {
      series = 'Brackett Series';
      region = 'Infrared';
      color = '#e11d48';
    } else {
      series = 'Pfund Series';
      region = 'Far Infrared';
      color = '#be123c';
    }

    return {
      nInitial: n1,
      nFinal: n2,
      deltaE: parseFloat(deltaE.toFixed(3)),
      wavelength: parseFloat(lambdaNm.toFixed(1)),
      series,
      region,
      color
    };
  };

  const triggerQuantumTransition = (destinationN: number) => {
    if (destinationN === currentN) return;
    const trans = calculateTransition(currentN, destinationN);
    setLastTransition(trans);
    setIsTransitioning(true);

    // Spawn expanding photon ring in Three.js
    if (photonPulseGroupRef.current) {
      while (photonPulseGroupRef.current.children.length > 0) {
        const o = photonPulseGroupRef.current.children[0];
        photonPulseGroupRef.current.remove(o);
      }

      const ringGeo = new THREE.RingGeometry(0.3, 0.45, 32);
      const ringMat = new THREE.MeshBasicMaterial({
        color: new THREE.Color(trans.color),
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.95
      });
      const pulseRing = new THREE.Mesh(ringGeo, ringMat);
      pulseRing.userData = { scale: 1, opacity: 0.95, isEmission: destinationN < currentN };
      photonPulseGroupRef.current.add(pulseRing);
    }

    setCurrentN(destinationN);
    setTimeout(() => setIsTransitioning(false), 800);
  };

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth || 500;
    const height = container.clientHeight || 380;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 0, 10);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const ambLight = new THREE.AmbientLight(0xfff7ed, 0.8);
    scene.add(ambLight);

    const dirLight1 = new THREE.DirectionalLight(0x38bdf8, 1.6);
    dirLight1.position.set(5, 8, 10);
    scene.add(dirLight1);

    const mainGroup = new THREE.Group();
    mainGroupRef.current = mainGroup;
    scene.add(mainGroup);

    // 1. Central Proton Nucleus (+1e)
    const nucGeo = new THREE.SphereGeometry(0.32, 32, 32);
    const nucMat = new THREE.MeshStandardMaterial({
      color: 0xef4444,
      emissive: 0x991b1b,
      emissiveIntensity: 0.8
    });
    const nucMesh = new THREE.Mesh(nucGeo, nucMat);
    mainGroup.add(nucMesh);

    // 2. Concentric Quantized Shells (n=1 to 6)
    shells.forEach((shell) => {
      const isCurrent = shell.n === currentN;
      const ringGeo = new THREE.BufferGeometry();
      const pts: THREE.Vector3[] = [];
      for (let i = 0; i <= 64; i++) {
        const a = (i / 64) * Math.PI * 2;
        pts.push(new THREE.Vector3(Math.cos(a) * shell.r, Math.sin(a) * shell.r, 0));
      }
      ringGeo.setFromPoints(pts);
      const ringMat = new THREE.LineBasicMaterial({
        color: isCurrent ? 0x06b6d4 : 0x475569,
        transparent: true,
        opacity: isCurrent ? 0.9 : 0.35,
        linewidth: isCurrent ? 2 : 1
      });
      const ringLine = new THREE.Line(ringGeo, ringMat);
      mainGroup.add(ringLine);
    });

    // 3. Orbiting Electron
    const eGeo = new THREE.SphereGeometry(0.16, 24, 24);
    const eMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
    const eMesh = new THREE.Mesh(eGeo, eMat);
    electronMeshRef.current = eMesh;
    mainGroup.add(eMesh);

    // 4. Photon Pulse Group
    const photonPulseGroup = new THREE.Group();
    photonPulseGroupRef.current = photonPulseGroup;
    mainGroup.add(photonPulseGroup);

    const handleResize = () => {
      if (!container || !renderer) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    let angle = 0;
    const animate = () => {
      // Calculate current shell radius
      const activeShell = shells.find((s) => s.n === currentN) || shells[0];
      const speed = 0.03 * Math.sqrt(1 / currentN);
      angle += speed;

      if (electronMeshRef.current) {
        electronMeshRef.current.position.set(
          Math.cos(angle) * activeShell.r,
          Math.sin(angle) * activeShell.r,
          0
        );
      }

      // Animate expanding photon pulse
      if (photonPulseGroupRef.current) {
        photonPulseGroupRef.current.children.forEach((child) => {
          if (child instanceof THREE.Mesh) {
            child.userData.scale += 0.08;
            child.userData.opacity -= 0.02;
            child.scale.set(child.userData.scale, child.userData.scale, 1);
            if (child.material) {
              (child.material as THREE.MeshBasicMaterial).opacity = Math.max(0, child.userData.opacity);
            }
          }
        });
      }

      if (mainGroupRef.current && !isDraggingRef.current) {
        mainGroupRef.current.rotation.z += 0.001;
      }

      renderer.render(scene, camera);
      frameIdRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameIdRef.current);
      renderer.dispose();
    };
  }, [currentN]);

  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current || !mainGroupRef.current) return;
    const dx = e.clientX - prevMousePos.current.x;
    const dy = e.clientY - prevMousePos.current.y;
    mainGroupRef.current.rotation.y += dx * 0.01;
    mainGroupRef.current.rotation.x += dy * 0.01;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  return (
    <div className="relative w-full h-[420px] rounded-2xl overflow-hidden bg-gradient-to-b from-[#13111c] to-[#0a0910] border border-cyan-900/30">
      {/* Archival Blueprint Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(#06b6d4_1px,transparent_1px)] [background-size:24px_24px] opacity-10 pointer-events-none" />

      {/* 3D Canvas */}
      <div
        ref={containerRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="w-full h-full cursor-grab active:cursor-grabbing select-none"
      />

      {/* Top Banner */}
      <div className="absolute top-4 left-4 pointer-events-none">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-cyan-950/80 border border-cyan-800/50 backdrop-blur-md">
          <Orbit className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-xs font-serif font-bold text-cyan-200 tracking-wider">
            BOHR QUANTIZED ELECTRON SHELLS (1913)
          </span>
        </div>
      </div>

      {/* Real-time Photon Emission Banner */}
      {lastTransition && (
        <div className="absolute top-4 right-4 p-3 rounded-xl bg-[#0d121f]/90 border border-cyan-800/60 backdrop-blur-md text-xs font-mono space-y-1">
          <div className="flex items-center gap-2 font-bold" style={{ color: lastTransition.color }}>
            {lastTransition.nFinal < lastTransition.nInitial ? (
              <ArrowDownRight className="w-4 h-4" />
            ) : (
              <ArrowUpRight className="w-4 h-4" />
            )}
            <span>
              n={lastTransition.nInitial} ➔ n={lastTransition.nFinal} ({lastTransition.series})
            </span>
          </div>
          <div className="text-slate-300 text-[11px]">
            ΔE = <span className="font-bold text-white">{lastTransition.deltaE} eV</span>
          </div>
          <div className="text-slate-300 text-[11px]">
            Wavelength λ = <span className="font-bold text-cyan-300">{lastTransition.wavelength} nm</span> ({lastTransition.region})
          </div>
        </div>
      )}

      {/* Bottom Controls — Shell Quantum Jumper */}
      <div className="absolute bottom-4 left-4 right-4 flex flex-wrap items-center justify-between gap-2 p-3 rounded-xl bg-[#0e0c18]/90 border border-cyan-900/40 backdrop-blur-md text-xs">
        {/* Shell buttons */}
        <div className="flex items-center gap-1.5">
          <span className="text-slate-400 font-serif text-[11px] mr-1">Shell:</span>
          {shells.map((s) => (
            <button
              key={s.n}
              onClick={() => triggerQuantumTransition(s.n)}
              className={`px-2.5 py-1 rounded-lg font-mono text-xs font-bold transition-all ${
                currentN === s.n
                  ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/50'
                  : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              n={s.n}
            </button>
          ))}
        </div>

        {/* Excitation → Emission Trigger */}
        <button
          onClick={() => triggerQuantumTransition(currentN === 1 ? 3 : 1)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white font-serif font-bold shadow-md shadow-rose-950 transition-all text-xs"
        >
          <Flame className="w-3.5 h-3.5" />
          <span>EXCITATION ➔ PHOTON EMISSION</span>
        </button>
      </div>
    </div>
  );
};
