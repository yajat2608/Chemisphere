import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Target, Play, RotateCcw, AlertTriangle } from 'lucide-react';

interface AlphaParticle {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  trail: THREE.Vector3[];
  deflected: boolean;
  color: string;
}

export const RutherfordAtom3D: React.FC = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const mainGroupRef = useRef<THREE.Group | null>(null);
  const isDraggingRef = useRef(false);
  const prevMousePos = useRef({ x: 0, y: 0 });
  const frameIdRef = useRef<number>(0);

  const [simMode, setSimMode] = useState<'nuclear-atom' | 'gold-foil-beam'>('nuclear-atom');
  const [alphaEnergy, setAlphaEnergy] = useState<number>(5.5); // MeV
  const [scatterStats, setScatterStats] = useState({ total: 0, straight: 0, deflected: 0, rebound: 0 });

  const particlesRef = useRef<AlphaParticle[]>([]);
  const lastSpawnRef = useRef<number>(0);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth || 500;
    const height = container.clientHeight || 380;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 0, 9);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const ambLight = new THREE.AmbientLight(0xfff1f2, 0.7);
    scene.add(ambLight);

    const dirLight1 = new THREE.DirectionalLight(0xf43f5e, 1.6);
    dirLight1.position.set(6, 8, 10);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x38bdf8, 1.0);
    dirLight2.position.set(-6, -6, -4);
    scene.add(dirLight2);

    const mainGroup = new THREE.Group();
    mainGroupRef.current = mainGroup;
    scene.add(mainGroup);

    // 1. Tiny Dense Nucleus (Gold 79+ / Rutherford nucleus)
    const nucleusGroup = new THREE.Group();
    mainGroup.add(nucleusGroup);

    // Core glow
    const nucCoreGeo = new THREE.SphereGeometry(0.35, 32, 32);
    const nucCoreMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      emissive: 0xd97706,
      emissiveIntensity: 0.8,
      roughness: 0.2
    });
    const nucCoreMesh = new THREE.Mesh(nucCoreGeo, nucCoreMat);
    nucleusGroup.add(nucCoreMesh);

    // Cluster of protons (red) and neutrons (grey)
    for (let i = 0; i < 14; i++) {
      const pGeo = new THREE.SphereGeometry(0.09, 12, 12);
      const isProton = i % 2 === 0;
      const pMat = new THREE.MeshStandardMaterial({
        color: isProton ? 0xef4444 : 0x94a3b8,
        roughness: 0.3
      });
      const pMesh = new THREE.Mesh(pGeo, pMat);
      pMesh.position.set(
        (Math.random() - 0.5) * 0.4,
        (Math.random() - 0.5) * 0.4,
        (Math.random() - 0.5) * 0.4
      );
      nucleusGroup.add(pMesh);
    }

    // 2. Classical Planetary Orbits & Orbiting Electrons
    const orbits = [
      { r: 2.2, speed: 0.04, tilt: { x: 0.4, y: 0.2 } },
      { r: 3.2, speed: -0.03, tilt: { x: -0.5, y: 0.6 } },
      { r: 4.2, speed: 0.025, tilt: { x: 0.7, y: -0.3 } }
    ];

    const electronMeshes: { mesh: THREE.Mesh; orbit: typeof orbits[0]; angle: number }[] = [];

    orbits.forEach((orb) => {
      // Orbit Path Ring
      const ringGeo = new THREE.BufferGeometry();
      const points: THREE.Vector3[] = [];
      for (let i = 0; i <= 64; i++) {
        const a = (i / 64) * Math.PI * 2;
        points.push(new THREE.Vector3(Math.cos(a) * orb.r, Math.sin(a) * orb.r, 0));
      }
      ringGeo.setFromPoints(points);
      const ringLine = new THREE.Line(
        ringGeo,
        new THREE.LineBasicMaterial({ color: 0x06b6d4, transparent: true, opacity: 0.35 })
      );
      ringLine.rotation.x = orb.tilt.x;
      ringLine.rotation.y = orb.tilt.y;
      mainGroup.add(ringLine);

      // Electron Sphere
      const eGeo = new THREE.SphereGeometry(0.12, 16, 16);
      const eMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      const eMesh = new THREE.Mesh(eGeo, eMat);
      mainGroup.add(eMesh);
      electronMeshes.push({ mesh: eMesh, orbit: orb, angle: Math.random() * Math.PI * 2 });
    });

    // 3. Dynamic Alpha Particle Scintillation Trails Group
    const trailsGroup = new THREE.Group();
    mainGroup.add(trailsGroup);

    const handleResize = () => {
      if (!container || !renderer) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    const animate = () => {
      // Rotate electron orbits
      electronMeshes.forEach((item) => {
        item.angle += item.orbit.speed;
        const x = Math.cos(item.angle) * item.orbit.r;
        const y = Math.sin(item.angle) * item.orbit.r;
        const p = new THREE.Vector3(x, y, 0);
        p.applyEuler(new THREE.Euler(item.orbit.tilt.x, item.orbit.tilt.y, 0));
        item.mesh.position.copy(p);
      });

      // Spawn Alpha particles if in beam mode
      const now = performance.now();
      if (simMode === 'gold-foil-beam' && now - lastSpawnRef.current > 120) {
        lastSpawnRef.current = now;
        const impactY = (Math.random() - 0.5) * 3.5;
        const impactZ = (Math.random() - 0.5) * 3.5;
        particlesRef.current.push({
          pos: new THREE.Vector3(-6, impactY, impactZ),
          vel: new THREE.Vector3(0.12, 0, 0),
          trail: [],
          deflected: false,
          color: '#38bdf8'
        });
      }

      // Clear old trails
      while (trailsGroup.children.length > 0) {
        const obj = trailsGroup.children[0];
        trailsGroup.remove(obj);
      }

      // Step & deflect Alpha particles via Coulomb force: F = k * (q1 * q2) / r^2
      particlesRef.current.forEach((p, idx) => {
        p.trail.push(p.pos.clone());
        if (p.trail.length > 15) p.trail.shift();

        const dist = p.pos.length();
        if (dist < 4.5 && dist > 0.3) {
          // Coulomb repulsion directed outward from (0,0,0)
          const forceDir = p.pos.clone().normalize();
          const forceMag = (0.015 * (alphaEnergy / 5.5)) / (dist * dist);
          p.vel.add(forceDir.multiplyScalar(forceMag));
        }

        p.pos.add(p.vel);

        // Render particle point and trail
        if (p.trail.length > 1) {
          const geo = new THREE.BufferGeometry().setFromPoints(p.trail);
          const mat = new THREE.LineBasicMaterial({
            color: dist < 0.8 ? 0xf43f5e : (p.vel.x < 0 ? 0xf59e0b : 0x06b6d4),
            transparent: true,
            opacity: 0.8
          });
          const line = new THREE.Line(geo, mat);
          trailsGroup.add(line);
        }
      });

      // Filter out off-screen particles and update stats
      particlesRef.current = particlesRef.current.filter((p) => {
        const alive = p.pos.x > -7 && p.pos.x < 7 && Math.abs(p.pos.y) < 6;
        if (!alive && !p.deflected) {
          p.deflected = true;
          const theta = Math.atan2(Math.sqrt(p.vel.y * p.vel.y + p.vel.z * p.vel.z), p.vel.x);
          const deg = (theta * 180) / Math.PI;
          setScatterStats((prev) => ({
            total: prev.total + 1,
            straight: deg < 5 ? prev.straight + 1 : prev.straight,
            deflected: deg >= 5 && deg < 90 ? prev.deflected + 1 : prev.deflected,
            rebound: deg >= 90 ? prev.rebound + 1 : prev.rebound
          }));
        }
        return alive;
      });

      renderer.render(scene, camera);
      frameIdRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameIdRef.current);
      renderer.dispose();
    };
  }, [simMode, alphaEnergy]);

  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current || !mainGroupRef.current) return;
    const dx = e.clientX - prevMousePos.current.x;
    const dy = e.clientY - prevMousePos.current.y;
    mainGroupRef.current.rotation.y += dx * 0.01;
    mainGroupRef.current.rotation.x += dy * 0.01;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  return (
    <div className="relative w-full h-[420px] rounded-2xl overflow-hidden bg-gradient-to-b from-[#180f12] to-[#0c0809] border border-rose-900/30">
      {/* Archival Gold Foil Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(#f43f5e_1px,transparent_1px)] [background-size:24px_24px] opacity-10 pointer-events-none" />

      {/* 3D Canvas */}
      <div
        ref={containerRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="w-full h-full cursor-grab active:cursor-grabbing select-none"
      />

      {/* Top Banner */}
      <div className="absolute top-4 left-4 pointer-events-none">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-rose-950/80 border border-rose-800/50 backdrop-blur-md">
          <Target className="w-3.5 h-3.5 text-rose-400" />
          <span className="text-xs font-serif font-bold text-rose-200 tracking-wider">
            RUTHERFORD NUCLEAR ATOM & α-SCATTERING (1911)
          </span>
        </div>
      </div>

      {/* Stats Counter (if in beam mode) */}
      {simMode === 'gold-foil-beam' && (
        <div className="absolute top-4 right-4 p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 backdrop-blur-md font-mono text-[10px] space-y-1">
          <div className="text-slate-400">α-Particles: <span className="text-white font-bold">{scatterStats.total}</span></div>
          <div className="text-emerald-400">Undeflected (&lt;5°): {scatterStats.straight}</div>
          <div className="text-cyan-400">Deflected (5°-90°): {scatterStats.deflected}</div>
          <div className="text-amber-400 font-bold">Rebounded (&gt;90°): {scatterStats.rebound}</div>
        </div>
      )}

      {/* Bottom Controls */}
      <div className="absolute bottom-4 left-4 right-4 flex flex-wrap items-center justify-between gap-2 p-3 rounded-xl bg-[#140b0d]/90 border border-rose-900/40 backdrop-blur-md text-xs">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSimMode('nuclear-atom')}
            className={`px-3 py-1 rounded-lg font-serif transition-all ${
              simMode === 'nuclear-atom'
                ? 'bg-rose-700 text-white font-bold shadow-md shadow-rose-900/50'
                : 'text-rose-300 hover:text-white'
            }`}
          >
            Nuclear Planetary Orbit
          </button>
          <button
            onClick={() => {
              setSimMode('gold-foil-beam');
              particlesRef.current = [];
            }}
            className={`px-3 py-1 rounded-lg font-serif transition-all ${
              simMode === 'gold-foil-beam'
                ? 'bg-rose-700 text-white font-bold shadow-md shadow-rose-900/50'
                : 'text-rose-300 hover:text-white'
            }`}
          >
            Gold Foil α-Beam Gun
          </button>
        </div>

        {simMode === 'gold-foil-beam' && (
          <div className="flex items-center gap-2 text-[11px] font-serif text-slate-300">
            <span>α-Energy:</span>
            <input
              type="range"
              min="2.0"
              max="10.0"
              step="0.5"
              value={alphaEnergy}
              onChange={(e) => setAlphaEnergy(parseFloat(e.target.value))}
              className="w-20 accent-rose-500"
            />
            <span className="font-mono text-rose-400">{alphaEnergy} MeV</span>
          </div>
        )}
      </div>
    </div>
  );
};
