import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Sliders, Eye, Sparkles, HelpCircle, Activity } from 'lucide-react';

export const HeisenbergUncertainty3D: React.FC = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const wavePointsRef = useRef<THREE.Points | null>(null);
  const mainGroupRef = useRef<THREE.Group | null>(null);
  const isDraggingRef = useRef(false);
  const prevMousePos = useRef({ x: 0, y: 0 });
  const frameIdRef = useRef<number>(0);

  // Position precision slider (0.1 = high position precision, wide momentum dispersion)
  const [deltaX, setDeltaX] = useState<number>(0.6);
  const [isObserving, setIsObserving] = useState<boolean>(false);

  // Derived delta P via Heisenberg limit: deltaX * deltaP >= hbar / 2
  const hbarHalf = 0.5;
  const deltaP = parseFloat((hbarHalf / deltaX).toFixed(2));

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth || 500;
    const height = container.clientHeight || 380;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 0, 8);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const ambLight = new THREE.AmbientLight(0xf5f3ff, 0.8);
    scene.add(ambLight);

    const dirLight = new THREE.DirectionalLight(0xa855f7, 1.6);
    dirLight.position.set(5, 8, 8);
    scene.add(dirLight);

    const mainGroup = new THREE.Group();
    mainGroupRef.current = mainGroup;
    scene.add(mainGroup);

    // Quantum Wave Packet Point Cloud (Probability density $|\psi(x)|^2$)
    const count = 3000;
    const geo = new THREE.BufferGeometry();
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
      // Gaussian distribution for position X with sigma = deltaX
      const u1 = Math.random();
      const u2 = Math.random();
      const randStdNormal = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);

      const x = randStdNormal * deltaX;
      const y = (Math.random() - 0.5) * 2.0;
      const z = (Math.random() - 0.5) * 2.0;

      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;

      // Color transition from core violet to cyan edge
      colors[i * 3] = 0.65;
      colors[i * 3 + 1] = 0.35;
      colors[i * 3 + 2] = 0.95;
    }

    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const mat = new THREE.PointsMaterial({
      size: 0.08,
      vertexColors: true,
      transparent: true,
      opacity: 0.8,
      blending: THREE.AdditiveBlending
    });

    const wavePoints = new THREE.Points(geo, mat);
    wavePointsRef.current = wavePoints;
    mainGroup.add(wavePoints);

    // Probability Envelope Mesh (Gaussian Wireframe Bell)
    const bellPts: THREE.Vector3[] = [];
    for (let x = -4; x <= 4; x += 0.1) {
      const prob = (1 / (deltaX * Math.sqrt(2 * Math.PI))) * Math.exp(-0.5 * Math.pow(x / deltaX, 2));
      bellPts.push(new THREE.Vector3(x, prob * 0.8 - 1.5, 0));
    }
    const bellLine = new THREE.Line(
      new THREE.BufferGeometry().setFromPoints(bellPts),
      new THREE.LineBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.75 })
    );
    mainGroup.add(bellLine);

    const handleResize = () => {
      if (!container || !renderer) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    let t = 0;
    const animate = () => {
      t += 0.02;
      if (mainGroupRef.current && !isDraggingRef.current) {
        mainGroupRef.current.rotation.y += 0.005;
      }

      // If observing (photon collision), add phase flicker
      if (isObserving && wavePointsRef.current) {
        const pAttr = wavePointsRef.current.geometry.attributes.position as THREE.BufferAttribute;
        for (let i = 0; i < count; i++) {
          pAttr.setY(i, pAttr.getY(i) + Math.sin(t * 10 + i) * 0.02);
        }
        pAttr.needsUpdate = true;
      }

      renderer.render(scene, camera);
      frameIdRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameIdRef.current);
      renderer.dispose();
    };
  }, [deltaX, isObserving]);

  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current || !mainGroupRef.current) return;
    const dx = e.clientX - prevMousePos.current.x;
    const dy = e.clientY - prevMousePos.current.y;
    mainGroupRef.current.rotation.y += dx * 0.01;
    mainGroupRef.current.rotation.x += dy * 0.01;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  return (
    <div className="relative w-full h-[420px] rounded-2xl overflow-hidden bg-gradient-to-b from-[#161022] to-[#0a0711] border border-purple-900/30">
      {/* Quantum Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(#a855f7_1px,transparent_1px)] [background-size:24px_24px] opacity-10 pointer-events-none" />

      {/* 3D Canvas */}
      <div
        ref={containerRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="w-full h-full cursor-grab active:cursor-grabbing select-none"
      />

      {/* Top Banner */}
      <div className="absolute top-4 left-4 pointer-events-none">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-purple-950/80 border border-purple-800/50 backdrop-blur-md">
          <Activity className="w-3.5 h-3.5 text-purple-400" />
          <span className="text-xs font-serif font-bold text-purple-200 tracking-wider">
            HEISENBERG UNCERTAINTY PRINCIPLE (1927)
          </span>
        </div>
      </div>

      {/* Math Inequality Display */}
      <div className="absolute top-4 right-4 p-3 rounded-xl bg-[#0e0a18]/90 border border-purple-800/60 backdrop-blur-md text-xs font-mono space-y-1">
        <div className="text-purple-300 font-bold">Δx · Δp ≥ ℏ / 2</div>
        <div className="flex items-center gap-3 text-[11px] pt-1">
          <span className="text-cyan-400">Position Unc. Δx: <strong>{deltaX} Å</strong></span>
          <span className="text-amber-400">Momentum Unc. Δp: <strong>{deltaP} ℏ/Å</strong></span>
        </div>
      </div>

      {/* Bottom Controls */}
      <div className="absolute bottom-4 left-4 right-4 flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-[#100b1d]/90 border border-purple-900/40 backdrop-blur-md text-xs">
        {/* Slider for Position Localization */}
        <div className="flex items-center gap-3 font-serif text-slate-300">
          <span>Localize Position (Δx):</span>
          <input
            type="range"
            min="0.2"
            max="1.8"
            step="0.1"
            value={deltaX}
            onChange={(e) => setDeltaX(parseFloat(e.target.value))}
            className="w-32 accent-purple-500"
          />
          <span className="font-mono text-purple-300">{deltaX} Å</span>
        </div>

        {/* Photon Measurement Flash */}
        <button
          onClick={() => setIsObserving(!isObserving)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border font-serif text-xs transition-all ${
            isObserving
              ? 'bg-purple-900 border-purple-400 text-white shadow-lg shadow-purple-900/60'
              : 'border-purple-800/60 text-purple-300 hover:text-white'
          }`}
        >
          <Eye className="w-3.5 h-3.5" />
          <span>{isObserving ? 'Observing (Wave Packet Collapsing)' : 'Illuminate with Photon (Measure)'}</span>
        </button>
      </div>
    </div>
  );
};
