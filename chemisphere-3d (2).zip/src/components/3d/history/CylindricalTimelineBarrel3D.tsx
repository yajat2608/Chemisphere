import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { ScientistData } from '../../../data/scientists';
import { ChevronLeft, ChevronRight, Rotate3d } from 'lucide-react';

interface CylindricalTimelineBarrel3DProps {
  scientists: ScientistData[];
  selectedIndex: number;
  onSelectScientist: (index: number) => void;
}

export const CylindricalTimelineBarrel3D: React.FC<CylindricalTimelineBarrel3DProps> = ({
  scientists,
  selectedIndex,
  onSelectScientist
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const barrelGroupRef = useRef<THREE.Group | null>(null);
  const nodeMeshesRef = useRef<{ plate: THREE.Mesh; labelPlane: THREE.Mesh; idx: number }[]>([]);
  const frameIdRef = useRef<number>(0);

  const targetRotationRef = useRef<number>(0);
  const currentRotationRef = useRef<number>(0);
  const isDraggingRef = useRef<boolean>(false);
  const startMouseYRef = useRef<number>(0);
  const prevMouseYRef = useRef<number>(0);
  const dragDistanceRef = useRef<number>(0);

  const totalCount = scientists.length;
  const angleStep = (Math.PI * 2) / totalCount;
  const barrelRadius = 3.8;

  // Sync target rotation when selectedIndex changes (positive rotation brings selected item to front-center)
  useEffect(() => {
    targetRotationRef.current = selectedIndex * angleStep;
  }, [selectedIndex, angleStep]);

  // Function to create crisp label textures
  const createLabelTexture = (scientist: ScientistData, isSelected: boolean) => {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 224;
    const ctx = canvas.getContext('2d');
    if (!ctx) return new THREE.CanvasTexture(canvas);

    ctx.clearRect(0, 0, 512, 224);

    // Rounded Card Background
    const r = 24;
    ctx.beginPath();
    ctx.roundRect(8, 8, 496, 208, r);

    // Gradient Background
    const grad = ctx.createLinearGradient(0, 8, 0, 216);
    if (isSelected) {
      grad.addColorStop(0, 'rgba(180, 83, 9, 0.96)');
      grad.addColorStop(1, 'rgba(120, 53, 15, 0.98)');
    } else {
      grad.addColorStop(0, 'rgba(28, 20, 16, 0.92)');
      grad.addColorStop(1, 'rgba(15, 11, 9, 0.95)');
    }
    ctx.fillStyle = grad;
    ctx.fill();

    // High Contrast Border
    ctx.strokeStyle = isSelected ? '#fbbf24' : 'rgba(180, 83, 9, 0.4)';
    ctx.lineWidth = isSelected ? 5 : 2;
    ctx.stroke();

    // Header: Year / Roman Numeral Badge
    ctx.fillStyle = isSelected ? '#fef3c7' : '#d97706';
    ctx.font = '700 24px "Cinzel", Georgia, serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    const yearText = scientist.romanYear ? `${scientist.romanYear} (${scientist.year})` : `${scientist.year}`;
    ctx.fillText(yearText, 256, 20);

    // Scientist Name (Auto-scale font size to fit neatly)
    ctx.fillStyle = '#ffffff';
    const nameUpper = scientist.name.toUpperCase();
    const fontSize = nameUpper.length > 18 ? 30 : nameUpper.length > 14 ? 34 : 38;
    ctx.font = `900 ${fontSize}px "Plus Jakarta Sans", -apple-system, sans-serif`;
    ctx.textBaseline = 'middle';
    ctx.fillText(nameUpper, 256, 95);

    // Model Title Subtext (Crisp and trimmed)
    ctx.fillStyle = isSelected ? '#fef08a' : '#94a3b8';
    const modelText = scientist.modelName.length > 28 ? scientist.modelName.slice(0, 26) + '...' : scientist.modelName;
    ctx.font = '600 22px "Plus Jakarta Sans", -apple-system, sans-serif';
    ctx.textBaseline = 'bottom';
    ctx.fillText(modelText, 256, 192);

    const texture = new THREE.CanvasTexture(canvas);
    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    return texture;
  };

  // Initialize Three.js Scene once
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 260;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    camera.position.set(0, 0, 7.8);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Studio Ambient & Key Lighting
    const ambLight = new THREE.AmbientLight(0xffedd5, 1.0);
    scene.add(ambLight);

    const dirLight1 = new THREE.DirectionalLight(0xd97706, 2.0);
    dirLight1.position.set(0, 10, 8);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x38bdf8, 0.9);
    dirLight2.position.set(0, -6, -4);
    scene.add(dirLight2);

    const barrelGroup = new THREE.Group();
    barrelGroupRef.current = barrelGroup;
    scene.add(barrelGroup);

    // 1. Archival Wireframe Latitudinal Barrel Cylinder
    const cylinderGeo = new THREE.CylinderGeometry(barrelRadius, barrelRadius, 3.4, 40, 8, true);
    const cylinderMat = new THREE.MeshBasicMaterial({
      color: 0xb45309,
      wireframe: true,
      transparent: true,
      opacity: 0.15
    });
    const cylinderMesh = new THREE.Mesh(cylinderGeo, cylinderMat);
    cylinderMesh.rotation.z = Math.PI / 2; // Lie horizontal
    barrelGroup.add(cylinderMesh);

    // Decorative brass rings at outer rims
    const rimMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      metalness: 0.8,
      roughness: 0.25
    });
    const rimGeo = new THREE.TorusGeometry(barrelRadius, 0.04, 16, 64);
    const leftRim = new THREE.Mesh(rimGeo, rimMat);
    leftRim.position.x = -1.7;
    leftRim.rotation.y = Math.PI / 2;
    barrelGroup.add(leftRim);

    const rightRim = new THREE.Mesh(rimGeo, rimMat);
    rightRim.position.x = 1.7;
    rightRim.rotation.y = Math.PI / 2;
    barrelGroup.add(rightRim);

    // 2. Nodes pinned tangentially around cylinder perimeter
    const nodes: { plate: THREE.Mesh; labelPlane: THREE.Mesh; idx: number }[] = [];

    scientists.forEach((scientist, idx) => {
      const angle = idx * angleStep;
      const y = Math.sin(angle) * barrelRadius;
      const z = Math.cos(angle) * barrelRadius;

      // Base solid bevel plate
      const plateGeo = new THREE.BoxGeometry(2.1, 0.92, 0.08);
      const plateMat = new THREE.MeshStandardMaterial({
        color: 0x1f1712,
        roughness: 0.35,
        metalness: 0.6
      });
      const plateMesh = new THREE.Mesh(plateGeo, plateMat);
      plateMesh.position.set(0, y, z);
      plateMesh.rotation.x = -angle;
      plateMesh.userData = { index: idx };
      barrelGroup.add(plateMesh);

      // Front-Facing Label Plane (with FrontSide culling so backside never renders or glitches)
      const labelGeo = new THREE.PlaneGeometry(2.05, 0.88);
      const labelTexture = createLabelTexture(scientist, idx === selectedIndex);
      const labelMat = new THREE.MeshBasicMaterial({
        map: labelTexture,
        transparent: true,
        side: THREE.FrontSide
      });
      const labelPlane = new THREE.Mesh(labelGeo, labelMat);
      labelPlane.position.set(0, 0, 0.045);
      labelPlane.userData = { index: idx };
      plateMesh.add(labelPlane);

      nodes.push({ plate: plateMesh, labelPlane, idx });
    });

    nodeMeshesRef.current = nodes;

    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    // Smooth inertia render loop
    const animate = () => {
      const diff = targetRotationRef.current - currentRotationRef.current;
      currentRotationRef.current += diff * 0.12;

      if (barrelGroupRef.current) {
        barrelGroupRef.current.rotation.x = currentRotationRef.current;
      }

      renderer.render(scene, camera);
      frameIdRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameIdRef.current);
      renderer.dispose();
    };
  }, [scientists, totalCount, angleStep, barrelRadius]);

  // Update textures and materials when selectedIndex changes
  useEffect(() => {
    nodeMeshesRef.current.forEach(({ plate, labelPlane, idx }) => {
      const isSelected = idx === selectedIndex;
      const scientist = scientists[idx];

      // Update plate emissive glow
      const plateMat = plate.material as THREE.MeshStandardMaterial;
      if (plateMat) {
        plateMat.color.setHex(isSelected ? 0x92400e : 0x1f1712);
        plateMat.emissive.setHex(isSelected ? 0xd97706 : 0x000000);
        plateMat.emissiveIntensity = isSelected ? 0.45 : 0;
      }

      // Update label texture
      const labelMat = labelPlane.material as THREE.MeshBasicMaterial;
      if (labelMat) {
        if (labelMat.map) labelMat.map.dispose();
        labelMat.map = createLabelTexture(scientist, isSelected);
        labelMat.needsUpdate = true;
      }
    });
  }, [selectedIndex, scientists]);

  // Handle Wheel Scroll
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    if (Math.abs(e.deltaY) > 10) {
      if (e.deltaY > 0 && selectedIndex < totalCount - 1) {
        onSelectScientist(selectedIndex + 1);
      } else if (e.deltaY < 0 && selectedIndex > 0) {
        onSelectScientist(selectedIndex - 1);
      }
    }
  };

  // Handle Dragging and Clicking
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    startMouseYRef.current = e.clientY;
    prevMouseYRef.current = e.clientY;
    dragDistanceRef.current = 0;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;
    const dy = e.clientY - prevMouseYRef.current;
    dragDistanceRef.current += Math.abs(dy);
    prevMouseYRef.current = e.clientY;

    if (Math.abs(e.clientY - startMouseYRef.current) > 35) {
      if (e.clientY < startMouseYRef.current && selectedIndex < totalCount - 1) {
        onSelectScientist(selectedIndex + 1);
        startMouseYRef.current = e.clientY;
      } else if (e.clientY > startMouseYRef.current && selectedIndex > 0) {
        onSelectScientist(selectedIndex - 1);
        startMouseYRef.current = e.clientY;
      }
    }
  };

  const handleMouseUp = (e: React.MouseEvent) => {
    isDraggingRef.current = false;

    // If it was a clean click without major drag, perform raycast click
    if (dragDistanceRef.current < 6) {
      const container = containerRef.current;
      const camera = cameraRef.current;
      const barrelGroup = barrelGroupRef.current;
      if (!container || !camera || !barrelGroup) return;

      const rect = container.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(new THREE.Vector2(x, y), camera);
      const intersects = raycaster.intersectObjects(barrelGroup.children, true);

      const hit = intersects.find((i) => i.object.userData?.index !== undefined);
      if (hit && hit.object.userData.index !== undefined) {
        onSelectScientist(hit.object.userData.index);
      }
    }
  };

  return (
    <div
      onWheel={handleWheel}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={() => {
        isDraggingRef.current = false;
      }}
      className="relative w-full h-[260px] rounded-2xl overflow-hidden bg-gradient-to-b from-[#140e0b] via-[#1c140f] to-[#120b08] border border-amber-800/40 select-none shadow-2xl"
    >
      {/* Archival Gold Dot Matrix */}
      <div className="absolute inset-0 bg-[radial-gradient(#b45309_1.2px,transparent_1.2px)] [background-size:20px_20px] opacity-20 pointer-events-none" />

      {/* 3D Barrel Canvas */}
      <div ref={containerRef} className="w-full h-full cursor-ns-resize" />

      {/* Atmospheric Vignettes */}
      <div className="absolute inset-0 bg-gradient-to-r from-[#140e0b]/90 via-transparent to-[#140e0b]/90 pointer-events-none" />
      <div className="absolute inset-x-0 top-0 h-14 bg-gradient-to-b from-[#140e0b] to-transparent pointer-events-none" />
      <div className="absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-[#140e0b] to-transparent pointer-events-none" />

      {/* Top Left Instrument Tag */}
      <div className="absolute top-3 left-4 flex items-center gap-2 pointer-events-none">
        <Rotate3d className="w-4 h-4 text-amber-500 animate-spin-slow" />
        <span className="text-[11px] font-serif font-bold text-amber-200 tracking-widest uppercase">
          Chronological Barrel (Drag, Scroll, or Click Node)
        </span>
      </div>

      {/* Navigation Quick Arrows */}
      <div className="absolute top-3 right-4 flex items-center gap-1.5 z-10">
        <button
          onClick={() => selectedIndex > 0 && onSelectScientist(selectedIndex - 1)}
          disabled={selectedIndex === 0}
          className="p-1.5 rounded-lg bg-amber-950/80 border border-amber-800/60 text-amber-200 hover:bg-amber-900 disabled:opacity-30 transition-all"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <span className="font-sans text-xs font-bold text-amber-300 px-2">
          {selectedIndex + 1} / {totalCount}
        </span>
        <button
          onClick={() => selectedIndex < totalCount - 1 && onSelectScientist(selectedIndex + 1)}
          disabled={selectedIndex === totalCount - 1}
          className="p-1.5 rounded-lg bg-amber-950/80 border border-amber-800/60 text-amber-200 hover:bg-amber-900 disabled:opacity-30 transition-all"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
