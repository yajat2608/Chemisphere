import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RotateCw, Sparkles, Sliders, Shield } from 'lucide-react';

export const DaltonAtom3D: React.FC = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sphereMeshRef = useRef<THREE.Mesh | null>(null);
  const latticeGroupRef = useRef<THREE.Group | null>(null);
  const isDraggingRef = useRef(false);
  const prevMousePos = useRef({ x: 0, y: 0 });
  const frameIdRef = useRef<number>(0);

  const [atomType, setAtomType] = useState<'hydrogen' | 'oxygen' | 'nitrogen' | 'carbon'>('carbon');
  const [showLattice, setShowLattice] = useState(false);
  const [elasticCollision, setElasticCollision] = useState(false);

  const atomConfig = {
    hydrogen: { name: 'Hydrogen (Relative Wt: 1)', color: 0xe2e8f0, radius: 1.2, mass: 1 },
    carbon: { name: 'Carbon (Relative Wt: 12)', color: 0x334155, radius: 1.8, mass: 12 },
    nitrogen: { name: 'Nitrogen (Relative Wt: 14)', color: 0x2563eb, radius: 1.9, mass: 14 },
    oxygen: { name: 'Oxygen (Relative Wt: 16)', color: 0xdc2626, radius: 2.0, mass: 16 }
  };

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth || 500;
    const height = container.clientHeight || 380;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 0, 7);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Warm vintage archival lighting
    const ambLight = new THREE.AmbientLight(0xfffbeb, 0.8);
    scene.add(ambLight);

    const dirLight1 = new THREE.DirectionalLight(0xd97706, 1.8);
    dirLight1.position.set(6, 10, 8);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x38bdf8, 0.6);
    dirLight2.position.set(-6, -6, -4);
    scene.add(dirLight2);

    // Sphere (Solid Billiard Ball)
    const conf = atomConfig[atomType];
    const sphereGeo = new THREE.SphereGeometry(conf.radius, 48, 48);
    const sphereMat = new THREE.MeshStandardMaterial({
      color: conf.color,
      roughness: 0.35,
      metalness: 0.25
    });
    const sphereMesh = new THREE.Mesh(sphereGeo, sphereMat);
    sphereMeshRef.current = sphereMesh;
    scene.add(sphereMesh);

    // Latitude & Longitude Archival Grid Rings
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0xd97706,
      wireframe: true,
      transparent: true,
      opacity: 0.35
    });
    const ringMesh = new THREE.Mesh(new THREE.SphereGeometry(conf.radius * 1.02, 16, 16), ringMat);
    sphereMesh.add(ringMesh);

    // Compound Lattice Demo Group
    const latticeGroup = new THREE.Group();
    latticeGroupRef.current = latticeGroup;
    latticeGroup.visible = showLattice;
    scene.add(latticeGroup);

    // Create a simple binary compound (e.g., CO or NO)
    const sat1 = new THREE.Mesh(
      new THREE.SphereGeometry(1.0, 32, 32),
      new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.3 })
    );
    sat1.position.set(2.4, 1.2, 0);
    latticeGroup.add(sat1);

    const sat2 = new THREE.Mesh(
      new THREE.SphereGeometry(1.2, 32, 32),
      new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.3 })
    );
    sat2.position.set(-2.4, -1.0, 0);
    latticeGroup.add(sat2);

    const handleResize = () => {
      if (!container || !renderer) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    let t = 0;
    const animate = () => {
      t += 0.01;
      if (sphereMeshRef.current && !isDraggingRef.current) {
        sphereMeshRef.current.rotation.y += 0.008;
        sphereMeshRef.current.rotation.x += 0.003;
      }
      if (latticeGroupRef.current && showLattice) {
        latticeGroupRef.current.rotation.y -= 0.006;
      }
      if (elasticCollision && sphereMeshRef.current) {
        sphereMeshRef.current.position.x = Math.sin(t * 3) * 0.8;
      } else if (sphereMeshRef.current) {
        sphereMeshRef.current.position.x = 0;
      }

      renderer.render(scene, camera);
      frameIdRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameIdRef.current);
      renderer.dispose();
    };
  }, [atomType, showLattice, elasticCollision]);

  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current || !sphereMeshRef.current) return;
    const dx = e.clientX - prevMousePos.current.x;
    const dy = e.clientY - prevMousePos.current.y;
    sphereMeshRef.current.rotation.y += dx * 0.01;
    sphereMeshRef.current.rotation.x += dy * 0.01;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  return (
    <div className="relative w-full h-[420px] rounded-2xl overflow-hidden bg-gradient-to-b from-[#171410] to-[#0c0a08] border border-amber-900/30">
      {/* Blueprint Grid Overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(#b45309_1px,transparent_1px)] [background-size:24px_24px] opacity-15 pointer-events-none" />

      {/* 3D Canvas */}
      <div
        ref={containerRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="w-full h-full cursor-grab active:cursor-grabbing select-none"
      />

      {/* Top Banner Tag */}
      <div className="absolute top-4 left-4 pointer-events-none">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-amber-950/80 border border-amber-800/50 backdrop-blur-md">
          <Shield className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-xs font-serif font-bold text-amber-200 tracking-wider">
            INDIVISIBLE HARD SPHERE (1803)
          </span>
        </div>
      </div>

      {/* Bottom Controls */}
      <div className="absolute bottom-4 left-4 right-4 flex flex-wrap items-center justify-between gap-2 p-3 rounded-xl bg-[#130f0c]/90 border border-amber-900/40 backdrop-blur-md text-xs">
        {/* Element Selection */}
        <div className="flex items-center gap-1.5">
          {(['hydrogen', 'carbon', 'nitrogen', 'oxygen'] as const).map((type) => (
            <button
              key={type}
              onClick={() => setAtomType(type)}
              className={`px-2.5 py-1 rounded-lg font-serif capitalize transition-all ${
                atomType === type
                  ? 'bg-amber-700 text-white font-bold shadow-md shadow-amber-900/50'
                  : 'text-amber-300/70 hover:text-amber-100 hover:bg-amber-950/50'
              }`}
            >
              {type}
            </button>
          ))}
        </div>

        {/* Action Toggles */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowLattice(!showLattice)}
            className={`px-3 py-1 rounded-lg border font-serif text-[11px] transition-all ${
              showLattice
                ? 'bg-amber-900/70 border-amber-500 text-amber-200'
                : 'border-amber-900/50 text-amber-400 hover:border-amber-700'
            }`}
          >
            Compound Ratio
          </button>
          <button
            onClick={() => setElasticCollision(!elasticCollision)}
            className={`px-3 py-1 rounded-lg border font-serif text-[11px] transition-all ${
              elasticCollision
                ? 'bg-amber-900/70 border-amber-500 text-amber-200'
                : 'border-amber-900/50 text-amber-400 hover:border-amber-700'
            }`}
          >
            Elastic Collision
          </button>
        </div>
      </div>
    </div>
  );
};
