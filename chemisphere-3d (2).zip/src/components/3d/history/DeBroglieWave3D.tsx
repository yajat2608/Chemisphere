import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  Waves,
  Sparkles,
  Sliders,
  CheckCircle2,
  XCircle,
  Eye,
  RotateCcw,
  Layers,
  Atom,
  HelpCircle,
  Activity
} from 'lucide-react';

export const DeBroglieWave3D: React.FC = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const mainGroupRef = useRef<THREE.Group | null>(null);
  const electronMeshRef = useRef<THREE.Mesh | null>(null);
  const isDraggingRef = useRef(false);
  const prevMousePos = useRef({ x: 0, y: 0 });
  const frameIdRef = useRef<number>(0);

  // User Interactive State
  const [quantumN, setQuantumN] = useState<number>(3); // Standing wave harmonic n = 1..6
  const [amplitude, setAmplitude] = useState<number>(0.28);
  const [isConstructive, setIsConstructive] = useState<boolean>(true);
  const [showMultiShells, setShowMultiShells] = useState<boolean>(false);
  const [showElectronParticle, setShowElectronParticle] = useState<boolean>(true);
  const [showNodes, setShowNodes] = useState<boolean>(true);
  const [viewAngle, setViewAngle] = useState<'3d' | 'top'>('3d');

  // Physical Bohr radius scaling
  const baseRadius = 2.5;

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth || 600;
    const height = container.clientHeight || 420;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    if (viewAngle === 'top') {
      camera.position.set(0, 0, 7.8);
      camera.lookAt(0, 0, 0);
    } else {
      camera.position.set(0, -3.2, 7.2);
      camera.lookAt(0, 0, 0);
    }
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Studio Lighting
    const ambLight = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(ambLight);

    const cyanLight = new THREE.PointLight(0x38bdf8, 3.0, 30);
    cyanLight.position.set(5, 6, 8);
    scene.add(cyanLight);

    const amberLight = new THREE.PointLight(0xf59e0b, 2.0, 30);
    amberLight.position.set(-5, -6, 6);
    scene.add(amberLight);

    const mainGroup = new THREE.Group();
    if (viewAngle === '3d') {
      mainGroup.rotation.x = 0.45;
    }
    mainGroupRef.current = mainGroup;
    scene.add(mainGroup);

    // 1. Central Positive Nucleus
    const nucGeo = new THREE.SphereGeometry(0.32, 32, 32);
    const nucMat = new THREE.MeshStandardMaterial({
      color: 0xef4444,
      emissive: 0xdc2626,
      emissiveIntensity: 0.9,
      roughness: 0.2
    });
    const nuc = new THREE.Mesh(nucGeo, nucMat);
    mainGroup.add(nuc);

    // Subtle Nucleus Quantum Aura
    const auraGeo = new THREE.SphereGeometry(0.48, 16, 16);
    const auraMat = new THREE.MeshBasicMaterial({
      color: 0xef4444,
      transparent: true,
      opacity: 0.2,
      wireframe: true
    });
    const aura = new THREE.Mesh(auraGeo, auraMat);
    mainGroup.add(aura);

    // 2. Reference Circular Bohr Orbits (Dashed / Thin Lines)
    const activeShells = showMultiShells ? [1, 2, 3, 4] : [quantumN];
    const shellRadii = [1.2, 1.8, 2.5, 3.2];

    activeShells.forEach((nVal) => {
      const r_n = shellRadii[nVal - 1] || baseRadius;
      const refPts: THREE.Vector3[] = [];
      for (let i = 0; i <= 96; i++) {
        const a = (i / 96) * Math.PI * 2;
        refPts.push(new THREE.Vector3(Math.cos(a) * r_n, Math.sin(a) * r_n, 0));
      }
      const refLine = new THREE.Line(
        new THREE.BufferGeometry().setFromPoints(refPts),
        new THREE.LineBasicMaterial({
          color: nVal === quantumN ? 0x0284c7 : 0x334155,
          transparent: true,
          opacity: nVal === quantumN ? 0.6 : 0.25
        })
      );
      mainGroup.add(refLine);
    });

    // 3. Dynamic Wave Line & Glowing Wave Tube Mesh
    const segments = 360;
    const waveGeo = new THREE.BufferGeometry();
    const positions = new Float32Array((segments + 1) * 3);
    const colors = new Float32Array((segments + 1) * 3);

    waveGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    waveGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const waveMat = new THREE.LineBasicMaterial({
      vertexColors: true,
      linewidth: 3,
      transparent: true,
      opacity: 0.95
    });
    const waveLine = new THREE.Line(waveGeo, waveMat);
    mainGroup.add(waveLine);

    // Node Markers (spheres at nodal points where wave cross baseline)
    const nodeGroup = new THREE.Group();
    mainGroup.add(nodeGroup);

    const effectiveN = isConstructive ? quantumN : quantumN + 0.5;
    const nodeCount = Math.round(effectiveN * 2);

    if (showNodes && isConstructive) {
      const nodeSphereGeo = new THREE.SphereGeometry(0.06, 12, 12);
      const nodeSphereMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });

      for (let i = 0; i < nodeCount; i++) {
        const thetaNode = (i / nodeCount) * Math.PI * 2;
        const xN = Math.cos(thetaNode) * baseRadius;
        const yN = Math.sin(thetaNode) * baseRadius;
        const nodeMesh = new THREE.Mesh(nodeSphereGeo, nodeSphereMat);
        nodeMesh.position.set(xN, yN, 0);
        nodeGroup.add(nodeMesh);
      }
    }

    // 4. Electron Particle / Wave Packet
    const elecGeo = new THREE.SphereGeometry(0.14, 20, 20);
    const elecMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 1.2
    });
    const electronMesh = new THREE.Mesh(elecGeo, elecMat);
    electronMesh.visible = showElectronParticle;
    electronMeshRef.current = electronMesh;
    mainGroup.add(electronMesh);

    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    // Smooth Animation Loop
    let phase = 0;
    let electronTheta = 0;

    const animate = () => {
      phase += 0.035;
      electronTheta += 0.015;

      const posAttr = waveGeo.attributes.position as THREE.BufferAttribute;
      const colAttr = waveGeo.attributes.color as THREE.BufferAttribute;

      for (let i = 0; i <= segments; i++) {
        const theta = (i / segments) * Math.PI * 2;

        // de Broglie radial matter wave oscillation:
        // r(θ) = r_0 + A * sin(n * θ - phase)
        const waveOffset = Math.sin(effectiveN * theta - phase) * amplitude;
        const r = baseRadius + waveOffset;

        const x = Math.cos(theta) * r;
        const y = Math.sin(theta) * r;
        // Subtle out-of-plane undulation for depth
        const z = Math.cos(effectiveN * theta - phase) * (amplitude * 0.45);

        posAttr.setXYZ(i, x, y, z);

        // Dynamic Color: Constructive = Cyan/Amber crests, Destructive = Crimson
        if (isConstructive) {
          const intensity = 0.5 + 0.5 * Math.sin(effectiveN * theta - phase);
          colAttr.setXYZ(
            i,
            0.15 + intensity * 0.8,
            0.65 + intensity * 0.35,
            0.95 - intensity * 0.3
          );
        } else {
          // Destructive interference: red/magenta flashing indicating self-cancellation
          colAttr.setXYZ(i, 0.95, 0.2, 0.35);
        }
      }

      posAttr.needsUpdate = true;
      colAttr.needsUpdate = true;

      // Position electron particle along wave crest
      if (electronMeshRef.current && showElectronParticle) {
        const eOffset = Math.sin(effectiveN * electronTheta - phase) * amplitude;
        const eR = baseRadius + eOffset;
        const eX = Math.cos(electronTheta) * eR;
        const eY = Math.sin(electronTheta) * eR;
        const eZ = Math.cos(effectiveN * electronTheta - phase) * (amplitude * 0.45);
        electronMeshRef.current.position.set(eX, eY, eZ);
      }

      // Gentle continuous rotation
      if (mainGroupRef.current && !isDraggingRef.current && viewAngle === '3d') {
        mainGroupRef.current.rotation.z += 0.0015;
      }

      renderer.render(scene, camera);
      frameIdRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameIdRef.current);
      renderer.dispose();
    };
  }, [quantumN, amplitude, isConstructive, showMultiShells, showElectronParticle, showNodes, viewAngle]);

  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current || !mainGroupRef.current) return;
    const dx = e.clientX - prevMousePos.current.x;
    const dy = e.clientY - prevMousePos.current.y;
    mainGroupRef.current.rotation.z += dx * 0.008;
    mainGroupRef.current.rotation.x += dy * 0.008;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  // Calculated physical properties for display HUD
  const wavelengthFraction = isConstructive
    ? `2πr / ${quantumN}`
    : `2πr / ${quantumN + 0.5}`;
  const totalNodesCount = isConstructive ? quantumN * 2 : (quantumN + 0.5) * 2;

  return (
    <div className="relative w-full h-[450px] rounded-2xl overflow-hidden bg-gradient-to-b from-[#090d16] via-[#0d121f] to-[#080b12] border border-cyan-900/40 shadow-2xl font-sans">
      {/* Archival Wave Grid Background */}
      <div className="absolute inset-0 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:24px_24px] opacity-10 pointer-events-none" />

      {/* 3D WebGL Canvas */}
      <div
        ref={containerRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="w-full h-full cursor-grab active:cursor-grabbing select-none"
      />

      {/* Top Left Title HUD */}
      <div className="absolute top-3 left-4 pointer-events-none">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-cyan-950/80 border border-cyan-800/60 backdrop-blur-md shadow-lg">
          <Waves className="w-4 h-4 text-cyan-400 animate-pulse" />
          <div>
            <span className="text-xs font-serif font-bold text-cyan-200 tracking-wider block">
              DE BROGLIE MATTER WAVES & STANDING ORBITS (1924)
            </span>
            <span className="text-[10px] font-mono text-cyan-400/80 block">
              Wave-Particle Duality: λ = h / p • Quantization: nλ = 2πr
            </span>
          </div>
        </div>
      </div>

      {/* Top Right Interference State Badge */}
      <div className="absolute top-3 right-4 p-2.5 rounded-xl bg-[#0c1220]/90 border border-cyan-800/60 backdrop-blur-md text-xs font-mono shadow-lg">
        <div className="flex items-center gap-2">
          {isConstructive ? (
            <CheckCircle2 className="w-4 h-4 text-cyan-400" />
          ) : (
            <XCircle className="w-4 h-4 text-rose-400" />
          )}
          <span className="font-bold text-white">
            {isConstructive ? `Standing Wave: n = ${quantumN}` : `Destructive: n = ${quantumN}.5`}
          </span>
        </div>
        <div className="text-slate-400 text-[10px] mt-0.5">
          {isConstructive
            ? `Circumference = ${quantumN} complete wavelengths (2πr = ${quantumN}λ)`
            : 'Fractional wavelength causes phase shift & destructive cancellation!'}
        </div>
      </div>

      {/* Quick View Angle & Display Mode Toggles */}
      <div className="absolute top-20 right-4 flex flex-col gap-1.5 z-10 font-mono text-[11px]">
        <button
          onClick={() => setViewAngle(viewAngle === '3d' ? 'top' : '3d')}
          className="px-2.5 py-1 rounded-lg bg-black/60 border border-white/10 text-cyan-300 hover:bg-white/10 transition-all flex items-center gap-1.5"
          title="Toggle Camera View Angle"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>{viewAngle === '3d' ? 'Top-Down 2D' : 'Isometric 3D'}</span>
        </button>

        <button
          onClick={() => setShowElectronParticle(!showElectronParticle)}
          className={`px-2.5 py-1 rounded-lg border transition-all flex items-center gap-1.5 ${
            showElectronParticle
              ? 'bg-cyan-950/80 border-cyan-500 text-cyan-200'
              : 'bg-black/60 border-white/10 text-slate-400'
          }`}
          title="Show or hide the orbiting electron wave packet"
        >
          <Atom className="w-3.5 h-3.5" />
          <span>Particle Dot</span>
        </button>

        <button
          onClick={() => setShowNodes(!showNodes)}
          className={`px-2.5 py-1 rounded-lg border transition-all flex items-center gap-1.5 ${
            showNodes
              ? 'bg-amber-950/80 border-amber-500 text-amber-200'
              : 'bg-black/60 border-white/10 text-slate-400'
          }`}
          title="Highlight wave nodes where amplitude is zero"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>{totalNodesCount} Nodes</span>
        </button>
      </div>

      {/* Bottom Interactive Control Dashboard */}
      <div className="absolute bottom-3 inset-x-3 sm:inset-x-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-3 rounded-xl bg-[#090d16]/95 border border-cyan-900/50 backdrop-blur-md text-xs font-mono">
        {/* Quantized Harmonics (n = 1..6) */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-slate-400 text-[11px] font-sans font-bold mr-1">Harmonic n:</span>
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <button
              key={n}
              onClick={() => {
                setQuantumN(n);
                setIsConstructive(true);
              }}
              className={`px-3 py-1 rounded-lg font-bold transition-all ${
                quantumN === n && isConstructive
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-md shadow-cyan-500/40 scale-105'
                  : 'bg-white/5 border border-white/10 text-slate-300 hover:text-white hover:bg-white/10'
              }`}
            >
              n={n}
            </button>
          ))}
        </div>

        {/* Amplitude Slider & Destructive Simulation Toggle */}
        <div className="flex items-center gap-3">
          <div className="hidden md:flex items-center gap-2">
            <span className="text-[10px] text-slate-400">Wave Height:</span>
            <input
              type="range"
              min={0.1}
              max={0.55}
              step={0.02}
              value={amplitude}
              onChange={(e) => setAmplitude(parseFloat(e.target.value))}
              className="w-20 accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
          </div>

          <button
            onClick={() => setIsConstructive(!isConstructive)}
            className={`px-3 py-1.5 rounded-lg border font-sans font-bold text-xs transition-all flex items-center gap-1.5 ${
              !isConstructive
                ? 'bg-rose-950/90 border-rose-500 text-rose-200 shadow-md shadow-rose-950'
                : 'bg-white/5 border-cyan-800/60 text-slate-300 hover:text-cyan-200'
            }`}
          >
            <Activity className="w-3.5 h-3.5 text-rose-400" />
            <span>{isConstructive ? 'Simulate Destructive (n + ½)' : 'Restore Constructive (n)'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
