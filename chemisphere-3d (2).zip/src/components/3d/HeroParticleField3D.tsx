import React, { useEffect, useRef } from 'react';

export const HeroParticleField3D: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let animationId: number;
    let isLightMode = document.documentElement.classList.contains('light');

    // Observe theme changes
    const observer = new MutationObserver(() => {
      isLightMode = document.documentElement.classList.contains('light');
    });
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });

    let width = window.innerWidth;
    let height = window.innerHeight;
    let isMobile = width < 768;

    const setupDimensions = () => {
      if (!canvas) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = window.innerWidth;
      height = window.innerHeight;
      isMobile = width < 768;

      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      ctx.scale(dpr, dpr);
    };

    setupDimensions();

    const handleResize = () => {
      setupDimensions();
    };

    window.addEventListener('resize', handleResize);

    // Pointer interaction physics for fluid mobile/desktop dynamics
    const pointer = { x: -9999, y: -9999, active: false };
    const handlePointerMove = (e: MouseEvent | TouchEvent) => {
      const clientX = 'touches' in e ? e.touches[0]?.clientX : (e as MouseEvent).clientX;
      const clientY = 'touches' in e ? e.touches[0]?.clientY : (e as MouseEvent).clientY;
      if (clientX !== undefined && clientY !== undefined && canvas) {
        const rect = canvas.getBoundingClientRect();
        pointer.x = clientX - rect.left - width / 2;
        pointer.y = clientY - rect.top - height / 2;
        pointer.active = true;
      }
    };

    const handlePointerLeave = () => {
      pointer.active = false;
    };

    window.addEventListener('mousemove', handlePointerMove, { passive: true });
    window.addEventListener('touchmove', handlePointerMove, { passive: true });
    window.addEventListener('touchend', handlePointerLeave, { passive: true });
    window.addEventListener('mouseleave', handlePointerLeave, { passive: true });

    interface Particle {
      x: number;
      y: number;
      z: number;
      vx: number;
      vy: number;
      vz: number;
      radius: number;
      colorDark: string;
      colorLight: string;
      symbol: string;
    }

    const particleCount = isMobile ? 22 : 42;
    const elements = [
      { sym: 'H', dark: 'rgba(56, 189, 248, ', light: 'rgba(2, 132, 199, ' },
      { sym: 'C', dark: 'rgba(148, 163, 184, ', light: 'rgba(71, 85, 105, ' },
      { sym: 'N', dark: 'rgba(59, 130, 246, ', light: 'rgba(37, 99, 235, ' },
      { sym: 'O', dark: 'rgba(239, 68, 68, ', light: 'rgba(220, 38, 38, ' },
      { sym: 'P', dark: 'rgba(168, 85, 247, ', light: 'rgba(147, 51, 234, ' },
      { sym: 'Na', dark: 'rgba(245, 158, 11, ', light: 'rgba(217, 119, 6, ' }
    ];

    const particles: Particle[] = [];
    for (let i = 0; i < particleCount; i++) {
      const el = elements[Math.floor(Math.random() * elements.length)];
      particles.push({
        x: (Math.random() - 0.5) * width,
        y: (Math.random() - 0.5) * height,
        z: Math.random() * 380 + 40,
        vx: (Math.random() - 0.5) * (isMobile ? 0.3 : 0.45),
        vy: (Math.random() - 0.5) * (isMobile ? 0.3 : 0.45),
        vz: (Math.random() - 0.5) * 0.25,
        radius: Math.random() * 2.5 + 2,
        colorDark: el.dark,
        colorLight: el.light,
        symbol: el.sym
      });
    }

    const maxBondDist = isMobile ? 95 : 125;
    const fov = 340;

    let lastFrameTime = performance.now();

    const render = (now: number) => {
      const delta = Math.min((now - lastFrameTime) / 1000, 0.1);
      lastFrameTime = now;

      ctx.clearRect(0, 0, width, height);
      const cx = width / 2;
      const cy = height / 2;

      // Update positions with subtle spring physics toward pointer
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        if (pointer.active) {
          const dx = pointer.x - p.x;
          const dy = pointer.y - p.y;
          const pDist = Math.sqrt(dx * dx + dy * dy);
          if (pDist < 180 && pDist > 1) {
            const force = (1 - pDist / 180) * 0.4;
            p.vx += (dx / pDist) * force * delta * 20;
            p.vy += (dy / pDist) * force * delta * 20;
          }
        }

        // Friction damping
        p.vx *= 0.992;
        p.vy *= 0.992;

        p.x += p.vx * 60 * delta;
        p.y += p.vy * 60 * delta;
        p.z += p.vz * 60 * delta;

        const boundX = width / 2 + 30;
        const boundY = height / 2 + 30;

        if (p.x < -boundX) p.x = boundX;
        if (p.x > boundX) p.x = -boundX;
        if (p.y < -boundY) p.y = boundY;
        if (p.y > boundY) p.y = -boundY;
        if (p.z < 40) p.z = 420;
        if (p.z > 420) p.z = 40;
      }

      // Draw dynamic bonds
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const p1 = particles[i];
          const p2 = particles[j];

          const dx = p1.x - p2.x;
          const dy = p1.y - p2.y;
          const dz = p1.z - p2.z;
          const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

          if (dist < maxBondDist) {
            const scale1 = fov / (fov + p1.z);
            const x1 = cx + p1.x * scale1;
            const y1 = cy + p1.y * scale1;

            const scale2 = fov / (fov + p2.z);
            const x2 = cx + p2.x * scale2;
            const y2 = cy + p2.y * scale2;

            const alpha = (1 - dist / maxBondDist) * (isLightMode ? 0.25 : 0.22);
            ctx.beginPath();
            ctx.moveTo(x1, y1);
            ctx.lineTo(x2, y2);
            ctx.strokeStyle = isLightMode
              ? `rgba(14, 165, 233, ${alpha})`
              : `rgba(6, 182, 212, ${alpha})`;
            ctx.lineWidth = isLightMode ? 1.2 : 1;
            ctx.stroke();
          }
        }
      }

      // Draw particles & symbols
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        const scale = fov / (fov + p.z);
        const sx = cx + p.x * scale;
        const sy = cy + p.y * scale;
        const sr = p.radius * scale;
        const depthAlpha = Math.max(0.2, (420 - p.z) / 380);

        ctx.beginPath();
        ctx.arc(sx, sy, sr, 0, Math.PI * 2);
        const baseColor = isLightMode ? p.colorLight : p.colorDark;
        ctx.fillStyle = `${baseColor}${depthAlpha})`;
        ctx.fill();

        // Node symbol label for closer particles
        if (p.z < 220) {
          ctx.fillStyle = isLightMode
            ? `rgba(15, 23, 42, ${depthAlpha * 0.85})`
            : `rgba(255, 255, 255, ${depthAlpha * 0.8})`;
          ctx.font = `bold ${Math.round(9 * scale)}px 'JetBrains Mono', monospace`;
          ctx.fillText(p.symbol, sx + sr + 2, sy + 3);
        }
      }

      animationId = requestAnimationFrame(render);
    };

    animationId = requestAnimationFrame(render);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('touchmove', handlePointerMove);
      window.removeEventListener('touchend', handlePointerLeave);
      window.removeEventListener('mouseleave', handlePointerLeave);
      observer.disconnect();
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full pointer-events-none opacity-60 dark:opacity-40 z-0 will-change-transform"
    />
  );
};
