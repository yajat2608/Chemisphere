import React, { useEffect, useRef, useState } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  status: 'active' | 'passed' | 'deflected' | 'backscattered';
  trail: { x: number; y: number }[];
}

export const GoldFoilExperiment3D: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [beamEnergy, setBeamEnergy] = useState<number>(5.5); // MeV
  const [totalEmitted, setTotalEmitted] = useState<number>(0);
  const [straightCount, setStraightCount] = useState<number>(0);
  const [deflectedCount, setDeflectedCount] = useState<number>(0);
  const [backscatterCount, setBackscatterCount] = useState<number>(0);
  const [isRunning, setIsRunning] = useState<boolean>(true);

  const particlesRef = useRef<Particle[]>([]);
  const countsRef = useRef({ total: 0, straight: 0, deflected: 0, back: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || 700);
    let height = (canvas.height = canvas.parentElement?.clientHeight || 450);

    const handleResize = () => {
      if (!canvas || !canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = canvas.parentElement.clientHeight;
    };
    window.addEventListener('resize', handleResize);

    // Gold Nuclei Array (Dense positive targets Z = 79)
    const goldNuclei = [
      { x: width * 0.5, y: height * 0.3, r: 9 },
      { x: width * 0.5, y: height * 0.5, r: 9 },
      { x: width * 0.5, y: height * 0.7, r: 9 },
      { x: width * 0.53, y: height * 0.4, r: 9 },
      { x: width * 0.53, y: height * 0.6, r: 9 }
    ];

    let spawnTimer = 0;

    const render = () => {
      ctx.fillStyle = '#090d16';
      ctx.fillRect(0, 0, width, height);

      // Draw Alpha Source Box (Lead Collimator)
      ctx.fillStyle = '#334155';
      ctx.fillRect(20, height / 2 - 35, 50, 70);
      ctx.strokeStyle = '#06b6d4';
      ctx.strokeRect(20, height / 2 - 35, 50, 70);
      ctx.fillStyle = '#06b6d4';
      ctx.font = '10px JetBrains Mono';
      ctx.fillText('α-GUN', 27, height / 2 + 4);

      // Draw Gold Foil (Thin central sheet)
      ctx.fillStyle = 'rgba(234, 179, 8, 0.15)';
      ctx.fillRect(width * 0.48, 20, width * 0.07, height - 40);
      ctx.strokeStyle = '#eab308';
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      ctx.strokeRect(width * 0.48, 20, width * 0.07, height - 40);
      ctx.setLineDash([]);

      ctx.fillStyle = '#eab308';
      ctx.fillText('Gold Foil (Au, Z=79)', width * 0.46, 16);

      // Draw Gold Nuclei with Coulomb field aura
      goldNuclei.forEach((n) => {
        const grad = ctx.createRadialGradient(n.x, n.y, 2, n.x, n.y, 45);
        grad.addColorStop(0, 'rgba(234, 179, 8, 0.8)');
        grad.addColorStop(0.3, 'rgba(234, 179, 8, 0.2)');
        grad.addColorStop(1, 'rgba(234, 179, 8, 0)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(n.x, n.y, 45, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#000';
        ctx.font = 'bold 9px sans-serif';
        ctx.fillText('+79', n.x - 9, n.y + 3);
      });

      // Draw Circular Fluorescent Zinc Sulfide (ZnS) Screen Detector
      ctx.beginPath();
      ctx.arc(width * 0.5, height / 2, width * 0.44, -Math.PI * 0.75, Math.PI * 0.75);
      ctx.strokeStyle = 'rgba(34, 197, 94, 0.5)';
      ctx.lineWidth = 4;
      ctx.stroke();

      // Spawn Alpha Particles
      if (isRunning) {
        spawnTimer++;
        if (spawnTimer % 2 === 0) {
          const speed = (beamEnergy / 5.5) * 5;
          const yOffset = (Math.random() - 0.5) * (height * 0.7);
          particlesRef.current.push({
            x: 70,
            y: height / 2 + yOffset,
            vx: speed,
            vy: 0,
            status: 'active',
            trail: []
          });
          countsRef.current.total++;
        }
      }

      // Update & Draw Alpha Particles
      const particles = particlesRef.current;
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];

        // Record trail
        p.trail.push({ x: p.x, y: p.y });
        if (p.trail.length > 8) p.trail.shift();

        // Calculate Coulomb Repulsion: F = k * (q1 * q2) / r²
        goldNuclei.forEach((n) => {
          const dx = p.x - n.x;
          const dy = p.y - n.y;
          const distSq = dx * dx + dy * dy;
          const dist = Math.sqrt(distSq);

          if (dist < 80) {
            // Strong inverse square repulsive force
            const force = (800 / (distSq + 200)) * (5.5 / beamEnergy);
            p.vx += (dx / dist) * force;
            p.vy += (dy / dist) * force;
          }
        });

        p.x += p.vx;
        p.y += p.vy;

        // Draw particle trail
        if (p.trail.length > 1) {
          ctx.beginPath();
          ctx.moveTo(p.trail[0].x, p.trail[0].y);
          for (let t = 1; t < p.trail.length; t++) {
            ctx.lineTo(p.trail[t].x, p.trail[t].y);
          }
          ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
          ctx.lineWidth = 1.5;
          ctx.stroke();
        }

        // Draw alpha particle (He²⁺)
        ctx.fillStyle = '#38bdf8';
        ctx.beginPath();
        ctx.arc(p.x, p.y, 2.5, 0, Math.PI * 2);
        ctx.fill();

        // Screen collision or boundary check
        if (p.x > width * 0.92 || p.x < 10 || p.y < 10 || p.y > height - 10) {
          if (p.status === 'active') {
            const angleDeg = Math.abs((Math.atan2(p.vy, p.vx) * 180) / Math.PI);
            if (p.vx < 0) {
              p.status = 'backscattered';
              countsRef.current.back++;
            } else if (angleDeg > 15) {
              p.status = 'deflected';
              countsRef.current.deflected++;
            } else {
              p.status = 'passed';
              countsRef.current.straight++;
            }

            // Flash on ZnS screen
            ctx.fillStyle = 'rgba(34, 197, 94, 0.9)';
            ctx.beginPath();
            ctx.arc(p.x, p.y, 6, 0, Math.PI * 2);
            ctx.fill();
          }
          particles.splice(i, 1);
        }
      }

      animationId = requestAnimationFrame(render);
    };

    render();

    // Update state display periodically
    const stateInterval = setInterval(() => {
      setTotalEmitted(countsRef.current.total);
      setStraightCount(countsRef.current.straight);
      setDeflectedCount(countsRef.current.deflected);
      setBackscatterCount(countsRef.current.back);
    }, 200);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationId);
      clearInterval(stateInterval);
    };
  }, [beamEnergy, isRunning]);

  const handleReset = () => {
    particlesRef.current = [];
    countsRef.current = { total: 0, straight: 0, deflected: 0, back: 0 };
    setTotalEmitted(0);
    setStraightCount(0);
    setDeflectedCount(0);
    setBackscatterCount(0);
  };

  return (
    <div className="flex flex-col gap-4 w-full">
      <div className="relative w-full h-[380px] rounded-xl overflow-hidden border border-slate-800 bg-[#090d16]">
        <canvas ref={canvasRef} className="w-full h-full" />
      </div>

      {/* Interactive Controls & Real-Time Counters */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800 flex flex-col justify-between">
          <div className="text-xs text-slate-400 font-mono">TOTAL ALPHAS (α)</div>
          <div className="text-xl font-bold text-white font-mono">{totalEmitted.toLocaleString()}</div>
          <div className="text-[11px] text-slate-500">He²⁺ ions fired</div>
        </div>

        <div className="p-3 rounded-lg bg-slate-900/80 border border-emerald-900/40 flex flex-col justify-between">
          <div className="text-xs text-emerald-400 font-mono">UNDEFLECTED (&gt;99%)</div>
          <div className="text-xl font-bold text-emerald-400 font-mono">{straightCount.toLocaleString()}</div>
          <div className="text-[11px] text-slate-400">Traversed empty atomic space</div>
        </div>

        <div className="p-3 rounded-lg bg-slate-900/80 border border-cyan-900/40 flex flex-col justify-between">
          <div className="text-xs text-cyan-400 font-mono">DEFLECTED (&gt;15°)</div>
          <div className="text-xl font-bold text-cyan-400 font-mono">{deflectedCount.toLocaleString()}</div>
          <div className="text-[11px] text-slate-400">Repelled by dense +79 charge</div>
        </div>

        <div className="p-3 rounded-lg bg-slate-900/80 border border-amber-900/40 flex flex-col justify-between">
          <div className="text-xs text-amber-400 font-mono">BACKSCATTERED (1 in 8,000)</div>
          <div className="text-xl font-bold text-amber-400 font-mono">{backscatterCount.toLocaleString()}</div>
          <div className="text-[11px] text-slate-400">Direct nuclear head-on rebound</div>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-4 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
        <div className="flex items-center gap-3">
          <label className="text-xs font-mono text-slate-300">Beam Kinetic Energy (MeV):</label>
          <input
            type="range"
            min="2.0"
            max="10.0"
            step="0.5"
            value={beamEnergy}
            onChange={(e) => setBeamEnergy(parseFloat(e.target.value))}
            className="w-32 accent-cyan-400 cursor-pointer"
          />
          <span className="text-xs font-mono text-cyan-400">{beamEnergy} MeV</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsRunning(!isRunning)}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all ${
              isRunning ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
            }`}
          >
            {isRunning ? 'Pause Beam' : 'Resume Beam'}
          </button>
          <button
            onClick={handleReset}
            className="px-3 py-1.5 rounded-lg text-xs font-mono bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-all"
          >
            Reset Counters
          </button>
        </div>
      </div>
    </div>
  );
};
