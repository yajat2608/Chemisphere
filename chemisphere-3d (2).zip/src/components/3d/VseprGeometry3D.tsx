import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

export interface VseprShapeInfo {
  name: string;
  electronGeometry: string;
  molecularGeometry: string;
  bondAngle: string;
  hybridization: string;
  bondingPairs: number;
  lonePairs: number;
  stericNumber: number;
  example: string;
  description: string;
  positions: { x: number; y: number; z: number; isLonePair?: boolean }[];
}

export const VSEPR_SHAPES: Record<string, VseprShapeInfo> = {
  linear: {
    name: 'Linear (AX₂)',
    electronGeometry: 'Linear',
    molecularGeometry: 'Linear',
    bondAngle: '180°',
    hybridization: 'sp',
    bondingPairs: 2,
    lonePairs: 0,
    stericNumber: 2,
    example: 'BeCl₂, CO₂, HCN',
    description: 'Two bonding pairs arranged on opposite sides of central atom to minimize repulsion.',
    positions: [
      { x: 0, y: 1.8, z: 0 },
      { x: 0, y: -1.8, z: 0 }
    ]
  },
  bent_sn3: {
    name: 'Bent (AX₂E₁)',
    electronGeometry: 'Trigonal Planar',
    molecularGeometry: 'Bent (V-shaped)',
    bondAngle: '< 120° (~119°)',
    hybridization: 'sp²',
    bondingPairs: 2,
    lonePairs: 1,
    stericNumber: 3,
    example: 'SO₂, O₃, NO₂⁻',
    description: 'One lone pair repels the two bonding pairs, compressing the angle below 120°.',
    positions: [
      { x: 1.5, y: -0.9, z: 0 },
      { x: -1.5, y: -0.9, z: 0 },
      { x: 0, y: 1.8, z: 0, isLonePair: true }
    ]
  },
  trigonal_planar: {
    name: 'Trigonal Planar (AX₃)',
    electronGeometry: 'Trigonal Planar',
    molecularGeometry: 'Trigonal Planar',
    bondAngle: '120°',
    hybridization: 'sp²',
    bondingPairs: 3,
    lonePairs: 0,
    stericNumber: 3,
    example: 'BF₃, AlCl₃, SO₃',
    description: 'Three electron domains symmetrically oriented in a single plane at 120°.',
    positions: [
      { x: 0, y: 1.8, z: 0 },
      { x: 1.56, y: -0.9, z: 0 },
      { x: -1.56, y: -0.9, z: 0 }
    ]
  },
  tetrahedral: {
    name: 'Tetrahedral (AX₄)',
    electronGeometry: 'Tetrahedral',
    molecularGeometry: 'Tetrahedral',
    bondAngle: '109.5°',
    hybridization: 'sp³',
    bondingPairs: 4,
    lonePairs: 0,
    stericNumber: 4,
    example: 'CH₄, SiCl₄, NH₄⁺, SO₄²⁻',
    description: 'Four bonding domains directed toward the four vertices of a regular tetrahedron.',
    positions: [
      { x: 0, y: 1.8, z: 0 },
      { x: 1.7, y: -0.6, z: 0 },
      { x: -0.85, y: -0.6, z: 1.47 },
      { x: -0.85, y: -0.6, z: -1.47 }
    ]
  },
  trigonal_pyramidal: {
    name: 'Trigonal Pyramidal (AX₃E₁)',
    electronGeometry: 'Tetrahedral',
    molecularGeometry: 'Trigonal Pyramidal',
    bondAngle: '< 109.5° (~107.8° in NH₃)',
    hybridization: 'sp³',
    bondingPairs: 3,
    lonePairs: 1,
    stericNumber: 4,
    example: 'NH₃, PCl₃, H₃O⁺',
    description: 'One apex lone pair strongly compresses the three basal bonds downward.',
    positions: [
      { x: 1.7, y: -0.6, z: 0 },
      { x: -0.85, y: -0.6, z: 1.47 },
      { x: -0.85, y: -0.6, z: -1.47 },
      { x: 0, y: 1.8, z: 0, isLonePair: true }
    ]
  },
  bent_sn4: {
    name: 'Bent (AX₂E₂)',
    electronGeometry: 'Tetrahedral',
    molecularGeometry: 'Bent (V-shaped)',
    bondAngle: '<< 109.5° (104.5° in H₂O)',
    hybridization: 'sp³',
    bondingPairs: 2,
    lonePairs: 2,
    stericNumber: 4,
    example: 'H₂O, H₂S, OF₂',
    description: 'Two repulsive lone pairs compress the bond angle significantly down to 104.5°.',
    positions: [
      { x: 1.4, y: -0.9, z: 0 },
      { x: -1.4, y: -0.9, z: 0 },
      { x: 0, y: 1.3, z: 1.3, isLonePair: true },
      { x: 0, y: 1.3, z: -1.3, isLonePair: true }
    ]
  },
  trigonal_bipyramidal: {
    name: 'Trigonal Bipyramidal (AX₅)',
    electronGeometry: 'Trigonal Bipyramidal',
    molecularGeometry: 'Trigonal Bipyramidal',
    bondAngle: '90° (axial-eq), 120° (eq-eq)',
    hybridization: 'sp³d',
    bondingPairs: 5,
    lonePairs: 0,
    stericNumber: 5,
    example: 'PCl₅, PF₅',
    description: 'Two axial bonds perpendicular to an equatorial trigonal planar ring of three bonds.',
    positions: [
      { x: 0, y: 2.0, z: 0 },
      { x: 0, y: -2.0, z: 0 },
      { x: 1.73, y: 0, z: 0 },
      { x: -0.86, y: 0, z: 1.5 },
      { x: -0.86, y: 0, z: -1.5 }
    ]
  },
  seesaw: {
    name: 'Seesaw (AX₄E₁)',
    electronGeometry: 'Trigonal Bipyramidal',
    molecularGeometry: 'Seesaw',
    bondAngle: '< 90° & < 120°',
    hybridization: 'sp³d',
    bondingPairs: 4,
    lonePairs: 1,
    stericNumber: 5,
    example: 'SF₄, TeCl₄',
    description: 'Lone pair occupies the equatorial position to minimize 90° lone-pair repulsions.',
    positions: [
      { x: 0, y: 1.9, z: 0 },
      { x: 0, y: -1.9, z: 0 },
      { x: -0.86, y: 0, z: 1.5 },
      { x: -0.86, y: 0, z: -1.5 },
      { x: 1.73, y: 0, z: 0, isLonePair: true }
    ]
  },
  t_shaped: {
    name: 'T-Shaped (AX₃E₂)',
    electronGeometry: 'Trigonal Bipyramidal',
    molecularGeometry: 'T-Shaped',
    bondAngle: '< 90° (~87.5° in ClF₃)',
    hybridization: 'sp³d',
    bondingPairs: 3,
    lonePairs: 2,
    stericNumber: 5,
    example: 'ClF₃, BrF₃, ICl₃',
    description: 'Two equatorial lone pairs compress the three bonds into a distinctive T geometry.',
    positions: [
      { x: 0, y: 1.9, z: 0 },
      { x: 0, y: -1.9, z: 0 },
      { x: -1.73, y: 0, z: 0 },
      { x: 1.2, y: 0, z: 1.2, isLonePair: true },
      { x: 1.2, y: 0, z: -1.2, isLonePair: true }
    ]
  },
  octahedral: {
    name: 'Octahedral (AX₆)',
    electronGeometry: 'Octahedral',
    molecularGeometry: 'Octahedral',
    bondAngle: '90° & 180°',
    hybridization: 'sp³d²',
    bondingPairs: 6,
    lonePairs: 0,
    stericNumber: 6,
    example: 'SF₆, [Fe(CN)₆]³⁻, [Co(NH₃)₆]³⁺',
    description: 'Six ligands arranged with perfect 90° octahedral symmetry around the central atom.',
    positions: [
      { x: 0, y: 1.9, z: 0 },
      { x: 0, y: -1.9, z: 0 },
      { x: 1.9, y: 0, z: 0 },
      { x: -1.9, y: 0, z: 0 },
      { x: 0, y: 0, z: 1.9 },
      { x: 0, y: 0, z: -1.9 }
    ]
  },
  square_planar: {
    name: 'Square Planar (AX₄E₂)',
    electronGeometry: 'Octahedral',
    molecularGeometry: 'Square Planar',
    bondAngle: '90° & 180°',
    hybridization: 'sp³d²',
    bondingPairs: 4,
    lonePairs: 2,
    stericNumber: 6,
    example: 'XeF₄, [PtCl₄]²⁻, Cisplatin',
    description: 'Two lone pairs occupy opposite axial positions, leaving four ligands in a planar square.',
    positions: [
      { x: 1.8, y: 0, z: 0 },
      { x: -1.8, y: 0, z: 0 },
      { x: 0, y: 0, z: 1.8 },
      { x: 0, y: 0, z: -1.8 },
      { x: 0, y: 1.8, z: 0, isLonePair: true },
      { x: 0, y: -1.8, z: 0, isLonePair: true }
    ]
  }
};

interface VseprGeometry3DProps {
  shapeKey: string;
  showLonePairs: boolean;
  autoRotate: boolean;
}

export const VseprGeometry3D: React.FC<VseprGeometry3DProps> = ({
  shapeKey,
  showLonePairs,
  autoRotate
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const groupRef = useRef<THREE.Group | null>(null);
  const isDraggingRef = useRef(false);
  const prevMousePos = useRef({ x: 0, y: 0 });
  const frameIdRef = useRef<number>(0);

  const shape = VSEPR_SHAPES[shapeKey] || VSEPR_SHAPES.tetrahedral;

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth || 500;
    const height = container.clientHeight || 380;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(4, 3, 5);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const ambLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambLight);

    const dirLight = new THREE.DirectionalLight(0x38bdf8, 1.4);
    dirLight.position.set(6, 10, 8);
    scene.add(dirLight);

    const group = new THREE.Group();
    groupRef.current = group;
    scene.add(group);

    const handleResize = () => {
      if (!container || !renderer) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    const animate = () => {
      if (groupRef.current && autoRotate && !isDraggingRef.current) {
        groupRef.current.rotation.y += 0.008;
        groupRef.current.rotation.x += 0.003;
      }
      renderer.render(scene, camera);
      frameIdRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameIdRef.current);
      renderer.dispose();
    };
  }, []);

  useEffect(() => {
    const group = groupRef.current;
    if (!group) return;

    while (group.children.length > 0) {
      const obj = group.children[0] as THREE.Mesh;
      if (obj.geometry) obj.geometry.dispose();
      group.remove(obj);
    }

    // Helper to create high-visibility bold typography sprite
    const createVseprLabel = (text: string, subText: string, color: string, bgColor: string, borderColor: string) => {
      const canvas = document.createElement('canvas');
      canvas.width = 512;
      canvas.height = 256;
      const ctx = canvas.getContext('2d');
      if (!ctx) return null;

      ctx.clearRect(0, 0, 512, 256);
      const cx = 256;
      const cy = 128;
      const rw = 300;
      const rh = 130;

      ctx.shadowColor = 'rgba(0, 0, 0, 0.85)';
      ctx.shadowBlur = 20;
      ctx.shadowOffsetY = 6;

      ctx.fillStyle = bgColor;
      ctx.strokeStyle = borderColor;
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.roundRect(cx - rw / 2, cy - rh / 2, rw, rh, 36);
      ctx.fill();
      ctx.stroke();

      ctx.shadowColor = 'transparent';
      ctx.fillStyle = color;
      ctx.font = '900 72px "Plus Jakarta Sans", "Outfit", -apple-system, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(text, cx - (subText ? 36 : 0), cy);

      if (subText) {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
        ctx.font = '700 36px "Plus Jakarta Sans", "Outfit", -apple-system, sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(subText, cx + 28, cy);
      }

      const texture = new THREE.CanvasTexture(canvas);
      texture.minFilter = THREE.LinearFilter;
      texture.magFilter = THREE.LinearFilter;
      const spriteMat = new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false, opacity: 0.98 });
      const sprite = new THREE.Sprite(spriteMat);
      sprite.scale.set(1.25, 0.62, 1);
      return sprite;
    };

    // Central Atom (A)
    const centerGeo = new THREE.SphereGeometry(0.5, 32, 32);
    const centerMat = new THREE.MeshStandardMaterial({
      color: 0x6366f1,
      roughness: 0.3,
      metalness: 0.2
    });
    const centerMesh = new THREE.Mesh(centerGeo, centerMat);
    group.add(centerMesh);

    const centerLabel = createVseprLabel('A', 'Core', '#ffffff', 'rgba(15, 23, 42, 0.88)', '#6366f1');
    if (centerLabel) {
      centerLabel.position.set(0, 0.75, 0);
      group.add(centerLabel);
    }

    let ligandIdx = 1;
    let lonePairIdx = 1;

    // Terminal atoms & Lone pairs
    shape.positions.forEach((pos) => {
      const p = new THREE.Vector3(pos.x, pos.y, pos.z);
      const dist = p.length();
      const dir = p.clone().normalize();

      if (pos.isLonePair) {
        if (!showLonePairs) return;

        // Lone pair teardrop balloon
        const loneGeo = new THREE.SphereGeometry(0.45, 24, 24);
        loneGeo.scale(0.8, 1.6, 0.8);
        const loneMat = new THREE.MeshPhysicalMaterial({
          color: 0xf59e0b,
          emissive: 0xb45309,
          emissiveIntensity: 0.5,
          transmission: 0.7,
          transparent: true,
          opacity: 0.7,
          roughness: 0.1
        });
        const loneMesh = new THREE.Mesh(loneGeo, loneMat);
        loneMesh.position.copy(p.clone().multiplyScalar(0.7));
        loneMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
        group.add(loneMesh);

        // Two small electron dots inside balloon
        const dotGeo = new THREE.SphereGeometry(0.08, 12, 12);
        const dotMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

        const dot1 = new THREE.Mesh(dotGeo, dotMat);
        const dot2 = new THREE.Mesh(dotGeo, dotMat);
        dot1.position.copy(p.clone().multiplyScalar(0.85)).add(new THREE.Vector3(0.12, 0, 0));
        dot2.position.copy(p.clone().multiplyScalar(0.85)).add(new THREE.Vector3(-0.12, 0, 0));
        group.add(dot1);
        group.add(dot2);

        const lpLabel = createVseprLabel(`:E${lonePairIdx}`, 'Pair', '#f59e0b', 'rgba(15, 23, 42, 0.88)', '#f59e0b');
        if (lpLabel) {
          lpLabel.position.copy(p.clone().multiplyScalar(1.2));
          group.add(lpLabel);
        }
        lonePairIdx++;
      } else {
        // Bonding ligand sphere (X)
        const ligandGeo = new THREE.SphereGeometry(0.38, 28, 28);
        const ligandMat = new THREE.MeshStandardMaterial({
          color: 0x06b6d4,
          roughness: 0.3,
          metalness: 0.2
        });
        const ligandMesh = new THREE.Mesh(ligandGeo, ligandMat);
        ligandMesh.position.copy(p);
        group.add(ligandMesh);

        // Bond cylinder
        const bondGeo = new THREE.CylinderGeometry(0.08, 0.08, dist, 16);
        const bondMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.4 });
        const bondMesh = new THREE.Mesh(bondGeo, bondMat);
        bondMesh.position.copy(p.clone().multiplyScalar(0.5));
        bondMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
        group.add(bondMesh);

        const ligLabel = createVseprLabel(`X${ligandIdx}`, 'Bond', '#38bdf8', 'rgba(15, 23, 42, 0.88)', '#06b6d4');
        if (ligLabel) {
          ligLabel.position.copy(p.clone().add(new THREE.Vector3(0, 0.45, 0)));
          group.add(ligLabel);
        }
        ligandIdx++;
      }
    });
  }, [shape, showLonePairs]);

  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current || !groupRef.current) return;
    const dx = e.clientX - prevMousePos.current.x;
    const dy = e.clientY - prevMousePos.current.y;
    groupRef.current.rotation.y += dx * 0.01;
    groupRef.current.rotation.x += dy * 0.01;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  return (
    <div
      ref={containerRef}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      className="w-full h-full min-h-[350px] relative cursor-grab active:cursor-grabbing select-none rounded-xl overflow-hidden"
    />
  );
};
