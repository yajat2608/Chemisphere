import React, { useEffect, useRef, useState } from 'react';
import { LatexRenderer } from '../common/LatexRenderer';

interface SpectralTransition {
  nInitial: number;
  nFinal: number;
  deltaE: number; // in eV
  wavelength: number; // in nm
  series: string;
  region: string;
  color: string;
}

export const BohrAtom3D: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [currentN, setCurrentN] = useState<number>(1);
  const [targetN, setTargetN] = useState<number>(3);
  const [lastTransition, setLastTransition] = useState<SpectralTransition | null>(null);
  const [isExcited, setIsExcited] = useState<boolean>(false);

  const electronAngleRef = useRef<number>(0);
  const photonPulseRef = useRef<{ active: boolean; x: number; y: number; r: number; color: string; type: 'emission' | 'absorption' }>({
    active: false,
    x: 0,
    y: 0,
    r: 0,
    color: '#06b6d4',
    type: 'absorption'
  });

  const shells = [
    { n: 1, name: 'K Shell (n=1)', energy: -13.6, radiusPx: 40 },
    { n: 2, name: 'L Shell (n=2)', energy: -3.4, radiusPx: 75 },
    { n: 3, name: 'M Shell (n=3)', energy: -1.51, radiusPx: 115 },
    { n: 4, name: 'N Shell (n=4)', energy: -0.85, radiusPx: 155 },
    { n: 5, name: 'O Shell (n=5)', energy: -0.54, radiusPx: 195 },
    { n: 6, name: 'P Shell (n=6)', energy: -0.38, radiusPx: 235 }
  ];

  const calculateTransition = (n1: number, n2: number): SpectralTransition => {
    const lower = Math.min(n1, n2);
    const upper = Math.max(n1, n2);

    const E_lower = -13.6 / (lower * lower);
    const E_upper = -13.6 / (upper * upper);
    const deltaE = Math.abs(E_upper - E_lower);

    // Rydberg formula: 1/lambda = R_H * (1/n1^2 - 1/n2^2), where R_H = 1.097373e7 m^-1
    const invLambda = 1.097373e7 * (1 / (lower * lower) - 1 / (upper * upper));
    const lambdaMeters = 1 / invLambda;
    const wavelengthNm = lambdaMeters * 1e9;

    let series = 'Unknown';
    let region = 'Ultraviolet';
    let color = '#a855f7';

    if (lower === 1) {
      series = 'Lyman Series';
      region = 'Ultraviolet (UV)';
      color = '#c084fc';
    } else if (lower === 2) {
      series = 'Balmer Series';
      region = 'Visible Spectrum';
      if (upper === 3) color = '#ef4444'; // H-alpha 656 nm (Red)
      else if (upper === 4) color = '#06b6d4'; // H-beta 486 nm (Cyan)
      else if (upper === 5) color = '#3b82f6'; // H-gamma 434 nm (Blue)
      else color = '#8b5cf6'; // H-delta 410 nm (Violet)
    } else if (lower === 3) {
      series = 'Paschen Series';
      region = 'Near Infrared (IR)';
      color = '#f97316';
    } else if (lower === 4) {
      series = 'Brackett Series';
      region = 'Infrared (IR)';
      color = '#e11d48';
    } else {
      series = 'Pfund Series';
      region = 'Far Infrared (IR)';
      color = '#be123c';
    }

    return {
      nInitial: n1,
      nFinal: n2,
      deltaE: parseFloat(deltaE.toFixed(3)),
      wavelength: parseFloat(wavelengthNm.toFixed(1)),
      series,
      region,
      color
    };
  };

  const triggerQuantumJump = (destN: number) => {
    if (destN === currentN) return;
    const trans = calculateTransition(currentN, destN);
    setLastTransition(trans);

    const isEmission = destN < currentN;
    photonPulseRef.current = {
      active: true,
      x: 0,
      y: 0,
      r: isEmission ? 0 : 250,
      color: trans.color,
      type: isEmission ? 'emission' : 'absorption'
    };

    setCurrentN(destN);
    setIsExcited(destN > 1);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || 600);
    let height = (canvas.height = canvas.parentElement?.clientHeight || 450);

    const handleResize = () => {
      if (!canvas || !canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = canvas.parentElement.clientHeight;
    };
    window.addEventListener('resize', handleResize);

    const render = () => {
      ctx.fillStyle = '#090d16';
      ctx.fillRect(0, 0, width, height);

      const cx = width / 2;
      const cy = height / 2;

      // Draw Nucleus (+1e Proton)
      const gradNuc = ctx.createRadialGradient(cx, cy, 2, cx, cy, 20);
      gradNuc.addColorStop(0, 'rgba(239, 68, 68, 1)');
      gradNuc.addColorStop(0.5, 'rgba(239, 68, 68, 0.4)');
      gradNuc.addColorStop(1, 'rgba(239, 68, 68, 0)');
      ctx.fillStyle = gradNuc;
      ctx.beginPath();
      ctx.arc(cx, cy, 20, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#f87171';
      ctx.beginPath();
      ctx.arc(cx, cy, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 9px monospace';
      ctx.fillText('+1', cx - 6, cy + 3);

      // Draw Quantized Shell Orbits
      shells.forEach((shell) => {
        const isCurrent = shell.n === currentN;

        ctx.beginPath();
        ctx.arc(cx, cy, shell.radiusPx, 0, Math.PI * 2);
        ctx.strokeStyle = isCurrent ? '#06b6d4' : 'rgba(148, 163, 184, 0.2)';
        ctx.lineWidth = isCurrent ? 2 : 1;
        ctx.setLineDash(isCurrent ? [] : [3, 4]);
        ctx.stroke();
        ctx.setLineDash([]);

        // Shell Label
        ctx.fillStyle = isCurrent ? '#38bdf8' : 'rgba(148, 163, 184, 0.5)';
        ctx.font = '9px JetBrains Mono';
        ctx.fillText(`n=${shell.n} (${shell.energy} eV)`, cx + shell.radiusPx - 25, cy - 4);
      });

      // Animate Orbiting Electron
      const currentShell = shells.find((s) => s.n === currentN) || shells[0];
      electronAngleRef.current += 0.02 * (3 / Math.sqrt(currentN));
      const ex = cx + Math.cos(electronAngleRef.current) * currentShell.radiusPx;
      const ey = cy + Math.sin(electronAngleRef.current) * currentShell.radiusPx;

      // Electron Glow
      const gradElec = ctx.createRadialGradient(ex, ey, 1, ex, ey, 14);
      gradElec.addColorStop(0, 'rgba(56, 189, 248, 1)');
      gradElec.addColorStop(0.5, 'rgba(56, 189, 248, 0.4)');
      gradElec.addColorStop(1, 'rgba(56, 189, 248, 0)');
      ctx.fillStyle = gradElec;
      ctx.beginPath();
      ctx.arc(ex, ey, 14, 0, Math.PI * 2);
      ctx.fill();

      // Electron Dot
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(ex, ey, 4.5, 0, Math.PI * 2);
      ctx.fill();

      // Animate Photon Pulse
      const pulse = photonPulseRef.current;
      if (pulse.active) {
        if (pulse.type === 'emission') {
          pulse.r += 3.5;
          ctx.beginPath();
          ctx.arc(cx, cy, pulse.r, 0, Math.PI * 2);
          ctx.strokeStyle = pulse.color;
          ctx.lineWidth = 2;
          ctx.stroke();

          // Sinusoidal wavy photon trail
          ctx.fillStyle = pulse.color;
          ctx.font = '11px JetBrains Mono';
          ctx.fillText(`hν (λ = ${lastTransition?.wavelength} nm)`, cx + pulse.r * 0.7, cy - pulse.r * 0.7);

          if (pulse.r > 260) pulse.active = false;
        } else {
          pulse.r -= 3.5;
          ctx.beginPath();
          ctx.arc(cx, cy, Math.max(0, pulse.r), 0, Math.PI * 2);
          ctx.strokeStyle = pulse.color;
          ctx.lineWidth = 2;
          ctx.stroke();
          if (pulse.r <= currentShell.radiusPx) pulse.active = false;
        }
      }

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationId);
    };
  }, [currentN, lastTransition]);

  return (
    <div className="flex flex-col gap-4 w-full">
      <div className="relative w-full h-[400px] rounded-xl overflow-hidden border border-slate-800 bg-[#090d16]">
        <canvas ref={canvasRef} className="w-full h-full" />
      </div>

      {/* Interactive Quantum State Selector */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-2">
        {shells.map((shell) => (
          <button
            key={shell.n}
            onClick={() => triggerQuantumJump(shell.n)}
            className={`p-2.5 rounded-lg border text-left transition-all font-mono text-xs ${
              currentN === shell.n
                ? 'bg-cyan-950/60 border-cyan-400 text-cyan-200 shadow-md shadow-cyan-900/30'
                : 'bg-slate-900/50 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white'
            }`}
          >
            <div className="font-bold flex items-center justify-between">
              <span>n = {shell.n}</span>
              {currentN === shell.n && <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">{shell.energy} eV</div>
          </button>
        ))}
      </div>

      {/* Spectral Emission Details Card */}
      {lastTransition && (
        <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-lg flex items-center justify-center font-bold text-white font-mono text-sm border shadow-md"
              style={{ backgroundColor: `${lastTransition.color}33`, borderColor: lastTransition.color }}
            >
              hν
            </div>
            <div>
              <div className="text-sm font-semibold text-white flex items-center gap-2">
                <span>{lastTransition.series}</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                  {lastTransition.region}
                </span>
              </div>
              <div className="text-xs text-slate-400 mt-0.5">
                Transition: n = {lastTransition.nInitial} → n = {lastTransition.nFinal} ({lastTransition.nInitial > lastTransition.nFinal ? 'Photon Emission' : 'Photon Absorption'})
              </div>
            </div>
          </div>

          <div className="flex items-center gap-6 font-mono text-xs">
            <div>
              <span className="text-slate-500">ENERGY (ΔE): </span>
              <span className="text-cyan-400 font-bold">{lastTransition.deltaE} eV</span>
            </div>
            <div>
              <span className="text-slate-500">WAVELENGTH (λ): </span>
              <span className="font-bold" style={{ color: lastTransition.color }}>
                {lastTransition.wavelength} nm
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
