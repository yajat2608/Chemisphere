import React, { useState, useEffect, useRef, useMemo } from 'react';
import * as THREE from 'three';
import {
  RotateCcw,
  Sparkles,
  Play,
  Pause,
  Info,
  Maximize2,
  Minimize2,
  Atom,
  Orbit,
  Layers,
  HelpCircle,
  X,
  ChevronRight,
  Shield,
  Radio,
  Sliders,
  Zap,
  Flame,
  Activity,
  Compass
} from 'lucide-react';
import { ChemicalElement } from '../../types';
import {
  SHELL_INFO,
  getElementBohrShells,
  getIndividualElectrons,
  getElementIsotopes,
  ElectronInfo,
  IsotopeInfo
} from '../../utils/atomicStructure';

interface InteractiveBohrAtom3DProps {
  element: ChemicalElement;
  onSelectElement?: (el: ChemicalElement) => void;
  className?: string;
  initialMode?: 'bohr' | 'orbital';
}

export const InteractiveBohrAtom3D: React.FC<InteractiveBohrAtom3DProps> = ({
  element,
  onSelectElement,
  className = 'h-[540px]',
  initialMode = 'bohr'
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // States
  const [modelMode, setModelMode] = useState<'bohr' | 'orbital'>(initialMode);
  const [ionCharge, setIonCharge] = useState<number>(0);
  const [selectedShellIndex, setSelectedShellIndex] = useState<number | null>(null);
  const [selectedElectron, setSelectedElectron] = useState<ElectronInfo | null>(null);
  const [isNucleusSelected, setIsNucleusSelected] = useState<boolean>(false);
  const [selectedIsotopeMass, setSelectedIsotopeMass] = useState<number | null>(null);
  const [isWhyModalOpen, setIsWhyModalOpen] = useState<boolean>(false);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1.0);
  const [hoveredObject, setHoveredObject] = useState<string | null>(null);

  // Quantum Orbital Mode parameters
  const [activeOrbitalSubshell, setActiveOrbitalSubshell] = useState<string>(
    element.block === 'd' ? '3d' : element.block === 'p' ? '2p' : element.block === 'f' ? '4f' : '2s'
  );

  // Three.js References
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const mainGroupRef = useRef<THREE.Group | null>(null);
  const nucleusGroupRef = useRef<THREE.Group | null>(null);
  const shellsGroupRef = useRef<THREE.Group | null>(null);
  const electronsGroupRef = useRef<THREE.Group | null>(null);
  const orbitalCloudGroupRef = useRef<THREE.Group | null>(null);
  const raycasterRef = useRef<THREE.Raycaster>(new THREE.Raycaster());
  const mousePosRef = useRef<THREE.Vector2>(new THREE.Vector2());

  // Mouse & Touch interaction state
  const isDraggingRef = useRef(false);
  const previousMousePositionRef = useRef({ x: 0, y: 0 });
  const rotationVelocityRef = useRef({ x: 0.002, y: 0.004 });
  const targetCameraZRef = useRef<number>(9.0);

  // Calculations for current element & ion
  const protons = element.number;
  const isotopes = useMemo(() => getElementIsotopes(element), [element]);
  const currentIsotope = useMemo(() => {
    if (selectedIsotopeMass !== null) {
      const found = isotopes.find((iso) => iso.massNumber === selectedIsotopeMass);
      if (found) return found;
    }
    return isotopes[0];
  }, [isotopes, selectedIsotopeMass]);

  const neutrons = currentIsotope ? currentIsotope.neutrons : Math.max(0, Math.round(Number(element.atomicMass)) - protons);
  const massNumber = protons + neutrons;
  const electronCount = Math.max(0, protons - ionCharge);
  const currentShells = useMemo(() => getElementBohrShells(protons, ionCharge), [protons, ionCharge]);

  // Scaled radii for coplanar shells
  const shellRadii = useMemo(() => {
    return currentShells.map((_, idx) => 1.4 + idx * 0.72);
  }, [currentShells]);

  const allElectrons = useMemo(() => {
    return getIndividualElectrons(protons, ionCharge, shellRadii);
  }, [protons, ionCharge, shellRadii]);

  // Possible oxidation states / ions
  const oxidationOptions = useMemo(() => {
    const defaultStates = element.oxidationStates || [0];
    const states = [0];
    defaultStates.forEach((st) => {
      if (typeof st === 'number' && !states.includes(st)) {
        states.push(st);
      }
    });
    // Add common standard defaults if none exist
    if (states.length === 1) {
      if (element.group === 1) states.push(1);
      else if (element.group === 2) states.push(2);
      else if (element.group === 17) states.push(-1);
      else if (element.group === 16) states.push(-2);
      else if (element.group === 13) states.push(3);
    }
    return states.sort((a, b) => a - b);
  }, [element]);

  // Reset Camera View
  const handleResetView = () => {
    if (cameraRef.current && mainGroupRef.current) {
      targetCameraZRef.current = 9.0;
      cameraRef.current.position.set(0, 0, 9.0);
      mainGroupRef.current.rotation.set(0.2, 0.3, 0);
      rotationVelocityRef.current = { x: 0.001, y: 0.003 };
    }
    setSelectedShellIndex(null);
    setSelectedElectron(null);
    setIsNucleusSelected(false);
  };

  // Zoom to Nucleus
  const handleInspectNucleus = () => {
    setIsNucleusSelected(true);
    setSelectedShellIndex(null);
    setSelectedElectron(null);
    targetCameraZRef.current = 3.6;
  };

  // Three.js Scene Setup
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 0, 9.0);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = false;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Ambient and Point Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.2);
    scene.add(ambientLight);

    const keyLight = new THREE.PointLight(0x38bdf8, 3.0, 60);
    keyLight.position.set(6, 6, 10);
    scene.add(keyLight);

    const goldLight = new THREE.PointLight(0xf59e0b, 2.2, 60);
    goldLight.position.set(-6, -4, 8);
    scene.add(goldLight);

    const rimLight = new THREE.PointLight(0xec4899, 1.5, 40);
    rimLight.position.set(0, 8, -6);
    scene.add(rimLight);

    // Root Group
    const mainGroup = new THREE.Group();
    mainGroup.rotation.set(0.2, 0.3, 0);
    scene.add(mainGroup);
    mainGroupRef.current = mainGroup;

    // Sub-groups
    const nucleusGroup = new THREE.Group();
    mainGroup.add(nucleusGroup);
    nucleusGroupRef.current = nucleusGroup;

    const shellsGroup = new THREE.Group();
    mainGroup.add(shellsGroup);
    shellsGroupRef.current = shellsGroup;

    const electronsGroup = new THREE.Group();
    mainGroup.add(electronsGroup);
    electronsGroupRef.current = electronsGroup;

    const orbitalCloudGroup = new THREE.Group();
    mainGroup.add(orbitalCloudGroup);
    orbitalCloudGroupRef.current = orbitalCloudGroup;

    // Resize Handler
    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // Animation Loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const delta = clock.getDelta();
      const elapsedTime = clock.getElapsedTime();

      // Smooth Camera Zoom Easing
      if (cameraRef.current) {
        cameraRef.current.position.z += (targetCameraZRef.current - cameraRef.current.position.z) * 0.08;
      }

      // Smooth Model Rotation (Inertia + Idle Rotation)
      if (mainGroupRef.current) {
        if (!isDraggingRef.current) {
          mainGroupRef.current.rotation.y += rotationVelocityRef.current.y;
          mainGroupRef.current.rotation.x += rotationVelocityRef.current.x;
          // Apply gentle damping to user velocity until it settles to gentle idle
          rotationVelocityRef.current.x += (0.0005 - rotationVelocityRef.current.x) * 0.03;
          rotationVelocityRef.current.y += (0.0015 - rotationVelocityRef.current.y) * 0.03;
        }
      }

      // Nucleus subtle breathing pulse
      if (nucleusGroupRef.current) {
        const pulse = 1.0 + Math.sin(elapsedTime * 2.5) * 0.02;
        nucleusGroupRef.current.scale.set(pulse, pulse, pulse);
      }

      // Electrons Orbit Animation
      if (electronsGroupRef.current && isPlaying) {
        electronsGroupRef.current.children.forEach((child) => {
          const userData = child.userData;
          if (userData && userData.isElectron) {
            // Revolution speed decreases with shell distance (Kepler / Bohr analog)
            const speed = (userData.baseSpeed || 1.2) * speedMultiplier;
            userData.currentAngle += speed * delta;

            const r = userData.radius;
            child.position.x = r * Math.cos(userData.currentAngle);
            child.position.y = r * Math.sin(userData.currentAngle);
            child.position.z = 0; // Strictly coplanar
          }
        });
      }

      // Orbital Cloud Rotation in Orbital Mode
      if (orbitalCloudGroupRef.current && modelMode === 'orbital') {
        orbitalCloudGroupRef.current.rotation.y += 0.005;
        orbitalCloudGroupRef.current.rotation.z += 0.003;
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, []);

  // Populate 3D Objects whenever element, ion, mode, or selection changes
  useEffect(() => {
    const nucleusGroup = nucleusGroupRef.current;
    const shellsGroup = shellsGroupRef.current;
    const electronsGroup = electronsGroupRef.current;
    const orbitalCloudGroup = orbitalCloudGroupRef.current;

    if (!nucleusGroup || !shellsGroup || !electronsGroup || !orbitalCloudGroup) return;

    // Clear all previous children
    while (nucleusGroup.children.length > 0) {
      const obj = nucleusGroup.children[0];
      nucleusGroup.remove(obj);
    }
    while (shellsGroup.children.length > 0) {
      const obj = shellsGroup.children[0];
      shellsGroup.remove(obj);
    }
    while (electronsGroup.children.length > 0) {
      const obj = electronsGroup.children[0];
      electronsGroup.remove(obj);
    }
    while (orbitalCloudGroup.children.length > 0) {
      const obj = orbitalCloudGroup.children[0];
      orbitalCloudGroup.remove(obj);
    }

    // ==========================================
    // 1. NUCLEUS CONSTRUCTION (Protons & Neutrons)
    // ==========================================
    const totalNucleons = protons + neutrons;
    const displayNucleons = Math.min(48, totalNucleons); // Cap for clean visual geometry

    const protonMat = new THREE.MeshStandardMaterial({
      color: 0xef4444,
      roughness: 0.25,
      metalness: 0.3,
      emissive: 0x991b1b,
      emissiveIntensity: 0.35
    });

    const neutronMat = new THREE.MeshStandardMaterial({
      color: 0x60a5fa,
      roughness: 0.3,
      metalness: 0.2,
      emissive: 0x1e3a8a,
      emissiveIntensity: 0.25
    });

    const nucleonRadius = 0.075;
    const nucleonGeo = new THREE.SphereGeometry(nucleonRadius, 14, 14);

    // Golden spiral sphere distribution for realistic dense nuclear cluster
    for (let i = 0; i < displayNucleons; i++) {
      const isProton = i % 2 === 0;
      const mesh = new THREE.Mesh(nucleonGeo, isProton ? protonMat : neutronMat);
      
      const phi = Math.acos(-1 + (2 * i) / displayNucleons);
      const theta = Math.sqrt(displayNucleons * Math.PI) * phi;
      const r = 0.32 * Math.cbrt((i + 1) / displayNucleons);

      mesh.position.set(
        r * Math.sin(phi) * Math.cos(theta),
        r * Math.sin(phi) * Math.sin(theta),
        r * Math.cos(phi)
      );

      mesh.userData = {
        isNucleon: true,
        type: isProton ? 'proton' : 'neutron',
        charge: isProton ? '+1e' : '0'
      };

      nucleusGroup.add(mesh);
    }

    // Nucleus Central Core Glow & Raycast Hitbox
    const nucHitboxGeo = new THREE.SphereGeometry(0.55, 16, 16);
    const nucHitboxMat = new THREE.MeshBasicMaterial({
      color: isNucleusSelected ? 0xf59e0b : 0xef4444,
      transparent: true,
      opacity: isNucleusSelected ? 0.35 : 0.12,
      wireframe: isNucleusSelected
    });
    const nucHitbox = new THREE.Mesh(nucHitboxGeo, nucHitboxMat);
    nucHitbox.userData = { isNucleusHitbox: true, name: 'Nucleus' };
    nucleusGroup.add(nucHitbox);

    // ==========================================
    // 2. BOHR COPLANAR CONCENTRIC SHELLS & ELECTRONS
    // ==========================================
    if (modelMode === 'bohr') {
      currentShells.forEach((eCount, sIdx) => {
        const shellMeta = SHELL_INFO[sIdx] || { n: sIdx + 1, letter: `S${sIdx + 1}`, color: '#38bdf8' };
        const radius = shellRadii[sIdx];
        const isSelected = selectedShellIndex === sIdx;
        const isDimmed = selectedShellIndex !== null && !isSelected;

        // Coplanar Concentric Circular Ring (Toroid / Tube)
        const ringGeo = new THREE.RingGeometry(radius - 0.015, radius + 0.015, 64);
        const ringMat = new THREE.MeshBasicMaterial({
          color: isSelected ? 0xf59e0b : new THREE.Color(shellMeta.color),
          side: THREE.DoubleSide,
          transparent: true,
          opacity: isSelected ? 0.95 : isDimmed ? 0.15 : 0.45
        });
        const ringMesh = new THREE.Mesh(ringGeo, ringMat);
        ringMesh.userData = {
          isShellRing: true,
          shellIndex: sIdx,
          shellLetter: shellMeta.letter,
          n: shellMeta.n,
          radius
        };
        shellsGroup.add(ringMesh);

        // Shell Subtle Glowing Outer Aura
        if (isSelected) {
          const glowRingGeo = new THREE.RingGeometry(radius - 0.08, radius + 0.08, 64);
          const glowRingMat = new THREE.MeshBasicMaterial({
            color: 0xf59e0b,
            side: THREE.DoubleSide,
            transparent: true,
            opacity: 0.25
          });
          const glowMesh = new THREE.Mesh(glowRingGeo, glowRingMat);
          shellsGroup.add(glowMesh);
        }
      });

      // Populate Individual Clickable Electrons on Coplanar Shells
      const electronGeo = new THREE.SphereGeometry(0.065, 14, 14);

      allElectrons.forEach((elInfo) => {
        const isSelected = selectedElectron?.index === elInfo.index;
        const isShellSelected = selectedShellIndex === elInfo.shellIndex;
        const isDimmed = selectedShellIndex !== null && !isShellSelected;

        const electronMat = new THREE.MeshStandardMaterial({
          color: isSelected ? 0xfacc15 : 0x38bdf8,
          emissive: isSelected ? 0xf59e0b : 0x0284c7,
          emissiveIntensity: isSelected ? 0.9 : 0.4,
          roughness: 0.1,
          metalness: 0.6
        });

        const eMesh = new THREE.Mesh(electronGeo, electronMat);
        const r = elInfo.shellRadius;
        eMesh.position.set(
          r * Math.cos(elInfo.ringAngle),
          r * Math.sin(elInfo.ringAngle),
          0 // strictly coplanar!
        );

        eMesh.userData = {
          isElectron: true,
          electronData: elInfo,
          radius: r,
          baseSpeed: 1.8 / Math.sqrt(elInfo.n),
          currentAngle: elInfo.ringAngle
        };

        // Electron Glow Ring if Selected
        if (isSelected) {
          const haloGeo = new THREE.RingGeometry(0.1, 0.14, 24);
          const haloMat = new THREE.MeshBasicMaterial({
            color: 0xfacc15,
            side: THREE.DoubleSide,
            transparent: true,
            opacity: 0.8
          });
          const halo = new THREE.Mesh(haloGeo, haloMat);
          eMesh.add(halo);
        }

        electronsGroup.add(eMesh);
      });
    }

    // ==========================================
    // 3. QUANTUM ORBITAL CLOUD MODE
    // ==========================================
    if (modelMode === 'orbital') {
      // Generate 3D Quantum Probability Cloud for the active orbital
      const particleCount = 2400;
      const positions = new Float32Array(particleCount * 3);
      const colors = new Float32Array(particleCount * 3);

      const colorPhasePos = new THREE.Color(0x38bdf8); // + Phase (Cyan)
      const colorPhaseNeg = new THREE.Color(0xf43f5e); // - Phase (Rose)
      const colorGold = new THREE.Color(0xfacc15);

      let idx = 0;
      for (let i = 0; i < particleCount; i++) {
        // Sample based on orbital shape
        let x = 0, y = 0, z = 0;
        let isPositivePhase = true;

        if (activeOrbitalSubshell === '1s') {
          // Spherically symmetric exponential decay
          const u = Math.random();
          const r = -Math.log(1 - u) * 1.1;
          const theta = Math.random() * Math.PI * 2;
          const phi = Math.acos(2 * Math.random() - 1);
          x = r * Math.sin(phi) * Math.cos(theta);
          y = r * Math.sin(phi) * Math.sin(theta);
          z = r * Math.cos(phi);
          isPositivePhase = true;
        } else if (activeOrbitalSubshell === '2s') {
          // Radial node at r ~ 1.2
          const u = Math.random();
          const r = (u < 0.25 ? Math.random() * 0.9 : 1.4 + Math.random() * 1.8);
          const theta = Math.random() * Math.PI * 2;
          const phi = Math.acos(2 * Math.random() - 1);
          x = r * Math.sin(phi) * Math.cos(theta);
          y = r * Math.sin(phi) * Math.sin(theta);
          z = r * Math.cos(phi);
          isPositivePhase = r > 1.2;
        } else if (activeOrbitalSubshell.includes('p') || activeOrbitalSubshell === '2p') {
          // Dumbbell lobes along Z axis
          const lobe = Math.random() > 0.5 ? 1 : -1;
          const r = Math.random() * 2.2 + 0.3;
          const theta = Math.random() * Math.PI * 2;
          const spread = Math.sqrt(Math.random()) * 0.45;
          x = spread * Math.cos(theta) * r;
          y = spread * Math.sin(theta) * r;
          z = lobe * r * (1 - spread * 0.5);
          isPositivePhase = lobe > 0;
        } else if (activeOrbitalSubshell.includes('d') || activeOrbitalSubshell === '3d') {
          // Cloverleaf 4-lobe structure in XY plane + Z lobes
          const lobeIdx = Math.floor(Math.random() * 4);
          const angles = [Math.PI / 4, 3 * Math.PI / 4, 5 * Math.PI / 4, 7 * Math.PI / 4];
          const baseAngle = angles[lobeIdx];
          const spreadAngle = baseAngle + (Math.random() - 0.5) * 0.6;
          const r = Math.random() * 2.6 + 0.4;
          const zSpread = (Math.random() - 0.5) * 0.8;
          x = r * Math.cos(spreadAngle);
          y = r * Math.sin(spreadAngle);
          z = zSpread;
          isPositivePhase = lobeIdx % 2 === 0;
        } else {
          // f-orbital complex 8-lobed / rosette geometry
          const u = Math.random();
          const r = 0.5 + Math.random() * 2.8;
          const theta = Math.random() * Math.PI * 2;
          const phi = Math.acos(2 * Math.random() - 1);
          x = r * Math.sin(phi) * Math.cos(theta) * Math.cos(3 * theta);
          y = r * Math.sin(phi) * Math.sin(theta) * Math.cos(3 * theta);
          z = r * Math.cos(phi);
          isPositivePhase = (x * y * z) > 0;
        }

        positions[idx * 3] = x;
        positions[idx * 3 + 1] = y;
        positions[idx * 3 + 2] = z;

        const col = isPositivePhase ? colorPhasePos : colorPhaseNeg;
        colors[idx * 3] = col.r;
        colors[idx * 3 + 1] = col.g;
        colors[idx * 3 + 2] = col.b;
        idx++;
      }

      const pointGeo = new THREE.BufferGeometry();
      pointGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      pointGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

      const pointMat = new THREE.PointsMaterial({
        size: 0.055,
        vertexColors: true,
        transparent: true,
        opacity: 0.85,
        blending: THREE.AdditiveBlending
      });

      const pointCloud = new THREE.Points(pointGeo, pointMat);
      orbitalCloudGroup.add(pointCloud);

      // Add Nodal Plane / Reference Axes
      const gridHelper = new THREE.GridHelper(5, 10, 0x38bdf8, 0x1e293b);
      gridHelper.rotation.x = Math.PI / 2;
      orbitalCloudGroup.add(gridHelper);
    }
  }, [
    element,
    protons,
    neutrons,
    ionCharge,
    currentShells,
    allElectrons,
    modelMode,
    selectedShellIndex,
    selectedElectron,
    isNucleusSelected,
    activeOrbitalSubshell
  ]);

  // Raycasting Click & Hover Interaction Handlers
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    isDraggingRef.current = true;
    previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const container = containerRef.current;
    if (!container) return;

    if (isDraggingRef.current && mainGroupRef.current) {
      const deltaX = e.clientX - previousMousePositionRef.current.x;
      const deltaY = e.clientY - previousMousePositionRef.current.y;

      mainGroupRef.current.rotation.y += deltaX * 0.008;
      mainGroupRef.current.rotation.x += deltaY * 0.008;

      rotationVelocityRef.current = {
        x: deltaY * 0.002,
        y: deltaX * 0.002
      };

      previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
      return;
    }

    // Raycast on hover
    if (cameraRef.current && sceneRef.current) {
      const rect = container.getBoundingClientRect();
      mousePosRef.current.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mousePosRef.current.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycasterRef.current.setFromCamera(mousePosRef.current, cameraRef.current);
      const intersects = raycasterRef.current.intersectObjects(sceneRef.current.children, true);

      if (intersects.length > 0) {
        const topHit = intersects[0].object;
        if (topHit.userData.isNucleusHitbox || topHit.userData.isNucleon) {
          setHoveredObject('Nucleus (Click to Inspect Protons/Neutrons)');
        } else if (topHit.userData.isElectron) {
          const ed = topHit.userData.electronData as ElectronInfo;
          setHoveredObject(`Electron #${ed.index} (${ed.shellLetter} Shell, ${ed.subshellName})`);
        } else if (topHit.userData.isShellRing) {
          setHoveredObject(`${topHit.userData.shellLetter} Shell (n=${topHit.userData.n})`);
        } else {
          setHoveredObject(null);
        }
      } else {
        setHoveredObject(null);
      }
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    const wasDragging = isDraggingRef.current;
    isDraggingRef.current = false;

    // Check if it was a distinct click (not a long drag)
    const deltaX = Math.abs(e.clientX - previousMousePositionRef.current.x);
    const deltaY = Math.abs(e.clientY - previousMousePositionRef.current.y);

    if (deltaX < 5 && deltaY < 5 && containerRef.current && cameraRef.current && sceneRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      mousePosRef.current.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mousePosRef.current.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycasterRef.current.setFromCamera(mousePosRef.current, cameraRef.current);
      const intersects = raycasterRef.current.intersectObjects(sceneRef.current.children, true);

      if (intersects.length > 0) {
        // Find highest priority hit
        let foundElectron = false;
        let foundNucleus = false;
        let foundShell = false;

        for (const hit of intersects) {
          const obj = hit.object;
          if (obj.userData.isElectron) {
            setSelectedElectron(obj.userData.electronData);
            setSelectedShellIndex(obj.userData.electronData.shellIndex);
            setIsNucleusSelected(false);
            targetCameraZRef.current = 7.5;
            foundElectron = true;
            break;
          } else if (obj.userData.isNucleusHitbox || obj.userData.isNucleon) {
            handleInspectNucleus();
            foundNucleus = true;
            break;
          } else if (obj.userData.isShellRing) {
            setSelectedShellIndex(obj.userData.shellIndex);
            setSelectedElectron(null);
            setIsNucleusSelected(false);
            targetCameraZRef.current = 8.5;
            foundShell = true;
            break;
          }
        }
      }
    }
  };

  // Zoom via Wheel
  const handleWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    e.preventDefault();
    targetCameraZRef.current = Math.min(14.0, Math.max(2.8, targetCameraZRef.current + e.deltaY * 0.005));
  };

  return (
    <div className={`relative w-full ${className} rounded-2xl bg-gradient-to-b from-[#060810] via-[#090d16] to-[#04060a] border border-cyan-900/30 overflow-hidden shadow-2xl flex flex-col`}>
      {/* Top Controls & Mode Switcher Bar */}
      <div className="absolute top-3 left-3 right-3 z-20 flex flex-wrap items-center justify-between gap-2 p-2 rounded-xl bg-[#090d16]/85 backdrop-blur-xl border border-white/10 font-mono text-xs">
        {/* Model Mode Toggle: BOHR vs ORBITAL */}
        <div className="flex items-center gap-1 p-1 rounded-lg bg-black/50 border border-white/10">
          <button
            onClick={() => {
              setModelMode('bohr');
              setSelectedElectron(null);
              setSelectedShellIndex(null);
            }}
            className={`px-3 py-1.5 rounded-md font-bold transition-all flex items-center gap-1.5 ${
              modelMode === 'bohr'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/30'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Orbit className="w-3.5 h-3.5" />
            <span>BOHR MODEL</span>
          </button>
          <button
            onClick={() => {
              setModelMode('orbital');
              setSelectedElectron(null);
              setSelectedShellIndex(null);
              setIsNucleusSelected(false);
            }}
            className={`px-3 py-1.5 rounded-md font-bold transition-all flex items-center gap-1.5 ${
              modelMode === 'orbital'
                ? 'bg-purple-500 text-white shadow-md shadow-purple-500/30'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>ORBITAL MODEL</span>
          </button>
        </div>

        {/* Ion State Selector */}
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] uppercase text-slate-400 font-bold hidden sm:inline">State:</span>
          <div className="flex items-center gap-1 p-1 rounded-lg bg-black/50 border border-white/10">
            {oxidationOptions.map((st) => {
              const label = st === 0 ? 'Neutral' : st > 0 ? `+${st}` : `${st}`;
              const isSelected = ionCharge === st;
              return (
                <button
                  key={st}
                  onClick={() => setIonCharge(st)}
                  className={`px-2 py-1 rounded text-[11px] font-bold transition-all ${
                    isSelected
                      ? st === 0
                        ? 'bg-slate-200 text-slate-950'
                        : 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                  title={st === 0 ? 'Neutral Atom' : `Ion state with charge ${label}`}
                >
                  {label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Action Controls: Why this model, Play/Pause, Reset */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setIsWhyModalOpen(true)}
            className="px-2.5 py-1.5 rounded-lg bg-amber-500/10 text-amber-300 border border-amber-500/30 hover:bg-amber-500/20 transition-colors flex items-center gap-1.5 font-sans font-semibold text-[11px]"
            title="Scientific explanation of Bohr vs Modern Quantum Model"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span className="hidden md:inline">WHY THIS MODEL?</span>
          </button>

          <button
            onClick={() => setIsPlaying((p) => !p)}
            className="p-1.5 rounded-lg bg-white/5 text-slate-300 hover:text-white hover:bg-white/10 transition-colors border border-white/10"
            title={isPlaying ? 'Pause revolution' : 'Resume revolution'}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={handleResetView}
            className="p-1.5 rounded-lg bg-white/5 text-slate-300 hover:text-white hover:bg-white/10 transition-colors border border-white/10"
            title="Reset 3D Camera & Orientations"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main 3D Canvas Area */}
      <div
        ref={containerRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onWheel={handleWheel}
        className="w-full flex-1 cursor-grab active:cursor-grabbing touch-none select-none relative"
      />

      {/* Interactive Hover HUD Tooltip */}
      {hoveredObject && (
        <div className="absolute bottom-16 left-1/2 -translate-x-1/2 pointer-events-none z-20 px-3 py-1 rounded-full bg-[#070b14]/90 border border-cyan-500/40 text-cyan-300 text-xs font-mono backdrop-blur-md shadow-xl animate-fade-in">
          {hoveredObject}
        </div>
      )}

      {/* Bottom Info Bar: Element Identity & Quick Shell Map */}
      <div className="absolute bottom-3 left-3 right-3 z-20 flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-xl bg-[#090d16]/85 backdrop-blur-xl border border-white/10 font-mono text-xs">
        {/* Element Summary & Nucleus Trigger */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleInspectNucleus}
            className="flex items-center gap-2 px-2.5 py-1 rounded-lg bg-red-500/10 border border-red-500/30 hover:bg-red-500/20 text-red-300 font-bold transition-all group"
            title="Click to inspect Nucleus & Isotopes"
          >
            <div className="w-2.5 h-2.5 rounded-full bg-red-500 group-hover:scale-125 transition-transform animate-pulse" />
            <span>NUCLEUS: {protons}p⁺ + {neutrons}n⁰</span>
          </button>

          <div className="hidden sm:flex items-center gap-2 text-slate-300">
            <span className="text-slate-400">Config:</span>
            <span className="font-bold text-cyan-300">{element.electronConfigurationShort || element.electronConfiguration}</span>
          </div>
        </div>

        {/* Interactive Shell Chips Bar */}
        {modelMode === 'bohr' ? (
          <div className="flex items-center gap-1">
            <span className="text-[10px] text-slate-400 font-bold hidden lg:inline mr-1">SHELLS:</span>
            {currentShells.map((count, idx) => {
              const info = SHELL_INFO[idx] || { letter: `S${idx + 1}`, n: idx + 1 };
              const isSelected = selectedShellIndex === idx;
              return (
                <button
                  key={idx}
                  onClick={() => {
                    setSelectedShellIndex(isSelected ? null : idx);
                    setSelectedElectron(null);
                    setIsNucleusSelected(false);
                  }}
                  className={`px-2 py-0.5 rounded-md font-mono text-[11px] transition-all flex items-center gap-1 ${
                    isSelected
                      ? 'bg-amber-500 text-slate-950 font-black shadow-md shadow-amber-500/30 ring-1 ring-amber-300'
                      : 'bg-white/5 text-slate-300 hover:text-white hover:bg-white/10 border border-white/10'
                  }`}
                  title={`${info.letter} shell (n=${info.n}): ${count} electrons`}
                >
                  <span className="font-bold">{info.letter}:</span>
                  <span>{count}</span>
                </button>
              );
            })}
          </div>
        ) : (
          <div className="flex items-center gap-1">
            <span className="text-[10px] text-purple-400 font-bold hidden sm:inline mr-1">ORBITAL VIEW:</span>
            {['1s', '2s', '2p', '3d', '4f'].map((orb) => (
              <button
                key={orb}
                onClick={() => setActiveOrbitalSubshell(orb)}
                className={`px-2 py-0.5 rounded-md text-[11px] font-bold transition-all ${
                  activeOrbitalSubshell === orb
                    ? 'bg-purple-500 text-white shadow-md shadow-purple-500/30'
                    : 'bg-white/5 text-slate-400 hover:text-slate-200 border border-white/10'
                }`}
              >
                {orb}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* ==========================================
          INSPECTOR PANEL OVERLAYS
         ========================================== */}

      {/* 1. NUCLEUS INSPECTOR DRAWER / MODAL */}
      {isNucleusSelected && (
        <div className="absolute top-16 right-3 z-30 w-80 max-w-[calc(100%-24px)] p-4 rounded-2xl bg-[#090d16]/95 backdrop-blur-2xl border border-red-500/40 shadow-2xl shadow-red-950/60 font-sans space-y-3 animate-fade-in">
          <div className="flex items-center justify-between border-b border-red-500/20 pb-2">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse" />
              <h3 className="font-serif font-black text-white text-base tracking-wide">NUCLEUS INSPECTOR</h3>
            </div>
            <button
              onClick={() => setIsNucleusSelected(false)}
              className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-white/10"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs font-mono">
            <div className="p-2 rounded-xl bg-red-950/30 border border-red-500/20">
              <div className="text-[10px] text-red-400 uppercase font-bold">Protons (Z)</div>
              <div className="text-xl font-bold text-white mt-0.5">{protons}</div>
              <div className="text-[9px] text-slate-400">Nuclear Charge: +{protons}e</div>
            </div>

            <div className="p-2 rounded-xl bg-blue-950/30 border border-blue-500/20">
              <div className="text-[10px] text-blue-400 uppercase font-bold">Neutrons (N)</div>
              <div className="text-xl font-bold text-white mt-0.5">{neutrons}</div>
              <div className="text-[9px] text-slate-400">Mass No. A = {massNumber}</div>
            </div>
          </div>

          {/* Atomic Identity Statement */}
          <div className="p-2.5 rounded-xl bg-black/40 border border-white/10 text-xs text-slate-300 space-y-1">
            <div className="text-amber-400 font-bold flex items-center gap-1.5 text-[11px]">
              <Shield className="w-3.5 h-3.5 text-amber-400" />
              <span>Atomic Identity</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              The number of <strong>protons ({protons})</strong> strictly dictates the elemental identity as <strong>{element.name} ({element.symbol})</strong>. Adding or removing protons transmutes the element.
            </p>
          </div>

          {/* Isotope Selection */}
          <div className="space-y-1.5">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono">
              Key Isotopes ({isotopes.length}):
            </div>
            <div className="space-y-1 max-h-32 overflow-y-auto pr-1">
              {isotopes.map((iso) => {
                const isSelected = (currentIsotope?.massNumber === iso.massNumber);
                return (
                  <div
                    key={iso.massNumber}
                    onClick={() => setSelectedIsotopeMass(iso.massNumber)}
                    className={`p-2 rounded-lg border text-xs cursor-pointer transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-amber-500/20 border-amber-500/60 text-amber-200'
                        : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    <div>
                      <span className="font-bold font-mono">{element.symbol}-{iso.massNumber}</span>
                      <span className="text-[10px] text-slate-400 ml-1.5">({iso.neutrons} neutrons)</span>
                    </div>
                    <div className="text-[10px] font-mono text-right">
                      <span className={iso.isStable ? 'text-emerald-400' : 'text-amber-400'}>
                        {iso.abundance}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* 2. SHELL INSPECTOR DRAWER / MODAL */}
      {selectedShellIndex !== null && !selectedElectron && !isNucleusSelected && (
        <div className="absolute top-16 right-3 z-30 w-80 max-w-[calc(100%-24px)] p-4 rounded-2xl bg-[#090d16]/95 backdrop-blur-2xl border border-amber-500/40 shadow-2xl shadow-amber-950/60 font-sans space-y-3 animate-fade-in">
          <div className="flex items-center justify-between border-b border-amber-500/20 pb-2">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-amber-500 animate-pulse" />
              <h3 className="font-serif font-black text-white text-base tracking-wide">
                {SHELL_INFO[selectedShellIndex]?.letter} SHELL INSPECTOR
              </h3>
            </div>
            <button
              onClick={() => setSelectedShellIndex(null)}
              className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-white/10"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs font-mono">
            <div className="p-2 rounded-xl bg-amber-950/30 border border-amber-500/20">
              <div className="text-[10px] text-amber-400 uppercase font-bold">Quantum Number</div>
              <div className="text-xl font-bold text-white mt-0.5">n = {selectedShellIndex + 1}</div>
              <div className="text-[9px] text-slate-400">{SHELL_INFO[selectedShellIndex]?.letter} Energy Level</div>
            </div>

            <div className="p-2 rounded-xl bg-cyan-950/30 border border-cyan-500/20">
              <div className="text-[10px] text-cyan-400 uppercase font-bold">Electrons Present</div>
              <div className="text-xl font-bold text-white mt-0.5">{currentShells[selectedShellIndex] || 0}</div>
              <div className="text-[9px] text-slate-400">Max: {SHELL_INFO[selectedShellIndex]?.maxCapacity} (2n²)</div>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-black/40 border border-white/10 text-xs space-y-1.5 font-mono">
            <div className="text-cyan-300 font-bold">Subshells in this Level:</div>
            <div className="flex flex-wrap gap-1.5">
              {SHELL_INFO[selectedShellIndex]?.subshells.map((sub) => (
                <span
                  key={sub}
                  className="px-2 py-1 rounded-md bg-white/10 text-white font-bold border border-white/10"
                >
                  {sub}
                </span>
              ))}
            </div>
            <p className="text-[10px] text-slate-400 mt-2 font-sans leading-relaxed">
              Energy increases with principal quantum number $n$. Electrons in the outermost occupied shell determine chemical bonding and valence.
            </p>
          </div>
        </div>
      )}

      {/* 3. INDIVIDUAL ELECTRON INSPECTOR DRAWER / MODAL */}
      {selectedElectron && (
        <div className="absolute top-16 right-3 z-30 w-80 max-w-[calc(100%-24px)] p-4 rounded-2xl bg-[#090d16]/95 backdrop-blur-2xl border border-cyan-500/40 shadow-2xl shadow-cyan-950/60 font-sans space-y-3 animate-fade-in">
          <div className="flex items-center justify-between border-b border-cyan-500/20 pb-2">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-cyan-400 animate-ping" />
              <h3 className="font-serif font-black text-white text-base tracking-wide">
                ELECTRON #{selectedElectron.index} INSPECTOR
              </h3>
            </div>
            <button
              onClick={() => setSelectedElectron(null)}
              className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-white/10"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs font-mono">
            <div className="p-2 rounded-xl bg-cyan-950/30 border border-cyan-500/20">
              <div className="text-[10px] text-cyan-400 uppercase font-bold">Shell & Subshell</div>
              <div className="text-base font-bold text-white mt-0.5">
                {selectedElectron.shellLetter} (n={selectedElectron.n}) • {selectedElectron.subshellName}
              </div>
            </div>

            <div className="p-2 rounded-xl bg-purple-950/30 border border-purple-500/20">
              <div className="text-[10px] text-purple-400 uppercase font-bold">Orbital Assignment</div>
              <div className="text-base font-bold text-white mt-0.5">{selectedElectron.orbitalName}</div>
            </div>
          </div>

          {/* Quantum Numbers Breakdown */}
          <div className="p-3 rounded-xl bg-black/40 border border-white/10 space-y-1.5 font-mono text-xs">
            <div className="text-amber-400 font-bold text-[11px] uppercase tracking-wider">
              Quantum Numbers Set:
            </div>
            <div className="grid grid-cols-4 gap-1 text-center">
              <div className="p-1.5 rounded-lg bg-white/5 border border-white/10">
                <div className="text-[9px] text-slate-400">n</div>
                <div className="font-bold text-white text-sm">{selectedElectron.n}</div>
              </div>
              <div className="p-1.5 rounded-lg bg-white/5 border border-white/10">
                <div className="text-[9px] text-slate-400">l</div>
                <div className="font-bold text-white text-sm">{selectedElectron.l}</div>
              </div>
              <div className="p-1.5 rounded-lg bg-white/5 border border-white/10">
                <div className="text-[9px] text-slate-400">mₗ</div>
                <div className="font-bold text-white text-sm">{selectedElectron.ml}</div>
              </div>
              <div className="p-1.5 rounded-lg bg-white/5 border border-white/10">
                <div className="text-[9px] text-slate-400">mₛ</div>
                <div className="font-bold text-cyan-300 text-sm">{selectedElectron.ms}</div>
              </div>
            </div>
          </div>

          <p className="text-[10px] text-slate-400 leading-relaxed font-sans">
            By Pauli’s Exclusion Principle, no two electrons in an atom can have the exact same set of four quantum numbers.
          </p>
        </div>
      )}

      {/* 4. WHY THIS MODEL? SCIENTIFIC OVERLAY MODAL */}
      {isWhyModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-lg p-6 rounded-3xl bg-[#090d16] border border-amber-500/40 shadow-2xl space-y-4 font-sans text-slate-200">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                  <HelpCircle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif font-black text-white text-lg">Why the Bohr Shell Model?</h3>
                  <p className="text-xs text-amber-400 font-mono">Pedagogical Utility vs Modern Quantum Mechanics</p>
                </div>
              </div>
              <button
                onClick={() => setIsWhyModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs leading-relaxed text-slate-300">
              <blockquote className="p-3.5 rounded-xl bg-amber-950/30 border-l-4 border-amber-500 text-amber-100 font-serif italic text-xs">
                “The Bohr model is a useful visualization of electrons distributed across principal energy levels. Modern quantum mechanics describes electrons using orbitals and probability distributions rather than fixed circular paths.”
              </blockquote>

              <div className="space-y-2">
                <h4 className="font-bold text-white text-xs uppercase tracking-wider font-mono">Key Distinctions:</h4>
                <ul className="space-y-1.5 list-disc pl-4 text-slate-300">
                  <li>
                    <strong className="text-cyan-300">Bohr Model (1913):</strong> Introduces quantized principal energy levels ($n=1, 2, 3\dots$) and explains elemental emission spectra, shell capacities ($2n^2$), and valence bonding rules.
                  </li>
                  <li>
                    <strong className="text-purple-300">Quantum Mechanical Model (1926+):</strong> Heisenberg’s Uncertainty Principle and Schrödinger’s wave equation prove electrons do not travel in fixed orbits. Instead, they occupy 3D probability clouds (orbitals $s, p, d, f$) defined by wave functions ($\psi$).
                  </li>
                </ul>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => setIsWhyModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs hover:bg-amber-400 transition-colors"
                >
                  Understood
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
