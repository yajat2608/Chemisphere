import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Molecule3DData, AtomCoordinate } from '../../types';

interface MoleculeViewer3DProps {
  molecule: Molecule3DData;
  displayMode: 'ball-and-stick' | 'space-filling' | 'wireframe' | 'electron-density';
  showLabels: boolean;
  autoRotate: boolean;
  onSelectAtom?: (atom: AtomCoordinate | null) => void;
  measurementMode?: 'none' | 'distance' | 'angle';
  onMeasurementResult?: (result: string | null) => void;
}

export const MoleculeViewer3D: React.FC<MoleculeViewer3DProps> = ({
  molecule,
  displayMode,
  showLabels,
  autoRotate,
  onSelectAtom,
  measurementMode = 'none',
  onMeasurementResult
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const molGroupRef = useRef<THREE.Group | null>(null);
  const labelsGroupRef = useRef<THREE.Group | null>(null);
  const isDraggingRef = useRef(false);
  const prevMousePos = useRef({ x: 0, y: 0 });
  const frameIdRef = useRef<number>(0);

  const [selectedAtoms, setSelectedAtoms] = useState<number[]>([]);

  // Init Three.js Scene
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth || 600;
    const height = container.clientHeight || 450;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 0, 8);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Lighting
    const ambLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.4);
    dirLight1.position.set(8, 12, 10);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x38bdf8, 0.8);
    dirLight2.position.set(-8, -6, -5);
    scene.add(dirLight2);

    const molGroup = new THREE.Group();
    molGroupRef.current = molGroup;
    scene.add(molGroup);

    const labelsGroup = new THREE.Group();
    labelsGroupRef.current = labelsGroup;
    scene.add(labelsGroup);

    const handleResize = () => {
      if (!container || !renderer) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    const animate = () => {
      if (molGroupRef.current && autoRotate && !isDraggingRef.current) {
        molGroupRef.current.rotation.y += 0.007;
        molGroupRef.current.rotation.x += 0.003;
      }
      renderer.render(scene, camera);
      frameIdRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameIdRef.current);
      renderer.dispose();
    };
  }, []);

  // Render Molecule Atoms & Bonds
  useEffect(() => {
    const molGroup = molGroupRef.current;
    if (!molGroup) return;

    // Clear old meshes
    while (molGroup.children.length > 0) {
      const obj = molGroup.children[0] as THREE.Mesh;
      if (obj.geometry) obj.geometry.dispose();
      molGroup.remove(obj);
    }

    // CPK standard colors dictionary
    const cpkColors: Record<string, number> = {
      H: 0xf8fafc,
      C: 0x475569,
      N: 0x3b82f6,
      O: 0xef4444,
      P: 0xa855f7,
      S: 0xeab308,
      Cl: 0x22c55e,
      F: 0x10b981,
      Br: 0xdc2626,
      I: 0x9333ea,
      Na: 0x6366f1,
      K: 0x8b5cf6
    };

    // Standard covalent / vdW radii scaling
    const cpkVdwRadii: Record<string, number> = {
      H: 0.65,
      C: 1.1,
      N: 1.05,
      O: 1.0,
      P: 1.3,
      S: 1.25,
      Cl: 1.2,
      F: 0.9,
      Na: 1.4,
      K: 1.6
    };

    // 1. Build Atoms & Atom Labels
    molecule.atoms.forEach((atom, idx) => {
      const colorHex = cpkColors[atom.element] || 0x94a3b8;
      const isSelected = selectedAtoms.includes(idx);

      let rad = atom.radius || 0.4;
      if (displayMode === 'space-filling') {
        rad = cpkVdwRadii[atom.element] || 1.1;
      } else if (displayMode === 'wireframe') {
        rad = 0.15;
      } else if (displayMode === 'electron-density') {
        rad = (atom.radius || 0.4) * 1.5;
      }

      const sphereGeo = new THREE.SphereGeometry(rad, 32, 32);

      let mat: THREE.Material;
      if (displayMode === 'electron-density') {
        mat = new THREE.MeshPhysicalMaterial({
          color: isSelected ? 0x38bdf8 : colorHex,
          emissive: colorHex,
          emissiveIntensity: 0.4,
          transmission: 0.6,
          roughness: 0.1,
          transparent: true,
          opacity: 0.65
        });
      } else {
        mat = new THREE.MeshStandardMaterial({
          color: isSelected ? 0x38bdf8 : colorHex,
          roughness: 0.3,
          metalness: 0.2,
          wireframe: displayMode === 'wireframe'
        });
      }

      const atomMesh = new THREE.Mesh(sphereGeo, mat);
      atomMesh.position.set(atom.x, atom.y, atom.z);
      atomMesh.userData = { atomIndex: idx, atomData: atom };
      molGroup.add(atomMesh);

      // Selection ring indicator
      if (isSelected) {
        const ringGeo = new THREE.RingGeometry(rad * 1.3, rad * 1.5, 32);
        const ringMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, side: THREE.DoubleSide });
        const ringMesh = new THREE.Mesh(ringGeo, ringMat);
        ringMesh.position.copy(atomMesh.position);
        ringMesh.lookAt(cameraRef.current?.position || new THREE.Vector3(0, 0, 10));
        molGroup.add(ringMesh);
      }

      // High-visibility, bold, crisp Atom Label Badge
      if (showLabels) {
        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 256;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.clearRect(0, 0, 512, 256);

          const cx = 256;
          const cy = 128;
          const rw = 280;
          const rh = 130;
          const r = 40;

          // Outer Glow / Contrast Drop Shadow
          ctx.shadowColor = isSelected ? 'rgba(56, 189, 248, 0.95)' : 'rgba(0, 0, 0, 0.85)';
          ctx.shadowBlur = isSelected ? 32 : 18;
          ctx.shadowOffsetX = 0;
          ctx.shadowOffsetY = 6;

          // High Contrast Pill Background
          ctx.fillStyle = isSelected ? 'rgba(12, 20, 36, 0.96)' : 'rgba(10, 14, 24, 0.92)';
          ctx.beginPath();
          ctx.roundRect(cx - rw / 2, cy - rh / 2, rw, rh, r);
          ctx.fill();

          // Border Accent
          ctx.strokeStyle = isSelected ? '#38bdf8' : 'rgba(255, 255, 255, 0.4)';
          ctx.lineWidth = isSelected ? 7 : 4;
          ctx.stroke();

          // Reset shadow for crisp text rendering
          ctx.shadowColor = 'transparent';
          ctx.shadowBlur = 0;

          // Element Symbol in Ultra-Bold Modern Font
          ctx.fillStyle = '#ffffff';
          ctx.font = '900 76px "Plus Jakarta Sans", "Outfit", -apple-system, sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(atom.element, cx - 24, cy);

          // Atom Sub-Index (Bold Cyan/Slate)
          ctx.fillStyle = isSelected ? '#38bdf8' : '#94a3b8';
          ctx.font = '800 38px "Plus Jakarta Sans", "Outfit", -apple-system, sans-serif';
          ctx.textAlign = 'left';
          ctx.fillText(`${idx + 1}`, cx + 36, cy - 4);

          const texture = new THREE.CanvasTexture(canvas);
          texture.minFilter = THREE.LinearFilter;
          texture.magFilter = THREE.LinearFilter;
          const spriteMat = new THREE.SpriteMaterial({
            map: texture,
            transparent: true,
            depthTest: false,
            opacity: 0.98
          });
          const sprite = new THREE.Sprite(spriteMat);
          sprite.position.set(atom.x, atom.y + rad + 0.38, atom.z);
          sprite.scale.set(1.3, 0.65, 1);
          molGroup.add(sprite);
        }
      }
    });

    // 2. Build Bonds (except in space-filling mode)
    if (displayMode !== 'space-filling') {
      molecule.bonds.forEach((bond) => {
        const a1 = molecule.atoms[bond.source];
        const a2 = molecule.atoms[bond.target];
        if (!a1 || !a2) return;

        const p1 = new THREE.Vector3(a1.x, a1.y, a1.z);
        const p2 = new THREE.Vector3(a2.x, a2.y, a2.z);
        const dist = p1.distanceTo(p2);
        const dir = new THREE.Vector3().subVectors(p2, p1).normalize();
        const mid = new THREE.Vector3().addVectors(p1, p2).multiplyScalar(0.5);

        const bondRadius = displayMode === 'wireframe' ? 0.03 : 0.08;

        const drawCylinder = (offset: THREE.Vector3 = new THREE.Vector3()) => {
          const cylGeo = new THREE.CylinderGeometry(bondRadius, bondRadius, dist, 16);
          const cylMat = new THREE.MeshStandardMaterial({
            color: 0x94a3b8,
            roughness: 0.4,
            metalness: 0.3
          });
          const cylMesh = new THREE.Mesh(cylGeo, cylMat);
          cylMesh.position.copy(mid).add(offset);
          cylMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
          molGroup.add(cylMesh);
        };

        if (bond.order === 1) {
          drawCylinder();
        } else if (bond.order === 2) {
          const perp = new THREE.Vector3(-dir.y, dir.x, 0).normalize().multiplyScalar(0.1);
          drawCylinder(perp);
          drawCylinder(perp.clone().negate());
        } else if (bond.order === 3) {
          const perp = new THREE.Vector3(-dir.y, dir.x, 0).normalize().multiplyScalar(0.12);
          drawCylinder(new THREE.Vector3());
          drawCylinder(perp);
          drawCylinder(perp.clone().negate());
        }
      });
    }
  }, [molecule, displayMode, selectedAtoms]);

  // Click & Selection Raycasting
  const handleClick = (e: React.MouseEvent) => {
    if (isDraggingRef.current) return;
    const container = containerRef.current;
    const camera = cameraRef.current;
    const molGroup = molGroupRef.current;
    if (!container || !camera || !molGroup) return;

    const rect = container.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), camera);
    const intersects = raycaster.intersectObjects(molGroup.children, true);

    const hitAtom = intersects.find((hit) => hit.object.userData?.atomIndex !== undefined);

    if (hitAtom) {
      const idx = hitAtom.object.userData.atomIndex as number;
      const atomData = hitAtom.object.userData.atomData as AtomCoordinate;

      if (measurementMode === 'distance') {
        const next = [...selectedAtoms, idx].slice(-2);
        setSelectedAtoms(next);
        if (next.length === 2 && onMeasurementResult) {
          const p1 = molecule.atoms[next[0]];
          const p2 = molecule.atoms[next[1]];
          const d = Math.sqrt((p1.x - p2.x) ** 2 + (p1.y - p2.y) ** 2 + (p1.z - p2.z) ** 2);
          onMeasurementResult(`Bond Length (${p1.element}${next[0] + 1} — ${p2.element}${next[1] + 1}): ${(d * 100).toFixed(1)} pm (${d.toFixed(3)} Å)`);
        }
      } else if (measurementMode === 'angle') {
        const next = [...selectedAtoms, idx].slice(-3);
        setSelectedAtoms(next);
        if (next.length === 3 && onMeasurementResult) {
          const p1 = new THREE.Vector3(molecule.atoms[next[0]].x, molecule.atoms[next[0]].y, molecule.atoms[next[0]].z);
          const vertex = new THREE.Vector3(molecule.atoms[next[1]].x, molecule.atoms[next[1]].y, molecule.atoms[next[1]].z);
          const p3 = new THREE.Vector3(molecule.atoms[next[2]].x, molecule.atoms[next[2]].y, molecule.atoms[next[2]].z);
          const v1 = p1.clone().sub(vertex).normalize();
          const v2 = p3.clone().sub(vertex).normalize();
          const angleRad = v1.angleTo(v2);
          const angleDeg = (angleRad * 180) / Math.PI;
          onMeasurementResult(`Bond Angle (${molecule.atoms[next[0]].element}—${molecule.atoms[next[1]].element}—${molecule.atoms[next[2]].element}): ${angleDeg.toFixed(1)}°`);
        }
      } else {
        setSelectedAtoms([idx]);
        if (onSelectAtom) onSelectAtom(atomData);
      }
    } else {
      setSelectedAtoms([]);
      if (onSelectAtom) onSelectAtom(null);
      if (onMeasurementResult) onMeasurementResult(null);
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = false;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (e.buttons !== 1 || !molGroupRef.current) return;
    const dx = e.clientX - prevMousePos.current.x;
    const dy = e.clientY - prevMousePos.current.y;
    if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
      isDraggingRef.current = true;
    }
    molGroupRef.current.rotation.y += dx * 0.01;
    molGroupRef.current.rotation.x += dy * 0.01;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  return (
    <div
      ref={containerRef}
      onClick={handleClick}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      className="w-full h-full min-h-[420px] relative cursor-grab active:cursor-grabbing select-none rounded-xl overflow-hidden"
    />
  );
};
