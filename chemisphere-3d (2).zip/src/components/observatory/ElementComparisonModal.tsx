import React, { useState } from 'react';
import { X, ArrowRight, Scale, Sparkles, Sliders, TrendingUp, Check, Layers, Atom } from 'lucide-react';
import { ChemicalElement } from '../../types';
import { ALL_118_ELEMENTS } from '../../data/elements';

interface ElementComparisonModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialElements?: ChemicalElement[];
  onSelectElement?: (el: ChemicalElement) => void;
}

export const ElementComparisonModal: React.FC<ElementComparisonModalProps> = ({
  isOpen,
  onClose,
  initialElements = [],
  onSelectElement
}) => {
  const [selectedElements, setSelectedElements] = useState<ChemicalElement[]>(() => {
    if (initialElements.length > 0) return initialElements.slice(0, 4);
    const na = ALL_118_ELEMENTS.find((e) => e.number === 11);
    const cl = ALL_118_ELEMENTS.find((e) => e.number === 17);
    const k = ALL_118_ELEMENTS.find((e) => e.number === 19);
    return [na, cl, k].filter(Boolean) as ChemicalElement[];
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [activeDiffMode, setActiveDiffMode] = useState<'table' | 'radar' | 'diff'>('table');

  if (!isOpen) return null;

  const handleAddElement = (el: ChemicalElement) => {
    if (selectedElements.some((e) => e.number === el.number)) return;
    if (selectedElements.length >= 4) return;
    setSelectedElements([...selectedElements, el]);
  };

  const handleRemoveElement = (num: number) => {
    setSelectedElements(selectedElements.filter((e) => e.number !== num));
  };

  const searchResults = searchQuery.trim()
    ? ALL_118_ELEMENTS.filter(
        (e) =>
          !selectedElements.some((s) => s.number === e.number) &&
          (e.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            e.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
            e.number.toString() === searchQuery.trim())
      ).slice(0, 8)
    : [];

  // Metrics to compare
  const metrics = [
    { label: 'Atomic Number (Z)', key: 'number', unit: '', max: 118 },
    { label: 'Atomic Mass', key: 'atomicMass', unit: 'u', max: 294, format: (v: number) => (v ? v.toFixed(3) : 'N/A') },
    { label: 'Atomic Radius', key: 'atomicRadius', unit: 'pm', max: 270 },
    { label: 'Electronegativity', key: 'electronegativity', unit: 'Pauling', max: 4.0, format: (v: number) => (v ? v.toFixed(2) : 'N/A') },
    { label: '1st Ionization Energy', key: 'ionizationEnergy', unit: 'kJ/mol', max: 2372 },
    { label: 'Electron Affinity', key: 'electronAffinity', unit: 'kJ/mol', max: 350 },
    { label: 'Melting Point', key: 'meltingPoint', unit: 'K', max: 3823, format: (v: number) => (v ? `${v} K (${Math.round(v - 273.15)}°C)` : 'N/A') },
    { label: 'Boiling Point', key: 'boilingPoint', unit: 'K', max: 5900, format: (v: number) => (v ? `${v} K (${Math.round(v - 273.15)}°C)` : 'N/A') },
    { label: 'Density', key: 'density', unit: 'g/cm³', max: 22.6 },
    { label: 'Valence Electrons', key: 'valenceElectrons', unit: 'e⁻', max: 8 },
    { label: 'Thermal Conductivity', key: 'thermalConductivity', unit: 'W/(m·K)', max: 430 },
    { label: 'Electrical Conductivity', key: 'electricalConductivity', unit: 'MS/m', max: 63 }
  ];

  // Quick Preset comparisons
  const presets = [
    { label: 'Alkali Period 2-4 (Li vs Na vs K)', numbers: [3, 11, 19] },
    { label: 'Halogen Trend (F vs Cl vs Br vs I)', numbers: [9, 17, 35, 53] },
    { label: 'Period 3 Cross-Section (Na vs Al vs P vs Cl)', numbers: [11, 13, 15, 17] },
    { label: 'Coinage Metals (Cu vs Ag vs Au)', numbers: [29, 47, 79] },
    { label: 'Life Elements (C vs N vs O vs P)', numbers: [6, 7, 8, 15] }
  ];

  const applyPreset = (nums: number[]) => {
    const matched = nums.map((n) => ALL_118_ELEMENTS.find((el) => el.number === n)).filter(Boolean) as ChemicalElement[];
    setSelectedElements(matched);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-xl animate-fade-in overflow-y-auto">
      <div className="w-full max-w-5xl rounded-3xl bg-[#090d16] border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="p-5 sm:p-6 border-b border-white/10 bg-white/[0.02] flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-400">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold font-display-periodic text-white tracking-tight">
                MULTI-ELEMENT COMPARATIVE OBSERVATORY
              </h2>
              <p className="text-xs text-slate-400 font-mono">
                Side-by-side quantum metrics, atomic radius bars & property diff engine (Compare 2 to 4 elements)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 rounded-2xl bg-white/[0.05] hover:bg-white/[0.1] text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Preset Selector & Quick Add Bar */}
        <div className="p-4 border-b border-white/10 bg-white/[0.01] flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
          <div className="flex items-center gap-2 overflow-x-auto pb-1 max-w-full">
            <span className="text-slate-500 uppercase tracking-wider text-[10px]">Presets:</span>
            {presets.map((p) => (
              <button
                key={p.label}
                onClick={() => applyPreset(p.numbers)}
                className="px-2.5 py-1 rounded-xl bg-white/[0.03] border border-white/5 text-slate-300 hover:text-white hover:bg-white/10 hover:border-cyan-500/30 whitespace-nowrap transition-all"
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Add Element Input */}
          <div className="relative">
            <input
              type="text"
              placeholder="+ Add element by name/Z..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              disabled={selectedElements.length >= 4}
              className="px-3 py-1.5 rounded-xl bg-white/[0.05] border border-white/10 text-xs font-mono text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400/60"
            />
            {searchResults.length > 0 && (
              <div className="absolute right-0 top-full mt-1.5 w-56 rounded-2xl bg-slate-900 border border-white/15 shadow-2xl p-1 z-30 space-y-0.5">
                {searchResults.map((el) => (
                  <button
                    key={el.number}
                    onClick={() => {
                      handleAddElement(el);
                      setSearchQuery('');
                    }}
                    className="w-full p-2 rounded-xl text-left hover:bg-cyan-500/20 text-xs flex items-center justify-between text-slate-200 hover:text-white"
                  >
                    <span>
                      {el.number}. {el.name} ({el.symbol})
                    </span>
                    <span className="text-[10px] text-cyan-300">{el.category.split('-')[0]}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Selected Elements Card Header Strip */}
        <div className="p-4 sm:p-6 grid grid-cols-2 sm:grid-cols-4 gap-3 bg-black/30 border-b border-white/5">
          {selectedElements.map((el) => (
            <div
              key={el.number}
              className="p-4 rounded-2xl border bg-white/[0.02] relative group transition-all"
              style={{ borderColor: el.colorHex || '#38bdf8' }}
            >
              <button
                onClick={() => handleRemoveElement(el.number)}
                className="absolute top-2.5 right-2.5 p-1 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-all opacity-70 group-hover:opacity-100"
                title="Remove element"
              >
                <X className="w-3.5 h-3.5" />
              </button>

              <div className="flex items-center gap-3">
                <div
                  className="w-12 h-12 rounded-xl border flex flex-col items-center justify-center font-mono shadow-md"
                  style={{
                    borderColor: el.colorHex || '#38bdf8',
                    backgroundColor: 'rgba(255, 255, 255, 0.04)'
                  }}
                >
                  <span className="text-[9px] text-slate-400 font-bold leading-none">{el.number}</span>
                  <span className="text-lg font-bold font-display-periodic text-white leading-tight">
                    {el.symbol}
                  </span>
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm truncate font-display-periodic">{el.name}</h3>
                  <p className="text-[10px] text-slate-400 font-mono">
                    Group {el.group} • Period {el.period}
                  </p>
                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-white/5 text-cyan-300 font-mono">
                    {el.block}-Block
                  </span>
                </div>
              </div>

              {/* Relative Atomic Radius Scale Bubble */}
              <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between text-[11px] font-mono">
                <span className="text-slate-400">Atomic Radius:</span>
                <span className="text-cyan-300 font-bold">{el.atomicRadius ? `${el.atomicRadius} pm` : 'N/A'}</span>
              </div>
            </div>
          ))}

          {selectedElements.length < 4 && (
            <div className="p-4 rounded-2xl border border-dashed border-white/10 bg-white/[0.01] flex flex-col items-center justify-center text-center p-4">
              <span className="text-slate-500 text-xs font-mono mb-1">Slot Available</span>
              <span className="text-[10px] text-slate-600 font-mono">Add up to 4 elements to compare</span>
            </div>
          )}
        </div>

        {/* Metrics Matrix Area */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
          <div className="space-y-3">
            {metrics.map((metric) => {
              const maxVal = metric.max;
              return (
                <div
                  key={metric.key}
                  className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 hover:border-white/10 transition-all space-y-2.5 font-mono text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-300 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                      {metric.label}
                    </span>
                    <span className="text-[10px] text-slate-500">Unit: {metric.unit || 'Standard'}</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
                    {selectedElements.map((el) => {
                      const rawVal = (el as any)[metric.key];
                      const numVal = typeof rawVal === 'number' ? rawVal : 0;
                      const ratio = maxVal ? Math.min(1, Math.max(0, numVal / maxVal)) : 0;
                      const displayVal = metric.format
                        ? metric.format(rawVal)
                        : rawVal !== undefined && rawVal !== null
                        ? `${rawVal} ${metric.unit}`
                        : 'N/A';

                      return (
                        <div key={el.number} className="space-y-1.5">
                          <div className="flex items-center justify-between text-[11px]">
                            <span className="text-slate-400 font-bold">{el.symbol}:</span>
                            <span className="text-white font-bold">{displayVal}</span>
                          </div>
                          {typeof rawVal === 'number' && maxVal && (
                            <div className="w-full bg-slate-800/80 h-2 rounded-full overflow-hidden border border-white/5">
                              <div
                                className="h-full rounded-full transition-all duration-500"
                                style={{
                                  width: `${Math.max(5, ratio * 100)}%`,
                                  backgroundColor: el.colorHex || '#38bdf8'
                                }}
                              />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Two-Element "What Changes?" Trend Analysis Engine if exactly 2 elements selected */}
          {selectedElements.length === 2 && (
            <div className="p-5 rounded-3xl bg-cyan-950/20 border border-cyan-500/30 space-y-3 font-mono text-xs">
              <div className="flex items-center gap-2.5 text-cyan-300 font-bold uppercase tracking-wider">
                <TrendingUp className="w-4 h-4" />
                <span>
                  Property Diff Engine: {selectedElements[0].symbol} → {selectedElements[1].symbol}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/5 space-y-1">
                  <span className="text-slate-400 text-[10px] block">Δ ATOMIC RADIUS</span>
                  <div className="text-sm font-bold text-white">
                    {selectedElements[0].atomicRadius && selectedElements[1].atomicRadius
                      ? `${selectedElements[1].atomicRadius - selectedElements[0].atomicRadius > 0 ? '+' : ''}${
                          selectedElements[1].atomicRadius - selectedElements[0].atomicRadius
                        } pm`
                      : 'N/A'}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/5 space-y-1">
                  <span className="text-slate-400 text-[10px] block">Δ ELECTRONEGATIVITY</span>
                  <div className="text-sm font-bold text-white">
                    {selectedElements[0].electronegativity !== undefined &&
                    selectedElements[1].electronegativity !== undefined &&
                    selectedElements[0].electronegativity !== null &&
                    selectedElements[1].electronegativity !== null
                      ? `${selectedElements[1].electronegativity - selectedElements[0].electronegativity > 0 ? '+' : ''}${(
                          selectedElements[1].electronegativity - selectedElements[0].electronegativity
                        ).toFixed(2)}`
                      : 'N/A'}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/5 space-y-1">
                  <span className="text-slate-400 text-[10px] block">Δ 1st IONIZATION ENERGY</span>
                  <div className="text-sm font-bold text-white">
                    {selectedElements[0].ionizationEnergy && selectedElements[1].ionizationEnergy
                      ? `${selectedElements[1].ionizationEnergy - selectedElements[0].ionizationEnergy > 0 ? '+' : ''}${
                          selectedElements[1].ionizationEnergy - selectedElements[0].ionizationEnergy
                        } kJ/mol`
                      : 'N/A'}
                  </div>
                </div>
              </div>

              <p className="text-slate-300 text-xs leading-relaxed pt-1">
                {selectedElements[0].period === selectedElements[1].period ? (
                  <>
                    Moving horizontally from <strong className="text-cyan-300">{selectedElements[0].name}</strong> to{' '}
                    <strong className="text-cyan-300">{selectedElements[1].name}</strong> across Period{' '}
                    {selectedElements[0].period}: Effective nuclear charge (Z_eff) increases as protons are
                    added to the nucleus while electrons enter the same quantum shell, pulling electron clouds closer and
                    increasing electronegativity and ionization enthalpy.
                  </>
                ) : selectedElements[0].group === selectedElements[1].group ? (
                  <>
                    Moving vertically from <strong className="text-cyan-300">{selectedElements[0].name}</strong> to{' '}
                    <strong className="text-cyan-300">{selectedElements[1].name}</strong> down Group{' '}
                    {selectedElements[0].group}: Principal quantum numbers (n) increase with added electron shells,
                    increasing nuclear shielding and increasing atomic radius while decreasing electronegativity.
                  </>
                ) : (
                  <>
                    Comparison between <strong className="text-cyan-300">{selectedElements[0].name}</strong> (Group{' '}
                    {selectedElements[0].group}, Period {selectedElements[0].period}) and{' '}
                    <strong className="text-cyan-300">{selectedElements[1].name}</strong> (Group{' '}
                    {selectedElements[1].group}, Period {selectedElements[1].period}): reflects combined Coulombic pull
                    and quantum shell differences.
                  </>
                )}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
