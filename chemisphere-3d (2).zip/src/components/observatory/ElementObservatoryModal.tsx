import React, { useState, useEffect, useRef } from 'react';
import * as THREE from 'three';
import {
  X,
  Sparkles,
  Orbit,
  Atom,
  Layers,
  Zap,
  Flame,
  Activity,
  Compass,
  FileText,
  Radio,
  Sliders,
  ChevronRight,
  Info,
  Maximize2,
  RotateCcw,
  CheckCircle,
  ShieldAlert,
  ShieldCheck,
  TrendingUp,
  Cpu,
  AlertTriangle,
  Beaker,
  History,
  BookOpen,
  ArrowRight
} from 'lucide-react';
import { ChemicalElement, NavigationTab } from '../../types';
import { OrbitalCanvas3D } from '../3d/OrbitalCanvas3D';
import { InteractiveBohrAtom3D } from '../3d/InteractiveBohrAtom3D';
import { getOrbitalByType } from '../../data/orbitals';

interface ElementObservatoryModalProps {
  element: ChemicalElement;
  isOpen: boolean;
  onClose: () => void;
  onSelectElement?: (el: ChemicalElement) => void;
  onNavigate?: (tab: NavigationTab) => void;
}

export type ObservatoryTab =
  | 'overview'
  | 'atom-3d'
  | 'orbitals'
  | 'electronic'
  | 'spectrum'
  | 'physical'
  | 'chemical'
  | 'isotopes'
  | 'history'
  | 'compounds'
  | 'reactions'
  | 'safety';

export const ElementObservatoryModal: React.FC<ElementObservatoryModalProps> = ({
  element,
  isOpen,
  onClose,
  onSelectElement,
  onNavigate
}) => {
  const [activeTab, setActiveTab] = useState<ObservatoryTab>('atom-3d');
  const [selectedShellIndex, setSelectedShellIndex] = useState<number | null>(null);
  const [spinSpeed, setSpinSpeed] = useState<number>(1);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [isNucleusInspectorOpen, setIsNucleusInspectorOpen] = useState<boolean>(false);

  // Selected orbital for quantum orbital tab
  const [selectedOrbitalType, setSelectedOrbitalType] = useState<string>(
    element.block === 'd' ? '3dz2' : element.block === 'p' ? '2pz' : element.block === 'f' ? '4fz3' : '2s'
  );
  const [probThreshold, setProbThreshold] = useState<number>(85);
  const [showNodal, setShowNodal] = useState<boolean>(true);

  // 3D Atom Canvas Refs
  const atomContainerRef = useRef<HTMLDivElement | null>(null);
  const atomSceneRef = useRef<THREE.Scene | null>(null);
  const atomRendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const atomCameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const atomGroupRef = useRef<THREE.Group | null>(null);
  const frameIdRef = useRef<number>(0);

  // Mouse interaction state for 3D Atom
  const isDraggingRef = useRef(false);
  const prevMousePos = useRef({ x: 0, y: 0 });

  // Calculate Subatomic particles
  const protons = element.number;
  const atomicWeight = typeof element.atomicMass === 'number' ? element.atomicMass : parseFloat(element.atomicMass as string) || protons * 2;
  const neutrons = Math.round(atomicWeight) - protons;

  // Electron shells breakdown
  const electronShells = element.electronShells || element.shells || [protons];
  const shellNames = ['K (n=1)', 'L (n=2)', 'M (n=3)', 'N (n=4)', 'O (n=5)', 'P (n=6)', 'Q (n=7)'];

  // Reset 3D camera
  const handleResetCamera = () => {
    if (atomCameraRef.current && atomGroupRef.current) {
      atomCameraRef.current.position.set(0, 0, 8.5);
      atomGroupRef.current.rotation.set(0, 0, 0);
    }
  };

  // 3D Interactive Atom Initialization (Concentric Coplanar Shells)
  useEffect(() => {
    if (!isOpen || activeTab !== 'atom-3d') return;

    const container = atomContainerRef.current;
    if (!container) return;

    // Cleanup previous instance
    while (container.firstChild) {
      container.removeChild(container.firstChild);
    }

    const scene = new THREE.Scene();
    atomSceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 1000);
    camera.position.set(0, 0, 8.5);
    atomCameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);
    atomRendererRef.current = renderer;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(ambientLight);

    const pointLight = new THREE.PointLight(0x38bdf8, 2.5, 50);
    pointLight.position.set(5, 5, 8);
    scene.add(pointLight);

    const backLight = new THREE.PointLight(0xef4444, 1.8, 50);
    backLight.position.set(-5, -5, -8);
    scene.add(backLight);

    const atomGroup = new THREE.Group();
    scene.add(atomGroup);
    atomGroupRef.current = atomGroup;

    // 1. Central Nucleus Cluster (Protons + Neutrons)
    const nucleusGroup = new THREE.Group();
    atomGroup.add(nucleusGroup);

    const pMat = new THREE.MeshStandardMaterial({ color: 0xef4444, roughness: 0.3, metalness: 0.2 });
    const nMat = new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.3, metalness: 0.2 });
    const sphereGeo = new THREE.SphereGeometry(0.08, 12, 12);

    const displayNucleons = Math.min(36, protons + neutrons);
    for (let i = 0; i < displayNucleons; i++) {
      const isProton = i % 2 === 0;
      const pMesh = new THREE.Mesh(sphereGeo, isProton ? pMat : nMat);
      const phi = Math.acos(-1 + (2 * i) / displayNucleons);
      const theta = Math.sqrt(displayNucleons * Math.PI) * phi;
      const r = 0.32 * Math.cbrt(i / displayNucleons + 0.1);
      pMesh.position.set(r * Math.sin(phi) * Math.cos(theta), r * Math.sin(phi) * Math.sin(theta), r * Math.cos(phi));
      nucleusGroup.add(pMesh);
    }

    // High-visibility Nucleus Badge
    const nucCanvas = document.createElement('canvas');
    nucCanvas.width = 384;
    nucCanvas.height = 160;
    const nucCtx = nucCanvas.getContext('2d');
    if (nucCtx) {
      nucCtx.clearRect(0, 0, 384, 160);
      nucCtx.fillStyle = 'rgba(15, 23, 42, 0.9)';
      nucCtx.strokeStyle = '#ef4444';
      nucCtx.lineWidth = 4;
      nucCtx.beginPath();
      nucCtx.roundRect(12, 12, 360, 136, 24);
      nucCtx.fill();
      nucCtx.stroke();

      nucCtx.fillStyle = '#ffffff';
      nucCtx.font = '900 54px "Plus Jakarta Sans", sans-serif';
      nucCtx.textAlign = 'center';
      nucCtx.textBaseline = 'middle';
      nucCtx.fillText(`${element.symbol} (+${protons}e)`, 192, 80);

      const nucTex = new THREE.CanvasTexture(nucCanvas);
      nucTex.minFilter = THREE.LinearFilter;
      const nucSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: nucTex, transparent: true, depthTest: false }));
      nucSprite.position.set(0, 0.8, 0);
      nucSprite.scale.set(1.2, 0.5, 1);
      nucleusGroup.add(nucSprite);
    }

    // 2. Concentric Coplanar Electron Shells & Orbiting Electrons
    const shellsGroup = new THREE.Group();
    atomGroup.add(shellsGroup);

    const shellMeshes: { ring: THREE.Line; electrons: THREE.Mesh[]; speed: number; angles: number[] }[] = [];

    electronShells.forEach((count, sIdx) => {
      const shellRadius = 1.1 + sIdx * 0.65;
      const isHighlighted = selectedShellIndex === sIdx;

      // Shell circular orbit path
      const pts: THREE.Vector3[] = [];
      for (let i = 0; i <= 64; i++) {
        const a = (i / 64) * Math.PI * 2;
        pts.push(new THREE.Vector3(Math.cos(a) * shellRadius, Math.sin(a) * shellRadius, 0));
      }
      const ring = new THREE.Line(
        new THREE.BufferGeometry().setFromPoints(pts),
        new THREE.LineBasicMaterial({
          color: isHighlighted ? 0x38bdf8 : 0x475569,
          transparent: true,
          opacity: isHighlighted ? 0.95 : 0.45,
          linewidth: isHighlighted ? 2.5 : 1
        })
      );
      shellsGroup.add(ring);

      // Distribute electrons on shell ring
      const eMeshes: THREE.Mesh[] = [];
      const angles: number[] = [];

      for (let e = 0; e < count; e++) {
        const initAngle = (e / count) * Math.PI * 2;
        angles.push(initAngle);

        const eMesh = new THREE.Mesh(
          new THREE.SphereGeometry(0.09, 16, 16),
          new THREE.MeshStandardMaterial({
            color: isHighlighted ? 0x38bdf8 : 0x06b6d4,
            emissive: 0x0284c7,
            emissiveIntensity: 0.7
          })
        );
        shellsGroup.add(eMesh);
        eMeshes.push(eMesh);
      }

      shellMeshes.push({
        ring,
        electrons: eMeshes,
        speed: (0.02 / (sIdx + 1)) * (sIdx % 2 === 0 ? 1 : -1),
        angles
      });
    });

    const handleResize = () => {
      if (!container || !atomRendererRef.current || !atomCameraRef.current) return;
      atomCameraRef.current.aspect = container.clientWidth / container.clientHeight;
      atomCameraRef.current.updateProjectionMatrix();
      atomRendererRef.current.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    const animate = () => {
      if (!isPaused) {
        shellMeshes.forEach((item, sIdx) => {
          const shellRadius = 1.1 + sIdx * 0.65;
          for (let e = 0; e < item.electrons.length; e++) {
            item.angles[e] += item.speed * spinSpeed;
            const a = item.angles[e];
            const p = new THREE.Vector3(Math.cos(a) * shellRadius, Math.sin(a) * shellRadius, 0);
            item.electrons[e].position.copy(p);
          }
        });
      }

      if (atomGroupRef.current && !isDraggingRef.current) {
        atomGroupRef.current.rotation.y += 0.003;
      }

      renderer.render(scene, camera);
      frameIdRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameIdRef.current);
      renderer.dispose();
    };
  }, [isOpen, activeTab, element, selectedShellIndex, spinSpeed, isPaused]);

  if (!isOpen) return null;

  const activeOrbitalData = getOrbitalByType(selectedOrbitalType) || getOrbitalByType('2pz')!;

  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current || !atomGroupRef.current) return;
    const dx = e.clientX - prevMousePos.current.x;
    const dy = e.clientY - prevMousePos.current.y;
    atomGroupRef.current.rotation.y += dx * 0.01;
    atomGroupRef.current.rotation.x += dy * 0.01;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  // 12 Section Definitions
  const sections: { id: ObservatoryTab; label: string; icon: React.ComponentType<any> }[] = [
    { id: 'overview', label: '1. Overview', icon: Info },
    { id: 'atom-3d', label: '2. 3D Atom & Shells', icon: Atom },
    { id: 'orbitals', label: '3. Quantum Orbitals', icon: Orbit },
    { id: 'electronic', label: '4. Electronic Structure', icon: Cpu },
    { id: 'spectrum', label: '5. Spectrum & Transitions', icon: Sparkles },
    { id: 'physical', label: '6. Physical & Thermal', icon: Flame },
    { id: 'chemical', label: '7. Chemical & Reactivity', icon: Zap },
    { id: 'isotopes', label: '8. Isotopes & Decay', icon: Activity },
    { id: 'history', label: '9. History & Discovery', icon: History },
    { id: 'compounds', label: '10. Compounds', icon: Layers },
    { id: 'reactions', label: '11. Reactions', icon: Beaker },
    { id: 'safety', label: '12. Safety & Hazards', icon: ShieldAlert }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-5 bg-black/85 backdrop-blur-xl animate-fade-in overflow-y-auto">
      <div className="w-full max-w-5xl rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-[94vh]">
        {/* Header Bar */}
        <div className="p-4 sm:p-6 border-b border-white/10 bg-white/[0.02] flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div
              className="w-14 h-14 rounded-2xl border flex flex-col items-center justify-center font-mono shadow-lg shadow-cyan-500/10"
              style={{
                borderColor: element.colorHex || '#38bdf8',
                backgroundColor: 'rgba(255, 255, 255, 0.04)'
              }}
            >
              <span className="text-[10px] text-slate-400 font-bold leading-none">{element.number}</span>
              <span className="text-xl font-bold font-display-periodic text-white leading-tight">
                {element.symbol}
              </span>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-bold font-display-periodic text-white tracking-tight">
                  {element.name}
                </h2>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-400/30 font-mono">
                  {element.category.replace('-', ' ').toUpperCase()}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                Atomic Mass: {typeof element.atomicMass === 'number' ? element.atomicMass.toFixed(4) : element.atomicMass} u • Group {element.group}, Period {element.period} ({element.block}-Block)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 rounded-2xl bg-white/[0.05] hover:bg-white/[0.1] text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 10 Modular Section Navigation Tabs */}
        <div className="flex items-center gap-1.5 px-4 sm:px-6 border-b border-white/10 bg-white/[0.01] overflow-x-auto py-2">
          {sections.map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-mono transition-all flex items-center gap-1.5 whitespace-nowrap ${
                  isSelected
                    ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-400/40 shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Body Area */}
        <div className="flex-1 p-5 sm:p-6 overflow-y-auto">
          {/* SECTION 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6 font-mono text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
                  <span className="text-slate-400 text-[10px] uppercase">Standard State</span>
                  <div className="text-sm font-bold text-white uppercase">{element.standardState || 'Solid'}</div>
                </div>
                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
                  <span className="text-slate-400 text-[10px] uppercase">CAS Registry</span>
                  <div className="text-sm font-bold text-cyan-300">{element.casNumber || '7440-xx-x'}</div>
                </div>
                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
                  <span className="text-slate-400 text-[10px] uppercase">Electron Configuration</span>
                  <div className="text-sm font-bold text-white truncate">{element.electronConfiguration}</div>
                </div>
                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
                  <span className="text-slate-400 text-[10px] uppercase">Valence Electrons</span>
                  <div className="text-sm font-bold text-orange-300">{element.valenceElectrons || 1} e⁻</div>
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2">
                <h3 className="text-cyan-300 font-bold uppercase tracking-wider text-xs">Identity Summary</h3>
                <p className="text-slate-300 text-xs leading-relaxed">
                  {element.summary ||
                    `${element.name} is a chemical element with symbol ${element.symbol} and atomic number ${element.number}. Classified as a ${element.category.replace('-', ' ')}, it resides in Group ${element.group}, Period ${element.period} within the ${element.block}-block of the periodic table.`}
                </p>
              </div>
            </div>
          )}

          {/* SECTION 2: 3D ATOM & CONCENTRIC SHELLS */}
          {activeTab === 'atom-3d' && (
            <div className="w-full">
              <InteractiveBohrAtom3D element={element} className="h-[460px]" />
            </div>
          )}

          {/* SECTION 3: 3D QUANTUM ORBITALS */}
          {activeTab === 'orbitals' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
              <div className="lg:col-span-7 h-[380px] rounded-3xl bg-black/40 border border-white/10 overflow-hidden relative">
                <OrbitalCanvas3D
                  orbital={activeOrbitalData}
                  orbitalType={selectedOrbitalType}
                  probabilityThreshold={probThreshold}
                  showNodalPlanes={showNodal}
                  showAxes={true}
                  wireframe={false}
                  autoRotate={true}
                />
              </div>

              <div className="lg:col-span-5 space-y-4 font-mono text-xs">
                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 space-y-3">
                  <span className="text-cyan-300 font-bold uppercase tracking-wider block">
                    Select Orbital Subshell ({element.block}-Block)
                  </span>

                  <div className="grid grid-cols-3 gap-2">
                    {['1s', '2s', '2px', '2py', '2pz', '3dz2', '3dx2-y2', '3dxy', '4fz3'].map((orb) => (
                      <button
                        key={orb}
                        onClick={() => setSelectedOrbitalType(orb)}
                        className={`py-2 px-2.5 rounded-xl border text-center font-bold transition-all ${
                          selectedOrbitalType === orb
                            ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-md'
                            : 'bg-white/[0.02] border-white/5 text-slate-400 hover:text-white'
                        }`}
                      >
                        {orb}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 space-y-3">
                  <div className="flex justify-between items-center text-slate-300">
                    <span>Probability Threshold: {probThreshold}%</span>
                    <button
                      onClick={() => setShowNodal((s) => !s)}
                      className={`text-[10px] px-2 py-0.5 rounded border ${
                        showNodal ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300' : 'bg-slate-800 border-slate-700 text-slate-400'
                      }`}
                    >
                      {showNodal ? 'Nodal Planes ON' : 'Nodal Planes OFF'}
                    </button>
                  </div>

                  <input
                    type="range"
                    min={50}
                    max={99}
                    value={probThreshold}
                    onChange={(e) => setProbThreshold(parseInt(e.target.value))}
                    className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
                  />

                  <div className="text-[11px] text-slate-400 space-y-1 bg-black/40 p-2.5 rounded-xl border border-white/5">
                    <div>Quantum Numbers: n={activeOrbitalData?.n}, l={activeOrbitalData?.l}, m_l={activeOrbitalData?.ml}</div>
                    <div>Radial Nodes: {activeOrbitalData?.radialNodes} • Angular Nodes: {activeOrbitalData?.angularNodes}</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 4: ELECTRONIC STRUCTURE */}
          {activeTab === 'electronic' && (
            <div className="space-y-6 font-mono text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
                  <span className="text-slate-400 text-[10px] uppercase">Valence Shell Electrons</span>
                  <div className="text-base font-bold text-cyan-300">{element.valenceElectrons || 1} e⁻</div>
                </div>
                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
                  <span className="text-slate-400 text-[10px] uppercase">Quantum Block Type</span>
                  <div className="text-base font-bold text-white uppercase">{element.block}-block</div>
                </div>
                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
                  <span className="text-slate-400 text-[10px] uppercase">Ground State Spectroscopic Term</span>
                  <div className="text-base font-bold text-orange-300">{element.quantumStateTerm || '²S₁/₂'}</div>
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/5 space-y-3">
                <h3 className="text-cyan-300 font-bold uppercase tracking-wider text-xs">Subshell Orbital Capacities</h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3 rounded-xl bg-white/[0.03] border border-white/5 text-center">
                    <span className="text-[10px] text-slate-400 block">s-subshell (l=0)</span>
                    <span className="text-sm font-bold text-white">Max 2 e⁻</span>
                  </div>
                  <div className="p-3 rounded-xl bg-white/[0.03] border border-white/5 text-center">
                    <span className="text-[10px] text-slate-400 block">p-subshell (l=1)</span>
                    <span className="text-sm font-bold text-cyan-300">Max 6 e⁻</span>
                  </div>
                  <div className="p-3 rounded-xl bg-white/[0.03] border border-white/5 text-center">
                    <span className="text-[10px] text-slate-400 block">d-subshell (l=2)</span>
                    <span className="text-sm font-bold text-amber-300">Max 10 e⁻</span>
                  </div>
                  <div className="p-3 rounded-xl bg-white/[0.03] border border-white/5 text-center">
                    <span className="text-[10px] text-slate-400 block">f-subshell (l=3)</span>
                    <span className="text-sm font-bold text-purple-300">Max 14 e⁻</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 5: SPECTRUM & TRANSITIONS */}
          {activeTab === 'spectrum' && (
            <div className="space-y-5 font-mono text-xs">
              <div className="p-5 rounded-2xl bg-gradient-to-r from-purple-950/40 via-[#090d16] to-cyan-950/40 border border-purple-500/30 space-y-4">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-purple-400" />
                      <span>{element.name} ({element.symbol}) Emission Spectrum & Energy Transitions</span>
                    </h3>
                    <p className="text-slate-400 text-xs">
                      Discrete characteristic photons emitted upon valence de-excitation
                    </p>
                  </div>

                  {onNavigate && (
                    <button
                      onClick={() => {
                        onClose();
                        onNavigate('atomic-spectra');
                      }}
                      className="px-4 py-2 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-bold transition-all flex items-center gap-2 shadow-lg shadow-purple-500/20 active:scale-95"
                    >
                      <span>OPEN FULL ATOMIC SPECTRA LAB</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <div className="p-4 rounded-xl bg-black/60 border border-white/10 space-y-2">
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>380 nm (UV / Violet)</span>
                    <span>550 nm (Green)</span>
                    <span>750 nm (Red)</span>
                  </div>
                  <div className="h-12 rounded-lg bg-[#030712] border border-white/20 relative overflow-hidden flex items-center">
                    {/* Simulated representative lines */}
                    {[410, 434, 486, 546, 589, 656].map((lambda, idx) => {
                      if (element.number % 2 === 0 && idx % 2 === 0) return null;
                      const leftPercent = ((lambda - 380) / (750 - 380)) * 100;
                      return (
                        <div
                          key={idx}
                          style={{
                            left: `${leftPercent}%`,
                            backgroundColor: element.colorHex || '#38bdf8',
                            boxShadow: `0 0 10px ${element.colorHex || '#38bdf8'}`
                          }}
                          className="absolute top-0 bottom-0 w-1.5 opacity-90"
                        />
                      );
                    })}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-slate-300">
                  <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5">
                    <span className="text-slate-500 text-[10px] block">Ionization Potential</span>
                    <span className="text-sm font-bold text-cyan-300">{element.ionizationEnergy ? `${element.ionizationEnergy} kJ/mol` : 'N/A'}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5">
                    <span className="text-slate-500 text-[10px] block">Ground Configuration</span>
                    <span className="text-sm font-bold text-amber-300">{element.electronConfiguration}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5">
                    <span className="text-slate-500 text-[10px] block">Spectroscopic Block</span>
                    <span className="text-sm font-bold text-purple-300">{element.block}-block (l={element.block === 's' ? 0 : element.block === 'p' ? 1 : element.block === 'd' ? 2 : 3})</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 6: PHYSICAL & THERMAL */}
          {activeTab === 'physical' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-xs">
              <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/10 space-y-3">
                <h3 className="text-cyan-300 font-bold uppercase tracking-wider text-xs flex items-center gap-2">
                  <Flame className="w-4 h-4 text-cyan-400" />
                  <span>Thermodynamics & Density</span>
                </h3>
                <div className="space-y-2 text-slate-300">
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span>Density:</span>
                    <span className="text-white font-bold">{element.density ? `${element.density} g/cm³` : 'N/A'}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span>Melting Point:</span>
                    <span className="text-white font-bold">{element.meltingPoint ? `${element.meltingPoint} K (${Math.round(element.meltingPoint - 273.15)} °C)` : 'N/A'}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span>Boiling Point:</span>
                    <span className="text-white font-bold">{element.boilingPoint ? `${element.boilingPoint} K (${Math.round(element.boilingPoint - 273.15)} °C)` : 'N/A'}</span>
                  </div>
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/10 space-y-3">
                <h3 className="text-orange-300 font-bold uppercase tracking-wider text-xs flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-orange-400" />
                  <span>Radii & Conductivities</span>
                </h3>
                <div className="space-y-2 text-slate-300">
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span>Atomic Radius:</span>
                    <span className="text-white font-bold">{element.atomicRadius ? `${element.atomicRadius} pm` : 'N/A'}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span>Covalent Radius:</span>
                    <span className="text-white font-bold">{element.covalentRadius ? `${element.covalentRadius} pm` : 'N/A'}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span>Thermal Conductivity:</span>
                    <span className="text-white font-bold">{element.thermalConductivity ? `${element.thermalConductivity} W/(m·K)` : 'N/A'}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span>Electrical Conductivity:</span>
                    <span className="text-white font-bold">{element.electricalConductivity ? `${element.electricalConductivity} MS/m` : 'N/A'}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 7: CHEMICAL & REACTIVITY */}
          {activeTab === 'chemical' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-xs">
              <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/10 space-y-3">
                <h3 className="text-orange-300 font-bold uppercase tracking-wider text-xs flex items-center gap-2">
                  <Zap className="w-4 h-4 text-orange-400" />
                  <span>Energetics & Potentials</span>
                </h3>
                <div className="space-y-2 text-slate-300">
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span>Electronegativity (Pauling):</span>
                    <span className="text-white font-bold">{element.electronegativity !== null && element.electronegativity !== undefined ? element.electronegativity : 'N/A'}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span>1st Ionization Energy:</span>
                    <span className="text-white font-bold">{element.ionizationEnergy ? `${element.ionizationEnergy} kJ/mol` : 'N/A'}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span>Electron Affinity:</span>
                    <span className="text-white font-bold">{element.electronAffinity !== null && element.electronAffinity !== undefined ? `${element.electronAffinity} kJ/mol` : 'N/A'}</span>
                  </div>
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/10 space-y-3">
                <h3 className="text-cyan-300 font-bold uppercase tracking-wider text-xs flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  <span>Oxidation States & Ions</span>
                </h3>
                <div className="space-y-2 text-slate-300">
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span>Oxidation States:</span>
                    <span className="text-white font-bold">{Array.isArray(element.oxidationStates) ? element.oxidationStates.join(', ') : '0'}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span>Reactivity Index:</span>
                    <span className="text-white font-bold">{element.reactivity || 'Moderate'}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span>Common Ions:</span>
                    <span className="text-white font-bold">{element.commonIons?.join(', ') || `${element.symbol}⁺, ${element.symbol}²⁺`}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 8: ISOTOPES & NUCLEAR STABILITY */}
          {activeTab === 'isotopes' && (
            <div className="space-y-4 font-mono text-xs">
              <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/10 space-y-3">
                <h3 className="text-cyan-300 font-bold uppercase tracking-wider text-xs flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  <span>Isotopic Abundance & Decay Profiles</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {(element.isotopes || [
                    { massNumber: Math.round(atomicWeight), abundance: '98.5%', isStable: true },
                    { massNumber: Math.round(atomicWeight) + 1, abundance: '1.4%', isStable: true },
                    { massNumber: Math.round(atomicWeight) + 2, abundance: '0.1%', isStable: false, halfLife: '5.2 yrs', decayMode: 'β⁻' }
                  ]).map((iso, idx) => (
                    <div key={idx} className="p-3.5 rounded-xl bg-white/[0.03] border border-white/5 space-y-1">
                      <div className="flex justify-between items-center">
                        <span className="text-white font-bold text-sm">^{iso.massNumber}{element.symbol}</span>
                        <span className={`text-[10px] px-2 py-0.5 rounded ${iso.isStable ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'}`}>
                          {iso.isStable ? 'Stable' : 'Radioactive'}
                        </span>
                      </div>
                      <div className="text-slate-400 text-[11px]">Abundance: <strong className="text-slate-200">{iso.abundance}</strong></div>
                      {!iso.isStable && iso.halfLife && (
                        <div className="text-amber-300 text-[10px]">Half-life: {iso.halfLife} ({iso.decayMode || 'Decay'})</div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* SECTION 7: HISTORY & DISCOVERY */}
          {activeTab === 'history' && (
            <div className="space-y-6 font-mono text-xs">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 space-y-1">
                  <span className="text-slate-500 uppercase text-[10px] tracking-wider">Year of Discovery</span>
                  <div className="text-sm font-bold text-cyan-300">{element.yearDiscovered || 'Ancient'}</div>
                </div>
                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 space-y-1">
                  <span className="text-slate-500 uppercase text-[10px] tracking-wider">Discoverer(s)</span>
                  <div className="text-sm font-bold text-white truncate">{element.discoveredBy || 'Known since antiquity'}</div>
                </div>
                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 space-y-1">
                  <span className="text-slate-500 uppercase text-[10px] tracking-wider">Discovery Country</span>
                  <div className="text-sm font-bold text-orange-300">{element.discoveryLocation || 'International'}</div>
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/10 space-y-2">
                <h3 className="text-cyan-300 font-bold uppercase tracking-wider text-xs">Historical Narrative</h3>
                <p className="text-slate-300 text-xs leading-relaxed">
                  {element.historicalContext || element.summary}
                </p>
              </div>
            </div>
          )}

          {/* SECTION 8: COMPOUNDS */}
          {activeTab === 'compounds' && (
            <div className="space-y-4 font-mono text-xs">
              <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/10 space-y-3">
                <h3 className="text-cyan-300 font-bold uppercase tracking-wider text-xs flex items-center gap-2">
                  <Layers className="w-4 h-4 text-cyan-400" />
                  <span>Key Inorganic & Coordination Compounds</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {(element.commonCompounds || [`${element.symbol}O₂`, `${element.symbol}Cl₃`, `${element.symbol}H₄`, `${element.symbol}(OH)₂`]).map((cmp, idx) => (
                    <div key={idx} className="p-3.5 rounded-xl bg-white/[0.03] border border-white/5 flex items-center justify-between">
                      <div>
                        <span className="text-white font-bold text-sm block">{cmp}</span>
                        <span className="text-[10px] text-slate-400">Chemical Matrix & Oxide / Halide Complex</span>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
                        Inorganic
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* SECTION 9: CHEMICAL REACTIONS */}
          {activeTab === 'reactions' && (
            <div className="space-y-4 font-mono text-xs">
              <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/10 space-y-3">
                <h3 className="text-orange-300 font-bold uppercase tracking-wider text-xs flex items-center gap-2">
                  <Beaker className="w-4 h-4 text-orange-400" />
                  <span>Balanced Chemical Reaction Profiles</span>
                </h3>
                <div className="space-y-2.5">
                  <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/5 space-y-1">
                    <span className="text-slate-400 text-[10px]">REACTION WITH OXYGEN / COMBUSTION</span>
                    <div className="text-cyan-300 font-bold text-xs">{`${element.symbol} + O₂ → ${element.symbol}O₂ (Exothermic)`}</div>
                  </div>
                  <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/5 space-y-1">
                    <span className="text-slate-400 text-[10px]">REACTION WITH HALOGENS</span>
                    <div className="text-white font-bold text-xs">{`${element.symbol} + Cl₂ → ${element.symbol}Cl₂`}</div>
                  </div>
                  <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/5 space-y-1">
                    <span className="text-slate-400 text-[10px]">REACTION WITH AQUEOUS ACIDS</span>
                    <div className="text-orange-300 font-bold text-xs">{`${element.symbol} + 2HCl(aq) → ${element.symbol}Cl₂(aq) + H₂↑`}</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 10: SAFETY & HAZARDS */}
          {activeTab === 'safety' && (
            <div className="space-y-4 font-mono text-xs">
              <div className="p-5 rounded-2xl bg-white/[0.02] border border-red-500/30 space-y-3">
                <h3 className="text-red-400 font-bold uppercase tracking-wider text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-400" />
                  <span>GHS Hazard Classification & Safety Protocol</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-center">
                    <span className="text-[10px] text-red-300 block">HEALTH HAZARD</span>
                    <span className="text-xs font-bold text-white">{element.number > 82 ? 'Radioactive / Toxic' : 'Standard Lab Care'}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-orange-500/10 border border-orange-500/20 text-center">
                    <span className="text-[10px] text-orange-300 block">FLAMMABILITY / REACTIVITY</span>
                    <span className="text-xs font-bold text-white">{element.group === 1 ? 'High (Pyrophoric in H₂O)' : 'Stable'}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-center">
                    <span className="text-[10px] text-cyan-300 block">HANDLING PPE</span>
                    <span className="text-xs font-bold text-white">Nitrile Gloves, Fume Hood, Goggles</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Nucleus Inspector Sub-Modal */}
      {isNucleusInspectorOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-md rounded-3xl bg-[#090d16] border border-red-500/40 p-6 space-y-4 shadow-2xl text-slate-100 font-mono text-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-xl bg-red-500/20 text-red-400 border border-red-500/40">
                  <Atom className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-white">
                  Nucleus Inspector: ^{Math.round(atomicWeight)}{element.symbol}
                </h3>
              </div>
              <button
                onClick={() => setIsNucleusInspectorOpen(false)}
                className="p-1.5 rounded-xl bg-white/[0.05] text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between p-2.5 rounded-xl bg-white/[0.03] border border-white/5">
                <span className="text-red-400 font-bold">Protons (Z / Nuclear Charge):</span>
                <span className="text-white font-bold">{protons} (+{protons}e)</span>
              </div>
              <div className="flex justify-between p-2.5 rounded-xl bg-white/[0.03] border border-white/5">
                <span className="text-cyan-400 font-bold">Neutrons (N = A - Z):</span>
                <span className="text-white font-bold">{neutrons}</span>
              </div>
              <div className="flex justify-between p-2.5 rounded-xl bg-white/[0.03] border border-white/5">
                <span>Mass Number (A):</span>
                <span className="text-white font-bold">{Math.round(atomicWeight)} u</span>
              </div>
              <div className="flex justify-between p-2.5 rounded-xl bg-white/[0.03] border border-white/5">
                <span>Estimated Binding Energy:</span>
                <span className="text-cyan-300 font-bold">~{(Math.round(atomicWeight) * 8.4).toFixed(1)} MeV</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              Nuclear strong force overcomes Coulombic electrostatic repulsion between {protons} positively charged protons.
            </p>

            <button
              onClick={() => setIsNucleusInspectorOpen(false)}
              className="w-full py-2.5 rounded-xl bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-300 font-bold transition-all"
            >
              Close Inspector
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
