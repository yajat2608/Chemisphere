import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  X,
  TrendingUp,
  Sparkles,
  ArrowRight,
  Activity,
  ChevronRight,
  HelpCircle,
  Play,
  Pause,
  RotateCcw,
  Sliders,
  Eye,
  GitCompare,
  Layers,
  BarChart3,
  Flame,
  Atom,
  Volume2
} from 'lucide-react';
import { ChemicalElement } from '../../types';
import { ALL_118_ELEMENTS } from '../../data/elements';

interface PeriodicTrendPathModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMetric?: string;
  onSelectElement?: (el: ChemicalElement) => void;
}

export type TrendMetricKey =
  | 'atomicRadius'
  | 'ionicRadius'
  | 'covalentRadius'
  | 'electronegativity'
  | 'ionizationEnergy'
  | 'electronAffinity'
  | 'meltingPoint'
  | 'boilingPoint'
  | 'density'
  | 'valenceElectrons'
  | 'atomicMass'
  | 'thermalConductivity'
  | 'electricalConductivity';

export interface TrendMetricConfig {
  key: TrendMetricKey;
  label: string;
  unit: string;
  color: string;
  desc: string;
  causeAcrossPeriod: string;
  causeDownGroup: string;
}

export const TREND_METRIC_CONFIGS: Record<TrendMetricKey, TrendMetricConfig> = {
  atomicRadius: {
    key: 'atomicRadius',
    label: 'Atomic Radius',
    unit: 'pm',
    color: '#38bdf8',
    desc: 'Distance from the nucleus to the outermost stable electron orbital.',
    causeAcrossPeriod: 'Decreases left to right: Effective nuclear charge (Z_eff) increases, pulling electron shells closer.',
    causeDownGroup: 'Increases top to bottom: Additional principal quantum shells (n) are added, causing increased electron shielding.'
  },
  ionicRadius: {
    key: 'ionicRadius',
    label: 'Ionic Radius',
    unit: 'pm',
    color: '#06b6d4',
    desc: 'Radius of an element when ionized into its most common valence oxidation state.',
    causeAcrossPeriod: 'Cations are much smaller than parent atoms; anions are larger due to inter-electron repulsion.',
    causeDownGroup: 'Increases down any group as additional electron shells surround the ionic core.'
  },
  covalentRadius: {
    key: 'covalentRadius',
    label: 'Covalent Radius',
    unit: 'pm',
    color: '#0ea5e9',
    desc: 'Half of the distance between nuclei in a homonuclear covalent single bond.',
    causeAcrossPeriod: 'Decreases across period due to stronger orbital overlap and nuclear attraction.',
    causeDownGroup: 'Increases down column with increasing principal quantum number n.'
  },
  electronegativity: {
    key: 'electronegativity',
    label: 'Electronegativity (Pauling)',
    unit: 'Pauling',
    color: '#ef4444',
    desc: 'Tendency of an atom to attract a shared pair of electrons in a chemical bond.',
    causeAcrossPeriod: 'Increases across period: High Z_eff and small radius create powerful electrostatic pull for bonding pairs.',
    causeDownGroup: 'Decreases down group: Valence orbitals are farther from nucleus, shielded by core electrons.'
  },
  ionizationEnergy: {
    key: 'ionizationEnergy',
    label: '1st Ionization Energy',
    unit: 'kJ/mol',
    color: '#a855f7',
    desc: 'Energy required to remove the most loosely held valence electron from a gaseous atom.',
    causeAcrossPeriod: 'Generally increases: Electrons held tighter by higher nuclear charge (anomalies at Be→B and N→O due to subshell symmetry).',
    causeDownGroup: 'Decreases down group: Valence electron is farther away in higher shell and more easily removed.'
  },
  electronAffinity: {
    key: 'electronAffinity',
    label: 'Electron Affinity',
    unit: 'kJ/mol',
    color: '#ec4899',
    desc: 'Energy released when an electron is added to a neutral gaseous atom.',
    causeAcrossPeriod: 'Increases toward Halogens (Group 17) as atoms achieve stable octet noble gas configuration.',
    causeDownGroup: 'Decreases slightly down group due to larger atomic radius and increased electron shielding.'
  },
  meltingPoint: {
    key: 'meltingPoint',
    label: 'Melting Point',
    unit: 'K',
    color: '#f59e0b',
    desc: 'Temperature at which solid state transitions into liquid state at standard pressure (1 atm).',
    causeAcrossPeriod: 'Peaks in central p-block and d-block (e.g. Carbon/Diamond and Tungsten) with giant covalent network and metallic bonding.',
    causeDownGroup: 'Decreases for Alkali metals (weaker metallic bond); increases for Halogens (stronger London dispersion forces).'
  },
  boilingPoint: {
    key: 'boilingPoint',
    label: 'Boiling Point',
    unit: 'K',
    color: '#f97316',
    desc: 'Temperature at which liquid vapor pressure equals atmospheric pressure.',
    causeAcrossPeriod: 'Follows cohesive lattice energy and intermolecular attraction strength.',
    causeDownGroup: 'Group 18 noble gases increase in boiling point as polarizability increases down group.'
  },
  density: {
    key: 'density',
    label: 'Density',
    unit: 'g/cm³',
    color: '#10b981',
    desc: 'Mass per unit volume under standard laboratory conditions.',
    causeAcrossPeriod: 'Peaks in d-block Period 6 (Osmium and Iridium reach ~22.6 g/cm³) due to Lanthanide contraction.',
    causeDownGroup: 'Increases down groups as atomic mass increases faster than atomic volume.'
  },
  valenceElectrons: {
    key: 'valenceElectrons',
    label: 'Valence Electrons',
    unit: 'e⁻',
    color: '#6366f1',
    desc: 'Electrons occupying the outermost electron shell available for bonding.',
    causeAcrossPeriod: 'Increases smoothly from 1 in Group 1 to 8 in Group 18 across main group elements.',
    causeDownGroup: 'Remains constant within main groups, establishing homologous chemical reactivity.'
  },
  atomicMass: {
    key: 'atomicMass',
    label: 'Atomic Mass',
    unit: 'u',
    color: '#8b5cf6',
    desc: 'Average mass of atoms of an element based on relative isotopic abundance.',
    causeAcrossPeriod: 'Increases monotonically with proton and neutron count Z.',
    causeDownGroup: 'Increases substantially with each additional nuclear period.'
  },
  thermalConductivity: {
    key: 'thermalConductivity',
    label: 'Thermal Conductivity',
    unit: 'W/(m·K)',
    color: '#14b8a6',
    desc: 'Rate at which heat passes through material via phonon vibrations and delocalized electrons.',
    causeAcrossPeriod: 'Highest in metals with high free electron mobility (e.g. Copper, Silver, Carbon/Diamond).',
    causeDownGroup: 'High in coinage metals and decreases in heavier non-metals.'
  },
  electricalConductivity: {
    key: 'electricalConductivity',
    label: 'Electrical Conductivity',
    unit: 'MS/m',
    color: '#22c55e',
    desc: 'Ability of material to conduct electrical charge.',
    causeAcrossPeriod: 'Distinguishes conductors (metals), semiconductors (metalloids), and insulators (nonmetals).',
    causeDownGroup: 'Peaks in Group 11 (Silver at 63 MS/m, Copper at 59 MS/m).'
  }
};

export const PeriodicTrendPathModal: React.FC<PeriodicTrendPathModalProps> = ({
  isOpen,
  onClose,
  initialMetric = 'atomicRadius',
  onSelectElement
}) => {
  const [primaryMetric, setPrimaryMetric] = useState<TrendMetricKey>(
    (initialMetric as TrendMetricKey) in TREND_METRIC_CONFIGS ? (initialMetric as TrendMetricKey) : 'atomicRadius'
  );
  const [secondaryMetric, setSecondaryMetric] = useState<TrendMetricKey | 'none'>('none');
  
  // Filtering states
  const [filterBlock, setFilterBlock] = useState<'all' | 's' | 'p' | 'd' | 'f'>('all');
  const [filterPeriod, setFilterPeriod] = useState<number | 'all'>('all');
  const [filterGroup, setFilterGroup] = useState<number | 'all'>('all');
  const [minZ, setMinZ] = useState<number>(1);
  const [maxZ, setMaxZ] = useState<number>(118);

  // Play Trend Animation State
  const [isPlayingTrend, setIsPlayingTrend] = useState<boolean>(false);
  const [playheadZ, setPlayheadZ] = useState<number>(1);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1); // 0.5x, 1x, 2x
  const [hoveredElement, setHoveredElement] = useState<ChemicalElement | null>(null);

  const graphContainerRef = useRef<HTMLDivElement | null>(null);

  // Presets
  const presets = [
    { label: 'All 118 Elements (Z = 1 to 118)', min: 1, max: 118, period: 'all', group: 'all', block: 'all' },
    { label: 'Period 2 (Li → Ne)', min: 3, max: 10, period: 2, group: 'all', block: 'all' },
    { label: 'Period 3 (Na → Ar)', min: 11, max: 18, period: 3, group: 'all', block: 'all' },
    { label: 'Group 1 Alkali Metals (Li → Fr)', min: 1, max: 118, period: 'all', group: 1, block: 'all' },
    { label: 'Group 17 Halogens (F → Ts)', min: 1, max: 118, period: 'all', group: 17, block: 'all' },
    { label: 'Group 18 Noble Gases (He → Og)', min: 1, max: 118, period: 'all', group: 18, block: 'all' },
    { label: '3d Transition Series (Sc → Zn)', min: 21, max: 30, period: 4, group: 'all', block: 'd' }
  ];

  // Filtered elements dataset
  const filteredElements = useMemo(() => {
    return ALL_118_ELEMENTS.filter((el) => {
      if (el.number < minZ || el.number > maxZ) return false;
      if (filterBlock !== 'all' && el.block !== filterBlock) return false;
      if (filterPeriod !== 'all' && el.period !== filterPeriod) return false;
      if (filterGroup !== 'all' && el.group !== filterGroup) return false;
      return true;
    });
  }, [minZ, maxZ, filterBlock, filterPeriod, filterGroup]);

  // Primary and secondary metric configs
  const primaryConfig = TREND_METRIC_CONFIGS[primaryMetric];
  const secondaryConfig = secondaryMetric !== 'none' ? TREND_METRIC_CONFIGS[secondaryMetric] : null;

  // Compute min/max values for scaling
  const primaryStats = useMemo(() => {
    let max = -Infinity;
    let min = Infinity;
    filteredElements.forEach((el) => {
      const val = (el as any)[primaryMetric];
      if (typeof val === 'number' && !isNaN(val)) {
        if (val > max) max = val;
        if (val < min) min = val;
      }
    });
    if (min === Infinity) min = 0;
    if (max === -Infinity) max = 100;
    if (min > 0) min = 0; // anchor baseline at 0 for intuitive graphs
    return { min, max: max * 1.1 };
  }, [filteredElements, primaryMetric]);

  const secondaryStats = useMemo(() => {
    if (!secondaryMetric || secondaryMetric === 'none') return { min: 0, max: 100 };
    let max = -Infinity;
    let min = Infinity;
    filteredElements.forEach((el) => {
      const val = (el as any)[secondaryMetric];
      if (typeof val === 'number' && !isNaN(val)) {
        if (val > max) max = val;
        if (val < min) min = val;
      }
    });
    if (min === Infinity) min = 0;
    if (max === -Infinity) max = 100;
    if (min > 0) min = 0;
    return { min, max: max * 1.1 };
  }, [filteredElements, secondaryMetric]);

  // Play Trend Animation Timer
  useEffect(() => {
    if (!isPlayingTrend) return;
    if (filteredElements.length === 0) return;

    const intervalTime = Math.max(80, Math.round(400 / playbackSpeed));
    const timer = setInterval(() => {
      setPlayheadZ((currentZ) => {
        // Find next element index in filteredElements
        const currentIndex = filteredElements.findIndex((e) => e.number === currentZ);
        if (currentIndex === -1 || currentIndex >= filteredElements.length - 1) {
          return filteredElements[0].number;
        }
        return filteredElements[currentIndex + 1].number;
      });
    }, intervalTime);

    return () => clearInterval(timer);
  }, [isPlayingTrend, filteredElements, playbackSpeed]);

  const activePlayheadElement = useMemo(() => {
    return filteredElements.find((e) => e.number === playheadZ) || filteredElements[0] || ALL_118_ELEMENTS[0];
  }, [filteredElements, playheadZ]);

  if (!isOpen) return null;

  // SVG Geometry Dimensions
  const svgWidth = 840;
  const svgHeight = 280;
  const padLeft = 50;
  const padRight = secondaryConfig ? 50 : 20;
  const padTop = 20;
  const padBottom = 40;
  const plotWidth = svgWidth - padLeft - padRight;
  const plotHeight = svgHeight - padTop - padBottom;

  // Generate SVG Points for Primary Curve
  const primaryPoints = filteredElements.map((el, idx) => {
    const x = padLeft + (idx / Math.max(1, filteredElements.length - 1)) * plotWidth;
    const val = typeof (el as any)[primaryMetric] === 'number' ? (el as any)[primaryMetric] : 0;
    const normalizedY = (val - primaryStats.min) / Math.max(0.001, primaryStats.max - primaryStats.min);
    const y = padTop + plotHeight - normalizedY * plotHeight;
    return { x, y, el, val };
  });

  // Generate SVG Points for Secondary Curve
  const secondaryPoints = secondaryConfig
    ? filteredElements.map((el, idx) => {
        const x = padLeft + (idx / Math.max(1, filteredElements.length - 1)) * plotWidth;
        const val = typeof (el as any)[secondaryMetric as TrendMetricKey] === 'number' ? (el as any)[secondaryMetric as TrendMetricKey] : 0;
        const normalizedY = (val - secondaryStats.min) / Math.max(0.001, secondaryStats.max - secondaryStats.min);
        const y = padTop + plotHeight - normalizedY * plotHeight;
        return { x, y, el, val };
      })
    : [];

  const primaryPathD = primaryPoints.reduce((acc, pt, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${pt.x.toFixed(1)} ${pt.y.toFixed(1)}`, '');
  const primaryAreaD = `${primaryPathD} L ${(padLeft + plotWidth).toFixed(1)} ${(padTop + plotHeight).toFixed(1)} L ${padLeft} ${(padTop + plotHeight).toFixed(1)} Z`;

  const secondaryPathD = secondaryPoints.reduce((acc, pt, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${pt.x.toFixed(1)} ${pt.y.toFixed(1)}`, '');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xl animate-fade-in overflow-y-auto font-sans">
      <div className="w-full max-w-6xl rounded-3xl bg-[#090d16] border border-cyan-500/30 shadow-2xl overflow-hidden flex flex-col max-h-[94vh]">
        {/* Modal Header */}
        <div className="p-5 border-b border-white/10 bg-white/[0.02] flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-400">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold font-mono text-white tracking-tight flex items-center gap-2">
                <span>INTERACTIVE PERIODIC TRENDS GRAPH ENGINE</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
                  {filteredElements.length} Elements
                </span>
              </h2>
              <p className="text-xs text-slate-400 font-mono">
                X-Axis: Atomic Number (Z) • Y-Axis: {primaryConfig.label} ({primaryConfig.unit}) • Dual-Property Comparison & Live Playhead
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 rounded-2xl bg-white/[0.05] hover:bg-white/[0.1] text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Controls Toolbar: Metrics & Quick Presets */}
        <div className="p-4 border-b border-white/10 bg-black/40 space-y-3 font-mono text-xs shrink-0">
          <div className="flex flex-wrap items-center justify-between gap-3">
            {/* Primary Metric Dropdown */}
            <div className="flex items-center gap-2">
              <span className="text-cyan-400 font-bold uppercase text-[10px]">Primary Y-Axis:</span>
              <select
                value={primaryMetric}
                onChange={(e) => setPrimaryMetric(e.target.value as TrendMetricKey)}
                className="px-3 py-1.5 rounded-xl bg-slate-900 border border-cyan-500/40 text-white font-bold focus:outline-none focus:border-cyan-400"
              >
                {Object.values(TREND_METRIC_CONFIGS).map((cfg) => (
                  <option key={cfg.key} value={cfg.key}>
                    {cfg.label} ({cfg.unit})
                  </option>
                ))}
              </select>
            </div>

            {/* Compare Metric Dropdown */}
            <div className="flex items-center gap-2">
              <span className="text-purple-400 font-bold uppercase text-[10px] flex items-center gap-1">
                <GitCompare className="w-3.5 h-3.5" />
                <span>Compare Secondary:</span>
              </span>
              <select
                value={secondaryMetric}
                onChange={(e) => setSecondaryMetric(e.target.value as any)}
                className="px-3 py-1.5 rounded-xl bg-slate-900 border border-purple-500/40 text-purple-300 font-bold focus:outline-none"
              >
                <option value="none">None (Single Curve)</option>
                {Object.values(TREND_METRIC_CONFIGS)
                  .filter((cfg) => cfg.key !== primaryMetric)
                  .map((cfg) => (
                    <option key={cfg.key} value={cfg.key}>
                      {cfg.label} ({cfg.unit})
                    </option>
                  ))}
              </select>
            </div>

            {/* "PLAY TREND" Animation Controls */}
            <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-900 border border-white/10">
              <button
                onClick={() => setIsPlayingTrend((p) => !p)}
                className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-all ${
                  isPlayingTrend
                    ? 'bg-amber-500 text-slate-950 shadow-md animate-pulse'
                    : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow'
                }`}
              >
                {isPlayingTrend ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                <span>{isPlayingTrend ? 'PAUSE TREND' : 'PLAY TREND'}</span>
              </button>

              <div className="flex items-center gap-1 px-1">
                {[0.5, 1, 2].map((spd) => (
                  <button
                    key={spd}
                    onClick={() => setPlaybackSpeed(spd)}
                    className={`px-2 py-0.5 rounded text-[10px] ${
                      playbackSpeed === spd ? 'bg-white/20 text-white font-bold' : 'text-slate-500 hover:text-slate-300'
                    }`}
                  >
                    {spd}x
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Quick Presets Ribbon & Filters */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-white/5">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
              <span className="text-slate-500 uppercase text-[10px] mr-1">Presets:</span>
              {presets.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setMinZ(preset.min);
                    setMaxZ(preset.max);
                    setFilterPeriod(preset.period as any);
                    setFilterGroup(preset.group as any);
                    setFilterBlock(preset.block as any);
                    setPlayheadZ(preset.min);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-white/[0.03] hover:bg-white/[0.08] text-slate-300 hover:text-white border border-white/5 whitespace-nowrap text-[11px]"
                >
                  {preset.label}
                </button>
              ))}
            </div>

            {/* Block Filter Switcher */}
            <div className="flex items-center gap-1">
              <span className="text-slate-500 uppercase text-[10px]">Block:</span>
              {(['all', 's', 'p', 'd', 'f'] as const).map((b) => (
                <button
                  key={b}
                  onClick={() => setFilterBlock(b)}
                  className={`px-2 py-0.5 rounded uppercase text-[10px] font-bold ${
                    filterBlock === b ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {b}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Body & Interactive Canvas */}
        <div className="flex-1 p-5 overflow-y-auto space-y-6">
          {/* Main SVG Graph */}
          <div className="p-6 rounded-3xl bg-[#080c14] border border-white/10 shadow-2xl space-y-3 relative">
            <div className="flex items-center justify-between text-xs font-mono">
              <div className="flex items-center gap-4">
                <span className="font-bold flex items-center gap-1.5" style={{ color: primaryConfig.color }}>
                  <span className="w-3 h-0.5 rounded" style={{ backgroundColor: primaryConfig.color }} />
                  <span>{primaryConfig.label} ({primaryConfig.unit})</span>
                </span>
                {secondaryConfig && (
                  <span className="font-bold flex items-center gap-1.5" style={{ color: secondaryConfig.color }}>
                    <span className="w-3 h-0.5 rounded" style={{ backgroundColor: secondaryConfig.color }} />
                    <span>{secondaryConfig.label} ({secondaryConfig.unit})</span>
                  </span>
                )}
              </div>

              <span className="text-slate-400 text-[11px]">
                Click any point to open Observatory • Hover for data
              </span>
            </div>

            {/* SVG Plot */}
            <div ref={graphContainerRef} className="w-full overflow-x-auto">
              <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-auto select-none">
                {/* Horizontal Gridlines */}
                {[0, 0.25, 0.5, 0.75, 1.0].map((frac, i) => {
                  const y = padTop + plotHeight * (1 - frac);
                  const primaryVal = (primaryStats.min + frac * (primaryStats.max - primaryStats.min)).toFixed(1);
                  return (
                    <g key={i}>
                      <line
                        x1={padLeft}
                        y1={y}
                        x2={padLeft + plotWidth}
                        y2={y}
                        stroke="rgba(255, 255, 255, 0.08)"
                        strokeDasharray={frac === 0 ? 'none' : '4 4'}
                      />
                      <text x={padLeft - 8} y={y + 3} textAnchor="end" fill="#64748b" fontSize="9" fontFamily="monospace">
                        {primaryVal}
                      </text>
                    </g>
                  );
                })}

                {/* Primary Area Fill Gradient */}
                <defs>
                  <linearGradient id="primaryAreaGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={primaryConfig.color} stopOpacity="0.25" />
                    <stop offset="100%" stopColor={primaryConfig.color} stopOpacity="0.0" />
                  </linearGradient>
                </defs>
                <path d={primaryAreaD} fill="url(#primaryAreaGrad)" />

                {/* Primary Curve Line */}
                <path d={primaryPathD} fill="none" stroke={primaryConfig.color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />

                {/* Secondary Curve Line if enabled */}
                {secondaryConfig && (
                  <path d={secondaryPathD} fill="none" stroke={secondaryConfig.color} strokeWidth="2" strokeDasharray="5 3" strokeLinecap="round" />
                )}

                {/* Data Points on Primary Curve */}
                {primaryPoints.map((pt, i) => {
                  const isHovered = hoveredElement?.number === pt.el.number;
                  const isPlayhead = activePlayheadElement.number === pt.el.number;

                  return (
                    <g
                      key={pt.el.number}
                      className="cursor-pointer"
                      onMouseEnter={() => setHoveredElement(pt.el)}
                      onMouseLeave={() => setHoveredElement(null)}
                      onClick={() => onSelectElement && onSelectElement(pt.el)}
                    >
                      {/* Interactive Touch Target */}
                      <circle cx={pt.x} cy={pt.y} r={12} fill="transparent" />

                      {/* Point Dot */}
                      <circle
                        cx={pt.x}
                        cy={pt.y}
                        r={isHovered || isPlayhead ? 6 : 3}
                        fill={isHovered || isPlayhead ? '#ffffff' : primaryConfig.color}
                        stroke={primaryConfig.color}
                        strokeWidth={isHovered || isPlayhead ? 3 : 1}
                        className="transition-all duration-200"
                      />

                      {/* Period Separators or Element Label if few elements */}
                      {filteredElements.length <= 25 && (
                        <text
                          x={pt.x}
                          y={padTop + plotHeight + 16}
                          textAnchor="middle"
                          fill={isHovered || isPlayhead ? '#ffffff' : '#94a3b8'}
                          fontSize="9"
                          fontFamily="monospace"
                          fontWeight="bold"
                        >
                          {pt.el.symbol}
                        </text>
                      )}
                    </g>
                  );
                })}

                {/* Playhead / Active Cursor Vertical Highlight Line */}
                {(() => {
                  const pt = primaryPoints.find((p) => p.el.number === (hoveredElement?.number || activePlayheadElement.number));
                  if (!pt) return null;
                  return (
                    <g>
                      <line
                        x1={pt.x}
                        y1={padTop}
                        x2={pt.x}
                        y2={padTop + plotHeight}
                        stroke="#facc15"
                        strokeWidth="1.5"
                        strokeDasharray="3 3"
                      />
                      <circle cx={pt.x} cy={pt.y} r={8} fill="none" stroke="#facc15" strokeWidth="2" className="animate-ping" />
                    </g>
                  );
                })()}

                {/* X-Axis Baseline */}
                <line x1={padLeft} y1={padTop + plotHeight} x2={padLeft + plotWidth} y2={padTop + plotHeight} stroke="rgba(255, 255, 255, 0.2)" />
                <text x={padLeft + plotWidth / 2} y={svgHeight - 6} textAnchor="middle" fill="#94a3b8" fontSize="10" fontFamily="monospace">
                  Atomic Number (Z) →
                </text>
              </svg>
            </div>
          </div>

          {/* Active Element & Physical Trend Explanation Cards */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 font-mono text-xs">
            {/* Active Element Spotlight Card */}
            <div className="md:col-span-5 p-5 rounded-3xl bg-[#080c14] border border-cyan-500/40 shadow-xl space-y-3">
              <div className="flex items-center justify-between border-b border-white/10 pb-2">
                <span className="text-cyan-400 font-bold uppercase tracking-wider text-[10px]">
                  Spotlight Element ({hoveredElement ? 'Hovered' : 'Playhead'})
                </span>
                <span className="text-[10px] text-slate-400">
                  Group {activePlayheadElement.group} • Period {activePlayheadElement.period}
                </span>
              </div>

              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-400/30 flex flex-col items-center justify-center text-cyan-300 font-bold font-mono shadow-inner">
                  <span className="text-xs opacity-60">#{activePlayheadElement.number}</span>
                  <span className="text-xl font-bold leading-none">{activePlayheadElement.symbol}</span>
                </div>

                <div>
                  <div className="text-base font-bold text-white">{activePlayheadElement.name}</div>
                  <div className="text-slate-400 text-xs">{activePlayheadElement.category}</div>
                  <div className="text-cyan-300 font-bold text-xs pt-0.5">
                    {primaryConfig.label}: {(activePlayheadElement as any)[primaryMetric] ?? 'N/A'} {primaryConfig.unit}
                  </div>
                </div>
              </div>

              <button
                onClick={() => onSelectElement && onSelectElement(activePlayheadElement)}
                className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold transition-all flex items-center justify-center gap-2 shadow-md active:scale-95"
              >
                <Eye className="w-4 h-4" />
                <span>OPEN OBSERVATORY MODAL FOR {activePlayheadElement.symbol}</span>
              </button>
            </div>

            {/* Scientific Trend Mechanism & Periodicity Explanations */}
            <div className="md:col-span-7 p-5 rounded-3xl bg-[#090d16] border border-white/10 shadow-xl space-y-3">
              <div className="flex items-center justify-between border-b border-white/10 pb-2">
                <span className="text-amber-400 font-bold uppercase tracking-wider text-[10px] flex items-center gap-1.5">
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>Physical Chemistry Cause: {primaryConfig.label}</span>
                </span>
              </div>

              <div className="space-y-2 text-slate-300 leading-relaxed font-sans text-xs">
                <p>
                  <strong className="text-cyan-300 font-mono">Across Period (→):</strong> {primaryConfig.causeAcrossPeriod}
                </p>
                <p>
                  <strong className="text-amber-300 font-mono">Down Group (↓):</strong> {primaryConfig.causeDownGroup}
                </p>
                <p className="text-slate-400 text-[11px]">
                  <strong>Periodicity Insight:</strong> Notice the characteristic sawtooth peaks and valleys corresponding to the closure of stable subshells ($s^2$, $p^6$, $d^{10}$) and the initiation of new principal quantum energy levels.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
