import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Bot,
  X,
  Send,
  Sparkles,
  Cpu,
  ArrowRight,
  RefreshCw,
  Atom,
  Boxes,
  Orbit,
  Maximize2,
  HelpCircle,
  Calculator,
  FlaskConical,
  Activity,
  Trophy,
  Compass,
  CheckCircle2
} from 'lucide-react';
import { LatexRenderer } from '../common/LatexRenderer';
import { ChemistryMarkdown } from '../common/ChemistryMarkdown';
import { NavigationTab } from '../../types';
import { StructuredAnswer } from '../views/AiTutorView';
import { getUserProfile } from '../../data/userProfile';

export type ChemobotMode = 'tutor' | 'solver' | 'lab_assistant' | 'analyst' | 'quiz' | 'navigator';

interface QuickChembotModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: NavigationTab) => void;
  currentTab?: NavigationTab;
  initialQuery?: string;
  contextData?: any;
}

export const QuickChembotModal: React.FC<QuickChembotModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
  currentTab = 'home',
  initialQuery,
  contextData
}) => {
  const [activeMode, setActiveMode] = useState<ChemobotMode>('tutor');
  const [messages, setMessages] = useState<
    Array<{ role: 'user' | 'assistant'; content: string | StructuredAnswer; mode?: ChemobotMode }>
  >(() => [
    {
      role: 'assistant',
      mode: 'tutor',
      content: {
        concept: 'ChemoBot 2.0 Scientific Intelligence',
        answer: `Hi **${getUserProfile().name || 'Chemist'}**! I am **ChemoBot 2.0**, your context-aware Chemistry AI Copilot.\n\nI am currently tracking your workspace on **\`${currentTab}\`**. Select an operating mode below or ask me any chemical question.`,
        result: 'Ready to assist across all 6 specialized scientific modes.',
        suggestedQuestions: [
          `Explain this screen (${currentTab})`,
          'Solve Henderson-Hasselbalch buffer pH',
          'Explain SN1 vs SN2 mechanisms with stereochemistry',
          'Why does 4s orbital fill before 3d?'
        ]
      }
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (isOpen && initialQuery) {
      handleSend(initialQuery);
    }
  }, [isOpen, initialQuery]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  if (!isOpen) return null;

  const MODES: { id: ChemobotMode; label: string; icon: any; color: string }[] = [
    { id: 'tutor', label: 'Tutor', icon: Sparkles, color: '#38bdf8' },
    { id: 'solver', label: 'Solver', icon: Calculator, color: '#a855f7' },
    { id: 'lab_assistant', label: 'Lab Assistant', icon: FlaskConical, color: '#10b981' },
    { id: 'analyst', label: 'Analyst', icon: Activity, color: '#f59e0b' },
    { id: 'quiz', label: 'Quiz Me', icon: Trophy, color: '#ec4899' },
    { id: 'navigator', label: 'Navigator', icon: Compass, color: '#06b6d4' }
  ];

  const handleSend = async (textToSend?: string) => {
    const q = textToSend || input.trim();
    if (!q || loading) return;

    setMessages((prev) => [...prev, { role: 'user', content: q, mode: activeMode }]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: q,
          context: {
            currentTab,
            mode: activeMode,
            ...contextData
          }
        })
      });
      const data = await res.json();
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: data.answer || 'Response synthesized.', mode: activeMode }
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          mode: activeMode,
          content: {
            concept: 'Chemical Intelligence Principle',
            answer: `Regarding **"${q}"**:\nIn chemistry, atomic symmetry, thermodynamic stability ($\\Delta G = \\Delta H - T\\Delta S < 0$), and orbital overlaps govern chemical transformation.`,
            result: `Analyze this further in the Chemisphere 3D laboratory modules.`,
            visualTarget: currentTab === 'home' ? 'orbital-atlas' : currentTab
          }
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleExplainCurrentScreen = () => {
    const query = `Explain what is currently happening on the '${currentTab}' screen and how to use it.`;
    handleSend(query);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-end sm:p-6 pointer-events-none animate-fade-in">
      <div className="w-full sm:w-[520px] h-[90vh] sm:h-[680px] bg-[#070b16]/95 border border-cyan-500/30 rounded-t-3xl sm:rounded-3xl shadow-2xl backdrop-blur-2xl flex flex-col overflow-hidden pointer-events-auto shadow-black/90">
        {/* Header */}
        <div className="p-4 border-b border-white/10 bg-white/[0.02] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-violet-600 via-indigo-600 to-cyan-600 flex items-center justify-center text-white shadow-md shadow-violet-500/20 border border-white/10">
              <Atom className="w-5 h-5 text-cyan-200" />
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5 font-editorial">
                <span>ChemoBot Assistant</span>
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  v2.4
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              </div>
              <div className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                <span>Context:</span>
                <span className="text-cyan-300 font-semibold truncate max-w-[150px]">
                  {currentTab}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                onNavigate('ai-tutor');
                onClose();
              }}
              className="p-1.5 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
              title="Expand to Full AI Tutor View"
            >
              <Maximize2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 6 AI Operating Modes Selector Ribbon */}
        <div className="px-3 py-2 border-b border-white/10 bg-black/30 flex items-center gap-1.5 overflow-x-auto no-scrollbar font-mono text-[11px]">
          {MODES.map((m) => {
            const isSelected = activeMode === m.id;
            const IconComp = m.icon;
            return (
              <button
                key={m.id}
                onClick={() => setActiveMode(m.id)}
                className={`px-2.5 py-1 rounded-xl border whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-cyan-500/20 border-cyan-400 text-white font-bold shadow-sm'
                    : 'bg-white/[0.02] border-white/5 text-slate-400 hover:text-slate-200 hover:bg-white/5'
                }`}
              >
                <IconComp className="w-3 h-3" style={{ color: m.color }} />
                <span>{m.label}</span>
              </button>
            );
          })}
        </div>

        {/* Screen Context Banner & Quick Explainer */}
        <div className="px-4 py-2 bg-cyan-950/20 border-b border-cyan-500/20 flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-1.5 text-cyan-300">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-[11px]">Screen: <strong>{currentTab}</strong></span>
          </div>
          <button
            onClick={handleExplainCurrentScreen}
            className="text-[10px] px-2 py-0.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 border border-cyan-500/30 transition-colors flex items-center gap-1"
          >
            <span>Explain This Screen</span>
            <ArrowRight className="w-2.5 h-2.5" />
          </button>
        </div>

        {/* Message history */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 font-mono text-xs">
          {messages.map((m, i) => {
            const isAss = m.role === 'assistant';
            const isStruct = typeof m.content === 'object' && m.content !== null;
            const struct: StructuredAnswer | null = isStruct ? (m.content as StructuredAnswer) : null;
            const text = typeof m.content === 'string' ? m.content : struct?.answer || '';

            return (
              <div key={i} className={`flex gap-2.5 ${isAss ? 'justify-start' : 'justify-end'}`}>
                {isAss && (
                  <div className="w-7 h-7 rounded-xl bg-gradient-to-tr from-violet-600 to-cyan-500 flex items-center justify-center text-white shrink-0 mt-0.5 shadow-sm">
                    <Sparkles className="w-3.5 h-3.5 text-cyan-200" />
                  </div>
                )}

                <div
                  className={`p-3.5 rounded-2xl border text-xs max-w-[88%] leading-relaxed ${
                    isAss
                      ? 'bg-white/[0.03] border-white/10 text-slate-200 shadow-md'
                      : 'bg-cyan-600/30 border-cyan-500/40 text-white shadow-md'
                  }`}
                >
                  {isAss && struct?.concept && (
                    <div className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider mb-1 flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-cyan-400" />
                      <span>{struct.concept}</span>
                    </div>
                  )}

                  <ChemistryMarkdown content={text} />

                  {/* Mathematical Formula Display */}
                  {struct?.formula && (
                    <div className="my-2 p-2.5 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-center overflow-x-auto">
                      <LatexRenderer latex={struct.formula} displayMode={true} className="text-cyan-300 text-xs" />
                    </div>
                  )}

                  {/* Derivation Steps Breakdown */}
                  {struct?.steps && struct.steps.length > 0 && (
                    <div className="my-2 p-2.5 rounded-xl bg-black/40 border border-white/10 space-y-1 text-[11px] text-slate-300">
                      <div className="text-cyan-400 font-bold text-[10px] uppercase">Step-by-Step Derivation:</div>
                      {struct.steps.map((st, sIdx) => (
                        <div key={sIdx} className="pl-2 border-l border-cyan-500/30">
                          {st}
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Direct Launch Module Button */}
                  {struct?.visualTarget && (
                    <button
                      onClick={() => {
                        onNavigate(struct.visualTarget as NavigationTab);
                        onClose();
                      }}
                      className="mt-2.5 w-full py-2 px-3 rounded-xl bg-gradient-to-r from-cyan-500/20 to-purple-500/20 hover:from-cyan-500/30 hover:to-purple-500/30 border border-cyan-400 text-cyan-200 text-[11px] font-bold flex items-center justify-between transition-all shadow-sm"
                    >
                      <span className="flex items-center gap-1.5">
                        <Atom className="w-3.5 h-3.5 text-cyan-300" />
                        <span>Launch 3D Lab: {struct.visualTarget}</span>
                      </span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}

                  {/* Suggested Follow-up Questions */}
                  {struct?.suggestedQuestions && (
                    <div className="mt-3 pt-2 border-t border-white/10 space-y-1">
                      <div className="text-[10px] text-slate-500 font-semibold">Suggested follow-ups:</div>
                      {struct.suggestedQuestions.slice(0, 3).map((sq, sqi) => (
                        <button
                          key={sqi}
                          onClick={() => handleSend(sq)}
                          className="block w-full text-left text-[11px] text-cyan-300 hover:text-white truncate py-0.5"
                        >
                          • {sq}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {loading && (
            <div className="flex items-center gap-2 text-cyan-300 text-xs p-3.5 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 max-w-[80%]">
              <Cpu className="w-4 h-4 animate-spin text-cyan-400" />
              <span>ChemoBot is analyzing molecular principles...</span>
            </div>
          )}

          <div ref={scrollRef} />
        </div>

        {/* Input area */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-3 border-t border-white/10 bg-white/[0.02] flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={`Ask ChemoBot in ${activeMode.toUpperCase()} mode...`}
            className="flex-1 px-3 py-2.5 bg-black/40 rounded-xl border border-white/10 text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-cyan-400 font-mono"
          />
          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="p-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-slate-950 font-bold transition-all shadow-md shadow-cyan-500/20"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
