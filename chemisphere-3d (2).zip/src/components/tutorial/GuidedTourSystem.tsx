import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Compass,
  CheckCircle2,
  X,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  BookOpen,
  Atom,
  FlaskConical,
  Activity,
  Layers,
  RotateCcw,
  Play,
  Grid3X3,
  Orbit,
  Flame,
  Zap,
  Radio,
  Boxes,
  Bot,
  ExternalLink,
  ChevronRight,
  HelpCircle,
  Eye,
  Award
} from 'lucide-react';
import { NavigationTab } from '../../types';
import {
  GUIDED_TOUR_ITEMS,
  GuidedTourItem,
  TourCategory
} from '../../data/guidedTourData';
import {
  getUserProfile,
  saveUserProfile,
  recordTutorialConceptExplored,
  resetTutorialOnly,
  calculateChemistLevel
} from '../../data/userProfile';

interface GuidedTourSystemProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToTab: (tab: NavigationTab) => void;
  currentTab?: NavigationTab;
}

export const GuidedTourSystem: React.FC<GuidedTourSystemProps> = ({
  isOpen,
  onClose,
  onNavigateToTab,
  currentTab
}) => {
  const [selectedCategory, setSelectedCategory] = useState<TourCategory | 'all'>('all');
  const [activeItemId, setActiveItemId] = useState<string>(GUIDED_TOUR_ITEMS[0].id);
  const [activeStepIndex, setActiveStepIndex] = useState<number>(0);
  const [profile, setProfile] = useState(getUserProfile());
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false);

  useEffect(() => {
    const handleProfileUpdate = () => {
      setProfile(getUserProfile());
    };
    window.addEventListener('chemisphere_profile_updated', handleProfileUpdate);
    return () => window.removeEventListener('chemisphere_profile_updated', handleProfileUpdate);
  }, []);

  useEffect(() => {
    if (isOpen) {
      setProfile(getUserProfile());
      // If currentTab matches a tour item, focus it
      if (currentTab) {
        const matching = GUIDED_TOUR_ITEMS.find((item) => item.tab === currentTab);
        if (matching) {
          setActiveItemId(matching.id);
          setActiveStepIndex(0);
        }
      }
    }
  }, [isOpen, currentTab]);

  if (!isOpen) return null;

  const currentItem =
    GUIDED_TOUR_ITEMS.find((item) => item.id === activeItemId) || GUIDED_TOUR_ITEMS[0];

  const filteredItems =
    selectedCategory === 'all'
      ? GUIDED_TOUR_ITEMS
      : GUIDED_TOUR_ITEMS.filter((item) => item.category === selectedCategory);

  const exploredSet = new Set(profile.tutorialExploredConcepts || []);
  const isCurrentExplored = exploredSet.has(currentItem.id);

  const stats = calculateChemistLevel(profile);

  const handleMarkExplored = (itemId: string) => {
    const updated = recordTutorialConceptExplored(itemId, currentItem.category as any);
    setProfile(updated);
  };

  const handleJumpToLiveModule = () => {
    handleMarkExplored(currentItem.id);
    onNavigateToTab(currentItem.tab);
    onClose();
  };

  const handleNextItem = () => {
    handleMarkExplored(currentItem.id);
    const currentIndex = GUIDED_TOUR_ITEMS.findIndex((i) => i.id === currentItem.id);
    if (currentIndex < GUIDED_TOUR_ITEMS.length - 1) {
      setActiveItemId(GUIDED_TOUR_ITEMS[currentIndex + 1].id);
      setActiveStepIndex(0);
    }
  };

  const handlePrevItem = () => {
    const currentIndex = GUIDED_TOUR_ITEMS.findIndex((i) => i.id === currentItem.id);
    if (currentIndex > 0) {
      setActiveItemId(GUIDED_TOUR_ITEMS[currentIndex - 1].id);
      setActiveStepIndex(0);
    }
  };

  const handleResetTutorial = () => {
    const updated = resetTutorialOnly();
    setProfile(updated);
    setShowResetConfirm(false);
  };

  const getIconComponent = (iconName: string) => {
    switch (iconName) {
      case 'Grid3X3': return <Grid3X3 className="w-4 h-4" />;
      case 'Atom': return <Atom className="w-4 h-4" />;
      case 'Orbit': return <Orbit className="w-4 h-4" />;
      case 'Activity': return <Activity className="w-4 h-4" />;
      case 'Flame': return <Flame className="w-4 h-4" />;
      case 'Zap': return <Zap className="w-4 h-4" />;
      case 'Radio': return <Radio className="w-4 h-4" />;
      case 'Boxes': return <Boxes className="w-4 h-4" />;
      case 'FlaskConical': return <FlaskConical className="w-4 h-4" />;
      case 'Bot': return <Bot className="w-4 h-4" />;
      default: return <Sparkles className="w-4 h-4" />;
    }
  };

  return (
    <div
      id="guided-tour-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-2xl transition-all duration-300 select-none animate-in fade-in"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 10 }}
        className="relative w-full max-w-5xl bg-[#070b14]/95 border border-cyan-500/30 rounded-3xl shadow-2xl shadow-cyan-500/10 flex flex-col max-h-[92vh] overflow-hidden backdrop-blur-xl"
      >
        {/* Ambient header glow */}
        <div className="absolute top-0 left-1/4 right-1/4 h-20 bg-gradient-to-r from-cyan-500/15 via-purple-500/15 to-pink-500/15 blur-3xl pointer-events-none" />

        {/* Top Header & Tracking Meter */}
        <div className="p-4 sm:p-6 border-b border-white/10 flex flex-col gap-4 relative z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-300 shadow-sm">
                <Compass className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg sm:text-xl font-extrabold text-white tracking-tight font-display-periodic">
                    Chemisphere 3D Guided Master Tutorial
                  </h2>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                    Interactive Walkthrough
                  </span>
                </div>
                <p className="text-xs text-slate-400 font-sans">
                  Learn how each 3D lab, instrument, solver, and simulation functions.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowResetConfirm(true)}
                className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-rose-500/10 border border-white/10 hover:border-rose-500/30 text-xs font-mono text-slate-400 hover:text-rose-300 transition-colors flex items-center gap-1.5"
                title="Reset tutorial progress tracking"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Reset Progress</span>
              </button>
              <button
                onClick={onClose}
                className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
                title="Close tutorial"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Tutorial Progress Meter Bar */}
          <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 font-mono text-xs">
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <div className="flex items-center gap-1.5 text-cyan-300 font-bold">
                <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                <span>
                  {exploredSet.size} / {GUIDED_TOUR_ITEMS.length} Disciplines Explored
                </span>
              </div>
              <span className="text-slate-500">•</span>
              <span className="text-slate-300 font-semibold">
                {Math.round((exploredSet.size / GUIDED_TOUR_ITEMS.length) * 100)}% Complete
              </span>
            </div>

            <div className="flex items-center gap-3 w-full sm:w-1/2">
              <div className="flex-1 h-2 rounded-full bg-white/10 overflow-hidden p-0.5">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-purple-500 transition-all duration-500 shadow-sm shadow-cyan-400/50"
                  style={{
                    width: `${Math.max(5, (exploredSet.size / GUIDED_TOUR_ITEMS.length) * 100)}%`
                  }}
                />
              </div>
              <span className="text-[11px] text-cyan-400 shrink-0 font-bold">
                +{exploredSet.size * 10} XP
              </span>
            </div>
          </div>

          {/* Category Filter Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs font-mono">
            {[
              { id: 'all', label: 'All Modules' },
              { id: 'modules', label: 'Core Curricula' },
              { id: 'laboratories', label: 'Laboratories' },
              { id: 'simulations', label: '3D Simulations' },
              { id: 'tools', label: 'Calculators & Tools' },
              { id: 'chemobot', label: 'ChemoBot 2.0' }
            ].map((cat) => {
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id as any)}
                  className={`px-3 py-1.5 rounded-xl border whitespace-nowrap transition-all ${
                    isSelected
                      ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200 shadow-sm font-bold'
                      : 'bg-white/[0.02] border-white/10 text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Main Body: Master-Detail Layout */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          {/* Left Sidebar: Module Selector List */}
          <div className="w-full md:w-80 border-b md:border-b-0 md:border-r border-white/10 p-3 overflow-y-auto max-h-48 md:max-h-none space-y-1.5 shrink-0 bg-black/20">
            {filteredItems.map((item) => {
              const isSelected = item.id === activeItemId;
              const isExplored = exploredSet.has(item.id);
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveItemId(item.id);
                    setActiveStepIndex(0);
                  }}
                  className={`w-full p-3 rounded-2xl border text-left transition-all flex items-center justify-between gap-2.5 ${
                    isSelected
                      ? 'bg-gradient-to-r from-cyan-500/20 to-purple-500/10 border-cyan-400/80 text-white shadow-md'
                      : 'bg-white/[0.02] border-white/5 text-slate-300 hover:bg-white/5 hover:border-white/10'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div
                      className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 border"
                      style={{
                        backgroundColor: `${item.accent}15`,
                        borderColor: `${item.accent}40`,
                        color: item.accent
                      }}
                    >
                      {getIconComponent(item.iconName)}
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-bold font-mono truncate text-white">
                        {item.title}
                      </div>
                      <div className="text-[10px] text-slate-400 font-sans truncate">
                        {item.badge}
                      </div>
                    </div>
                  </div>

                  {isExplored ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <ChevronRight className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Right Detail Pane: Rich Interactive Guide for Selected Module */}
          <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-6">
            {/* Top Banner */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/10">
              <div className="space-y-1">
                <div className="flex items-center gap-2 font-mono text-xs">
                  <span
                    className="px-2.5 py-0.5 rounded-full border text-[11px] font-bold"
                    style={{
                      backgroundColor: `${currentItem.accent}15`,
                      borderColor: `${currentItem.accent}40`,
                      color: currentItem.accent
                    }}
                  >
                    {currentItem.badge}
                  </span>
                  {isCurrentExplored && (
                    <span className="flex items-center gap-1 text-emerald-400 text-[11px]">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Explored
                    </span>
                  )}
                </div>
                <h3 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight font-display-periodic">
                  {currentItem.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 font-sans leading-relaxed">
                  {currentItem.summary}
                </p>
              </div>

              {/* Direct Jump Action Button */}
              <button
                onClick={handleJumpToLiveModule}
                className="px-4 py-2.5 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold font-mono text-xs transition-all flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 shrink-0"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Launch Live Lab</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Scientific Architecture Breakdown Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
              {/* Box 1: What It Does */}
              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 space-y-2">
                <div className="text-cyan-300 font-bold flex items-center gap-1.5">
                  <Atom className="w-4 h-4 text-cyan-400" />
                  <span>Purpose & Simulation Scope</span>
                </div>
                <p className="text-slate-300 font-sans text-xs leading-relaxed">
                  {currentItem.whatItDoes}
                </p>
              </div>

              {/* Box 2: How to Interpret Results */}
              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 space-y-2">
                <div className="text-purple-300 font-bold flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-purple-400" />
                  <span>How to Interpret Results</span>
                </div>
                <p className="text-slate-300 font-sans text-xs leading-relaxed">
                  {currentItem.howToInterpret}
                </p>
              </div>

              {/* Box 3: Inputs Accepted */}
              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 space-y-2">
                <div className="text-amber-300 font-bold flex items-center gap-1.5">
                  <Boxes className="w-4 h-4 text-amber-400" />
                  <span>Inputs & Parameters Accepted</span>
                </div>
                <ul className="space-y-1 text-slate-300 pl-4 list-disc text-[11px]">
                  {currentItem.inputs.map((inp, idx) => (
                    <li key={idx}>{inp}</li>
                  ))}
                </ul>
              </div>

              {/* Box 4: Outputs & Visualizations */}
              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 space-y-2">
                <div className="text-emerald-300 font-bold flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  <span>Outputs & Scientific Visuals</span>
                </div>
                <ul className="space-y-1 text-slate-300 pl-4 list-disc text-[11px]">
                  {currentItem.outputs.map((out, idx) => (
                    <li key={idx}>{out}</li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Interactive Step-by-Step Hands-on Walkthrough */}
            <div className="p-5 rounded-2xl bg-gradient-to-b from-cyan-950/20 to-purple-950/20 border border-cyan-500/30 space-y-4">
              <div className="flex items-center justify-between">
                <div className="text-sm font-bold text-cyan-300 font-mono flex items-center gap-2">
                  <Compass className="w-4 h-4 text-cyan-400" />
                  <span>Interactive Walkthrough Steps ({currentItem.interactiveSteps.length} steps)</span>
                </div>
                <span className="text-[11px] font-mono text-slate-400">
                  Step {activeStepIndex + 1} of {currentItem.interactiveSteps.length}
                </span>
              </div>

              {/* Step Navigator Bar */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {currentItem.interactiveSteps.map((step, sIdx) => {
                  const isActive = sIdx === activeStepIndex;
                  return (
                    <button
                      key={sIdx}
                      onClick={() => setActiveStepIndex(sIdx)}
                      className={`p-2.5 rounded-xl border text-left font-mono text-[11px] transition-all flex flex-col gap-1 ${
                        isActive
                          ? 'bg-cyan-500/20 border-cyan-400 text-white font-bold shadow-sm'
                          : 'bg-white/5 border-white/10 text-slate-400 hover:bg-white/10 hover:text-slate-200'
                      }`}
                    >
                      <span className="text-[10px] text-cyan-400">0{sIdx + 1}</span>
                      <span className="truncate">{step.title}</span>
                    </button>
                  );
                })}
              </div>

              {/* Active Step Content */}
              {currentItem.interactiveSteps[activeStepIndex] && (
                <div className="p-4 rounded-xl bg-black/40 border border-cyan-500/20 space-y-2">
                  <div className="text-xs font-bold text-white font-mono flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-300 flex items-center justify-center text-[10px]">
                      {activeStepIndex + 1}
                    </span>
                    <span>{currentItem.interactiveSteps[activeStepIndex].title}</span>
                  </div>
                  <p className="text-xs text-slate-300 font-sans leading-relaxed">
                    {currentItem.interactiveSteps[activeStepIndex].instruction}
                  </p>
                  {currentItem.interactiveSteps[activeStepIndex].actionHint && (
                    <div className="text-[11px] font-mono text-cyan-300/80 bg-cyan-500/10 px-3 py-1.5 rounded-lg inline-block border border-cyan-500/20">
                      💡 Suggested Action: {currentItem.interactiveSteps[activeStepIndex].actionHint}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Key Controls Ribbon */}
            <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-white/10 font-mono text-xs">
              <span className="text-slate-400 text-[11px]">Key Controls:</span>
              {currentItem.keyControls.map((ctrl, cIdx) => (
                <span
                  key={cIdx}
                  className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-slate-300 text-[11px]"
                >
                  {ctrl}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Navigation Bar */}
        <div className="p-4 sm:p-5 border-t border-white/10 flex items-center justify-between bg-black/30 relative z-10">
          <button
            onClick={handlePrevItem}
            className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-slate-300 hover:text-white flex items-center gap-2 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Previous Discipline</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleMarkExplored(currentItem.id)}
              className={`px-4 py-2 rounded-xl border text-xs font-mono transition-all flex items-center gap-2 ${
                isCurrentExplored
                  ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                  : 'bg-white/5 border-white/20 text-slate-300 hover:bg-white/10 hover:text-white'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isCurrentExplored ? 'Completed (+10 XP)' : 'Mark Concept Explored'}</span>
            </button>

            <button
              onClick={handleNextItem}
              className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold font-mono text-xs transition-all flex items-center gap-2 shadow-lg shadow-cyan-500/20"
            >
              <span>Next Concept</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </motion.div>

      {/* Reset Confirmation Dialog */}
      <AnimatePresence>
        {showResetConfirm && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="w-full max-w-md p-6 rounded-3xl bg-[#090e1a] border border-rose-500/40 space-y-4 font-mono text-xs shadow-2xl shadow-rose-500/20 text-center"
            >
              <div className="w-12 h-12 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/30 flex items-center justify-center mx-auto">
                <RotateCcw className="w-6 h-6" />
              </div>
              <h4 className="text-base font-bold text-white">Reset Tutorial Progress?</h4>
              <p className="text-slate-300 font-sans text-xs">
                This will clear your tutorial completion badges and allow you to re-take the entire interactive tour from 0%.
              </p>
              <div className="flex items-center justify-center gap-3 pt-2">
                <button
                  onClick={() => setShowResetConfirm(false)}
                  className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  onClick={handleResetTutorial}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold"
                >
                  Yes, Reset Progress
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
