import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Boxes,
  KeyRound,
  Sparkles,
  Trophy,
  CheckCircle2,
  XCircle,
  RotateCcw,
  HelpCircle,
  Zap,
  Flame,
  Atom,
  Dna,
  Layers,
  Lock,
  Unlock,
  ArrowRight,
  ShieldAlert,
  Search,
  Scale,
  Award,
  ChevronRight,
  X
} from 'lucide-react';
import { userPassportStore } from '../../data/UserPassportStore';
import { LatexRenderer } from '../common/LatexRenderer';

interface ChemistryPuzzlesModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPuzzle?: 'molecular' | 'bond' | 'detective' | 'chain' | 'escape-room';
  onNavigateToTab?: (tab: any) => void;
}

export const ChemistryPuzzlesModal: React.FC<ChemistryPuzzlesModalProps> = ({
  isOpen,
  onClose,
  initialPuzzle = 'escape-room',
  onNavigateToTab
}) => {
  const [activeTab, setActiveTab] = useState<'escape-room' | 'molecular' | 'bond' | 'detective' | 'chain'>(initialPuzzle);

  useEffect(() => {
    if (initialPuzzle) {
      setActiveTab(initialPuzzle);
    }
  }, [initialPuzzle]);

  // =========================================================================
  // 1. CHEMISTRY ESCAPE ROOM: THE ALCHEMIST'S SEALED LABORATORY (4 Stages)
  // =========================================================================
  const [escapeStage, setEscapeStage] = useState<1 | 2 | 3 | 4>(1);
  const [escapeCompleted, setEscapeCompleted] = useState<boolean>(false);
  const [stageAnswers, setStageAnswers] = useState<{ [key: number]: string }>({});
  const [stageError, setStageError] = useState<string | null>(null);
  const [stageSuccess, setStageSuccess] = useState<string | null>(null);

  // Stage 1: Neutralization volume (25.0 mL of 0.2 M HCl neutralized by 0.1 M NaOH -> V = (25 * 0.2)/0.1 = 50.0 mL)
  // Stage 2: Redox Cell (Zn/Zn2+ E° = -0.76 V and Ag+/Ag E° = +0.80 V -> E°cell = 0.80 - (-0.76) = 1.56 V)
  // Stage 3: Spectroscopy IR Peak (1715 cm⁻¹ corresponds to Carbonyl C=O)
  // Stage 4: Quantum Core (3d electron: n=3, l=2, ml=-2..+2)

  const handleVerifyEscapeStage = (stage: number, answer: string) => {
    setStageError(null);
    setStageSuccess(null);

    if (stage === 1) {
      const val = parseFloat(answer.trim());
      if (Math.abs(val - 50.0) < 0.5 || answer.trim() === '50') {
        setStageSuccess('Correct! 50.0 mL of 0.1 M NaOH precisely neutralizes 25.0 mL of 0.2 M HCl. The Acid/Base Cryptex unlocks!');
        setTimeout(() => {
          setEscapeStage(2);
          setStageSuccess(null);
        }, 1200);
      } else {
        setStageError('Incorrect volume. Use M₁V₁ = M₂V₂: (0.20 M × 25.0 mL) / 0.10 M = 50.0 mL.');
      }
    } else if (stage === 2) {
      if (answer === 'zn_ag') {
        setStageSuccess('Redox Circuit Engaged! E°cell = E°(Ag⁺/Ag) - E°(Zn²⁺/Zn) = +0.80V - (-0.76V) = +1.56 V (> 1.50 V threshold). Chamber door opens!');
        setTimeout(() => {
          setEscapeStage(3);
          setStageSuccess(null);
        }, 1200);
      } else {
        setStageError('Cell voltage too low! Choose the pair with the greatest positive standard cell potential difference.');
      }
    } else if (stage === 3) {
      if (answer === 'carbonyl') {
        setStageSuccess('Spectroscopic Resonance Matched! Sharp, intense 1715 cm⁻¹ stretching frequency identifies the Carbonyl (C=O) bond.');
        setTimeout(() => {
          setEscapeStage(4);
          setStageSuccess(null);
        }, 1200);
      } else {
        setStageError('Incorrect vibrational signature. A strong sharp band around 1715 cm⁻¹ is the classic fingerprint of Carbonyl (C=O) stretching.');
      }
    } else if (stage === 4) {
      if (answer === '3_2') {
        setStageSuccess('Quantum Lock Disengaged! For a 3d valence orbital, Principal quantum number n = 3 and Azimuthal quantum number l = 2.');
        setEscapeCompleted(true);
        userPassportStore.unlockBadge('escape_room_champion');
        userPassportStore.recordQuestionSolved(300, 'Escape Room');
      } else {
        setStageError('Quantum numbers invalid. Recall: s=0, p=1, d=2, f=3. For 3d: n = 3 and l = 2.');
      }
    }
  };

  const handleResetEscapeRoom = () => {
    setEscapeStage(1);
    setEscapeCompleted(false);
    setStageAnswers({});
    setStageError(null);
    setStageSuccess(null);
  };

  // =========================================================================
  // 2. MOLECULAR ASSEMBLY PUZZLE
  // =========================================================================
  const [moleculeTarget, setMoleculeTarget] = useState<'ethanol' | 'acetone' | 'glycine'>('ethanol');
  const [atomInventory, setAtomInventory] = useState<{ C: number; H: number; O: number; N: number }>({ C: 0, H: 0, O: 0, N: 0 });
  const [assemblyStatus, setAssemblyStatus] = useState<string | null>(null);

  const TARGETS = {
    ethanol: { name: 'Ethanol (C₂H₆O)', formula: 'C₂H₅OH', required: { C: 2, H: 6, O: 1, N: 0 }, desc: 'Alcohol synthesized via ethylene hydration or sugar fermentation.' },
    acetone: { name: 'Acetone (C₃H₆O)', formula: 'CH₃COCH₃', required: { C: 3, H: 6, O: 1, N: 0 }, desc: 'Simplest ketone solvent with carbonyl C=O group.' },
    glycine: { name: 'Glycine (C₂H₅NO₂)', formula: 'NH₂CH₂COOH', required: { C: 2, H: 5, O: 2, N: 1 }, desc: 'The simplest proteinogenic amino acid.' }
  };

  const handleAddAtom = (atom: 'C' | 'H' | 'O' | 'N') => {
    setAtomInventory(prev => ({ ...prev, [atom]: prev[atom] + 1 }));
    setAssemblyStatus(null);
  };

  const handleRemoveAtom = (atom: 'C' | 'H' | 'O' | 'N') => {
    setAtomInventory(prev => ({ ...prev, [atom]: Math.max(0, prev[atom] - 1) }));
    setAssemblyStatus(null);
  };

  const handleValidateAssembly = () => {
    const req = TARGETS[moleculeTarget].required;
    const isMatch =
      atomInventory.C === req.C &&
      atomInventory.H === req.H &&
      atomInventory.O === req.O &&
      atomInventory.N === req.N;

    if (isMatch) {
      setAssemblyStatus('success');
      userPassportStore.recordQuestionSolved(75, 'Molecular Assembly');
      userPassportStore.unlockBadge('puzzle_master');
    } else {
      setAssemblyStatus('error');
    }
  };

  // =========================================================================
  // 3. BOND BUILDER (Ionic Crystal Formula Balancing)
  // =========================================================================
  const [selectedCation, setSelectedCation] = useState<{ symbol: string; charge: number; count: number }>({ symbol: 'Al³⁺', charge: 3, count: 1 });
  const [selectedAnion, setSelectedAnion] = useState<{ symbol: string; charge: number; count: number }>({ symbol: 'SO₄²⁻', charge: -2, count: 1 });
  const [bondResult, setBondResult] = useState<string | null>(null);

  const netCharge = selectedCation.charge * selectedCation.count + selectedAnion.charge * selectedAnion.count;

  const handleCheckNeutrality = () => {
    if (netCharge === 0) {
      setBondResult('success');
      userPassportStore.recordQuestionSolved(50, 'Bond Builder');
      userPassportStore.unlockBadge('puzzle_master');
    } else {
      setBondResult('error');
    }
  };

  // =========================================================================
  // 4. PERIODIC DETECTIVE (Guess the mystery element with fewest clues)
  // =========================================================================
  const [mysteryCluesRevealed, setMysteryCluesRevealed] = useState<number>(1);
  const [detectiveGuess, setDetectiveGuess] = useState<string>('');
  const [detectiveFeedback, setDetectiveFeedback] = useState<string | null>(null);

  // Mystery Element: Cesium (Cs, Z=55)
  const DETECTIVE_CLUES = [
    'Clue 1: I am an alkali metal located in Period 6 with a golden-silvery metallic luster.',
    'Clue 2: My valence electron configuration terminates in 6s¹.',
    'Clue 3: I have one of the lowest Pauling electronegativity values (0.79) and a very low melting point (28.5 °C).',
    'Clue 4: My atomic transition (9,192,631,770 Hz) defines the exact SI base unit of the second in atomic clocks.'
  ];

  const handleDetectiveGuess = (e: React.FormEvent) => {
    e.preventDefault();
    const g = detectiveGuess.trim().toLowerCase();
    if (g === 'cesium' || g === 'caesium' || g === 'cs' || g === '55') {
      setDetectiveFeedback('correct');
      userPassportStore.recordQuestionSolved(100, 'Periodic Detective');
      userPassportStore.unlockBadge('puzzle_master');
    } else {
      setDetectiveFeedback('incorrect');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-xl overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-700/60 rounded-3xl shadow-2xl overflow-hidden my-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Boxes className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                Chemistry Playground & Puzzles
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-mono">
                  Interactive Mini-Games
                </span>
              </h2>
              <p className="text-xs text-slate-400">Challenge your chemical intuition with real laboratory simulations & escape rooms</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 px-6 gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('escape-room')}
            className={`py-3 px-4 font-semibold text-xs sm:text-sm border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'escape-room'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-500/5'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Lock className="w-4 h-4 text-amber-400" />
            Alchemist Escape Room
          </button>

          <button
            onClick={() => setActiveTab('molecular')}
            className={`py-3 px-4 font-semibold text-xs sm:text-sm border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'molecular'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-500/5'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Atom className="w-4 h-4 text-emerald-400" />
            Molecular Assembly
          </button>

          <button
            onClick={() => setActiveTab('bond')}
            className={`py-3 px-4 font-semibold text-xs sm:text-sm border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'bond'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-500/5'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Scale className="w-4 h-4 text-purple-400" />
            Bond Builder
          </button>

          <button
            onClick={() => setActiveTab('detective')}
            className={`py-3 px-4 font-semibold text-xs sm:text-sm border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'detective'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-500/5'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Search className="w-4 h-4 text-rose-400" />
            Periodic Detective
          </button>
        </div>

        {/* Content Area */}
        <div className="p-6 sm:p-8 space-y-6">

          {/* ================================================================= */}
          {/* TAB 1: ESCAPE ROOM                                                */}
          {/* ================================================================= */}
          {activeTab === 'escape-room' && (
            <div className="space-y-6">
              <div className="p-5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-4">
                <ShieldAlert className="w-8 h-8 text-amber-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h3 className="text-base font-bold text-amber-200">The Alchemist’s Sealed Laboratory</h3>
                  <p className="text-xs sm:text-sm text-slate-300">
                    You are locked in a historic high-tech chemical repository. Unlock all 4 resonance stages by applying stoichiometry, electrochemistry, infrared spectroscopy, and quantum numbers.
                  </p>
                </div>
              </div>

              {/* Progress Steps */}
              <div className="grid grid-cols-4 gap-2">
                {[1, 2, 3, 4].map((st) => (
                  <div
                    key={st}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      escapeStage === st
                        ? 'border-cyan-400 bg-cyan-500/15 text-cyan-200 font-bold'
                        : escapeStage > st
                        ? 'border-emerald-500/50 bg-emerald-500/10 text-emerald-300'
                        : 'border-slate-800 bg-slate-950/40 text-slate-500'
                    }`}
                  >
                    <div className="text-[10px] uppercase tracking-wider">Stage {st}</div>
                    <div className="text-xs truncate font-mono">
                      {st === 1 ? 'Acid Cryptex' : st === 2 ? 'Redox Cell' : st === 3 ? 'IR Peak Lock' : 'Quantum Core'}
                    </div>
                  </div>
                ))}
              </div>

              {!escapeCompleted ? (
                <div className="p-6 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-5">
                  {/* Stage 1 */}
                  {escapeStage === 1 && (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-xs uppercase px-2.5 py-1 rounded bg-amber-500/20 text-amber-300 font-mono">Stage 1: Neutralization Volumetric Lock</span>
                        <span className="text-xs text-slate-400 font-mono">Stoichiometry Protocol</span>
                      </div>
                      <p className="text-sm text-slate-200 leading-relaxed">
                        To disengage the hydraulic acid seal, you must completely neutralize a container of <strong>25.0 mL of 0.20 M Hydrochloric Acid (HCl)</strong> using a solution of <strong>0.10 M Sodium Hydroxide (NaOH)</strong>.
                      </p>
                      <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-700/50 text-xs font-mono text-cyan-300">
                        Reaction: HCl + NaOH → NaCl + H₂O &emsp; | &emsp; M₁V₁ = M₂V₂
                      </div>
                      <div className="flex gap-3">
                        <input
                          type="number"
                          step="0.1"
                          placeholder="Enter required NaOH volume in mL (e.g., 50.0)"
                          value={stageAnswers[1] || ''}
                          onChange={(e) => setStageAnswers({ ...stageAnswers, 1: e.target.value })}
                          className="flex-1 px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-cyan-400 font-mono"
                        />
                        <button
                          onClick={() => handleVerifyEscapeStage(1, stageAnswers[1] || '')}
                          className="px-6 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm transition-all"
                        >
                          Disengage Seal
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Stage 2 */}
                  {escapeStage === 2 && (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-xs uppercase px-2.5 py-1 rounded bg-cyan-500/20 text-cyan-300 font-mono">Stage 2: Galvanic Battery Voltage Gate</span>
                        <span className="text-xs text-slate-400 font-mono">Electrochemistry</span>
                      </div>
                      <p className="text-sm text-slate-200 leading-relaxed">
                        The secondary security gate requires an electromotive force of at least <strong>+1.50 Volts</strong>. Standard Reduction Potentials:
                      </p>
                      <div className="grid grid-cols-2 gap-2 text-xs font-mono text-slate-300 bg-slate-900/80 p-3 rounded-xl border border-slate-700/50">
                        <div>Zn²⁺ + 2e⁻ → Zn &emsp; (E° = -0.76 V)</div>
                        <div>Cu²⁺ + 2e⁻ → Cu &emsp; (E° = +0.34 V)</div>
                        <div>Ag⁺ + e⁻ → Ag &emsp; (E° = +0.80 V)</div>
                        <div>Fe²⁺ + 2e⁻ → Fe &emsp; (E° = -0.44 V)</div>
                      </div>
                      <p className="text-xs text-slate-400">Select the electrochemical galvanic pair that generates E°cell ≥ 1.50 V:</p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {[
                          { id: 'zn_cu', label: 'Zn / Cu²⁺ Cell (E° = 1.10 V)' },
                          { id: 'fe_cu', label: 'Fe / Cu²⁺ Cell (E° = 0.78 V)' },
                          { id: 'zn_ag', label: 'Zn / Ag⁺ Galvanic Cell (E° = 1.56 V)' },
                          { id: 'fe_ag', label: 'Fe / Ag⁺ Galvanic Cell (E° = 1.24 V)' }
                        ].map(opt => (
                          <button
                            key={opt.id}
                            onClick={() => handleVerifyEscapeStage(2, opt.id)}
                            className="p-3 rounded-xl bg-slate-900 hover:bg-cyan-500/20 border border-slate-700 hover:border-cyan-400/60 text-left text-xs sm:text-sm text-white transition-all font-mono"
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Stage 3 */}
                  {escapeStage === 3 && (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-xs uppercase px-2.5 py-1 rounded bg-purple-500/20 text-purple-300 font-mono">Stage 3: Infrared Spectroscopic Key</span>
                        <span className="text-xs text-slate-400 font-mono">Vibrational Spectroscopy</span>
                      </div>
                      <p className="text-sm text-slate-200 leading-relaxed">
                        An optical detector beam reads a very sharp, intense infrared absorption peak at <strong>1715 cm⁻¹</strong>. What chemical functional group resonance unlocks this frequency?
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        {[
                          { id: 'alcohol', label: 'Alcohol O-H Stretch (~3300 cm⁻¹ broad)' },
                          { id: 'carbonyl', label: 'Carbonyl C=O Stretch (~1715 cm⁻¹ sharp)' },
                          { id: 'alkyne', label: 'Alkyne C≡C Stretch (~2200 cm⁻¹ weak)' },
                          { id: 'amine', label: 'Amine N-H Bend (~1600 cm⁻¹)' }
                        ].map(opt => (
                          <button
                            key={opt.id}
                            onClick={() => handleVerifyEscapeStage(3, opt.id)}
                            className="p-3 rounded-xl bg-slate-900 hover:bg-purple-500/20 border border-slate-700 hover:border-purple-400/60 text-left text-xs sm:text-sm text-white transition-all font-mono"
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Stage 4 */}
                  {escapeStage === 4 && (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-xs uppercase px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-300 font-mono">Stage 4: Quantum Core Resonance</span>
                        <span className="text-xs text-slate-400 font-mono">Quantum Mechanics</span>
                      </div>
                      <p className="text-sm text-slate-200 leading-relaxed">
                        To stabilize the magnetic containment core, configure the exact quantum numbers (n, l) for a <strong>3d electron</strong> in a transition metal:
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        {[
                          { id: '3_1', label: 'n = 3, l = 1 (3p orbital)' },
                          { id: '3_2', label: 'n = 3, l = 2 (3d orbital)' },
                          { id: '4_2', label: 'n = 4, l = 2 (4d orbital)' },
                          { id: '3_0', label: 'n = 3, l = 0 (3s orbital)' }
                        ].map(opt => (
                          <button
                            key={opt.id}
                            onClick={() => handleVerifyEscapeStage(4, opt.id)}
                            className="p-3 rounded-xl bg-slate-900 hover:bg-emerald-500/20 border border-slate-700 hover:border-emerald-400/60 text-left text-xs sm:text-sm text-white transition-all font-mono"
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Feedback alerts */}
                  {stageError && (
                    <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                      <XCircle className="w-4 h-4 shrink-0" />
                      {stageError}
                    </div>
                  )}
                  {stageSuccess && (
                    <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                      {stageSuccess}
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-8 rounded-2xl bg-gradient-to-br from-emerald-500/20 via-cyan-500/15 to-purple-500/20 border border-emerald-500/40 text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center mx-auto text-emerald-300">
                    <Trophy className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-bold text-white">Laboratory Vault Unlocked!</h3>
                  <p className="text-sm text-slate-300 max-w-lg mx-auto">
                    Masterful chemistry deduction! You solved all four experimental security layers and claimed the <strong>Escape Room Champion</strong> badge (+300 XP).
                  </p>
                  <button
                    onClick={handleResetEscapeRoom}
                    className="px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs sm:text-sm transition-all inline-flex items-center gap-2"
                  >
                    <RotateCcw className="w-4 h-4" />
                    Replay Escape Room
                  </button>
                </div>
              )}
            </div>
          )}

          {/* ================================================================= */}
          {/* TAB 2: MOLECULAR ASSEMBLY                                         */}
          {/* ================================================================= */}
          {activeTab === 'molecular' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
                <div>
                  <span className="text-xs font-mono uppercase text-emerald-400">Target Molecule</span>
                  <h3 className="text-lg font-bold text-white">{TARGETS[moleculeTarget].name}</h3>
                  <p className="text-xs text-slate-400">{TARGETS[moleculeTarget].desc}</p>
                </div>
                <div className="flex gap-2">
                  {(['ethanol', 'acetone', 'glycine'] as const).map(targetKey => (
                    <button
                      key={targetKey}
                      onClick={() => {
                        setMoleculeTarget(targetKey);
                        setAtomInventory({ C: 0, H: 0, O: 0, N: 0 });
                        setAssemblyStatus(null);
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold capitalize border transition-all ${
                        moleculeTarget === targetKey
                          ? 'bg-emerald-500/20 border-emerald-400 text-emerald-200'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {targetKey}
                    </button>
                  ))}
                </div>
              </div>

              {/* Atom Spawner Palette */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  { sym: 'C', name: 'Carbon (Valency 4)', color: 'bg-slate-700 border-slate-500 text-white' },
                  { sym: 'H', name: 'Hydrogen (Valency 1)', color: 'bg-sky-500/20 border-sky-400/50 text-sky-200' },
                  { sym: 'O', name: 'Oxygen (Valency 2)', color: 'bg-rose-500/20 border-rose-400/50 text-rose-200' },
                  { sym: 'N', name: 'Nitrogen (Valency 3)', color: 'bg-blue-500/20 border-blue-400/50 text-blue-200' }
                ].map(atom => (
                  <div key={atom.sym} className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 flex flex-col items-center gap-3">
                    <div className={`w-12 h-12 rounded-full border flex items-center justify-center font-bold text-lg font-mono ${atom.color}`}>
                      {atom.sym}
                    </div>
                    <span className="text-xs text-slate-400 font-mono">{atom.name}</span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleRemoveAtom(atom.sym as any)}
                        className="w-8 h-8 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 font-bold"
                      >
                        -
                      </button>
                      <span className="w-6 text-center font-mono font-bold text-white">{atomInventory[atom.sym as keyof typeof atomInventory]}</span>
                      <button
                        onClick={() => handleAddAtom(atom.sym as any)}
                        className="w-8 h-8 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 font-bold"
                      >
                        +
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Assembly Status & Submit */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
                <div className="text-xs font-mono text-slate-300">
                  Required: C: {TARGETS[moleculeTarget].required.C} | H: {TARGETS[moleculeTarget].required.H} | O: {TARGETS[moleculeTarget].required.O} | N: {TARGETS[moleculeTarget].required.N}
                </div>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setAtomInventory({ C: 0, H: 0, O: 0, N: 0 })}
                    className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-400 hover:text-white text-xs font-mono"
                  >
                    Clear Canvas
                  </button>
                  <button
                    onClick={handleValidateAssembly}
                    className="px-6 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs sm:text-sm font-mono transition-all"
                  >
                    Synthesize Molecule
                  </button>
                </div>
              </div>

              {assemblyStatus === 'success' && (
                <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs sm:text-sm flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 shrink-0" />
                  <span>Brilliant synthesis! Stoichiometry and molecular assembly verified (+75 XP).</span>
                </div>
              )}
              {assemblyStatus === 'error' && (
                <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs sm:text-sm flex items-center gap-3">
                  <XCircle className="w-5 h-5 shrink-0" />
                  <span>Atom inventory does not match the target formula stoichiometry. Check required counts above.</span>
                </div>
              )}
            </div>
          )}

          {/* ================================================================= */}
          {/* TAB 3: BOND BUILDER                                               */}
          {/* ================================================================= */}
          {activeTab === 'bond' && (
            <div className="space-y-6">
              <div className="p-4 rounded-2xl bg-purple-500/10 border border-purple-500/30 text-xs sm:text-sm text-slate-300">
                Select and adjust stoichiometric multipliers for cation and anion charges until the overall crystal lattice net charge equals <strong>0</strong>.
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Cations */}
                <div className="p-5 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-4">
                  <span className="text-xs font-mono uppercase text-cyan-400">Select Cation</span>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { symbol: 'Na⁺', charge: 1 },
                      { symbol: 'Mg²⁺', charge: 2 },
                      { symbol: 'Al³⁺', charge: 3 }
                    ].map(c => (
                      <button
                        key={c.symbol}
                        onClick={() => setSelectedCation({ ...c, count: 1 })}
                        className={`p-3 rounded-xl border font-mono font-bold text-sm transition-all ${
                          selectedCation.symbol === c.symbol
                            ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200'
                            : 'bg-slate-900 border-slate-800 text-slate-400'
                        }`}
                      >
                        {c.symbol}
                      </button>
                    ))}
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-xs text-slate-400">Multiplier (Subscript)</span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedCation({ ...selectedCation, count: Math.max(1, selectedCation.count - 1) })}
                        className="w-7 h-7 rounded bg-slate-800 text-white font-bold"
                      >
                        -
                      </button>
                      <span className="w-6 text-center font-mono font-bold text-white">{selectedCation.count}</span>
                      <button
                        onClick={() => setSelectedCation({ ...selectedCation, count: selectedCation.count + 1 })}
                        className="w-7 h-7 rounded bg-slate-800 text-white font-bold"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>

                {/* Anions */}
                <div className="p-5 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-4">
                  <span className="text-xs font-mono uppercase text-rose-400">Select Anion</span>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { symbol: 'Cl⁻', charge: -1 },
                      { symbol: 'O²⁻', charge: -2 },
                      { symbol: 'PO₄³⁻', charge: -3 }
                    ].map(a => (
                      <button
                        key={a.symbol}
                        onClick={() => setSelectedAnion({ ...a, count: 1 })}
                        className={`p-3 rounded-xl border font-mono font-bold text-sm transition-all ${
                          selectedAnion.symbol === a.symbol
                            ? 'bg-rose-500/20 border-rose-400 text-rose-200'
                            : 'bg-slate-900 border-slate-800 text-slate-400'
                        }`}
                      >
                        {a.symbol}
                      </button>
                    ))}
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-xs text-slate-400">Multiplier (Subscript)</span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedAnion({ ...selectedAnion, count: Math.max(1, selectedAnion.count - 1) })}
                        className="w-7 h-7 rounded bg-slate-800 text-white font-bold"
                      >
                        -
                      </button>
                      <span className="w-6 text-center font-mono font-bold text-white">{selectedAnion.count}</span>
                      <button
                        onClick={() => setSelectedAnion({ ...selectedAnion, count: selectedAnion.count + 1 })}
                        className="w-7 h-7 rounded bg-slate-800 text-white font-bold"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Lattice Calculation */}
              <div className="p-5 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="space-y-1 text-center sm:text-left">
                  <div className="text-xs text-slate-400 font-mono">
                    Net Lattice Charge: ({selectedCation.count} × +{selectedCation.charge}) + ({selectedAnion.count} × {selectedAnion.charge}) ={' '}
                    <span className={`font-bold ${netCharge === 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {netCharge > 0 ? `+${netCharge}` : netCharge}
                    </span>
                  </div>
                  <div className="text-lg font-mono font-bold text-white">
                    Formula: {selectedCation.symbol.replace(/[⁺\d]/g, '')}
                    {selectedCation.count > 1 ? `₍${selectedCation.count}₎` : ''}
                    {selectedAnion.symbol.includes('₄') ? `(${selectedAnion.symbol.replace(/[⁻\d]/g, '')}₄)` : selectedAnion.symbol.replace(/[⁻\d]/g, '')}
                    {selectedAnion.count > 1 ? `₍${selectedAnion.count}₎` : ''}
                  </div>
                </div>
                <button
                  onClick={handleCheckNeutrality}
                  className="px-6 py-2.5 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-bold text-xs sm:text-sm font-mono transition-all"
                >
                  Verify Neutral Lattice
                </button>
              </div>

              {bondResult === 'success' && (
                <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs sm:text-sm flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 shrink-0" />
                  <span>Neutral crystal unit formed successfully! Net formal charge = 0 (+50 XP).</span>
                </div>
              )}
              {bondResult === 'error' && (
                <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs sm:text-sm flex items-center gap-3">
                  <XCircle className="w-5 h-5 shrink-0" />
                  <span>Lattice possesses a net non-zero charge ({netCharge > 0 ? `+${netCharge}` : netCharge}). Adjust cation or anion count.</span>
                </div>
              )}
            </div>
          )}

          {/* ================================================================= */}
          {/* TAB 4: PERIODIC DETECTIVE                                         */}
          {/* ================================================================= */}
          {activeTab === 'detective' && (
            <div className="space-y-6">
              <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-xs sm:text-sm text-slate-300">
                Deduce the mystery element with the fewest number of revealed clues. Each unused clue grants bonus mastery score!
              </div>

              <div className="space-y-3">
                {DETECTIVE_CLUES.slice(0, mysteryCluesRevealed).map((clue, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 text-xs sm:text-sm text-slate-200 font-mono">
                    {clue}
                  </div>
                ))}
              </div>

              {mysteryCluesRevealed < DETECTIVE_CLUES.length && (
                <button
                  onClick={() => setMysteryCluesRevealed(prev => prev + 1)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono transition-colors flex items-center gap-2"
                >
                  <Search className="w-3.5 h-3.5" />
                  Reveal Next Clue ({mysteryCluesRevealed}/{DETECTIVE_CLUES.length})
                </button>
              )}

              <form onSubmit={handleDetectiveGuess} className="flex gap-3 pt-2">
                <input
                  type="text"
                  placeholder="Enter Element Name, Symbol or Atomic # (e.g., Cesium, Cs, 55)"
                  value={detectiveGuess}
                  onChange={(e) => setDetectiveGuess(e.target.value)}
                  className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-rose-400 font-mono"
                />
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-400 text-slate-950 font-bold text-sm font-mono transition-all"
                >
                  Submit Guess
                </button>
              </form>

              {detectiveFeedback === 'correct' && (
                <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs sm:text-sm flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 shrink-0" />
                  <span>Correct! The mystery element is <strong>Cesium (Cs, Z = 55)</strong> (+100 XP).</span>
                </div>
              )}
              {detectiveFeedback === 'incorrect' && (
                <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs sm:text-sm flex items-center gap-3">
                  <XCircle className="w-5 h-5 shrink-0" />
                  <span>Incorrect element. Read the clues carefully or reveal another clue!</span>
                </div>
              )}
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
