import React from 'react';

export type ModuleThemeType =
  | 'library'
  | 'periodic-table'
  | 'atomic-structure'
  | 'orbital-atlas'
  | 'organic-chem'
  | 'physical-chem'
  | 'spectroscopy'
  | 'nuclear-chem'
  | 'waves-radiation'
  | 'molecules-3d'
  | 'questions-playground'
  | 'chemistry-lab'
  | 'ai-tutor'
  | 'tools'
  | 'creator';

interface ModuleThematicBackdropProps {
  theme: ModuleThemeType;
  children?: React.ReactNode;
  className?: string;
}

export const ModuleThematicBackdrop: React.FC<ModuleThematicBackdropProps> = ({
  theme,
  children,
  className = ''
}) => {
  return (
    <div className={`relative w-full overflow-hidden ${className}`}>
      {/* Dynamic Thematic Background Layer */}
      <div className="absolute inset-0 pointer-events-none z-0 select-none overflow-hidden">
        {/* 1. DIGITAL CHEMISTRY LIBRARY (Parchment, Bookplates, Archival Grid) */}
        {theme === 'library' && (
          <div className="absolute inset-0 opacity-40">
            <div className="absolute inset-0 bg-gradient-to-b from-[#1a140d]/60 via-[#0e0c0a]/80 to-[#050505]" />
            <svg className="absolute w-full h-full opacity-15" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="library-ruling" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#d97706" strokeWidth="0.5" strokeDasharray="2 4" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#library-ruling)" />
            </svg>
            {/* Subtle Archival Warm Spotlights */}
            <div className="absolute -top-32 left-1/4 w-96 h-96 rounded-full bg-amber-500/10 blur-3xl" />
            <div className="absolute top-1/3 -right-24 w-80 h-80 rounded-full bg-amber-600/10 blur-3xl" />
          </div>
        )}

        {/* 2. PERIODIC TABLE & INORGANIC (Element Observatory & Subtle Lattice) */}
        {theme === 'periodic-table' && (
          <div className="absolute inset-0 opacity-35">
            <div className="absolute inset-0 bg-gradient-to-b from-[#060c18]/60 via-[#060812]/80 to-[#050505]" />
            <svg className="absolute w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="periodic-lattice" width="60" height="60" patternUnits="userSpaceOnUse">
                  <circle cx="30" cy="30" r="1.5" fill="#38bdf8" />
                  <path d="M 30 0 L 30 60 M 0 30 L 60 30" fill="none" stroke="#0284c7" strokeWidth="0.3" strokeDasharray="1 5" />
                  <circle cx="30" cy="30" r="18" fill="none" stroke="#0ea5e9" strokeWidth="0.2" strokeDasharray="3 6" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#periodic-lattice)" />
            </svg>
            <div className="absolute -top-40 right-1/4 w-[500px] h-[500px] rounded-full bg-cyan-500/10 blur-3xl" />
          </div>
        )}

        {/* 3. ATOMIC STRUCTURE & HISTORY (Bohr Orbitals & Scattering) */}
        {theme === 'atomic-structure' && (
          <div className="absolute inset-0 opacity-40">
            <div className="absolute inset-0 bg-gradient-to-b from-[#0a0818]/60 via-[#060510]/80 to-[#050505]" />
            <svg className="absolute top-0 right-0 w-[600px] h-[600px] opacity-25" viewBox="0 0 600 600" fill="none">
              <circle cx="300" cy="300" r="60" stroke="#a855f7" strokeWidth="0.75" strokeDasharray="4 4" />
              <circle cx="300" cy="300" r="120" stroke="#818cf8" strokeWidth="0.75" />
              <circle cx="300" cy="300" r="200" stroke="#c084fc" strokeWidth="0.75" strokeDasharray="6 6" />
              <circle cx="300" cy="300" r="280" stroke="#38bdf8" strokeWidth="0.5" strokeDasharray="2 8" />
              <line x1="0" y1="300" x2="600" y2="300" stroke="#6366f1" strokeWidth="0.3" strokeDasharray="3 3" />
              <line x1="300" y1="0" x2="300" y2="600" stroke="#6366f1" strokeWidth="0.3" strokeDasharray="3 3" />
            </svg>
            <div className="absolute top-10 left-10 w-72 h-72 rounded-full bg-purple-600/10 blur-3xl" />
          </div>
        )}

        {/* 4. ORBITAL ATLAS (Probability Clouds & Harmonics) */}
        {theme === 'orbital-atlas' && (
          <div className="absolute inset-0 opacity-35">
            <div className="absolute inset-0 bg-gradient-to-b from-[#05091a]/70 via-[#040612]/80 to-[#050505]" />
            <svg className="absolute w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <radialGradient id="orbital-glow" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#6366f1" stopOpacity="0.3" />
                  <stop offset="100%" stopColor="#050505" stopOpacity="0" />
                </radialGradient>
              </defs>
              <circle cx="85%" cy="20%" r="260" fill="url(#orbital-glow)" />
              <circle cx="15%" cy="75%" r="320" fill="url(#orbital-glow)" />
            </svg>
          </div>
        )}

        {/* 5. ORGANIC CHEMISTRY (Reaction Lab & Carbon Skeletons) */}
        {theme === 'organic-chem' && (
          <div className="absolute inset-0 opacity-40">
            <div className="absolute inset-0 bg-gradient-to-b from-[#180f08]/60 via-[#100b06]/80 to-[#050505]" />
            <svg className="absolute w-full h-full opacity-15" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="benzene-grid" width="80" height="92.37" patternUnits="userSpaceOnUse">
                  <path
                    d="M 40 0 L 80 23.09 L 80 69.28 L 40 92.37 L 0 69.28 L 0 23.09 Z"
                    fill="none"
                    stroke="#f97316"
                    strokeWidth="0.5"
                    strokeDasharray="2 4"
                  />
                  <circle cx="40" cy="46.18" r="14" fill="none" stroke="#ea580c" strokeWidth="0.4" strokeDasharray="3 3" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#benzene-grid)" />
            </svg>
            <div className="absolute top-20 right-10 w-96 h-96 rounded-full bg-orange-600/10 blur-3xl" />
          </div>
        )}

        {/* 6. PHYSICAL CHEMISTRY (Thermodynamic Curves & State Manifolds) */}
        {theme === 'physical-chem' && (
          <div className="absolute inset-0 opacity-35">
            <div className="absolute inset-0 bg-gradient-to-b from-[#14081e]/60 via-[#0c0514]/80 to-[#050505]" />
            <svg className="absolute bottom-0 left-0 w-full h-64 opacity-20" preserveAspectRatio="none" viewBox="0 0 1200 400" fill="none">
              <path d="M 0 350 Q 300 50 600 200 T 1200 100" stroke="#a855f7" strokeWidth="1" strokeDasharray="4 4" />
              <path d="M 0 380 Q 400 120 800 280 T 1200 180" stroke="#ec4899" strokeWidth="0.75" />
              <path d="M 0 400 Q 500 200 900 320 T 1200 240" stroke="#f43f5e" strokeWidth="0.5" strokeDasharray="2 6" />
            </svg>
            <div className="absolute top-12 left-1/3 w-80 h-80 rounded-full bg-pink-500/10 blur-3xl" />
          </div>
        )}

        {/* 7. SPECTROSCOPY SUITE (Optical Bench & Spectral Dispersion) */}
        {theme === 'spectroscopy' && (
          <div className="absolute inset-0 opacity-40">
            <div className="absolute inset-0 bg-gradient-to-b from-[#09081a]/60 via-[#060512]/80 to-[#050505]" />
            {/* Subtle Spectral Dispersion Bar at top */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-500 via-blue-500 via-cyan-400 via-emerald-400 via-yellow-400 via-orange-500 to-red-500 opacity-60" />
            <svg className="absolute w-full h-full opacity-15" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="spectro-ruler" width="100" height="20" patternUnits="userSpaceOnUse">
                  <line x1="0" y1="20" x2="100" y2="20" stroke="#ec4899" strokeWidth="0.5" />
                  <line x1="0" y1="10" x2="0" y2="20" stroke="#ec4899" strokeWidth="0.75" />
                  <line x1="20" y1="14" x2="20" y2="20" stroke="#a855f7" strokeWidth="0.5" />
                  <line x1="40" y1="14" x2="40" y2="20" stroke="#a855f7" strokeWidth="0.5" />
                  <line x1="60" y1="14" x2="60" y2="20" stroke="#a855f7" strokeWidth="0.5" />
                  <line x1="80" y1="14" x2="80" y2="20" stroke="#a855f7" strokeWidth="0.5" />
                  <line x1="100" y1="10" x2="100" y2="20" stroke="#ec4899" strokeWidth="0.75" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#spectro-ruler)" />
            </svg>
            <div className="absolute -top-20 right-10 w-96 h-96 rounded-full bg-pink-600/10 blur-3xl" />
          </div>
        )}

        {/* 8. NUCLEAR CHEMISTRY (Particle Tracks & Cloud Chamber) */}
        {theme === 'nuclear-chem' && (
          <div className="absolute inset-0 opacity-35">
            <div className="absolute inset-0 bg-gradient-to-b from-[#18080c]/60 via-[#100508]/80 to-[#050505]" />
            <svg className="absolute w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
              <path d="M 100 100 Q 300 150 450 350 T 800 600" fill="none" stroke="#f43f5e" strokeWidth="0.75" strokeDasharray="3 3" />
              <path d="M 200 500 Q 400 450 650 250 T 1100 100" fill="none" stroke="#fb7185" strokeWidth="0.5" strokeDasharray="2 4" />
              <circle cx="450" cy="350" r="6" fill="none" stroke="#f43f5e" strokeWidth="1" />
              <circle cx="650" cy="250" r="4" fill="none" stroke="#fb7185" strokeWidth="0.75" />
            </svg>
            <div className="absolute top-20 left-1/4 w-80 h-80 rounded-full bg-rose-600/10 blur-3xl" />
          </div>
        )}

        {/* 9. WAVES & RADIATION (Harmonic Wave Interferences) */}
        {theme === 'waves-radiation' && (
          <div className="absolute inset-0 opacity-35">
            <div className="absolute inset-0 bg-gradient-to-b from-[#141206]/60 via-[#0e0c04]/80 to-[#050505]" />
            <svg className="absolute w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
              <path d="M 0 200 C 150 150, 300 250, 450 200 C 600 150, 750 250, 900 200 C 1050 150, 1200 250, 1350 200" fill="none" stroke="#eab308" strokeWidth="0.75" />
              <path d="M 0 240 C 150 210, 300 270, 450 240 C 600 210, 750 270, 900 240 C 1050 210, 1200 270, 1350 240" fill="none" stroke="#facc15" strokeWidth="0.5" strokeDasharray="3 3" />
            </svg>
            <div className="absolute top-10 right-20 w-80 h-80 rounded-full bg-yellow-500/10 blur-3xl" />
          </div>
        )}

        {/* 10. MOLECULES & VSEPR (Unit Cell & Coordinate Geometry) */}
        {theme === 'molecules-3d' && (
          <div className="absolute inset-0 opacity-35">
            <div className="absolute inset-0 bg-gradient-to-b from-[#080d1e]/60 via-[#050914]/80 to-[#050505]" />
            <svg className="absolute w-full h-full opacity-15" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="iso-grid" width="60" height="60" patternUnits="userSpaceOnUse">
                  <path d="M 30 0 L 60 30 L 30 60 L 0 30 Z" fill="none" stroke="#6366f1" strokeWidth="0.4" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#iso-grid)" />
            </svg>
            <div className="absolute top-20 left-10 w-96 h-96 rounded-full bg-indigo-600/10 blur-3xl" />
          </div>
        )}

        {/* 11. QUESTIONS PLAYGROUND (Challenge Room & Academic Notebook Grid) */}
        {theme === 'questions-playground' && (
          <div className="absolute inset-0 opacity-40">
            <div className="absolute inset-0 bg-gradient-to-b from-[#161208]/60 via-[#0f0c05]/80 to-[#050505]" />
            <svg className="absolute w-full h-full opacity-15" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="notebook-grid" width="24" height="24" patternUnits="userSpaceOnUse">
                  <rect width="24" height="24" fill="none" stroke="#f59e0b" strokeWidth="0.3" strokeDasharray="1 3" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#notebook-grid)" />
            </svg>
            <div className="absolute top-10 right-1/4 w-80 h-80 rounded-full bg-amber-500/10 blur-3xl" />
          </div>
        )}

        {/* 12. VIRTUAL CHEMISTRY LAB (Wet Lab Bench & Measurement Probes) */}
        {theme === 'chemistry-lab' && (
          <div className="absolute inset-0 opacity-40">
            <div className="absolute inset-0 bg-gradient-to-b from-[#061413]/60 via-[#040e0d]/80 to-[#050505]" />
            <svg className="absolute w-full h-full opacity-15" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="bench-tiles" width="48" height="48" patternUnits="userSpaceOnUse">
                  <rect width="48" height="48" fill="none" stroke="#10b981" strokeWidth="0.4" />
                  <circle cx="24" cy="24" r="1" fill="#34d399" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#bench-tiles)" />
            </svg>
            <div className="absolute -top-20 left-10 w-96 h-96 rounded-full bg-emerald-500/10 blur-3xl" />
          </div>
        )}

        {/* 13. CHEMOBOT RESEARCH ASSISTANT (Editorial Scholar Columns) */}
        {theme === 'ai-tutor' && (
          <div className="absolute inset-0 opacity-35">
            <div className="absolute inset-0 bg-gradient-to-b from-[#0c0919]/60 via-[#070510]/80 to-[#050505]" />
            <svg className="absolute w-full h-full opacity-15" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="graph-nodes" width="80" height="80" patternUnits="userSpaceOnUse">
                  <circle cx="40" cy="40" r="2" fill="#8b5cf6" />
                  <path d="M 40 40 L 80 0 M 40 40 L 0 80 M 40 40 L 80 80" stroke="#6d28d9" strokeWidth="0.3" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#graph-nodes)" />
            </svg>
            <div className="absolute top-10 right-10 w-80 h-80 rounded-full bg-violet-600/10 blur-3xl" />
          </div>
        )}

        {/* 14. TOOLS & MASTER CALCULATORS */}
        {theme === 'tools' && (
          <div className="absolute inset-0 opacity-35">
            <div className="absolute inset-0 bg-gradient-to-b from-[#051119]/60 via-[#030a0f]/80 to-[#050505]" />
            <svg className="absolute w-full h-full opacity-15" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="tools-hex" width="50" height="50" patternUnits="userSpaceOnUse">
                  <path d="M 25 0 L 50 25 L 25 50 L 0 25 Z" fill="none" stroke="#06b6d4" strokeWidth="0.3" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#tools-hex)" />
            </svg>
            <div className="absolute top-10 left-10 w-80 h-80 rounded-full bg-cyan-600/10 blur-3xl" />
          </div>
        )}

        {/* 15. CREATOR & PORTFOLIO */}
        {theme === 'creator' && (
          <div className="absolute inset-0 opacity-35">
            <div className="absolute inset-0 bg-gradient-to-b from-[#140e06]/60 via-[#0c0803]/80 to-[#050505]" />
            <div className="absolute -top-32 right-1/3 w-96 h-96 rounded-full bg-amber-500/10 blur-3xl" />
          </div>
        )}
      </div>

      {/* Content wrapper */}
      <div className="relative z-10 w-full">{children}</div>
    </div>
  );
};
