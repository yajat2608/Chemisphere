import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  User,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  RotateCcw,
  Compass,
  X,
  Atom,
  Bot,
  FlaskConical,
  Trophy,
  Grid3X3,
  Orbit,
  Boxes,
  Activity,
  Dna,
  Flame,
  BookOpen,
  Award,
  Users,
  Search,
  Globe,
  HelpCircle,
  Zap,
  Radio,
  Archive,
  Layers
} from 'lucide-react';
import { NavigationTab } from '../../types';
import {
  UserProfile,
  getUserProfile,
  saveUserProfile,
  CHEMISTRY_INTERESTS,
  REFERRAL_SOURCES,
  calculateChemistLevel
} from '../../data/userProfile';

interface OnboardingTutorialModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: NavigationTab) => void;
  initialStep?: number;
}

export const OnboardingTutorialModal: React.FC<OnboardingTutorialModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
  initialStep = 1
}) => {
  const [step, setStep] = useState(initialStep);
  const [profile, setProfile] = useState<UserProfile>(() => getUserProfile());
  const [nameInput, setNameInput] = useState('');
  const [selectedInterest, setSelectedInterest] = useState('general');
  const [selectedReferral, setSelectedReferral] = useState('search');

  // Tour module index for step 5
  const [tourIndex, setTourIndex] = useState(0);

  useEffect(() => {
    if (isOpen) {
      const current = getUserProfile();
      setProfile(current);
      setNameInput(current.name || '');
      setSelectedInterest(current.chemistryInterest || 'general');
      setSelectedReferral(current.referralSource || 'search');
      setStep(initialStep);
    }
  }, [isOpen, initialStep]);

  if (!isOpen) return null;

  const totalSteps = 6;
  const levelStats = calculateChemistLevel(profile);

  const tourModules = [
    {
      tab: 'home' as NavigationTab,
      title: 'Command Deck & Central OS',
      badge: 'Hub & Matrix',
      icon: Atom,
      accent: '#06b6d4',
      description: 'The mission control of Chemisphere 3D. Access all 14 interconnected chemistry disciplines, real-time telemetry, and scientific calculators.',
      highlights: ['Interactive 3D space backdrop', 'Recent lab history', '14-discipline navigation']
    },
    {
      tab: 'periodic-table' as NavigationTab,
      title: '3D Periodic Table & Trends Grapher',
      badge: 'Inorganic Chemistry',
      icon: Grid3X3,
      accent: '#38bdf8',
      description: 'Explore all 118 IUPAC elements with continuous SVG property trend curves (Atomic Radius, Ionization Energy, Electronegativity, Melting Points).',
      highlights: ['118 Element deep dossiers', 'Electron configuration viewer', 'Continuous trend graphing']
    },
    {
      tab: 'orbital-atlas' as NavigationTab,
      title: '3D Quantum Orbital Atlas',
      badge: 'Atomic & Quantum',
      icon: Orbit,
      accent: '#a855f7',
      description: 'Exact 3D iso-surfaces of hydrogenic wavefunctions (1s, 2p, 3d, 4f) derived from spherical harmonics and radial probability distributions.',
      highlights: ['Nodal plane visualization', 'Phase coloring (±ψ)', 'Cross-section slice controls']
    },
    {
      tab: 'molecules-3d' as NavigationTab,
      title: '3D Molecular Simulator & CAD',
      badge: 'Bonding & Structures',
      icon: Boxes,
      accent: '#6366f1',
      description: 'Interactive Ball-and-Stick, Space-Filling CPK, and Wireframe molecular visualization with real-time bond angle analysis and dipole moments.',
      highlights: ['60+ Preloaded molecules', 'Custom bond length measuring', 'VSEPR geometry alignment']
    },
    {
      tab: 'chemistry-lab' as NavigationTab,
      title: 'New: Virtual Chemistry Lab & Reaction Sandbox',
      badge: 'Experimental Sandbox',
      icon: FlaskConical,
      accent: '#10b981',
      description: 'Interactive beaker workbench where you can mix real acids, bases, salts, and indicators. Observe live color shifts, precipitates, gas fizzing, and pH probes.',
      highlights: ['20+ Chemical reagents', 'Precipitate & temperature simulation', '8 Famous preset reactions']
    },
    {
      tab: 'questions-playground' as NavigationTab,
      title: 'New: Questions Playground & Speed Trials',
      badge: 'Interactive Challenges',
      icon: Trophy,
      accent: '#f59e0b',
      description: 'Test your chemical intuition with Olympiad problem challenges, reaction prediction arenas, equation balancing speed trials, and spectral detective puzzles.',
      highlights: ['Multi-tier difficulty', 'Instant LaTeX derivations', 'Streak & mastery scoring']
    },
    {
      tab: 'spectroscopy-suite' as NavigationTab,
      title: 'Spectroscopy Suite (5 Instruments)',
      badge: 'Analytical Science',
      icon: Activity,
      accent: '#ec4899',
      description: 'Operate 5 distinct analytical instruments: UV-Vis Absorbance, FTIR Functional Group vibrations, 1H-NMR Chemical Shifts, Quadrupole Mass Spec, and XRD.',
      highlights: ['Peak picking analysis', 'Functional group tables', 'Unknown compound identification']
    },
    {
      tab: 'archive' as NavigationTab,
      title: 'New: Scientific Archive & Safety Vault',
      badge: 'Reference Library',
      icon: Archive,
      accent: '#14b8a6',
      description: 'Comprehensive repository of landmark chemical discoveries, Nobel Prize timelines, GHS MSDS chemical safety pictograms, and quick-reference cheat sheets.',
      highlights: ['Nobel discovery timeline', 'GHS hazard guidelines', 'Printable reference cheat sheets']
    },
    {
      tab: 'ai-tutor' as NavigationTab,
      title: 'ChemoBot AI Scientific Copilot',
      badge: 'AI Reasoning',
      icon: Bot,
      accent: '#c084fc',
      description: 'Context-aware chemistry intelligence. Get step-by-step reaction mechanisms, stoichiometry equations, and Olympiad derivations on demand.',
      highlights: ['LaTeX formula rendering', 'Personalized to your interests', 'One-click lab cross-linking']
    }
  ];

  const handleSaveNameAndNext = () => {
    const trimmed = nameInput.trim() || 'Chemist';
    const updated = saveUserProfile({ name: trimmed });
    setProfile(updated);
    setStep(3);
  };

  const handleSaveInterestAndNext = () => {
    const chosen = CHEMISTRY_INTERESTS.find((i) => i.id === selectedInterest);
    const updated = saveUserProfile({
      chemistryInterest: selectedInterest,
      interestLabel: chosen ? chosen.label : 'General Science'
    });
    setProfile(updated);
    setStep(4);
  };

  const handleSaveReferralAndNext = () => {
    const chosen = REFERRAL_SOURCES.find((r) => r.id === selectedReferral);
    const updated = saveUserProfile({
      referralSource: selectedReferral,
      referralLabel: chosen ? chosen.label : 'Web Search'
    });
    setProfile(updated);
    setStep(5);
  };

  const handleFinishOnboarding = () => {
    const updated = saveUserProfile({
      hasCompletedOnboarding: true,
      hasCompletedTutorial: true
    });
    setProfile(updated);
    onClose();
  };

  const handleLaunchModuleFromTour = (tab: NavigationTab) => {
    saveUserProfile({
      hasCompletedOnboarding: true,
      hasCompletedTutorial: true
    });
    onNavigate(tab);
    onClose();
  };

  const handleResetTutorial = () => {
    setStep(1);
    setTourIndex(0);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl bg-[#080d19] border border-cyan-500/30 rounded-3xl shadow-2xl shadow-cyan-500/20 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Top Glowing Header Bar with Progress & Controls */}
        <div className="p-4 sm:p-5 border-b border-white/10 bg-gradient-to-r from-cyan-950/40 via-slate-900/60 to-purple-950/40 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-cyan-500 to-purple-600 p-[1px] shrink-0 shadow-md shadow-cyan-500/20">
              <div className="w-full h-full bg-[#070b14] rounded-[15px] flex items-center justify-center overflow-hidden p-0.5">
                <img
                  src="/favicon-32x32.png"
                  alt="Chemisphere 3D"
                  className="w-full h-full object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-extrabold text-white tracking-tight truncate">
                  CHEMISPHERE 3D
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-mono">
                  GUIDED INTRO & TOUR
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono truncate">
                {profile.name ? `Hello, ${profile.name}!` : 'Interactive Chemistry Learning Platform'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Reset Tutorial Button */}
            <button
              onClick={handleResetTutorial}
              className="px-2.5 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-slate-300 hover:text-white flex items-center gap-1.5 transition-colors"
              title="Reset tutorial to Step 1"
            >
              <RotateCcw className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Reset Tutorial</span>
            </button>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-400 hover:text-white transition-colors"
              title="Close Tutorial"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Dynamic Tracking Progress Meter */}
        <div className="bg-slate-950/80 px-4 sm:px-6 py-2 border-b border-white/5 flex items-center justify-between text-xs font-mono text-slate-400">
          <div className="flex items-center gap-2">
            <span className="text-cyan-300 font-bold">Step {step} of {totalSteps}:</span>
            <span className="text-slate-200">
              {step === 1 && 'Welcome & Overview'}
              {step === 2 && 'Chemist Identity'}
              {step === 3 && 'Chemistry Focus & Interest'}
              {step === 4 && 'Discovery Source'}
              {step === 5 && 'Interactive Module Tour'}
              {step === 6 && 'Ready for Launch!'}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-cyan-400">
              {Math.round((step / totalSteps) * 100)}%
            </span>
            <div className="w-20 sm:w-28 h-1.5 bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full transition-all duration-300"
                style={{ width: `${(step / totalSteps) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Modal Main Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-7 space-y-6">
          <AnimatePresence mode="wait">
            {/* STEP 1: WELCOME & OVERVIEW */}
            {step === 1 && (
              <motion.div
                key="step-1"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-6 text-center sm:text-left"
              >
                <div className="flex flex-col sm:flex-row items-center gap-5 p-5 rounded-2xl bg-white/[0.02] border border-cyan-500/20 backdrop-blur-md">
                  <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600 p-[2px] shadow-2xl shadow-cyan-500/30 shrink-0">
                    <div className="w-full h-full bg-[#050811] rounded-[22px] flex items-center justify-center p-2">
                      <img
                        src="/apple-touch-icon.png"
                        alt="Chemisphere 3D"
                        className="w-full h-full object-contain"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 text-xs font-mono">
                      <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Next-Generation Chemistry OS</span>
                    </div>
                    <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                      Welcome to Chemisphere 3D
                    </h3>
                    <p className="text-sm text-slate-300 leading-relaxed font-sans">
                      The premier interactive 3D laboratory and curriculum platform uniting <strong className="text-cyan-300">14 Chemistry Disciplines</strong>, quantum orbital simulations, real-time chemical reaction sandboxes, spectroscopy suites, and AI-powered step-by-step guidance.
                    </p>
                  </div>
                </div>

                {/* Feature Grid Summary */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-left font-mono">
                  <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1.5">
                    <div className="flex items-center gap-2 text-cyan-300 font-bold text-xs">
                      <Orbit className="w-4 h-4 text-cyan-400" />
                      <span>3D Quantum Physics</span>
                    </div>
                    <p className="text-[11px] text-slate-400 font-sans">
                      Spherical harmonic orbital wavefunctions, atomic emission series, and ball-and-stick molecular CAD.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1.5">
                    <div className="flex items-center gap-2 text-emerald-300 font-bold text-xs">
                      <FlaskConical className="w-4 h-4 text-emerald-400" />
                      <span>Virtual Lab Sandbox</span>
                    </div>
                    <p className="text-[11px] text-slate-400 font-sans">
                      Mix acids, bases, and salts in an interactive beaker with live pH probes, color shifts, and precipitation.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1.5">
                    <div className="flex items-center gap-2 text-purple-300 font-bold text-xs">
                      <Bot className="w-4 h-4 text-purple-400" />
                      <span>ChemoBot AI Copilot</span>
                    </div>
                    <p className="text-[11px] text-slate-400 font-sans">
                      Real-time scientific reasoning, mechanism derivations, equation balancing, and Olympiad hints.
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-200 text-xs font-mono flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>Created & Curated by Yajat Sarkar (PM Shri KV Balaghat)</span>
                  </div>
                  <span className="text-[10px] text-amber-400/80">Interactive 3D Engine</span>
                </div>
              </motion.div>
            )}

            {/* STEP 2: ASKS USER'S NAME & LIVE GREETING */}
            {step === 2 && (
              <motion.div
                key="step-2"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-6"
              >
                <div className="space-y-2">
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 text-xs font-mono">
                    <User className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Chemist Identity & Profile</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                    What should we call you, Future Chemist?
                  </h3>
                  <p className="text-sm text-slate-300 font-sans">
                    Enter your name or preferred scientific callsign so Chemisphere 3D and ChemoBot AI can personalize your laboratory workspace.
                  </p>
                </div>

                {/* Name Input Box */}
                <div className="space-y-3">
                  <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider">
                    Your Name / Scientist Callsign:
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={nameInput}
                      onChange={(e) => setNameInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleSaveNameAndNext();
                      }}
                      placeholder="e.g. Alex, Marie, Yajat, Einstein..."
                      maxLength={32}
                      className="w-full px-4 py-3.5 rounded-2xl bg-white/5 border border-cyan-500/40 text-white font-mono text-base placeholder-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-500/20 transition-all"
                      autoFocus
                    />
                    <User className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-cyan-400/50" />
                  </div>
                </div>

                {/* Dynamic "Hello Name" Live Preview Card */}
                <div className="p-4 rounded-2xl bg-gradient-to-r from-cyan-950/40 to-purple-950/40 border border-cyan-500/30 flex items-center justify-between gap-3 font-mono">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300 text-lg font-black">
                      {nameInput.trim() ? nameInput.trim().charAt(0).toUpperCase() : 'C'}
                    </div>
                    <div>
                      <div className="text-xs text-slate-400">Dynamic Greeting Preview:</div>
                      <div className="text-base font-extrabold text-cyan-300">
                        Hello, {nameInput.trim() || 'Chemist'}!
                      </div>
                    </div>
                  </div>
                  <span className="text-[10px] px-2 py-1 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                    Live Reactive
                  </span>
                </div>
              </motion.div>
            )}

            {/* STEP 3: DYNAMIC GREETING & ASKS SPECIFIC INTEREST */}
            {step === 3 && (
              <motion.div
                key="step-3"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-5"
              >
                {/* Dynamic Header Displaying "Hello Name" */}
                <div className="p-4 rounded-2xl bg-gradient-to-r from-cyan-900/30 via-blue-900/20 to-purple-900/30 border border-cyan-500/40 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-mono text-cyan-400 font-bold uppercase tracking-wider">
                      Personalized Laboratory Setup
                    </span>
                    <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                      Hello, {profile.name || nameInput || 'Chemist'}!
                    </h3>
                  </div>
                  <span className="hidden sm:inline-flex px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-xs font-mono">
                    Step 3: Chemistry Focus
                  </span>
                </div>

                <div className="space-y-1">
                  <p className="text-sm font-semibold text-slate-200">
                    What is your specific primary interest in chemistry?
                  </p>
                  <p className="text-xs text-slate-400">
                    We will tailor recommended simulations, ChemoBot suggestions, and laboratory tools to match your focus.
                  </p>
                </div>

                {/* Grid of Selectable Interests */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 font-mono max-h-[300px] overflow-y-auto pr-1">
                  {CHEMISTRY_INTERESTS.map((interest) => {
                    const isSelected = selectedInterest === interest.id;
                    return (
                      <div
                        key={interest.id}
                        onClick={() => setSelectedInterest(interest.id)}
                        className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-start gap-3 ${
                          isSelected
                            ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-md shadow-cyan-500/10'
                            : 'bg-white/[0.02] border-white/10 hover:border-white/20 text-slate-300 hover:bg-white/5'
                        }`}
                      >
                        <div
                          className={`p-2 rounded-xl shrink-0 ${
                            isSelected ? 'bg-cyan-500 text-slate-950 font-bold' : 'bg-white/10 text-slate-300'
                          }`}
                        >
                          <Atom className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-white flex items-center justify-between gap-1">
                            <span className="truncate">{interest.label}</span>
                            {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />}
                          </div>
                          <p className="text-[10px] text-slate-400 font-sans line-clamp-2 mt-0.5">
                            Specialized simulations & interactive theory
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </motion.div>
            )}

            {/* STEP 4: HOW DID YOU HEAR ABOUT US */}
            {step === 4 && (
              <motion.div
                key="step-4"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-5"
              >
                <div className="space-y-2">
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/30 text-xs font-mono">
                    <Compass className="w-3.5 h-3.5 text-purple-400" />
                    <span>Scientific Community</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                    How did you discover Chemisphere 3D?
                  </h3>
                  <p className="text-sm text-slate-300 font-sans">
                    Help us understand how students, researchers, and chemistry lovers are discovering the platform.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 font-mono">
                  {REFERRAL_SOURCES.map((source) => {
                    const isSelected = selectedReferral === source.id;
                    return (
                      <button
                        key={source.id}
                        type="button"
                        onClick={() => setSelectedReferral(source.id)}
                        className={`p-3 rounded-2xl border text-left transition-all flex items-center justify-between gap-2 ${
                          isSelected
                            ? 'bg-purple-500/20 border-purple-400 text-white shadow-md shadow-purple-500/10 font-bold'
                            : 'bg-white/[0.02] border-white/10 hover:border-white/20 text-slate-300 hover:bg-white/5'
                        }`}
                      >
                        <span className="text-xs truncate">{source.label}</span>
                        {isSelected && <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </motion.div>
            )}

            {/* STEP 5: GUIDED MODULE TOUR */}
            {step === 5 && (
              <motion.div
                key="step-5"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-4"
              >
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 text-xs font-mono">
                      <Compass className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Curriculum & Module Tour</span>
                    </div>
                    <h3 className="text-lg sm:text-xl font-bold text-white tracking-tight">
                      Explore Chemisphere 3D Core Laboratories
                    </h3>
                  </div>

                  <div className="flex items-center gap-1.5 font-mono text-xs text-slate-400">
                    <span>{tourIndex + 1} / {tourModules.length}</span>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setTourIndex((prev) => (prev > 0 ? prev - 1 : tourModules.length - 1))}
                        className="p-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10"
                        title="Previous Module"
                      >
                        <ArrowLeft className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setTourIndex((prev) => (prev < tourModules.length - 1 ? prev + 1 : 0))}
                        className="p-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10"
                        title="Next Module"
                      >
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Tour Module Active Card */}
                {(() => {
                  const curr = tourModules[tourIndex];
                  const Icon = curr.icon;
                  return (
                    <div className="p-5 rounded-3xl bg-gradient-to-br from-[#0c1424] to-[#080d19] border border-cyan-500/30 space-y-4 shadow-xl">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div
                            className="w-12 h-12 rounded-2xl flex items-center justify-center p-2.5 shadow-lg"
                            style={{ backgroundColor: `${curr.accent}20`, borderColor: `${curr.accent}50`, borderWidth: 1 }}
                          >
                            <Icon className="w-6 h-6" style={{ color: curr.accent }} />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span
                                className="text-[10px] font-mono px-2 py-0.5 rounded-full border"
                                style={{ backgroundColor: `${curr.accent}15`, color: curr.accent, borderColor: `${curr.accent}40` }}
                              >
                                {curr.badge}
                              </span>
                            </div>
                            <h4 className="text-lg font-bold text-white tracking-tight mt-0.5">
                              {curr.title}
                            </h4>
                          </div>
                        </div>

                        {/* Test this module directly button */}
                        <button
                          onClick={() => handleLaunchModuleFromTour(curr.tab)}
                          className="px-3.5 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold font-mono text-xs hover:bg-cyan-400 transition-all flex items-center justify-center gap-1.5 shadow-md shadow-cyan-500/20 shrink-0"
                        >
                          <span>Launch Module</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <p className="text-sm text-slate-300 leading-relaxed font-sans">
                        {curr.description}
                      </p>

                      <div className="space-y-1.5 pt-2 border-t border-white/10">
                        <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
                          Key Capabilities & Interactive Tools:
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                          {curr.highlights.map((hl, hIdx) => (
                            <div key={hIdx} className="flex items-center gap-1.5 text-xs text-slate-300 font-mono">
                              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shrink-0" />
                              <span className="truncate">{hl}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })()}

                {/* Tour Quick Selector Pills */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 font-mono text-xs">
                  {tourModules.map((m, idx) => (
                    <button
                      key={idx}
                      onClick={() => setTourIndex(idx)}
                      className={`px-2.5 py-1 rounded-xl whitespace-nowrap text-[11px] transition-all ${
                        tourIndex === idx
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                          : 'bg-white/5 text-slate-400 hover:text-white border border-white/5'
                      }`}
                    >
                      {m.title.split(' ')[0]}
                    </button>
                  ))}
                </div>
              </motion.div>
            )}

            {/* STEP 6: READY FOR LAUNCH & BADGE UNLOCK */}
            {step === 6 && (
              <motion.div
                key="step-6"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-5 text-center sm:text-left"
              >
                <div className="p-5 rounded-3xl bg-gradient-to-r from-emerald-950/40 via-slate-900 to-cyan-950/40 border border-emerald-500/30 flex flex-col sm:flex-row items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-300 shrink-0">
                    <Award className="w-8 h-8" />
                  </div>
                  <div className="space-y-1">
                    <span className="text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
                      Badge Unlocked: Chemisphere Initiate
                    </span>
                    <h3 className="text-xl font-bold text-white">
                      You are all set, {profile.name || nameInput || 'Chemist'}!
                    </h3>
                    <p className="text-xs text-slate-300 font-sans">
                      Your profile has been provisioned with 50 XP points and customized with your primary interest in <strong>{profile.interestLabel}</strong>.
                    </p>
                  </div>
                </div>

                {/* Summary Metrics & Tracking Meter */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-center">
                  <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                    <div className="text-[10px] text-slate-400">Scientist Rank</div>
                    <div className="text-sm font-bold text-cyan-300">{levelStats.title}</div>
                  </div>
                  <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                    <div className="text-[10px] text-slate-400">Curriculum Matrix</div>
                    <div className="text-sm font-bold text-purple-300">14 Disciplines</div>
                  </div>
                  <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                    <div className="text-[10px] text-slate-400">New Tools</div>
                    <div className="text-sm font-bold text-emerald-300">Lab, Playground & Archive</div>
                  </div>
                  <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                    <div className="text-[10px] text-slate-400">ChemoBot AI</div>
                    <div className="text-sm font-bold text-amber-300">Online & Ready</div>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/10 text-xs font-mono text-slate-300 flex items-center justify-between">
                  <span>Press <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-cyan-300 border border-white/10">⌘K</kbd> anywhere for the Command Search Palette</span>
                  <span className="text-cyan-400 font-bold">Chemisphere 3D OS</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Bottom Actions Toolbar */}
        <div className="p-4 sm:p-5 border-t border-white/10 bg-slate-950/90 flex items-center justify-between gap-3">
          {/* Back Button */}
          {step > 1 ? (
            <button
              onClick={() => setStep((prev) => prev - 1)}
              className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-slate-300 hover:text-white flex items-center gap-1.5 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>
          ) : (
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-slate-400 hover:text-white transition-colors"
            >
              Skip Tour
            </button>
          )}

          {/* Next / Complete Action Button */}
          <div className="flex items-center gap-2">
            {step === 1 && (
              <button
                onClick={() => setStep(2)}
                className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-extrabold font-mono text-xs transition-all flex items-center gap-2 shadow-lg shadow-cyan-500/20"
              >
                <span>Get Started</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {step === 2 && (
              <button
                onClick={handleSaveNameAndNext}
                className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-extrabold font-mono text-xs transition-all flex items-center gap-2 shadow-lg shadow-cyan-500/20"
              >
                <span>Confirm Name & Continue</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {step === 3 && (
              <button
                onClick={handleSaveInterestAndNext}
                className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-extrabold font-mono text-xs transition-all flex items-center gap-2 shadow-lg shadow-cyan-500/20"
              >
                <span>Next: Discovery Source</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {step === 4 && (
              <button
                onClick={handleSaveReferralAndNext}
                className="px-5 py-2.5 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-extrabold font-mono text-xs transition-all flex items-center gap-2 shadow-lg shadow-purple-500/20"
              >
                <span>Explore Interactive Tour</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {step === 5 && (
              <button
                onClick={() => setStep(6)}
                className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-extrabold font-mono text-xs transition-all flex items-center gap-2 shadow-lg shadow-cyan-500/20"
              >
                <span>Complete Setup</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {step === 6 && (
              <button
                onClick={handleFinishOnboarding}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-emerald-400 text-slate-950 font-black font-mono text-xs hover:opacity-95 transition-all flex items-center gap-2 shadow-xl shadow-cyan-500/25"
              >
                <span>Enter Chemisphere 3D OS</span>
                <Sparkles className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
