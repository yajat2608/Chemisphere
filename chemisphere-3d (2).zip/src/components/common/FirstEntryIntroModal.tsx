import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  User,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  X,
  Atom,
  Compass,
  GraduationCap,
  BookOpen,
  Award,
  Users,
  Search,
  Globe,
  Trophy,
  Dna,
  Flame,
  Activity,
  Orbit,
  Zap,
  Radio,
  Layers,
  Boxes,
  FlaskConical,
  HelpCircle
} from 'lucide-react';
import { NavigationTab } from '../../types';
import {
  UserProfile,
  getUserProfile,
  saveUserProfile,
  CHEMISTRY_INTEREST_CHIPS,
  PURPOSE_OPTIONS,
  REFERRAL_SOURCES
} from '../../data/userProfile';

interface FirstEntryIntroModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTakeGuidedTour?: () => void;
  onExploreChemisphere?: () => void;
  onLaunchTutorial?: () => void;
  onExploreDirectly?: (tab?: NavigationTab) => void;
}

export const FirstEntryIntroModal: React.FC<FirstEntryIntroModalProps> = ({
  isOpen,
  onClose,
  onTakeGuidedTour,
  onExploreChemisphere,
  onLaunchTutorial,
  onExploreDirectly
}) => {
  const [currentCard, setCurrentCard] = useState<number>(1);
  const [name, setName] = useState<string>('');
  const [selectedInterests, setSelectedInterests] = useState<string[]>([
    'Organic',
    'Quantum',
    'Chemistry Calculations'
  ]);
  const [selectedPurposes, setSelectedPurposes] = useState<string[]>([
    'Learn',
    'Virtual experiments',
    'Practice'
  ]);
  const [selectedDiscovery, setSelectedDiscovery] = useState<string>('search');

  useEffect(() => {
    if (isOpen) {
      const profile = getUserProfile();
      setName(profile.name || '');
      if (profile.chemistryInterests?.length) {
        setSelectedInterests(profile.chemistryInterests);
      }
      if (profile.purposes?.length) {
        setSelectedPurposes(profile.purposes);
      }
      if (profile.referralSource) {
        setSelectedDiscovery(profile.referralSource);
      }
      setCurrentCard(1);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const totalCards = 6;

  const toggleInterest = (id: string) => {
    setSelectedInterests((prev) =>
      prev.includes(id) ? (prev.length > 1 ? prev.filter((i) => i !== id) : prev) : [...prev, id]
    );
  };

  const togglePurpose = (id: string) => {
    setSelectedPurposes((prev) =>
      prev.includes(id) ? (prev.length > 1 ? prev.filter((p) => p !== id) : prev) : [...prev, id]
    );
  };

  const handleNextFromCard1 = () => setCurrentCard(2);

  const handleNextFromCard2 = () => {
    const cleanName = name.trim() || 'Explorer';
    saveUserProfile({ name: cleanName });
    setCurrentCard(3);
  };

  const handleNextFromCard3 = () => {
    saveUserProfile({
      chemistryInterests: selectedInterests,
      chemistryInterest: selectedInterests[0] || 'Organic',
      interestLabel: selectedInterests.slice(0, 2).join(' & ')
    });
    setCurrentCard(4);
  };

  const handleNextFromCard4 = () => {
    saveUserProfile({ purposes: selectedPurposes });
    setCurrentCard(5);
  };

  const handleNextFromCard5 = () => {
    const ref = REFERRAL_SOURCES.find((r) => r.id === selectedDiscovery);
    saveUserProfile({
      referralSource: selectedDiscovery,
      referralLabel: ref?.label || 'Web Search'
    });
    setCurrentCard(6);
  };

  const handleExploreAction = () => {
    saveUserProfile({ hasCompletedOnboarding: true });
    if (onExploreChemisphere) {
      onExploreChemisphere();
    } else if (onExploreDirectly) {
      onExploreDirectly();
    } else {
      onClose();
    }
  };

  const handleTourAction = () => {
    saveUserProfile({ hasCompletedOnboarding: true });
    if (onTakeGuidedTour) {
      onTakeGuidedTour();
    } else if (onLaunchTutorial) {
      onLaunchTutorial();
    } else {
      onClose();
    }
  };

  // Icon resolver for chips
  const getChipIcon = (id: string) => {
    switch (id) {
      case 'Organic': return <Dna className="w-3.5 h-3.5" />;
      case 'Inorganic': return <Atom className="w-3.5 h-3.5" />;
      case 'Physical': return <Flame className="w-3.5 h-3.5" />;
      case 'Analytical': return <Activity className="w-3.5 h-3.5" />;
      case 'Quantum': return <Orbit className="w-3.5 h-3.5" />;
      case 'Spectroscopy': return <Activity className="w-3.5 h-3.5" />;
      case 'Electrochemistry': return <Zap className="w-3.5 h-3.5" />;
      case 'Nuclear': return <Radio className="w-3.5 h-3.5" />;
      case 'Biochemistry': return <Layers className="w-3.5 h-3.5" />;
      case 'Materials': return <Boxes className="w-3.5 h-3.5" />;
      case 'Molecular Chemistry': return <Atom className="w-3.5 h-3.5" />;
      case 'Chemistry Calculations': return <FlaskConical className="w-3.5 h-3.5" />;
      default: return <Sparkles className="w-3.5 h-3.5" />;
    }
  };

  return (
    <div
      id="chemisphere-intro-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-2xl transition-all duration-300 select-none animate-in fade-in"
      style={{ perspective: '1200px' }}
    >
      {/* Floating Glassmorphism Modal Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.92, rotateX: 6, y: 20 }}
        animate={{ opacity: 1, scale: 1, rotateX: 0, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, rotateX: -4, y: 15 }}
        transition={{ type: 'spring', damping: 24, stiffness: 220 }}
        className="relative w-full max-w-xl bg-gradient-to-b from-[#09101f]/95 via-[#060a14]/95 to-[#04060d]/98 border border-cyan-500/30 rounded-3xl shadow-[0_0_50px_-10px_rgba(6,182,212,0.25)] p-6 sm:p-8 backdrop-blur-xl flex flex-col justify-between min-h-[500px] overflow-hidden"
      >
        {/* Ambient Top Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-24 bg-gradient-to-r from-cyan-500/20 via-purple-500/20 to-pink-500/20 blur-3xl pointer-events-none" />

        {/* Header Ribbon */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 relative z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-xl bg-gradient-to-tr from-cyan-500 to-purple-600 p-[1px] shadow-sm shadow-cyan-500/30">
              <div className="w-full h-full bg-[#050811] rounded-[11px] flex items-center justify-center p-0.5">
                <img
                  src="/favicon-32x32.png"
                  alt="Chemisphere"
                  className="w-full h-full object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
            <span className="text-xs font-mono font-bold tracking-widest text-cyan-300 uppercase">
              CHEMISPHERE 3D
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-[11px] font-mono text-slate-400 bg-white/5 px-2.5 py-0.5 rounded-full border border-white/10">
              {currentCard} / {totalCards}
            </span>
            <button
              onClick={onClose}
              className="p-1 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
              title="Close introduction"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Flash Card Content Sequence */}
        <div className="flex-1 my-6 flex flex-col justify-center relative z-10">
          <AnimatePresence mode="wait">
            {/* CARD 01 — Welcome */}
            {currentCard === 1 && (
              <motion.div
                key="card-1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.22 }}
                className="space-y-5 text-center sm:text-left"
              >
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 text-xs font-mono">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Next-Generation Chemistry OS</span>
                </div>

                <div className="space-y-2">
                  <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-display-periodic">
                    Welcome to Chemisphere 3D
                  </h1>
                  <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-sans font-light">
                    Explore chemistry through interactive 3D laboratories, real-time wave simulations, quantum orbital visualizers, spectrometry suites, and reaction sandboxes.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 text-xs font-mono text-slate-300 space-y-2 text-left">
                  <div className="text-cyan-300 font-bold flex items-center gap-2">
                    <Atom className="w-4 h-4 text-cyan-400" />
                    <span>A complete scientific curriculum universe:</span>
                  </div>
                  <ul className="space-y-1 text-slate-400 pl-6 list-disc">
                    <li>14 interconnected interactive chemistry laboratory disciplines</li>
                    <li>Olympiad questions playground & stoichiometry speed trials</li>
                    <li>Virtual beaker reaction sandbox with pH and temperature tracking</li>
                  </ul>
                </div>
              </motion.div>
            )}

            {/* CARD 02 — Your Name */}
            {currentCard === 2 && (
              <motion.div
                key="card-2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.22 }}
                className="space-y-6"
              >
                <div className="space-y-2">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 text-xs font-mono">
                    <User className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Identity Setup</span>
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-display-periodic">
                    What should we call you?
                  </h2>
                  <p className="text-sm text-slate-300 font-sans">
                    Enter your name or scientific callsign so Chemisphere 3D can personalize your workspaces.
                  </p>
                </div>

                <div className="space-y-3">
                  <div className="relative">
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleNextFromCard2();
                      }}
                      placeholder="Your name (e.g. Marie Curie, Yajat, Alex)..."
                      maxLength={32}
                      className="w-full px-4 py-3.5 rounded-2xl bg-white/5 border border-cyan-500/40 text-white font-mono text-base placeholder-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-500/20 transition-all shadow-inner"
                      autoFocus
                    />
                    <User className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-cyan-400/40" />
                  </div>

                  {/* Dynamic greeting box */}
                  <div className="p-4 rounded-2xl bg-cyan-950/30 border border-cyan-500/30 flex items-center justify-between font-mono">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">👋</span>
                      <div>
                        <div className="text-[11px] text-slate-400">Greeting Preview:</div>
                        <div className="text-base font-extrabold text-cyan-300">
                          Hello, {name.trim() || 'Explorer'}!
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                      Live
                    </span>
                  </div>
                </div>
              </motion.div>
            )}

            {/* CARD 03 — Chemistry Interests (Multi-select) */}
            {currentCard === 3 && (
              <motion.div
                key="card-3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.22 }}
                className="space-y-4"
              >
                <div className="space-y-1.5">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 text-xs font-mono">
                    <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Curriculum Interests</span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight font-display-periodic">
                    What would you like to explore?
                  </h2>
                  <p className="text-xs text-slate-300 font-sans">
                    Select all fields that interest you (multiple allowed):
                  </p>
                </div>

                {/* Multi-selectable chips grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 font-mono text-xs max-h-[250px] overflow-y-auto pr-1">
                  {CHEMISTRY_INTEREST_CHIPS.map((chip) => {
                    const isSelected = selectedInterests.includes(chip.id);
                    return (
                      <button
                        key={chip.id}
                        type="button"
                        onClick={() => toggleInterest(chip.id)}
                        className={`p-2.5 rounded-2xl border text-left transition-all flex items-center justify-between gap-1.5 ${
                          isSelected
                            ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200 shadow-sm shadow-cyan-500/20 font-bold'
                            : 'bg-white/[0.02] border-white/10 text-slate-400 hover:text-slate-200 hover:bg-white/5'
                        }`}
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <span className={isSelected ? 'text-cyan-300' : 'text-slate-500'}>
                            {getChipIcon(chip.id)}
                          </span>
                          <span className="truncate text-[11px]">{chip.label}</span>
                        </div>
                        {isSelected && (
                          <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </motion.div>
            )}

            {/* CARD 04 — Purpose */}
            {currentCard === 4 && (
              <motion.div
                key="card-4"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.22 }}
                className="space-y-4"
              >
                <div className="space-y-1.5">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/30 text-xs font-mono">
                    <Compass className="w-3.5 h-3.5 text-purple-400" />
                    <span>Learning Goals</span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight font-display-periodic">
                    What are you here for?
                  </h2>
                  <p className="text-xs text-slate-300 font-sans">
                    Tell us what you aim to accomplish today:
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 font-mono text-xs max-h-[250px] overflow-y-auto pr-1">
                  {PURPOSE_OPTIONS.map((item) => {
                    const isSelected = selectedPurposes.includes(item.id);
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => togglePurpose(item.id)}
                        className={`p-3 rounded-2xl border text-left transition-all flex items-center justify-between gap-2 ${
                          isSelected
                            ? 'bg-purple-500/20 border-purple-400 text-purple-200 shadow-sm shadow-purple-500/20 font-bold'
                            : 'bg-white/[0.02] border-white/10 text-slate-400 hover:text-slate-200 hover:bg-white/5'
                        }`}
                      >
                        <span className="truncate text-xs">{item.label}</span>
                        {isSelected && (
                          <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </motion.div>
            )}

            {/* CARD 05 — Discovery */}
            {currentCard === 5 && (
              <motion.div
                key="card-5"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.22 }}
                className="space-y-4"
              >
                <div className="space-y-1.5">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30 text-xs font-mono">
                    <Globe className="w-3.5 h-3.5 text-amber-400" />
                    <span>Discovery</span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight font-display-periodic">
                    How did you discover Chemisphere 3D?
                  </h2>
                  <p className="text-xs text-slate-300 font-sans">
                    Help us learn how you found our interactive platform:
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 font-mono text-xs max-h-[250px] overflow-y-auto pr-1">
                  {REFERRAL_SOURCES.map((source) => {
                    const isSelected = selectedDiscovery === source.id;
                    return (
                      <button
                        key={source.id}
                        type="button"
                        onClick={() => setSelectedDiscovery(source.id)}
                        className={`p-3 rounded-2xl border text-left transition-all flex items-center justify-between gap-1.5 ${
                          isSelected
                            ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-sm shadow-amber-500/20 font-bold'
                            : 'bg-white/[0.02] border-white/10 text-slate-400 hover:text-slate-200 hover:bg-white/5'
                        }`}
                      >
                        <span className="truncate text-[11px]">{source.label}</span>
                        {isSelected && (
                          <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </motion.div>
            )}

            {/* CARD 06 — Finish */}
            {currentCard === 6 && (
              <motion.div
                key="card-6"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.22 }}
                className="space-y-6 text-center sm:text-left"
              >
                <div className="space-y-2">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 text-xs font-mono">
                    <Award className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Workspace Configured</span>
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-display-periodic">
                    Your Chemistry Universe is ready, {name.trim() || 'Explorer'}.
                  </h2>
                  <p className="text-sm text-slate-300 font-sans leading-relaxed">
                    Personalized with your focus on <strong className="text-cyan-300 font-mono">{selectedInterests.join(', ')}</strong>. You can dive in directly or take the guided interactive tour.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2 font-mono">
                  {/* Option A: Explore Directly */}
                  <button
                    onClick={handleExploreAction}
                    className="p-4 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/20 text-left transition-all hover:border-cyan-400/50 group flex flex-col justify-between space-y-3"
                  >
                    <div className="flex items-center justify-between text-slate-300">
                      <Atom className="w-6 h-6 text-cyan-400 group-hover:scale-110 transition-transform" />
                      <ArrowRight className="w-4 h-4 text-slate-400 group-hover:translate-x-1 transition-transform" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-white group-hover:text-cyan-300">
                        Explore Chemisphere
                      </div>
                      <div className="text-[11px] text-slate-400 font-sans mt-0.5">
                        Jump straight into the command deck and interactive laboratories.
                      </div>
                    </div>
                  </button>

                  {/* Option B: Take the Guided Tour */}
                  <button
                    onClick={handleTourAction}
                    className="p-4 rounded-2xl bg-gradient-to-br from-cyan-500/20 via-purple-500/20 to-cyan-500/10 hover:from-cyan-500/30 hover:to-purple-500/30 border border-cyan-400 text-left transition-all shadow-lg shadow-cyan-500/20 group flex flex-col justify-between space-y-3"
                  >
                    <div className="flex items-center justify-between text-cyan-300">
                      <Compass className="w-6 h-6 text-cyan-300 group-hover:scale-110 transition-transform" />
                      <Sparkles className="w-4 h-4 text-cyan-300" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-cyan-200 group-hover:text-white">
                        Take the Guided Tour
                      </div>
                      <div className="text-[11px] text-cyan-300/80 font-sans mt-0.5">
                        Learn how each 3D lab, spectroscopy instrument, and tool works.
                      </div>
                    </div>
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Footer Navigation Controls */}
        <div className="pt-4 border-t border-white/10 flex items-center justify-between relative z-10">
          {currentCard > 1 && currentCard < 6 ? (
            <button
              onClick={() => setCurrentCard((prev) => prev - 1)}
              className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-slate-300 hover:text-white flex items-center gap-1.5 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>
          ) : (
            <div />
          )}

          <div className="flex items-center gap-2">
            {currentCard === 1 && (
              <button
                onClick={handleNextFromCard1}
                className="px-6 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold font-mono text-xs transition-all flex items-center gap-2 shadow-lg shadow-cyan-500/20"
              >
                <span>Get Started</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {currentCard === 2 && (
              <button
                onClick={handleNextFromCard2}
                className="px-6 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold font-mono text-xs transition-all flex items-center gap-2 shadow-lg shadow-cyan-500/20"
              >
                <span>Continue</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {currentCard === 3 && (
              <button
                onClick={handleNextFromCard3}
                className="px-6 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold font-mono text-xs transition-all flex items-center gap-2 shadow-lg shadow-cyan-500/20"
              >
                <span>Next: Purpose</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {currentCard === 4 && (
              <button
                onClick={handleNextFromCard4}
                className="px-6 py-2.5 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-bold font-mono text-xs transition-all flex items-center gap-2 shadow-lg shadow-purple-500/20"
              >
                <span>Next: Discovery</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {currentCard === 5 && (
              <button
                onClick={handleNextFromCard5}
                className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold font-mono text-xs transition-all flex items-center gap-2 shadow-lg shadow-amber-500/20"
              >
                <span>Finalize Setup</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
};
