import React from 'react';
import { LatexRenderer } from './LatexRenderer';

interface ChemistryMarkdownProps {
  content: string;
  className?: string;
}

export const ChemistryMarkdown: React.FC<ChemistryMarkdownProps> = ({
  content,
  className = ''
}) => {
  if (!content) return null;

  // Helper to parse blocks (headers, lists, math blocks, paragraphs)
  const parseContent = (text: string) => {
    // Split text by lines
    const lines = text.split('\n');
    const elements: React.ReactNode[] = [];
    let currentParagraph: string[] = [];

    const flushParagraph = (key: string) => {
      if (currentParagraph.length > 0) {
        const pText = currentParagraph.join(' ');
        elements.push(
          <p key={key} className="mb-2 leading-relaxed">
            {renderInline(pText)}
          </p>
        );
        currentParagraph = [];
      }
    };

    lines.forEach((line, index) => {
      const trimmed = line.trim();

      // Check for LaTeX block $$...$$
      if (trimmed.startsWith('$$') && trimmed.endsWith('$$') && trimmed.length > 4) {
        flushParagraph(`p-${index}`);
        const mathContent = trimmed.slice(2, -2).trim();
        elements.push(
          <div key={`math-${index}`} className="my-3 p-3 rounded-xl bg-cyan-950/20 border border-cyan-500/20 flex justify-center overflow-x-auto">
            <LatexRenderer latex={mathContent} displayMode={true} className="text-cyan-300 text-sm" />
          </div>
        );
        return;
      }

      // Check for markdown headers
      if (trimmed.startsWith('### ')) {
        flushParagraph(`p-${index}`);
        elements.push(
          <h4 key={`h3-${index}`} className="text-sm font-bold text-cyan-300 mt-3 mb-1.5 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
            {renderInline(trimmed.slice(4))}
          </h4>
        );
        return;
      }

      if (trimmed.startsWith('## ')) {
        flushParagraph(`p-${index}`);
        elements.push(
          <h3 key={`h2-${index}`} className="text-base font-bold text-white mt-4 mb-2">
            {renderInline(trimmed.slice(3))}
          </h3>
        );
        return;
      }

      // Check for bullet list items
      if (trimmed.startsWith('- ') || trimmed.startsWith('* ') || trimmed.startsWith('• ')) {
        flushParagraph(`p-${index}`);
        elements.push(
          <div key={`li-${index}`} className="flex items-start gap-2 ml-2 mb-1.5">
            <span className="text-cyan-400 mt-1 shrink-0 font-bold">•</span>
            <span className="leading-relaxed">{renderInline(trimmed.slice(2))}</span>
          </div>
        );
        return;
      }

      // Numbered list item
      const numMatch = trimmed.match(/^(\d+)\.\s+(.*)/);
      if (numMatch) {
        flushParagraph(`p-${index}`);
        elements.push(
          <div key={`num-${index}`} className="flex items-start gap-2 ml-2 mb-1.5">
            <span className="text-purple-400 font-mono font-bold shrink-0">{numMatch[1]}.</span>
            <span className="leading-relaxed">{renderInline(numMatch[2])}</span>
          </div>
        );
        return;
      }

      // Empty line
      if (trimmed === '') {
        flushParagraph(`p-${index}`);
        return;
      }

      currentParagraph.push(trimmed);
    });

    flushParagraph('final-p');
    return elements;
  };

  // Helper to render inline formatting: bold (**text**), code (`text`), inline math ($latex$)
  const renderInline = (text: string): React.ReactNode => {
    // Split by inline math $...$ first
    const parts = text.split(/(\$[^$]+\$)/g);

    return parts.map((part, pIdx) => {
      if (part.startsWith('$') && part.endsWith('$') && part.length > 2) {
        const math = part.slice(1, -1);
        return (
          <LatexRenderer
            key={`imath-${pIdx}`}
            latex={math}
            displayMode={false}
            className="text-cyan-300 font-mono px-1"
          />
        );
      }

      // Process bold **bold**
      const boldParts = part.split(/(\*\*[^*]+\*\*)/g);
      return boldParts.map((bPart, bIdx) => {
        if (bPart.startsWith('**') && bPart.endsWith('**') && bPart.length > 4) {
          return (
            <strong key={`bold-${pIdx}-${bIdx}`} className="font-bold text-white">
              {bPart.slice(2, -2)}
            </strong>
          );
        }

        // Process inline code `code`
        const codeParts = bPart.split(/(`[^`]+`)/g);
        return codeParts.map((cPart, cIdx) => {
          if (cPart.startsWith('`') && cPart.endsWith('`') && cPart.length > 2) {
            return (
              <code
                key={`code-${pIdx}-${bIdx}-${cIdx}`}
                className="px-1.5 py-0.5 rounded bg-white/10 text-cyan-300 font-mono text-[11px] border border-white/10"
              >
                {cPart.slice(1, -1)}
              </code>
            );
          }
          return cPart;
        });
      });
    });
  };

  return <div className={`text-xs text-slate-200 ${className}`}>{parseContent(content)}</div>;
};
