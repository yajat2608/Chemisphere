import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GlobalNav } from './components/navigation/GlobalNav';
import { CommandPalette } from './components/navigation/CommandPalette';
import { HomeUniverseView } from './components/views/HomeUniverseView';
import { PeriodicTableView } from './components/views/PeriodicTableView';
import { OrbitalAtlasView } from './components/views/OrbitalAtlasView';
import { MoleculeLabView } from './components/views/MoleculeLabView';
import { VseprLabView } from './components/views/VseprLabView';
import { AtomicStructureView } from './components/views/AtomicStructureView';
import { StoichiometryView } from './components/views/StoichiometryView';
import { PhysicalChemView } from './components/views/PhysicalChemView';
import { OrganicChemView } from './components/views/OrganicChemView';
import { FormulaVaultView } from './components/views/FormulaVaultView';
import { PracticeView } from './components/views/PracticeView';
import { AiTutorView } from './components/views/AiTutorView';
import { CreatorPortfolioView } from './components/views/CreatorPortfolioView';
import { BeautyOfChemistryView } from './components/beauty/BeautyOfChemistryView';
import { LabDirectoryView } from './components/views/LabDirectoryView';
import { SpectroscopySuiteView } from './components/views/SpectroscopySuiteView';
import { QuantumLabView } from './components/views/QuantumLabView';
import { NuclearChemistryView } from './components/views/NuclearChemistryView';
import { ThermoKineticsView } from './components/views/ThermoKineticsView';
import { AdvancedOrganicLabView } from './components/views/AdvancedOrganicLabView';
import { AnalyticalLabView } from './components/views/AnalyticalLabView';
import { ElectrochemistryLabView } from './components/views/ElectrochemistryLabView';
import { AtomicSpectraLabView } from './components/views/AtomicSpectraLabView';
import { WavesRadiationLabView } from './components/views/WavesRadiationLabView';
import { QuestionsPlaygroundView } from './components/views/QuestionsPlaygroundView';
import { VirtualChemistryLabView } from './components/views/VirtualChemistryLabView';
import { ScientificArchiveView } from './components/views/ScientificArchiveView';
import { UserProfileView } from './components/views/UserProfileView';
import { ChemistryToolsMasterView } from './components/views/ChemistryToolsMasterView';
import { ChemistryMapView } from './components/views/ChemistryMapView';
import { FirstEntryIntroModal } from './components/common/FirstEntryIntroModal';
import { GuidedTourSystem } from './components/tutorial/GuidedTourSystem';
import { QuickChembotModal } from './components/ai/QuickChembotModal';
import { Footer } from './components/navigation/Footer';
import { NavigationTab, ChemicalElement } from './types';
import { logLabVisit } from './data/sessionHistory';
import { getUserProfile, userPassportStore } from './data/UserPassportStore';
import { Atom, Sparkles, Heart, Bot, GraduationCap, MessageSquare, Boxes } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('home');
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [isQuickChembotOpen, setIsQuickChembotOpen] = useState(false);
  const [chembotInitialQuery, setChembotInitialQuery] = useState<string | undefined>(undefined);
  const [chembotContextData, setChembotContextData] = useState<any>(undefined);

  // First-entry cinematic popup modal
  const [isFirstEntryIntroOpen, setIsFirstEntryIntroOpen] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const profile = getUserProfile();
      return !profile.hasCompletedOnboarding;
    }
    return false;
  });

  // Guided tour interactive walkthrough system
  const [isGuidedTourOpen, setIsGuidedTourOpen] = useState<boolean>(false);
  const [selectedElementForModal, setSelectedElementForModal] = useState<ChemicalElement | null>(null);
  
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('chemisphere_theme');
      if (saved === 'light' || saved === 'dark') return saved;
    }
    return 'dark';
  });

  const [motionIntensity, setMotionIntensity] = useState<'minimal' | 'balanced' | 'dynamic'>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('chemisphere_motion');
      if (saved === 'minimal' || saved === 'balanced' || saved === 'dynamic') return saved;
    }
    return 'balanced';
  });

  // Sync theme with html root class and localStorage
  useEffect(() => {
    localStorage.setItem('chemisphere_theme', theme);
    if (theme === 'light') {
      document.documentElement.classList.add('light');
      document.documentElement.classList.remove('dark');
    } else {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
    }
  }, [theme]);

  // Sync motion intensity with html attribute
  useEffect(() => {
    localStorage.setItem('chemisphere_motion', motionIntensity);
    document.documentElement.setAttribute('data-motion', motionIntensity);
  }, [motionIntensity]);

  // Track session history and UserPassportStore exploration on tab change
  useEffect(() => {
    if (activeTab !== 'home') {
      logLabVisit(activeTab);
      userPassportStore.recordTabVisit(activeTab);
    }
  }, [activeTab]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const cycleMotionIntensity = () => {
    setMotionIntensity((prev) => {
      if (prev === 'balanced') return 'dynamic';
      if (prev === 'dynamic') return 'minimal';
      return 'balanced';
    });
  };

  // Global keyboard shortcut (Ctrl+K or Cmd+K) to open Command Palette
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleNavigate = (tab: NavigationTab) => {
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectElement = (el: ChemicalElement) => {
    setSelectedElementForModal(el);
    setActiveTab('periodic-table');
  };

  const handleOpenChembotWithContext = (query: string, context?: any) => {
    setChembotInitialQuery(query);
    setChembotContextData(context);
    setIsQuickChembotOpen(true);
  };

  return (
    <div className={`min-h-screen ${theme === 'light' ? 'light bg-[#f8fafc] text-slate-900' : 'dark bg-[#050505] text-slate-100'} flex flex-col selection:bg-cyan-500 selection:text-slate-950 relative overflow-x-hidden transition-colors duration-300`}>
      {/* Background Micro-Textured Grid */}
      <div className="fixed inset-0 pointer-events-none frosted-dot-grid opacity-25 z-0" />
      
      {/* Top Global Navigation Bar */}
      <GlobalNav
        activeTab={activeTab}
        onTabChange={handleNavigate}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        onOpenTutorial={() => setIsGuidedTourOpen(true)}
        theme={theme}
        onToggleTheme={toggleTheme}
        motionIntensity={motionIntensity}
        onCycleMotion={cycleMotionIntensity}
      />

      {/* Main View Area with Framer Motion transitions */}
      <main className="flex-1 w-full relative z-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: motionIntensity === 'minimal' ? 0 : 8, scale: motionIntensity === 'minimal' ? 1 : 0.995 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: motionIntensity === 'minimal' ? 0 : -8, scale: motionIntensity === 'minimal' ? 1 : 0.995 }}
            transition={{ duration: motionIntensity === 'minimal' ? 0.05 : 0.22, ease: [0.16, 1, 0.3, 1] }}
            className="w-full"
          >
            {activeTab === 'home' && <HomeUniverseView onNavigate={handleNavigate} />}
            {activeTab === 'chemistry-map' && (
              <ChemistryMapView
                onNavigate={handleNavigate}
                onConsultAi={handleOpenChembotWithContext}
              />
            )}
            {activeTab === 'tools' && (
              <ChemistryToolsMasterView
                onNavigateToTab={handleNavigate}
                onOpenChembotWithContext={handleOpenChembotWithContext}
              />
            )}
            {activeTab === 'questions-playground' && <QuestionsPlaygroundView onNavigate={handleNavigate} />}
            {activeTab === 'chemistry-lab' && <VirtualChemistryLabView onNavigate={handleNavigate} />}
            {activeTab === 'archive' && <ScientificArchiveView onNavigate={handleNavigate} />}
            {activeTab === 'profile' && (
              <UserProfileView
                onNavigate={handleNavigate}
                onOpenTutorial={() => setIsGuidedTourOpen(true)}
                onOpenIntroModal={() => setIsFirstEntryIntroOpen(true)}
              />
            )}
            {activeTab === 'lab-directory' && <LabDirectoryView onNavigate={handleNavigate} />}
            {activeTab === 'atomic-spectra' && <AtomicSpectraLabView onNavigate={handleNavigate} />}
            {activeTab === 'waves-radiation' && <WavesRadiationLabView onNavigate={handleNavigate} />}
            {activeTab === 'spectroscopy-suite' && <SpectroscopySuiteView onNavigate={handleNavigate} />}
            {activeTab === 'quantum-lab' && <QuantumLabView onNavigate={handleNavigate} />}
            {(activeTab === 'nuclear-chemistry' || activeTab === 'nuclear-lab') && <NuclearChemistryView onNavigate={handleNavigate} />}
            {activeTab === 'thermo-kinetics' && <ThermoKineticsView onNavigate={handleNavigate} />}
            {(activeTab === 'advanced-organic' || activeTab === 'organic-mechanisms') && <AdvancedOrganicLabView onNavigate={handleNavigate} />}
            {(activeTab === 'analytical-lab' || activeTab === 'analytical-materials') && <AnalyticalLabView onNavigate={handleNavigate} />}
            {(activeTab === 'electrochemistry-lab' || activeTab === 'electro-solutions') && <ElectrochemistryLabView onNavigate={handleNavigate} />}
            {activeTab === 'beauty-of-chemistry' && <BeautyOfChemistryView onNavigate={handleNavigate} />}
            {activeTab === 'periodic-table' && (
              <PeriodicTableView
                onNavigate={handleNavigate}
                selectedElementFromProp={selectedElementForModal}
              />
            )}
            {activeTab === 'orbital-atlas' && <OrbitalAtlasView onNavigate={handleNavigate} />}
            {activeTab === 'molecules-3d' && <MoleculeLabView onNavigate={handleNavigate} />}
            {activeTab === 'vsepr-lab' && <VseprLabView onNavigate={handleNavigate} />}
            {activeTab === 'atomic-structure' && <AtomicStructureView onNavigate={handleNavigate} />}
            {activeTab === 'stoichiometry' && <StoichiometryView onNavigate={handleNavigate} />}
            {activeTab === 'physical-chem' && <PhysicalChemView onNavigate={handleNavigate} />}
            {activeTab === 'organic-chem' && <OrganicChemView onNavigate={handleNavigate} />}
            {activeTab === 'formula-vault' && <FormulaVaultView onNavigate={handleNavigate} />}
            {activeTab === 'practice' && <PracticeView onNavigate={handleNavigate} />}
            {activeTab === 'ai-tutor' && <AiTutorView onNavigate={handleNavigate} />}
            {activeTab === 'creator' && <CreatorPortfolioView onNavigate={handleNavigate} />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* FIRST ENTRY INTRODUCTION POPUP MODAL (Appears centered over heavily blurred background on first visit) */}
      <FirstEntryIntroModal
        isOpen={isFirstEntryIntroOpen}
        onClose={() => setIsFirstEntryIntroOpen(false)}
        onTakeGuidedTour={() => {
          setIsFirstEntryIntroOpen(false);
          setIsGuidedTourOpen(true);
        }}
        onExploreChemisphere={() => {
          setIsFirstEntryIntroOpen(false);
        }}
        onLaunchTutorial={() => {
          setIsFirstEntryIntroOpen(false);
          setIsGuidedTourOpen(true);
        }}
        onExploreDirectly={(tab) => {
          setIsFirstEntryIntroOpen(false);
          if (tab) handleNavigate(tab);
        }}
      />

      {/* GUIDED TUTORIAL WALKTHROUGH SYSTEM */}
      <GuidedTourSystem
        isOpen={isGuidedTourOpen}
        onClose={() => setIsGuidedTourOpen(false)}
        onNavigate={handleNavigate}
        onOpenChembot={(prompt) => {
          handleOpenChembotWithContext(prompt);
        }}
      />

      {/* Floating ChemoBot Quick Action */}
      {activeTab !== 'ai-tutor' && (
        <button
          onClick={() => {
            setChembotInitialQuery(undefined);
            setChembotContextData(undefined);
            setIsQuickChembotOpen(true);
          }}
          className="fixed bottom-6 right-6 z-40 p-3.5 rounded-2xl bg-gradient-to-br from-violet-600 via-indigo-600 to-cyan-600 text-white shadow-2xl shadow-violet-600/40 border border-violet-400/40 hover:scale-105 active:scale-95 transition-all flex items-center gap-2 font-mono text-xs group"
          title="Open ChemoBot Scientific Assistant"
        >
          <Sparkles className="w-4 h-4 group-hover:rotate-12 transition-transform text-cyan-200" />
          <span className="hidden sm:inline font-bold">ChemoBot Assistant</span>
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        </button>
      )}

      {/* Quick ChemBot Drawer/Modal */}
      <QuickChembotModal
        isOpen={isQuickChembotOpen}
        onClose={() => {
          setIsQuickChembotOpen(false);
          setChembotInitialQuery(undefined);
        }}
        onNavigate={handleNavigate}
        currentTab={activeTab}
        initialQuery={chembotInitialQuery}
        contextData={chembotContextData}
      />

      {/* Global Command Palette (Cmd + K) */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        onNavigate={handleNavigate}
        onSelectElement={handleSelectElement}
      />

      {/* Editorial Scientific 4-Column Footer */}
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}
