import { ChemicalReaction } from '../types';

export const REACTIONS_DATA: ChemicalReaction[] = [
  {
    id: 'naoh-hcl',
    name: 'Strong Acid - Strong Base Neutralization',
    category: 'Acid-Base',
    reactants: ['NaOH', 'HCl'],
    products: ['NaCl', 'H₂O'],
    balancedEquation: 'NaOH (aq) + HCl (aq) \\rightarrow NaCl (aq) + H_2O (l)',
    ionicEquation: 'Na^+ (aq) + OH^- (aq) + H^+ (aq) + Cl^- (aq) \\rightarrow Na^+ (aq) + Cl^- (aq) + H_2O (l)',
    netIonicEquation: 'H^+ (aq) + OH^- (aq) \\rightarrow H_2O (l)',
    deltaH: '-57.3 kJ/mol',
    typeDescription: 'Exothermic proton transfer neutralization forming neutral salt and water.',
    conditions: 'Standard Room Temperature (298 K, 1 atm)',
    applications: 'Acid-base volumetric titration, antacid pharmaceutical mechanisms, chemical waste pH neutralization.'
  },
  {
    id: 'haber-bosch',
    name: 'Haber-Bosch Ammonia Synthesis',
    category: 'Synthesis',
    reactants: ['N₂', 'H₂'],
    products: ['NH₃'],
    balancedEquation: 'N_2 (g) + 3H_2 (g) \\rightleftharpoons 2NH_3 (g)',
    ionicEquation: 'N/A (Covalent Molecular Gas Phase)',
    netIonicEquation: 'N_2 (g) + 3H_2 (g) \\rightleftharpoons 2NH_3 (g)',
    deltaH: '-92.4 kJ/mol',
    typeDescription: 'Exothermic gas-phase dynamic equilibrium reaction governed by Le Chatelier principle.',
    conditions: '400-450 °C, 150-200 atm, Osmium/Iron catalyst (promoted with K₂O/Al₂O₃)',
    applications: 'Production of global synthetic fertilizers feeding roughly half the world\'s human population.'
  },
  {
    id: 'combustion-methane',
    name: 'Complete Combustion of Methane',
    category: 'Combustion',
    reactants: ['CH₄', 'O₂'],
    products: ['CO₂', 'H₂O'],
    balancedEquation: 'CH_4 (g) + 2O_2 (g) \\rightarrow CO_2 (g) + 2H_2O (g)',
    deltaH: '-890.3 kJ/mol',
    typeDescription: 'Highly exothermic rapid oxidation releasing energy and carbon dioxide.',
    conditions: 'Ignition spark, excess oxygen',
    applications: 'Natural gas power generation, residential heating, industrial furnaces.'
  },
  {
    id: 'sn2-bromomethane',
    name: 'SN2 Nucleophilic Substitution (Bimolecular)',
    category: 'Organic',
    reactants: ['CH₃Br', 'OH⁻'],
    products: ['CH₃OH', 'Br⁻'],
    balancedEquation: 'CH_3Br + OH^- \\rightarrow CH_3OH + Br^-',
    deltaH: '-85 kJ/mol',
    typeDescription: 'Concerted single-step mechanism with backside attack, pentacoordinate transition state, and Walden inversion.',
    conditions: 'Polar aprotic solvent (DMSO or Acetone), strong nucleophile',
    applications: 'Stereospecific organic synthesis, pharmaceutical drug chiral intermediate construction.'
  },
  {
    id: 'sn1-tbutyl',
    name: 'SN1 Nucleophilic Substitution (Unimolecular)',
    category: 'Organic',
    reactants: ['(CH₃)₃C-Br', 'H₂O'],
    products: ['(CH₃)₃C-OH', 'HBr'],
    balancedEquation: '(CH_3)_3C-Br + H_2O \\rightarrow (CH_3)_3C-OH + HBr',
    deltaH: '-40 kJ/mol',
    typeDescription: 'Two-step mechanism involving rate-determining carbocation intermediate generation followed by nucleophilic capture (racemization).',
    conditions: 'Polar protic solvent (H₂O, EtOH), tertiary substrate',
    applications: 'Synthesis of bulky tertiary alcohols and ethers.'
  },
  {
    id: 'daniell-cell',
    name: 'Zinc-Copper Redox Couple (Daniell Cell)',
    category: 'Redox',
    reactants: ['Zn (s)', 'Cu²⁺ (aq)'],
    products: ['Zn²⁺ (aq)', 'Cu (s)'],
    balancedEquation: 'Zn (s) + Cu^{2+} (aq) \\rightarrow Zn^{2+} (aq) + Cu (s)',
    deltaH: '-218 kJ/mol (E° = +1.10 V)',
    typeDescription: 'Spontaneous 2-electron transfer from zinc anode to copper cathode through external circuit.',
    conditions: 'Aqueous electrolyte with salt bridge (KNO₃ / KCl)',
    applications: 'Historical primary electrochemical batteries and modern galvanic cell education.'
  },
  {
    id: 'silver-chloride-precip',
    name: 'Silver Chloride Precipitation',
    category: 'Precipitation',
    reactants: ['AgNO₃', 'NaCl'],
    products: ['AgCl (s)', 'NaNO₃'],
    balancedEquation: 'AgNO_3 (aq) + NaCl (aq) \\rightarrow AgCl (s) \\downarrow + NaNO_3 (aq)',
    netIonicEquation: 'Ag^+ (aq) + Cl^- (aq) \\rightarrow AgCl (s) \\downarrow',
    typeDescription: 'Curdy white precipitate formation due to extremely low solubility product (K_sp = 1.8 × 10⁻¹⁰).',
    conditions: 'Room temperature aqueous mixing',
    applications: 'Qualitative chloride identification test, gravimetric analysis, water salinity testing.'
  },
  {
    id: 'esterification-fischer',
    name: 'Fischer Esterification',
    category: 'Organic',
    reactants: ['CH₃COOH', 'C₂H₅OH'],
    products: ['CH₃COOC₂H₅ (Ethyl Acetate)', 'H₂O'],
    balancedEquation: 'CH_3COOH + C_2H_5OH \\xrightleftharpoons{H^+} CH_3COOC_2H_5 + H_2O',
    typeDescription: 'Acid-catalyzed condensation between carboxylic acid and alcohol forming fruity-scented ester.',
    conditions: 'Concentrated H₂SO₄ catalyst, reflux heat',
    applications: 'Flavoring industry, fragrance synthesis, industrial solvent manufacturing.'
  }
];

export interface OrganicTransformationNode {
  id: string;
  name: string;
  formula: string;
  functionalGroup: string;
  x: number;
  y: number;
}

export interface OrganicReactionEdge {
  from: string;
  to: string;
  reagent: string;
  conditions: string;
  mechanism: string;
  type: string;
}

export const ORGANIC_REACTION_MAP: { nodes: OrganicTransformationNode[]; edges: OrganicReactionEdge[] } = {
  nodes: [
    { id: 'alkane', name: 'Alkane (Ethane)', formula: 'CH₃-CH₃', functionalGroup: 'C-C Single Bond', x: 80, y: 100 },
    { id: 'haloalkane', name: 'Haloalkane (Bromoethane)', formula: 'CH₃-CH₂Br', functionalGroup: 'Alkyl Halide (-X)', x: 280, y: 100 },
    { id: 'alkene', name: 'Alkene (Ethene)', formula: 'CH₂=CH₂', functionalGroup: 'C=C Double Bond', x: 480, y: 100 },
    { id: 'alcohol', name: 'Primary Alcohol (Ethanol)', formula: 'CH₃-CH₂OH', functionalGroup: 'Hydroxyl (-OH)', x: 280, y: 260 },
    { id: 'aldehyde', name: 'Aldehyde (Acetaldehyde)', formula: 'CH₃-CHO', functionalGroup: 'Carbonyl (-CHO)', x: 480, y: 260 },
    { id: 'carboxylic', name: 'Carboxylic Acid (Acetic Acid)', formula: 'CH₃-COOH', functionalGroup: 'Carboxyl (-COOH)', x: 680, y: 260 },
    { id: 'ester', name: 'Ester (Ethyl Acetate)', formula: 'CH₃-COO-C₂H₅', functionalGroup: 'Ester (-COOR)', x: 680, y: 400 },
    { id: 'alkyne', name: 'Alkyne (Ethyne)', formula: 'CH≡CH', functionalGroup: 'C≡C Triple Bond', x: 680, y: 100 }
  ],
  edges: [
    { from: 'alkane', to: 'haloalkane', reagent: 'Br₂ / UV Light (hν)', conditions: 'Free radical substitution', mechanism: 'Free Radical Halogenation', type: 'Substitution' },
    { from: 'haloalkane', to: 'alkene', reagent: 'Alcoholic KOH / Heat (Δ)', conditions: 'Beta-elimination', mechanism: 'E2 Elimination', type: 'Elimination' },
    { from: 'alkene', to: 'haloalkane', reagent: 'HBr', conditions: 'Markovnikov addition', mechanism: 'Electrophilic Addition', type: 'Addition' },
    { from: 'haloalkane', to: 'alcohol', reagent: 'Aqueous KOH', conditions: 'Nucleophilic substitution', mechanism: 'SN2 Substitution', type: 'Substitution' },
    { from: 'alkene', to: 'alcohol', reagent: 'H₂O / Dilute H₂SO₄', conditions: 'Acid-catalyzed hydration', mechanism: 'Electrophilic Addition', type: 'Hydration' },
    { from: 'alcohol', to: 'alkene', reagent: 'Conc. H₂SO₄ / 170 °C', conditions: 'Dehydration', mechanism: 'E1 Elimination', type: 'Dehydration' },
    { from: 'alcohol', to: 'aldehyde', reagent: 'PCC (Pyridinium Chlorochromate)', conditions: 'Controlled mild oxidation', mechanism: 'Oxidation', type: 'Oxidation' },
    { from: 'aldehyde', to: 'carboxylic', reagent: 'KMnO₄ / Acidic or K₂Cr₂O₇', conditions: 'Strong oxidation', mechanism: 'Oxidation', type: 'Oxidation' },
    { from: 'alcohol', to: 'carboxylic', reagent: 'Jones Reagent (CrO₃ / H₂SO₄)', conditions: 'Direct vigorous oxidation', mechanism: 'Oxidation', type: 'Oxidation' },
    { from: 'carboxylic', to: 'ester', reagent: 'Ethanol (C₂H₅OH) + Conc. H₂SO₄', conditions: 'Reflux heat (Δ)', mechanism: 'Nucleophilic Acyl Substitution', type: 'Esterification' },
    { from: 'alkene', to: 'alkyne', reagent: '1. Br₂ / CCl₄  2. NaNH₂ / Heat', conditions: 'Vicinal dihalide double dehydrohalogenation', mechanism: 'Double E2', type: 'Elimination' }
  ]
};
