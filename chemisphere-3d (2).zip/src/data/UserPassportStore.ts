import { useSyncExternalStore, useCallback } from 'react';
import { NavigationTab } from '../types';

export const USER_PASSPORT_STORAGE_KEY = 'chemisphere_user_profile_v3';
export const ONBOARDING_COMPLETED_KEY = 'chemisphere_onboarding_done_v3';
export const TUTORIAL_COMPLETED_KEY = 'chemisphere_tutorial_done_v3';
export const PASSPORT_EVENT_CHANNEL = 'chemisphere_passport_updated';
export const LEGACY_PROFILE_EVENT_CHANNEL = 'chemisphere_profile_updated';
export const BADGE_UNLOCKED_EVENT_CHANNEL = 'chemisphere_badge_unlocked';

export interface ChemistryInterestOption {
  id: string;
  label: string;
  category: string;
  icon: string;
  description: string;
  recommendedTab: NavigationTab;
}

export const CHEMISTRY_INTEREST_CHIPS: { id: string; label: string; icon: string }[] = [
  { id: 'Organic', label: 'Organic', icon: 'Dna' },
  { id: 'Inorganic', label: 'Inorganic', icon: 'Grid3X3' },
  { id: 'Physical', label: 'Physical', icon: 'Flame' },
  { id: 'Analytical', label: 'Analytical', icon: 'Activity' },
  { id: 'Quantum', label: 'Quantum', icon: 'Orbit' },
  { id: 'Spectroscopy', label: 'Spectroscopy', icon: 'Activity' },
  { id: 'Electrochemistry', label: 'Electrochemistry', icon: 'Zap' },
  { id: 'Nuclear', label: 'Nuclear', icon: 'Radio' },
  { id: 'Biochemistry', label: 'Biochemistry', icon: 'Layers' },
  { id: 'Materials', label: 'Materials', icon: 'Boxes' },
  { id: 'Molecular Chemistry', label: 'Molecular Chemistry', icon: 'Atom' },
  { id: 'Chemistry Calculations', label: 'Chemistry Calculations', icon: 'FlaskConical' }
];

export const CHEMISTRY_INTERESTS = CHEMISTRY_INTEREST_CHIPS;

export const PURPOSE_OPTIONS: { id: string; label: string; icon: string }[] = [
  { id: 'Learn', label: 'Learn', icon: 'BookOpen' },
  { id: 'Exam preparation', label: 'Exam preparation', icon: 'GraduationCap' },
  { id: 'Practice', label: 'Practice', icon: 'Trophy' },
  { id: 'Virtual experiments', label: 'Virtual experiments', icon: 'FlaskConical' },
  { id: 'Research', label: 'Research', icon: 'Search' },
  { id: 'Explore concepts', label: 'Explore concepts', icon: 'Sparkles' },
  { id: 'Solve problems', label: 'Solve problems', icon: 'Zap' },
  { id: 'Understand difficult topics', label: 'Understand difficult topics', icon: 'HelpCircle' }
];

export interface ReferralOption {
  id: string;
  label: string;
  icon: string;
}

export const REFERRAL_SOURCES: ReferralOption[] = [
  { id: 'school', label: 'School / High School Class', icon: 'GraduationCap' },
  { id: 'university', label: 'University / College Chemistry', icon: 'BookOpen' },
  { id: 'teacher', label: 'Chemistry Teacher / Professor', icon: 'Award' },
  { id: 'friend', label: 'Friend / Classmate Recommendation', icon: 'Users' },
  { id: 'social', label: 'YouTube / Social Media / Video', icon: 'Globe' },
  { id: 'search', label: 'Web Search (Google / AI Search)', icon: 'Search' },
  { id: 'olympiad', label: 'Chemistry Olympiad / Science Fair', icon: 'Trophy' },
  { id: 'creator', label: 'Yajat Sarkar Creator Portfolio', icon: 'Sparkles' },
  { id: 'other', label: 'Other Scientific Discovery', icon: 'Compass' }
];

export interface UserBadge {
  id: string;
  name: string;
  icon: string;
  description: string;
  category?: string;
  xpReward?: number;
  unlockedAt?: number;
}

export const SYSTEM_BADGES: UserBadge[] = [
  { id: 'initiate', name: 'Chemisphere Initiate', icon: 'Sparkles', description: 'Completed welcome onboarding and started your journey', xpReward: 50 },
  { id: 'lab_apprentice', name: 'Lab Apprentice', icon: 'FlaskConical', description: 'Conducted your first reaction in the Virtual Chemistry Lab', xpReward: 50 },
  { id: 'element_explorer', name: 'Element Explorer', icon: 'Grid3X3', description: 'Explored 20+ chemical elements across the periodic table', xpReward: 100 },
  { id: 'quantum_explorer', name: 'Quantum Explorer', icon: 'Orbit', description: 'Explored 3D Quantum Orbitals and Atomic Spectra', xpReward: 75 },
  { id: 'spectrum_hunter', name: 'Spectrum Hunter', icon: 'Activity', description: 'Analyzed emission spectra in the Spectroscopy Suite', xpReward: 75 },
  { id: 'synthesis_architect', name: 'Synthesis Architect', icon: 'Dna', description: 'Navigated the Organic Reaction Highway & Synthesis', xpReward: 75 },
  { id: 'organic_navigator', name: 'Organic Navigator', icon: 'Layers', description: 'Mastered organic mechanisms and stereochemistry', xpReward: 100 },
  { id: 'equation_master', name: 'Equation Master', icon: 'Scale', description: 'Balanced complex reactions and stoichiometric conversions', xpReward: 125 },
  { id: 'lab_operator', name: 'Laboratory Operator', icon: 'Thermometer', description: 'Conducted 3+ experiments in the Virtual Chemistry Lab', xpReward: 100 },
  { id: 'problem_solver', name: 'Olympiad Challenger', icon: 'Trophy', description: 'Solved 5+ challenges in the Questions Playground', xpReward: 125 },
  { id: 'rapid_chemist', name: 'Rapid Chemist', icon: 'Zap', description: 'Conquered the 60-Second Rapid-Fire Chemistry Blitz', xpReward: 100 },
  { id: 'puzzle_master', name: 'Puzzle Master', icon: 'Boxes', description: 'Solved molecular assembly and chemical logic puzzles', xpReward: 150 },
  { id: 'escape_room_champion', name: 'Escape Room Champion', icon: 'Award', description: 'Unlocked all 4 stages of the Alchemist Escape Room', xpReward: 300 },
  { id: 'daily_champion', name: 'Daily Champion', icon: 'Sparkles', description: 'Completed the Daily Chemistry Challenge of the Day', xpReward: 100 },
  { id: 'world_explorer', name: 'World Explorer', icon: 'Compass', description: 'Explored all scientific continents on the Chemistry Map', xpReward: 150 },
  { id: 'archivist', name: 'Master Archivist', icon: 'BookOpen', description: 'Discovered historical breakthroughs in the Chemistry Archive', xpReward: 75 },
  { id: 'polymath', name: 'Chemistry Polymath', icon: 'Atom', description: 'Explored 10+ distinct laboratory disciplines', xpReward: 150 },
  { id: 'master_synthesizer', name: 'Master of Synthesis', icon: 'Award', description: 'Reached Level 5 Chemist Mastery Rank (1500+ XP)', xpReward: 250 }
];

export interface DisciplineVisitStat {
  count: number;
  firstVisited: number;
  lastVisited: number;
}

export interface QuestionSolvedRecord {
  questionId: string;
  category: string;
  points: number;
  timestamp: number;
}

export interface ExperimentRecord {
  id: string;
  name: string;
  timestamp: number;
  reactionType?: string;
}

export interface NotebookEntry {
  id: string;
  title: string;
  content: string;
  createdAt: number;
  tab?: NavigationTab;
}

export interface UserPassportState {
  // Identity & Meta
  name: string;
  title: string;
  avatarIcon: string;
  joinedAt: number;
  lastVisit: number;
  streakDays: number;
  lastActiveDateStr: string;

  // Interests & Goals
  chemistryInterests: string[];
  chemistryInterest: string; // primary for compatibility
  interestLabel: string;
  purposes: string[];
  referralSource: string;
  referralLabel: string;

  // Onboarding & Guided Tour Progress
  hasCompletedOnboarding: boolean;
  hasCompletedTutorial: boolean;
  tutorialExploredConcepts: string[];
  tutorialModulesExplored: string[];
  tutorialToolsExplored: string[];

  // Exploration & Disciplines
  visitedTabs: NavigationTab[];
  disciplineStats: Record<string, DisciplineVisitStat>;
  pinnedTabs: NavigationTab[];

  // Practice & Laboratory Metrics
  questionsSolved: number;
  questionsAttempted: number;
  questionsHistory: QuestionSolvedRecord[];
  experimentsConducted: number;
  experimentsList: string[];
  experimentsHistory: ExperimentRecord[];

  // Gamification & Badges
  score: number;
  unlockedBadges: string[];
  badgeUnlockDates: Record<string, number>;
  notebookEntries: NotebookEntry[];
}

export type UserProfile = UserPassportState;

export interface ChemistLevelStats {
  level: number;
  title: string;
  progressPercent: number;
  currentPoints: number;
  nextThreshold: number;
  totalModulesExplored: number;
  totalModulesCount: number;
  curriculumProgressPercent: number;
  tutorialExploredCount: number;
  totalTutorialConcepts: number;
  tutorialProgressPercent: number;
  streakDays: number;
  badgesUnlockedCount: number;
  totalBadgesCount: number;
}

export type PassportEventName =
  | 'change'
  | 'tab_visited'
  | 'xp_gained'
  | 'badge_unlocked'
  | 'level_up'
  | 'question_solved'
  | 'experiment_conducted'
  | 'reset';

export interface PassportEventMap {
  change: UserPassportState;
  tab_visited: { tab: NavigationTab; timestamp: number; isFirstVisit: boolean };
  xp_gained: { amount: number; newTotal: number; reason?: string };
  badge_unlocked: { badge: UserBadge; timestamp: number };
  level_up: { newLevel: number; oldLevel: number; title: string };
  question_solved: { points: number; totalSolved: number; category?: string };
  experiment_conducted: { name: string; totalConducted: number };
  reset: { type: 'all' | 'onboarding' | 'tutorial' };
}

export type PassportListener<E extends PassportEventName = 'change'> = (
  payload: PassportEventMap[E]
) => void;

const DEFAULT_PASSPORT_STATE: UserPassportState = {
  name: '',
  title: 'Apprentice Chemist',
  avatarIcon: 'Atom',
  joinedAt: Date.now(),
  lastVisit: Date.now(),
  streakDays: 1,
  lastActiveDateStr: new Date().toISOString().slice(0, 10),

  chemistryInterests: ['Organic', 'Quantum', 'Chemistry Calculations'],
  chemistryInterest: 'Organic',
  interestLabel: 'Organic Chemistry & Quantum',
  purposes: ['Learn', 'Virtual experiments', 'Practice'],
  referralSource: 'search',
  referralLabel: 'Web Search',

  hasCompletedOnboarding: false,
  hasCompletedTutorial: false,
  tutorialExploredConcepts: [],
  tutorialModulesExplored: [],
  tutorialToolsExplored: [],

  visitedTabs: ['home'],
  disciplineStats: {
    home: { count: 1, firstVisited: Date.now(), lastVisited: Date.now() }
  },
  pinnedTabs: ['periodic-table', 'orbital-atlas', 'chemistry-lab'],

  questionsSolved: 0,
  questionsAttempted: 0,
  questionsHistory: [],
  experimentsConducted: 0,
  experimentsList: [],
  experimentsHistory: [],

  score: 50,
  unlockedBadges: [],
  badgeUnlockDates: {},
  notebookEntries: []
};

/**
 * UserPassportStore
 * Centralized, singleton state store managing identity, scientific interests, 
 * curriculum exploration, and achievements with an event-driven pub/sub bus.
 */
export class UserPassportStore {
  private static instance: UserPassportStore;
  private state: UserPassportState;
  private listeners: Map<PassportEventName, Set<PassportListener<any>>> = new Map();

  private constructor() {
    this.state = this.loadFromStorage();
    this.updateDailyStreak();
    this.attachWindowListeners();
  }

  public static getInstance(): UserPassportStore {
    if (!UserPassportStore.instance) {
      UserPassportStore.instance = new UserPassportStore();
    }
    return UserPassportStore.instance;
  }

  /**
   * Safe getter for current state snapshot
   */
  public getState(): UserPassportState {
    return this.state;
  }

  /**
   * Subscribe to state updates for React useSyncExternalStore or custom listeners
   */
  public subscribe(listener: (state: UserPassportState) => void): () => void {
    return this.on('change', listener);
  }

  /**
   * Subscribe to specific event types
   */
  public on<E extends PassportEventName>(event: E, handler: PassportListener<E>): () => void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    const eventListeners = this.listeners.get(event)!;
    eventListeners.add(handler);

    return () => {
      eventListeners.delete(handler);
    };
  }

  private emit<E extends PassportEventName>(event: E, payload: PassportEventMap[E]) {
    const eventListeners = this.listeners.get(event);
    if (eventListeners) {
      eventListeners.forEach((fn) => {
        try {
          fn(payload);
        } catch (err) {
          console.error(`Error in UserPassportStore listener for event ${event}:`, err);
        }
      });
    }

    // Also broadcast through browser CustomEvents for cross-module decoupling
    if (typeof window !== 'undefined') {
      try {
        if (event === 'change') {
          window.dispatchEvent(new CustomEvent(PASSPORT_EVENT_CHANNEL, { detail: payload }));
          window.dispatchEvent(new CustomEvent(LEGACY_PROFILE_EVENT_CHANNEL, { detail: payload }));
        } else if (event === 'badge_unlocked') {
          window.dispatchEvent(new CustomEvent(BADGE_UNLOCKED_EVENT_CHANNEL, { detail: payload }));
        }
      } catch {}
    }
  }

  /**
   * Persist state and broadcast events
   */
  private commit(newState: UserPassportState) {
    const oldScore = this.state.score;
    const oldLevel = this.calculateChemistLevel(this.state).level;

    this.state = newState;
    this.saveToStorage(newState);

    // Evaluate badge unlock criteria
    this.evaluateAutomaticBadges();

    // Check level up
    const newLevel = this.calculateChemistLevel(this.state).level;
    if (newLevel > oldLevel) {
      const levelTitle = this.calculateChemistLevel(this.state).title;
      this.emit('level_up', { newLevel, oldLevel, title: levelTitle });
    }

    // Emit general change event
    this.emit('change', this.state);
  }

  /**
   * Update profile fields with partial payload
   */
  public updateProfile(updates: Partial<UserPassportState>): UserPassportState {
    const updated: UserPassportState = {
      ...this.state,
      ...updates,
      lastVisit: Date.now()
    };

    if (updates.name !== undefined) {
      updated.name = updates.name.trim();
    }

    if (updates.hasCompletedOnboarding && typeof window !== 'undefined') {
      try {
        localStorage.setItem(ONBOARDING_COMPLETED_KEY, 'true');
      } catch {}
    }

    if (updates.hasCompletedTutorial && typeof window !== 'undefined') {
      try {
        localStorage.setItem(TUTORIAL_COMPLETED_KEY, 'true');
      } catch {}
    }

    this.commit(updated);
    return this.state;
  }

  /**
   * Set user display name
   */
  public setName(name: string): UserPassportState {
    return this.updateProfile({ name: name.trim() });
  }

  /**
   * Toggle a chemistry interest chip
   */
  public toggleInterest(interestId: string): UserPassportState {
    const current = this.state.chemistryInterests || [];
    const updated = current.includes(interestId)
      ? current.length > 1
        ? current.filter((id) => id !== interestId)
        : current
      : [...current, interestId];

    return this.updateProfile({
      chemistryInterests: updated,
      chemistryInterest: updated[0] || 'Organic',
      interestLabel: updated.slice(0, 2).join(' & ')
    });
  }

  /**
   * Set entire list of interests
   */
  public setInterests(interests: string[]): UserPassportState {
    const valid = interests.length > 0 ? interests : ['Organic'];
    return this.updateProfile({
      chemistryInterests: valid,
      chemistryInterest: valid[0],
      interestLabel: valid.slice(0, 2).join(' & ')
    });
  }

  /**
   * Toggle a learning purpose/goal
   */
  public togglePurpose(purposeId: string): UserPassportState {
    const current = this.state.purposes || [];
    const updated = current.includes(purposeId)
      ? current.length > 1
        ? current.filter((p) => p !== purposeId)
        : current
      : [...current, purposeId];

    return this.updateProfile({ purposes: updated });
  }

  /**
   * Set list of learning purposes
   */
  public setPurposes(purposes: string[]): UserPassportState {
    return this.updateProfile({ purposes: purposes.length > 0 ? purposes : ['Learn'] });
  }

  /**
   * Set referral discovery source
   */
  public setReferral(sourceId: string, label?: string): UserPassportState {
    const refOption = REFERRAL_SOURCES.find((r) => r.id === sourceId);
    return this.updateProfile({
      referralSource: sourceId,
      referralLabel: label || refOption?.label || 'Web Search'
    });
  }

  /**
   * Record navigation visit to a laboratory module
   */
  public recordTabVisit(tab: NavigationTab): UserPassportState {
    const isFirstVisit = !this.state.visitedTabs.includes(tab);
    const newVisited = isFirstVisit ? [...this.state.visitedTabs, tab] : this.state.visitedTabs;

    const stats = { ...(this.state.disciplineStats || {}) };
    const currentStat = stats[tab] || { count: 0, firstVisited: Date.now(), lastVisited: Date.now() };

    stats[tab] = {
      count: currentStat.count + 1,
      firstVisited: currentStat.firstVisited || Date.now(),
      lastVisited: Date.now()
    };

    const xpDelta = isFirstVisit ? 20 : 2;
    const newScore = (this.state.score || 0) + xpDelta;

    const updated: UserPassportState = {
      ...this.state,
      visitedTabs: newVisited,
      disciplineStats: stats,
      score: newScore,
      lastVisit: Date.now()
    };

    this.commit(updated);
    this.emit('tab_visited', { tab, timestamp: Date.now(), isFirstVisit });
    if (xpDelta > 0) {
      this.emit('xp_gained', { amount: xpDelta, newTotal: newScore, reason: `Explored ${tab}` });
    }

    return this.state;
  }

  /**
   * Record question solved in playground or quizzes
   */
  public recordQuestionSolved(points = 25, category = 'General', questionId?: string): UserPassportState {
    const newScore = (this.state.score || 0) + points;
    const historyItem: QuestionSolvedRecord = {
      questionId: questionId || `q_${Date.now()}`,
      category,
      points,
      timestamp: Date.now()
    };

    const updated: UserPassportState = {
      ...this.state,
      questionsSolved: (this.state.questionsSolved || 0) + 1,
      questionsAttempted: (this.state.questionsAttempted || 0) + 1,
      questionsHistory: [historyItem, ...(this.state.questionsHistory || [])].slice(0, 50),
      score: newScore,
      lastVisit: Date.now()
    };

    this.commit(updated);
    this.emit('question_solved', { points, totalSolved: updated.questionsSolved, category });
    this.emit('xp_gained', { amount: points, newTotal: newScore, reason: `Solved chemistry question` });

    return this.state;
  }

  /**
   * Record virtual wet-lab experiment conducted
   */
  public recordExperiment(experimentName: string, details?: { reactionType?: string }): UserPassportState {
    const currentList = this.state.experimentsList || [];
    const list = currentList.includes(experimentName) ? currentList : [...currentList, experimentName];

    const expRecord: ExperimentRecord = {
      id: `exp_${Date.now()}`,
      name: experimentName,
      timestamp: Date.now(),
      reactionType: details?.reactionType
    };

    const xpDelta = 30;
    const newScore = (this.state.score || 0) + xpDelta;

    const updated: UserPassportState = {
      ...this.state,
      experimentsConducted: (this.state.experimentsConducted || 0) + 1,
      experimentsList: list,
      experimentsHistory: [expRecord, ...(this.state.experimentsHistory || [])].slice(0, 50),
      score: newScore,
      lastVisit: Date.now()
    };

    this.commit(updated);
    this.emit('experiment_conducted', { name: experimentName, totalConducted: updated.experimentsConducted });
    this.emit('xp_gained', { amount: xpDelta, newTotal: newScore, reason: `Conducted ${experimentName}` });

    return this.state;
  }

  /**
   * Alias for recordExperiment for backward compatibility
   */
  public recordExperimentConducted(experimentName: string, details?: { reactionType?: string }): UserPassportState {
    return this.recordExperiment(experimentName, details);
  }

  /**
   * Record guided tour / tutorial concept explored
   */
  public recordTutorialConcept(conceptId: string, category?: 'module' | 'tool' | 'lab' | 'interface'): UserPassportState {
    const concepts = new Set(this.state.tutorialExploredConcepts || []);
    const isNew = !concepts.has(conceptId);
    concepts.add(conceptId);

    const modules = new Set(this.state.tutorialModulesExplored || []);
    const tools = new Set(this.state.tutorialToolsExplored || []);

    if (category === 'module' || category === 'lab') modules.add(conceptId);
    if (category === 'tool') tools.add(conceptId);

    const xpDelta = isNew ? 10 : 0;
    const newScore = (this.state.score || 0) + xpDelta;

    const updated: UserPassportState = {
      ...this.state,
      tutorialExploredConcepts: Array.from(concepts),
      tutorialModulesExplored: Array.from(modules),
      tutorialToolsExplored: Array.from(tools),
      score: newScore,
      lastVisit: Date.now()
    };

    this.commit(updated);
    if (xpDelta > 0) {
      this.emit('xp_gained', { amount: xpDelta, newTotal: newScore, reason: `Explored tutorial concept: ${conceptId}` });
    }

    return this.state;
  }

  /**
   * Add XP directly with event notification
   */
  public addXP(points: number, reason?: string): UserPassportState {
    if (points <= 0) return this.state;
    const newScore = (this.state.score || 0) + points;
    const updated: UserPassportState = {
      ...this.state,
      score: newScore,
      lastVisit: Date.now()
    };

    this.commit(updated);
    this.emit('xp_gained', { amount: points, newTotal: newScore, reason });
    return this.state;
  }

  /**
   * Toggle pinned tab in passport favorites
   */
  public togglePinTab(tab: NavigationTab): UserPassportState {
    const pinned = this.state.pinnedTabs || [];
    const updatedPinned = pinned.includes(tab)
      ? pinned.filter((t) => t !== tab)
      : [...pinned, tab];

    return this.updateProfile({ pinnedTabs: updatedPinned });
  }

  /**
   * Add custom scientific notebook entry
   */
  public addNotebookEntry(title: string, content: string, tab?: NavigationTab): UserPassportState {
    const entry: NotebookEntry = {
      id: `note_${Date.now()}`,
      title: title.trim() || 'Laboratory Note',
      content: content.trim(),
      createdAt: Date.now(),
      tab
    };

    const updatedNotes = [entry, ...(this.state.notebookEntries || [])];
    return this.updateProfile({ notebookEntries: updatedNotes });
  }

  /**
   * Delete notebook entry by ID
   */
  public deleteNotebookEntry(id: string): UserPassportState {
    const updatedNotes = (this.state.notebookEntries || []).filter((n) => n.id !== id);
    return this.updateProfile({ notebookEntries: updatedNotes });
  }

  /**
   * Manually unlock a badge if not already unlocked
   */
  public unlockBadge(badgeId: string): boolean {
    const current = new Set(this.state.unlockedBadges || []);
    if (current.has(badgeId)) return false;

    current.add(badgeId);
    const badgeMeta = SYSTEM_BADGES.find((b) => b.id === badgeId);
    const dates = { ...(this.state.badgeUnlockDates || {}), [badgeId]: Date.now() };
    const xpReward = badgeMeta?.xpReward || 50;

    const updated: UserPassportState = {
      ...this.state,
      unlockedBadges: Array.from(current),
      badgeUnlockDates: dates,
      score: (this.state.score || 0) + xpReward
    };

    this.commit(updated);
    if (badgeMeta) {
      this.emit('badge_unlocked', { badge: badgeMeta, timestamp: Date.now() });
      this.emit('xp_gained', { amount: xpReward, newTotal: updated.score, reason: `Unlocked ${badgeMeta.name} badge` });
    }
    return true;
  }

  /**
   * Internal automatic badge rule checks
   */
  private evaluateAutomaticBadges() {
    const current = new Set(this.state.unlockedBadges || []);
    const dates = { ...(this.state.badgeUnlockDates || {}) };
    let newlyUnlocked: UserBadge[] = [];

    const tryUnlock = (badgeId: string) => {
      if (!current.has(badgeId)) {
        current.add(badgeId);
        dates[badgeId] = Date.now();
        const badge = SYSTEM_BADGES.find((b) => b.id === badgeId);
        if (badge) newlyUnlocked.push(badge);
      }
    };

    if (this.state.hasCompletedOnboarding) tryUnlock('initiate');
    if ((this.state.experimentsConducted || 0) >= 1) tryUnlock('lab_apprentice');
    if ((this.state.experimentsConducted || 0) >= 3) tryUnlock('lab_operator');
    if (this.state.visitedTabs.includes('orbital-atlas') || this.state.visitedTabs.includes('quantum-lab') || this.state.visitedTabs.includes('atomic-spectra')) {
      tryUnlock('quantum_explorer');
    }
    if (this.state.visitedTabs.includes('spectroscopy-suite') || this.state.visitedTabs.includes('waves-radiation')) {
      tryUnlock('spectrum_hunter');
    }
    if (this.state.visitedTabs.includes('organic-chem') || this.state.visitedTabs.includes('advanced-organic')) {
      tryUnlock('synthesis_architect');
      tryUnlock('organic_navigator');
    }
    if (this.state.visitedTabs.includes('periodic-table')) tryUnlock('element_explorer');
    if (this.state.visitedTabs.includes('archive')) tryUnlock('archivist');
    if (this.state.visitedTabs.includes('chemistry-map')) tryUnlock('world_explorer');
    if (this.state.visitedTabs.includes('stoichiometry') || this.state.visitedTabs.includes('formula-vault')) tryUnlock('equation_master');
    if ((this.state.questionsSolved || 0) >= 5) tryUnlock('problem_solver');
    if ((this.state.visitedTabs || []).length >= 10) tryUnlock('polymath');
    if ((this.state.score || 0) >= 1500) tryUnlock('master_synthesizer');

    if (newlyUnlocked.length > 0) {
      this.state = {
        ...this.state,
        unlockedBadges: Array.from(current),
        badgeUnlockDates: dates
      };
      this.saveToStorage(this.state);

      newlyUnlocked.forEach((badge) => {
        this.emit('badge_unlocked', { badge, timestamp: Date.now() });
      });
    }
  }

  /**
   * Calculates comprehensive level and curriculum statistics
   */
  public calculateChemistLevel(profile?: UserPassportState): ChemistLevelStats {
    const target = profile || this.state;
    const totalDisciplines = 28;
    const uniqueExplored = target.visitedTabs ? target.visitedTabs.length : 1;
    const curriculumProgressPercent = Math.min(100, Math.round((uniqueExplored / totalDisciplines) * 100));

    const totalPoints = target.score || 0;

    let level = 1;
    let title = 'Apprentice Chemist';
    let nextThreshold = 200;

    if (totalPoints >= 1500) {
      level = 5;
      title = 'Master of Scientific Synthesis';
      nextThreshold = 2500;
    } else if (totalPoints >= 900) {
      level = 4;
      title = 'Senior Quantum Investigator';
      nextThreshold = 1500;
    } else if (totalPoints >= 450) {
      level = 3;
      title = 'Molecular Research Chemist';
      nextThreshold = 900;
    } else if (totalPoints >= 150) {
      level = 2;
      title = 'Laboratory Explorer';
      nextThreshold = 450;
    }

    const prevThreshold = level === 1 ? 0 : level === 2 ? 150 : level === 3 ? 450 : level === 4 ? 900 : 1500;
    const range = Math.max(1, nextThreshold - prevThreshold);
    const progressInLevel = Math.max(0, totalPoints - prevThreshold);
    const progressPercent = Math.min(100, Math.round((progressInLevel / range) * 100));

    const totalTutorialConcepts = 25;
    const tutorialExploredCount = target.tutorialExploredConcepts?.length || 0;
    const tutorialProgressPercent = Math.min(100, Math.round((tutorialExploredCount / totalTutorialConcepts) * 100));

    const totalBadgesCount = SYSTEM_BADGES.length;
    const badgesUnlockedCount = target.unlockedBadges?.length || 0;

    return {
      level,
      title,
      progressPercent,
      currentPoints: totalPoints,
      nextThreshold,
      totalModulesExplored: uniqueExplored,
      totalModulesCount: totalDisciplines,
      curriculumProgressPercent,
      tutorialExploredCount,
      totalTutorialConcepts,
      tutorialProgressPercent,
      streakDays: target.streakDays || 1,
      badgesUnlockedCount,
      totalBadgesCount
    };
  }

  /**
   * Export passport as formatted JSON file string
   */
  public exportPassportJSON(): string {
    const exportData = {
      version: 'chemisphere_passport_v3',
      exportedAt: new Date().toISOString(),
      passport: this.state
    };
    return JSON.stringify(exportData, null, 2);
  }

  /**
   * Import passport from JSON file string
   */
  public importPassportJSON(jsonString: string): { success: boolean; error?: string } {
    try {
      const parsed = JSON.parse(jsonString);
      const dataToImport = parsed.passport || parsed;

      if (!dataToImport || typeof dataToImport !== 'object') {
        return { success: false, error: 'Invalid passport JSON format.' };
      }

      const merged: UserPassportState = {
        ...DEFAULT_PASSPORT_STATE,
        ...dataToImport,
        lastVisit: Date.now()
      };

      this.commit(merged);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to parse JSON file.' };
    }
  }

  /**
   * Reset store data
   */
  public reset(type: 'all' | 'onboarding' | 'tutorial' = 'all'): UserPassportState {
    if (typeof window === 'undefined') return DEFAULT_PASSPORT_STATE;

    if (type === 'all') {
      try {
        localStorage.removeItem(USER_PASSPORT_STORAGE_KEY);
        localStorage.removeItem(ONBOARDING_COMPLETED_KEY);
        localStorage.removeItem(TUTORIAL_COMPLETED_KEY);
        localStorage.removeItem('chemisphere_recent_labs_v1');
      } catch {}
      this.state = { ...DEFAULT_PASSPORT_STATE, joinedAt: Date.now(), lastVisit: Date.now() };
      this.saveToStorage(this.state);
      this.emit('reset', { type: 'all' });
      this.emit('change', this.state);
      return this.state;
    }

    if (type === 'onboarding') {
      try {
        localStorage.removeItem(ONBOARDING_COMPLETED_KEY);
      } catch {}
      return this.updateProfile({ hasCompletedOnboarding: false });
    }

    if (type === 'tutorial') {
      try {
        localStorage.removeItem(TUTORIAL_COMPLETED_KEY);
      } catch {}
      return this.updateProfile({
        hasCompletedTutorial: false,
        tutorialExploredConcepts: [],
        tutorialModulesExplored: [],
        tutorialToolsExplored: []
      });
    }

    return this.state;
  }

  /**
   * Update daily visit streaks
   */
  private updateDailyStreak() {
    const todayStr = new Date().toISOString().slice(0, 10);
    const lastActive = this.state.lastActiveDateStr;

    if (lastActive === todayStr) {
      return; // Already tracked today
    }

    if (!lastActive) {
      this.state.lastActiveDateStr = todayStr;
      this.state.streakDays = 1;
      this.saveToStorage(this.state);
      return;
    }

    const lastDate = new Date(lastActive);
    const today = new Date(todayStr);
    const diffDays = Math.floor((today.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDays === 1) {
      // Consecutive active day!
      this.state.streakDays = (this.state.streakDays || 1) + 1;
    } else if (diffDays > 1) {
      // Missed a day
      this.state.streakDays = 1;
    }

    this.state.lastActiveDateStr = todayStr;
    this.saveToStorage(this.state);
  }

  /**
   * Listen to multi-window or multi-tab cross communication
   */
  private attachWindowListeners() {
    if (typeof window === 'undefined') return;

    window.addEventListener('storage', (e) => {
      if (e.key === USER_PASSPORT_STORAGE_KEY && e.newValue) {
        try {
          const fresh = JSON.parse(e.newValue);
          this.state = { ...DEFAULT_PASSPORT_STATE, ...fresh };
          this.emit('change', this.state);
        } catch {}
      }
    });
  }

  private loadFromStorage(): UserPassportState {
    if (typeof window === 'undefined') return DEFAULT_PASSPORT_STATE;
    try {
      const raw = localStorage.getItem(USER_PASSPORT_STORAGE_KEY);
      if (!raw) return DEFAULT_PASSPORT_STATE;
      const parsed = JSON.parse(raw);

      return {
        ...DEFAULT_PASSPORT_STATE,
        ...parsed,
        chemistryInterests: Array.isArray(parsed.chemistryInterests) ? parsed.chemistryInterests : [parsed.chemistryInterest || 'Organic'],
        purposes: Array.isArray(parsed.purposes) ? parsed.purposes : ['Learn'],
        tutorialExploredConcepts: Array.isArray(parsed.tutorialExploredConcepts) ? parsed.tutorialExploredConcepts : [],
        tutorialModulesExplored: Array.isArray(parsed.tutorialModulesExplored) ? parsed.tutorialModulesExplored : [],
        tutorialToolsExplored: Array.isArray(parsed.tutorialToolsExplored) ? parsed.tutorialToolsExplored : [],
        visitedTabs: Array.isArray(parsed.visitedTabs) ? parsed.visitedTabs : ['home'],
        unlockedBadges: Array.isArray(parsed.unlockedBadges) ? parsed.unlockedBadges : [],
        experimentsList: Array.isArray(parsed.experimentsList) ? parsed.experimentsList : [],
        disciplineStats: parsed.disciplineStats && typeof parsed.disciplineStats === 'object' ? parsed.disciplineStats : { home: { count: 1, firstVisited: Date.now(), lastVisited: Date.now() } },
        pinnedTabs: Array.isArray(parsed.pinnedTabs) ? parsed.pinnedTabs : ['periodic-table', 'orbital-atlas', 'chemistry-lab'],
        notebookEntries: Array.isArray(parsed.notebookEntries) ? parsed.notebookEntries : []
      };
    } catch {
      return DEFAULT_PASSPORT_STATE;
    }
  }

  private saveToStorage(state: UserPassportState) {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(USER_PASSPORT_STORAGE_KEY, JSON.stringify(state));
    } catch (err) {
      console.warn('UserPassportStore storage save warning:', err);
    }
  }
}

/**
 * Singleton Export
 */
export const userPassportStore = UserPassportStore.getInstance();

/**
 * React Hook for frictionless reactive synchronization across all components
 */
export function useUserPassport() {
  const state = useSyncExternalStore(
    useCallback((onStoreChange) => userPassportStore.subscribe(onStoreChange), []),
    () => userPassportStore.getState(),
    () => DEFAULT_PASSPORT_STATE
  );

  const stats = userPassportStore.calculateChemistLevel(state);

  return {
    passport: state,
    profile: state, // Alias for backward compatibility
    stats,
    setName: useCallback((name: string) => userPassportStore.setName(name), []),
    toggleInterest: useCallback((id: string) => userPassportStore.toggleInterest(id), []),
    setInterests: useCallback((interests: string[]) => userPassportStore.setInterests(interests), []),
    togglePurpose: useCallback((id: string) => userPassportStore.togglePurpose(id), []),
    setPurposes: useCallback((purposes: string[]) => userPassportStore.setPurposes(purposes), []),
    setReferral: useCallback((id: string, label?: string) => userPassportStore.setReferral(id, label), []),
    recordTabVisit: useCallback((tab: NavigationTab) => userPassportStore.recordTabVisit(tab), []),
    recordQuestionSolved: useCallback((points?: number, cat?: string, qId?: string) => userPassportStore.recordQuestionSolved(points, cat, qId), []),
    recordExperiment: useCallback((name: string, details?: { reactionType?: string }) => userPassportStore.recordExperiment(name, details), []),
    recordTutorialConcept: useCallback((cId: string, cat?: 'module' | 'tool' | 'lab' | 'interface') => userPassportStore.recordTutorialConcept(cId, cat), []),
    addXP: useCallback((points: number, reason?: string) => userPassportStore.addXP(points, reason), []),
    unlockBadge: useCallback((id: string) => userPassportStore.unlockBadge(id), []),
    togglePinTab: useCallback((tab: NavigationTab) => userPassportStore.togglePinTab(tab), []),
    addNotebookEntry: useCallback((title: string, content: string, tab?: NavigationTab) => userPassportStore.addNotebookEntry(title, content, tab), []),
    deleteNotebookEntry: useCallback((id: string) => userPassportStore.deleteNotebookEntry(id), []),
    reset: useCallback((type?: 'all' | 'onboarding' | 'tutorial') => userPassportStore.reset(type), []),
    exportPassport: useCallback(() => userPassportStore.exportPassportJSON(), []),
    importPassport: useCallback((json: string) => userPassportStore.importPassportJSON(json), []),
    updateProfile: useCallback((updates: Partial<UserPassportState>) => userPassportStore.updateProfile(updates), [])
  };
}

/**
 * Backward compatibility functions matching legacy userProfile.ts API
 */
export function getUserProfile(): UserProfile {
  return userPassportStore.getState();
}

export function saveUserProfile(updates: Partial<UserProfile>): UserProfile {
  return userPassportStore.updateProfile(updates);
}

export function recordTabVisit(tab: NavigationTab): UserProfile {
  return userPassportStore.recordTabVisit(tab);
}

export function recordTutorialConceptExplored(conceptId: string, category?: 'module' | 'tool' | 'lab' | 'interface'): UserProfile {
  return userPassportStore.recordTutorialConcept(conceptId, category);
}

export function recordQuestionSolved(points = 25): UserProfile {
  return userPassportStore.recordQuestionSolved(points);
}

export function recordExperimentConducted(experimentName: string): UserProfile {
  return userPassportStore.recordExperiment(experimentName);
}

export function resetAllUserData(): UserProfile {
  return userPassportStore.reset('all');
}

export function resetOnboardingOnly(): UserProfile {
  return userPassportStore.reset('onboarding');
}

export function resetTutorialOnly(): UserProfile {
  return userPassportStore.reset('tutorial');
}

export function calculateChemistLevel(profile: UserProfile) {
  return userPassportStore.calculateChemistLevel(profile);
}
