import { FormulaItem, ChemicalConstant } from '../types';

export const CHEMICAL_CONSTANTS: ChemicalConstant[] = [
  {
    symbol: 'N_A',
    name: 'Avogadro Constant',
    value: '6.02214076 \\times 10^{23}',
    unit: '\\text{mol}^{-1}',
    description: 'The exact number of constituent particles (usually atoms or molecules) per mole of a substance.',
    category: 'fundamental'
  },
  {
    symbol: 'R',
    name: 'Universal Gas Constant',
    value: '8.314462618',
    unit: '\\text{J}/(\\text{mol}\\cdot\\text{K})',
    description: 'Constant relating energy scale in physics to the temperature scale when considering molar amounts.',
    category: 'fundamental'
  },
  {
    symbol: 'h',
    name: 'Planck Constant',
    value: '6.62607015 \\times 10^{-34}',
    unit: '\\text{J}\\cdot\\text{s}',
    description: 'Fundamental physical constant characterizing the quantum scale of action in quantum mechanics.',
    category: 'atomic'
  },
  {
    symbol: 'F',
    name: 'Faraday Constant',
    value: '96485.33212',
    unit: '\\text{C}/\\text{mol}',
    description: 'Magnitude of electric charge per mole of electrons (e · N_A). Used in electrochemistry and electrolysis.',
    category: 'fundamental'
  },
  {
    symbol: 'k_B',
    name: 'Boltzmann Constant',
    value: '1.380649 \\times 10^{-23}',
    unit: '\\text{J}/\\text{K}',
    description: 'Relates the average kinetic energy of particles in a gas with the thermodynamic temperature.',
    category: 'thermodynamics'
  },
  {
    symbol: 'c',
    name: 'Speed of Light in Vacuum',
    value: '2.99792458 \\times 10^8',
    unit: '\\text{m}/\\text{s}',
    description: 'Universal physical constant representing the maximum speed at which all conventional energy matter travels.',
    category: 'fundamental'
  },
  {
    symbol: 'R_H',
    name: 'Rydberg Constant',
    value: '1.097373 \\times 10^7',
    unit: '\\text{m}^{-1}',
    description: 'Relates to electromagnetic spectra of hydrogen atoms in the Rydberg formula.',
    category: 'atomic'
  }
];

export const FORMULAS_DATA: FormulaItem[] = [
  {
    id: 'ideal-gas',
    name: 'Ideal Gas Equation',
    category: 'Physical',
    latex: 'P V = n R T',
    variables: [
      { symbol: 'P', name: 'Pressure', unit: 'atm' },
      { symbol: 'V', name: 'Volume', unit: 'L' },
      { symbol: 'n', name: 'Moles', unit: 'mol' },
      { symbol: 'R', name: 'Gas Constant (0.08206)', unit: 'L·atm/(mol·K)' },
      { symbol: 'T', name: 'Temperature', unit: 'K' }
    ],
    meaning: 'Describes the macroscopic state of a hypothetical ideal gas at given pressure, volume, moles, and temperature.',
    whenToUse: 'When calculating gas properties under moderate temperature and low pressure where intermolecular forces are negligible.',
    example: 'Calculate volume occupied by 2.5 mol of gas at 1.2 atm and 300 K.',
    defaultInputs: [
      { id: 'n', label: 'Moles (n)', unit: 'mol', defaultValue: 2.5 },
      { id: 'P', label: 'Pressure (P)', unit: 'atm', defaultValue: 1.2 },
      { id: 'T', label: 'Temperature (T)', unit: 'K', defaultValue: 300 }
    ],
    calculate: (inputs) => {
      const R = 0.08206;
      const V = (inputs.n * R * inputs.T) / inputs.P;
      return {
        result: parseFloat(V.toFixed(3)),
        unit: 'L',
        steps: `V = \\frac{n R T}{P} = \\frac{(${inputs.n}) \\times (${R}) \\times (${inputs.T})}{${inputs.P}} = ${V.toFixed(3)}\\text{ L}`
      };
    }
  },
  {
    id: 'gibbs-free-energy',
    name: 'Gibbs Free Energy & Spontaneity',
    category: 'Thermodynamics',
    latex: '\\Delta G = \\Delta H - T \\Delta S',
    variables: [
      { symbol: '\\Delta G', name: 'Gibbs Free Energy Change', unit: 'kJ/mol' },
      { symbol: '\\Delta H', name: 'Enthalpy Change', unit: 'kJ/mol' },
      { symbol: 'T', name: 'Absolute Temperature', unit: 'K' },
      { symbol: '\\Delta S', name: 'Entropy Change', unit: 'J/(mol·K)' }
    ],
    meaning: 'Determines the thermodynamic spontaneity of a reaction at constant temperature and pressure. ΔG < 0 is spontaneous.',
    whenToUse: 'Predicting whether a chemical reaction will proceed forward spontaneously at a given temperature.',
    example: 'For ΔH = -50 kJ/mol, ΔS = -100 J/(mol·K) at T = 298 K, find ΔG.',
    defaultInputs: [
      { id: 'dH', label: 'ΔH', unit: 'kJ/mol', defaultValue: -50 },
      { id: 'dS', label: 'ΔS', unit: 'J/(mol·K)', defaultValue: -100 },
      { id: 'T', label: 'Temperature (T)', unit: 'K', defaultValue: 298 }
    ],
    calculate: (inputs) => {
      const dG = inputs.dH - (inputs.T * (inputs.dS / 1000));
      return {
        result: parseFloat(dG.toFixed(2)),
        unit: 'kJ/mol',
        steps: `\\Delta G = ${inputs.dH} - (${inputs.T} \\times \\frac{${inputs.dS}}{1000}) = ${dG.toFixed(2)}\\text{ kJ/mol} (${dG < 0 ? '\\text{Spontaneous}' : '\\text{Non-spontaneous}'})`
      };
    }
  },
  {
    id: 'nernst-equation',
    name: 'Nernst Equation (Electrochemistry)',
    category: 'Electrochemistry',
    latex: 'E_{\\text{cell}} = E^\\circ_{\\text{cell}} - \\frac{0.0592}{n} \\log_{10}(Q)',
    variables: [
      { symbol: 'E_{\\text{cell}}', name: 'Non-standard Cell Potential', unit: 'V' },
      { symbol: 'E^\\circ', name: 'Standard Cell Potential', unit: 'V' },
      { symbol: 'n', name: 'Moles of electrons transferred', unit: 'mol e⁻' },
      { symbol: 'Q', name: 'Reaction Quotient', unit: 'ratio' }
    ],
    meaning: 'Calculates the electromotive force (EMF) of an electrochemical cell under non-standard concentration conditions at 298 K.',
    whenToUse: 'Predicting voltage changes during battery discharge or variable electrolyte concentrations.',
    example: 'Daniell cell with standard EMF 1.10V, 2 electrons transferred, with [Zn²⁺]/[Cu²⁺] = 0.01.',
    defaultInputs: [
      { id: 'E0', label: 'Standard E°', unit: 'V', defaultValue: 1.10 },
      { id: 'n', label: 'Electrons (n)', unit: 'e⁻', defaultValue: 2 },
      { id: 'Q', label: 'Reaction Quotient (Q)', unit: 'ratio', defaultValue: 0.01 }
    ],
    calculate: (inputs) => {
      const E = inputs.E0 - (0.0592 / inputs.n) * Math.log10(inputs.Q);
      return {
        result: parseFloat(E.toFixed(4)),
        unit: 'V',
        steps: `E = ${inputs.E0} - \\frac{0.0592}{${inputs.n}} \\log_{10}(${inputs.Q}) = ${E.toFixed(4)}\\text{ V}`
      };
    }
  },
  {
    id: 'arrhenius-equation',
    name: 'Arrhenius Rate Equation',
    category: 'Kinetics',
    latex: 'k = A e^{-\\frac{E_a}{R T}}',
    variables: [
      { symbol: 'k', name: 'Rate Constant', unit: 's⁻¹ / M⁻¹s⁻¹' },
      { symbol: 'A', name: 'Frequency / Pre-exponential Factor', unit: 's⁻¹' },
      { symbol: 'E_a', name: 'Activation Energy', unit: 'J/mol' },
      { symbol: 'R', name: 'Gas Constant (8.314)', unit: 'J/(mol·K)' },
      { symbol: 'T', name: 'Absolute Temperature', unit: 'K' }
    ],
    meaning: 'Quantifies the temperature dependence of chemical reaction rates based on collision theory and energy barrier threshold.',
    whenToUse: 'Calculating activation energies or reaction rate changes when temperature increases.',
    example: 'Calculate rate constant k at 300 K for A = 10¹² s⁻¹ and Ea = 50,000 J/mol.',
    defaultInputs: [
      { id: 'A', label: 'Frequency Factor (A)', unit: 's⁻¹', defaultValue: 1000000000000 },
      { id: 'Ea', label: 'Activation Energy (Ea)', unit: 'J/mol', defaultValue: 50000 },
      { id: 'T', label: 'Temperature (T)', unit: 'K', defaultValue: 300 }
    ],
    calculate: (inputs) => {
      const R = 8.314;
      const k = inputs.A * Math.exp(-inputs.Ea / (R * inputs.T));
      return {
        result: parseFloat(k.toExponential(4)),
        unit: 's⁻¹',
        steps: `k = (${inputs.A}) \\times e^{-\\frac{${inputs.Ea}}{8.314 \\times ${inputs.T}}} = ${k.toExponential(4)}\\text{ s}^{-1}`
      };
    }
  },
  {
    id: 'molarity-calc',
    name: 'Molarity & Solution Concentration',
    category: 'Solutions',
    latex: 'M = \\frac{n_{\\text{solute}}}{V_{\\text{solution (L)}}} = \\frac{\\text{mass (g)}}{\\text{Molar Mass (g/mol)} \\times V (\\text{L})}',
    variables: [
      { symbol: 'M', name: 'Molarity', unit: 'mol/L' },
      { symbol: 'm', name: 'Mass of Solute', unit: 'g' },
      { symbol: 'M_w', name: 'Molar Mass', unit: 'g/mol' },
      { symbol: 'V', name: 'Volume of Solution', unit: 'L' }
    ],
    meaning: 'Concentration expressed as number of moles of solute dissolved per liter of solution.',
    whenToUse: 'Preparing standard laboratory volumetric solutions and titrations.',
    example: 'Find molarity of 5.85 g NaCl (58.44 g/mol) dissolved in 0.5 L solution.',
    defaultInputs: [
      { id: 'mass', label: 'Mass of Solute', unit: 'g', defaultValue: 5.85 },
      { id: 'mw', label: 'Molar Mass (Mw)', unit: 'g/mol', defaultValue: 58.44 },
      { id: 'vol', label: 'Volume (V)', unit: 'L', defaultValue: 0.5 }
    ],
    calculate: (inputs) => {
      const M = inputs.mass / (inputs.mw * inputs.vol);
      return {
        result: parseFloat(M.toFixed(4)),
        unit: 'mol/L',
        steps: `M = \\frac{${inputs.mass}\\text{ g}}{${inputs.mw}\\text{ g/mol} \\times ${inputs.vol}\\text{ L}} = ${M.toFixed(4)}\\text{ M}`
      };
    }
  },
  {
    id: 'ph-calc',
    name: 'pH & Hydrogen Ion Concentration',
    category: 'Equilibrium',
    latex: '\\text{pH} = -\\log_{10}[\\text{H}^+], \\quad \\text{pOH} = -\\log_{10}[\\text{OH}^-], \\quad \\text{pH} + \\text{pOH} = 14',
    variables: [
      { symbol: '\\text{pH}', name: 'Potential of Hydrogen', unit: 'scale 0-14' },
      { symbol: '[\\text{H}^+]', name: 'Hydronium Ion Concentration', unit: 'M' }
    ],
    meaning: 'Logarithmic scale specifying the acidity or basicity of an aqueous solution.',
    whenToUse: 'Acid-base analysis, buffer capacity calculations, and physiological pH monitoring.',
    example: 'Find pH when [H⁺] = 2.5 × 10⁻⁴ M.',
    defaultInputs: [
      { id: 'hConc', label: '[H⁺] (e.g. 0.00025 for 2.5×10⁻⁴)', unit: 'M', defaultValue: 0.00025 }
    ],
    calculate: (inputs) => {
      const ph = -Math.log10(inputs.hConc);
      const poh = 14 - ph;
      return {
        result: parseFloat(ph.toFixed(3)),
        unit: 'pH',
        steps: `\\text{pH} = -\\log_{10}(${inputs.hConc}) = ${ph.toFixed(3)}, \\quad \\text{pOH} = ${poh.toFixed(3)}`
      };
    }
  }
];

export const FUNDAMENTAL_CONSTANTS = CHEMICAL_CONSTANTS;
export const CHEMICAL_FORMULAS = FORMULAS_DATA.map((f) => ({
  ...f,
  equationLatex: f.equationLatex || f.latex || '',
  variables: f.variables.map((v) => (typeof v === 'string' ? v : `${v.symbol} = ${v.name} (${v.unit})`)),
  description: f.description || f.meaning || ''
}));
export type { FormulaItem };
