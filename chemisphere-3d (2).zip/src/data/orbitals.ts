import { OrbitalData } from '../types';

export const ORBITALS_DATA: OrbitalData[] = [
  // s Orbitals
  {
    id: '1s',
    type: 's',
    name: '1s Orbital',
    n: 1,
    l: 0,
    ml: 0,
    radialNodes: 0,
    angularNodes: 0,
    totalNodes: 0,
    formulaLatex: '\\psi_{100}(r) = \\frac{1}{\\sqrt{\\pi}} \\left(\\frac{Z}{a_0}\\right)^{3/2} e^{-Zr/a_0}',
    description: 'Spherically symmetric ground state orbital with maximum electron probability density at the nucleus.',
    orientation: 'Spherical (Isotropic)'
  },
  {
    id: '2s',
    type: 's',
    name: '2s Orbital',
    n: 2,
    l: 0,
    ml: 0,
    radialNodes: 1,
    angularNodes: 0,
    totalNodes: 1,
    formulaLatex: '\\psi_{200}(r) = \\frac{1}{4\\sqrt{2\\pi}} \\left(\\frac{Z}{a_0}\\right)^{3/2} \\left(2 - \\frac{Zr}{a_0}\\right) e^{-Zr/2a_0}',
    description: 'Spherical orbital featuring 1 internal spherical radial nodal surface where wave function phase flips from (+) to (-).',
    orientation: 'Spherical with 1 Radial Node'
  },
  {
    id: '3s',
    type: 's',
    name: '3s Orbital',
    n: 3,
    l: 0,
    ml: 0,
    radialNodes: 2,
    angularNodes: 0,
    totalNodes: 2,
    formulaLatex: '\\psi_{300}(r) = \\frac{1}{81\\sqrt{3\\pi}} \\left(\\frac{Z}{a_0}\\right)^{3/2} \\left(27 - 18\\sigma + 2\\sigma^2\\right) e^{-\\sigma/3}',
    description: 'Concentric spherical probability distribution featuring 2 distinct radial nodal shells.',
    orientation: 'Spherical with 2 Radial Nodes'
  },
  // p Orbitals
  {
    id: '2pz',
    type: 'p',
    name: '2p_z Orbital',
    n: 2,
    l: 1,
    ml: 0,
    radialNodes: 0,
    angularNodes: 1,
    totalNodes: 1,
    formulaLatex: '\\psi_{2p_z} = \\frac{1}{4\\sqrt{2\\pi}} \\left(\\frac{Z}{a_0}\\right)^{5/2} z e^{-Zr/2a_0}',
    description: 'Dumbbell-shaped orbital aligned along the z-axis with an angular nodal plane across the xy-plane (z = 0).',
    orientation: 'Aligned along Z-axis'
  },
  {
    id: '2px',
    type: 'p',
    name: '2p_x Orbital',
    n: 2,
    l: 1,
    ml: 1,
    radialNodes: 0,
    angularNodes: 1,
    totalNodes: 1,
    formulaLatex: '\\psi_{2p_x} = \\frac{1}{4\\sqrt{2\\pi}} \\left(\\frac{Z}{a_0}\\right)^{5/2} x e^{-Zr/2a_0}',
    description: 'Two opposing lobes of opposite wave-function sign aligned along the x-axis, separated by the yz-nodal plane.',
    orientation: 'Aligned along X-axis'
  },
  {
    id: '2py',
    type: 'p',
    name: '2p_y Orbital',
    n: 2,
    l: 1,
    ml: -1,
    radialNodes: 0,
    angularNodes: 1,
    totalNodes: 1,
    formulaLatex: '\\psi_{2p_y} = \\frac{1}{4\\sqrt{2\\pi}} \\left(\\frac{Z}{a_0}\\right)^{5/2} y e^{-Zr/2a_0}',
    description: 'Two symmetrical lobes oriented along the y-axis with an xz-nodal plane passing through the origin.',
    orientation: 'Aligned along Y-axis'
  },
  {
    id: '3px',
    type: 'p',
    name: '3p_x Orbital',
    n: 3,
    l: 1,
    ml: 1,
    radialNodes: 1,
    angularNodes: 1,
    totalNodes: 2,
    formulaLatex: '\\psi_{3p_x} = R_{31}(r) Y_1^1(\\theta, \\phi)',
    description: 'p-orbital possessing both 1 radial nodal surface and 1 angular nodal plane (yz-plane).',
    orientation: 'X-axis + Radial Node'
  },
  // d Orbitals
  {
    id: '3dz2',
    type: 'd',
    name: '3d_{z^2} Orbital',
    n: 3,
    l: 2,
    ml: 0,
    radialNodes: 0,
    angularNodes: 2,
    totalNodes: 2,
    formulaLatex: '\\psi_{3d_{z^2}} \\propto (3z^2 - r^2) e^{-Zr/3a_0}',
    description: 'Two prominent vertical lobes along the z-axis surrounded by a toroidal donut ring of electron density in the xy-plane.',
    orientation: 'Z-axis Lobes + Toroidal Ring'
  },
  {
    id: '3dx2-y2',
    type: 'd',
    name: '3d_{x^2-y^2} Orbital',
    n: 3,
    l: 2,
    ml: 2,
    radialNodes: 0,
    angularNodes: 2,
    totalNodes: 2,
    formulaLatex: '\\psi_{3d_{x^2-y^2}} \\propto (x^2 - y^2) e^{-Zr/3a_0}',
    description: 'Four cloverleaf lobes lying directly along the x and y axes. Nodal planes bisect at 45°.',
    orientation: 'Lobes directly on X & Y axes'
  },
  {
    id: '3dxy',
    type: 'd',
    name: '3d_{xy} Orbital',
    n: 3,
    l: 2,
    ml: -2,
    radialNodes: 0,
    angularNodes: 2,
    totalNodes: 2,
    formulaLatex: '\\psi_{3d_{xy}} \\propto xy e^{-Zr/3a_0}',
    description: 'Four cloverleaf lobes positioned between the x and y axes with nodal planes at x=0 and y=0.',
    orientation: 'Between X & Y axes (xy plane)'
  },
  {
    id: '3dxz',
    type: 'd',
    name: '3d_{xz} Orbital',
    n: 3,
    l: 2,
    ml: 1,
    radialNodes: 0,
    angularNodes: 2,
    totalNodes: 2,
    formulaLatex: '\\psi_{3d_{xz}} \\propto xz e^{-Zr/3a_0}',
    description: 'Four lobes in the xz plane with nodal planes corresponding to xy and yz planes.',
    orientation: 'Between X & Z axes (xz plane)'
  },
  {
    id: '3dyz',
    type: 'd',
    name: '3d_{yz} Orbital',
    n: 3,
    l: 2,
    ml: -1,
    radialNodes: 0,
    angularNodes: 2,
    totalNodes: 2,
    formulaLatex: '\\psi_{3d_{yz}} \\propto yz e^{-Zr/3a_0}',
    description: 'Four lobes in the yz plane with nodal planes corresponding to xy and xz planes.',
    orientation: 'Between Y & Z axes (yz plane)'
  },
  // f Orbitals
  {
    id: '4fz3',
    type: 'f',
    name: '4f_{z^3} Orbital',
    n: 4,
    l: 3,
    ml: 0,
    radialNodes: 0,
    angularNodes: 3,
    totalNodes: 3,
    formulaLatex: '\\psi_{4f_{z^3}} \\propto z(5z^2 - 3r^2) e^{-Zr/4a_0}',
    description: 'Two axial lobes along the z-axis with two conical nodal surfaces and donut rings above and below the xy-plane.',
    orientation: 'Complex 3-fold Z symmetry'
  },
  {
    id: '4fxz2',
    type: 'f',
    name: '4f_{xz^2} Orbital',
    n: 4,
    l: 3,
    ml: 1,
    radialNodes: 0,
    angularNodes: 3,
    totalNodes: 3,
    formulaLatex: '\\psi_{4f_{xz^2}} \\propto x(5z^2 - r^2) e^{-Zr/4a_0}',
    description: 'Six distinct lobes distributed with reflection symmetry about the yz-plane.',
    orientation: '6-lobe XZ orientation'
  },
  {
    id: '4fxyz',
    type: 'f',
    name: '4f_{xyz} Orbital',
    n: 4,
    l: 3,
    ml: -2,
    radialNodes: 0,
    angularNodes: 3,
    totalNodes: 3,
    formulaLatex: '\\psi_{4f_{xyz}} \\propto xyz e^{-Zr/4a_0}',
    description: 'Eight octant lobes alternating in phase sign across the three Cartesian planes x=0, y=0, z=0.',
    orientation: '8 Octant Alternating Lobes'
  },
  {
    id: '4fz_x2-y2',
    type: 'f',
    name: '4f_{z(x^2-y^2)} Orbital',
    n: 4,
    l: 3,
    ml: 2,
    radialNodes: 0,
    angularNodes: 3,
    totalNodes: 3,
    formulaLatex: '\\psi_{4f_{z(x^2-y^2)}} \\propto z(x^2 - y^2) e^{-Zr/4a_0}',
    description: 'Eight lobes arranged symmetrically above and below the xy plane.',
    orientation: '8 Lobes (Tetrahedral Symmetry)'
  }
];

export interface SubshellInfo {
  n: number;
  subshells: {
    symbol: string;
    l: number;
    orbitalsCount: number;
    maxElectrons: number;
    shape: string;
    radialNodes: number;
    angularNodes: number;
  }[];
}

export const SUBSHELL_LEVELS: SubshellInfo[] = [
  {
    n: 1,
    subshells: [
      { symbol: '1s', l: 0, orbitalsCount: 1, maxElectrons: 2, shape: 'Spherical', radialNodes: 0, angularNodes: 0 }
    ]
  },
  {
    n: 2,
    subshells: [
      { symbol: '2s', l: 0, orbitalsCount: 1, maxElectrons: 2, shape: 'Spherical (1 radial node)', radialNodes: 1, angularNodes: 0 },
      { symbol: '2p', l: 1, orbitalsCount: 3, maxElectrons: 6, shape: 'Dumbbell (px, py, pz)', radialNodes: 0, angularNodes: 1 }
    ]
  },
  {
    n: 3,
    subshells: [
      { symbol: '3s', l: 0, orbitalsCount: 1, maxElectrons: 2, shape: 'Spherical (2 radial nodes)', radialNodes: 2, angularNodes: 0 },
      { symbol: '3p', l: 1, orbitalsCount: 3, maxElectrons: 6, shape: 'Dumbbell', radialNodes: 1, angularNodes: 1 },
      { symbol: '3d', l: 2, orbitalsCount: 5, maxElectrons: 10, shape: 'Cloverleaf & Donut', radialNodes: 0, angularNodes: 2 }
    ]
  },
  {
    n: 4,
    subshells: [
      { symbol: '4s', l: 0, orbitalsCount: 1, maxElectrons: 2, shape: 'Spherical', radialNodes: 3, angularNodes: 0 },
      { symbol: '4p', l: 1, orbitalsCount: 3, maxElectrons: 6, shape: 'Dumbbell', radialNodes: 2, angularNodes: 1 },
      { symbol: '4d', l: 2, orbitalsCount: 5, maxElectrons: 10, shape: 'Cloverleaf', radialNodes: 1, angularNodes: 2 },
      { symbol: '4f', l: 3, orbitalsCount: 7, maxElectrons: 14, shape: 'Complex multi-lobed / 8-octant', radialNodes: 0, angularNodes: 3 }
    ]
  }
];

export const getOrbitalById = (id: string): OrbitalData | undefined => {
  return ORBITALS_DATA.find((o) => o.id.toLowerCase() === id.toLowerCase());
};

export const getOrbitalByType = (type: string): OrbitalData | undefined => {
  return ORBITALS_DATA.find((o) => o.id.toLowerCase() === type.toLowerCase()) || ORBITALS_DATA[0];
};

