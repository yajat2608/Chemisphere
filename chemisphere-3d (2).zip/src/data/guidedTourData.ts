import { NavigationTab } from '../types';

export type TourCategory = 'modules' | 'tools' | 'laboratories' | 'simulations' | 'chemobot' | 'profile' | 'navigation';

export interface TourStepAction {
  title: string;
  instruction: string;
  targetElementSelector?: string;
  actionHint?: string;
}

export interface GuidedTourItem {
  id: string;
  title: string;
  category: TourCategory;
  tab: NavigationTab;
  badge: string;
  accent: string;
  iconName: string;
  summary: string;
  whatItDoes: string;
  inputs: string[];
  outputs: string[];
  howToInterpret: string;
  interactiveSteps: TourStepAction[];
  keyControls: string[];
  relatedModules: NavigationTab[];
}

export const GUIDED_TOUR_ITEMS: GuidedTourItem[] = [
  // 1. PERIODIC TABLE
  {
    id: 'periodic-table',
    title: '3D Periodic Table & Trends Grapher',
    category: 'modules',
    tab: 'periodic-table',
    badge: 'Inorganic Chemistry',
    accent: '#38bdf8',
    iconName: 'Grid3X3',
    summary: 'Interactive IUPAC 118-element periodic grid with 3D quantum atomic shell visualizer and continuous trend curve grapher.',
    whatItDoes: 'Visualizes all chemical elements with comprehensive physical, thermodynamic, quantum, and historical properties alongside real-time heatmap overlays.',
    inputs: ['Element selection (1-118)', 'Periodic trend metric (Atomic radius, Electronegativity, Ionization Energy, Melting Point)', 'Phase state temperature filter'],
    outputs: ['Deep elemental dossier', 'Quantized electron shell configuration', 'Interactive Bohr orbit jump diagram', 'Continuous property trend graph'],
    howToInterpret: 'Peaks on ionization energy denote noble gases; valleys on atomic radius denote halogen/noble gas contractions across periods from alkali metals.',
    interactiveSteps: [
      { title: 'Step 1: Select an Element', instruction: 'Click on any element tile in the 118-element matrix (e.g., Carbon #6 or Iron #26) to open its atomic dossier.', actionHint: 'Click element card' },
      { title: 'Step 2: Inspect Atomic Structure', instruction: 'Explore the 3D Bohr shell diagram displaying electron distribution across K, L, M, N quantum energy levels.', actionHint: 'View atomic shells' },
      { title: 'Step 3: Click Nucleus & Shells', instruction: 'Interact directly with the central nucleus to inspect protons/neutrons, or click individual orbital rings to isolate valence electrons.', actionHint: 'Click nucleus or rings' },
      { title: 'Step 4: Enable Periodic Trend Heatmaps', instruction: 'Toggle the Trend Mode dropdown to visualize atomic radius, electronegativity (Pauling scale), and first ionization energy curves.', actionHint: 'Toggle trend visualizer' }
    ],
    keyControls: ['Element Search (Ctrl+F)', 'Block Filters (s, p, d, f)', 'Trend Heatmap Mode', 'Temperature Phase Slider'],
    relatedModules: ['atomic-structure', 'orbital-atlas', 'spectroscopy-suite']
  },

  // 2. ATOMIC STRUCTURE
  {
    id: 'atomic-structure',
    title: 'Atomic Structure & Quantum Transitions',
    category: 'laboratories',
    tab: 'atomic-structure',
    badge: 'Atomic Physics',
    accent: '#06b6d4',
    iconName: 'Atom',
    summary: 'Historical and modern atomic structure models: Rutherford alpha scattering, Thomson plum pudding, and quantized Bohr jumps.',
    whatItDoes: 'Simulates gold foil particle trajectories to prove nuclear concentration and demonstrates photon absorption/emission during electron jumps between n1 and n2.',
    inputs: ['Alpha particle beam kinetic energy (MeV)', 'Gold foil nuclear charge (Z)', 'Bohr jump initial level (n1) and final level (n2)'],
    outputs: ['Scattering deflection angle distribution', 'Emitted photon wavelength (nm)', 'Rydberg energy calculation (eV)'],
    howToInterpret: 'Rare wide-angle back-scattering (>90°) confirms Rutherford atomic nucleus mass concentration; discrete spectral emission lines confirm quantized orbits.',
    interactiveSteps: [
      { title: 'Step 1: Fire Alpha Particle Beam', instruction: 'Adjust beam velocity and trigger particle emission to observe Rutherford deflection near heavy nuclei.', actionHint: 'Start alpha emitter' },
      { title: 'Step 2: Trigger Bohr Electron Jump', instruction: 'Select initial shell n=3 and final shell n=2 (Balmer red H-alpha 656.3 nm). Watch photon emission.', actionHint: 'Set n1 & n2 levels' },
      { title: 'Step 3: Click Shells to Transition', instruction: 'Click directly on shell rings in the 3D canvas to trigger quantum leaps interactively.', actionHint: 'Click canvas shells' }
    ],
    keyControls: ['Rutherford Beam Speed', 'Nuclear Charge Slider (Z)', 'Bohr Quantized Shell Selector', 'Photomultiplier Zoom'],
    relatedModules: ['atomic-spectra', 'orbital-atlas', 'waves-radiation']
  },

  // 3. ORBITAL ATLAS
  {
    id: 'orbital-atlas',
    title: '3D Quantum Orbital Atlas',
    category: 'simulations',
    tab: 'orbital-atlas',
    badge: 'Quantum Mechanics',
    accent: '#a855f7',
    iconName: 'Orbit',
    summary: 'Exact 3D iso-surfaces of hydrogenic wavefunctions derived from spherical harmonics and radial probability distributions.',
    whatItDoes: 'Renders mathematical Schrödinger solutions ($1s, 2s, 2p, 3d, 4f$) with probability density coloring, phase signage ($\pm\psi$), and slice planes.',
    inputs: ['Principal quantum number (n)', 'Azimuthal number (l)', 'Magnetic quantum number (ml)', 'Iso-surface probability threshold'],
    outputs: ['3D wavefunction iso-surface mesh', 'Radial probability density $r^2 R(r)^2$', 'Angular and radial nodal plane count'],
    howToInterpret: 'Total nodes = $n - 1$. Angular nodes equal $l$, while radial nodes equal $n - l - 1$. Phase changes indicate nodal surface crossings where $\psi = 0$.',
    interactiveSteps: [
      { title: 'Step 1: Select Subshell', instruction: 'Switch between 1s (spherical), 2px/2py/2pz (dumbbell), and 3dz² (torus) subshells.', actionHint: 'Choose orbital' },
      { title: 'Step 2: Inspect Nodal Surfaces', instruction: 'Enable the nodal plane toggle to visualize planes where electron discovery probability is exactly zero.', actionHint: 'Toggle nodal planes' },
      { title: 'Step 3: Slice Cross-Section', instruction: 'Drag the slice-plane slider to view the internal radial probability core.', actionHint: 'Drag slice slider' }
    ],
    keyControls: ['Subshell Grid (1s-4f)', 'Iso-surface Cutoff Slider', 'Phase Color Toggle (+/- ψ)', 'Slice Plane X/Y/Z'],
    relatedModules: ['periodic-table', 'quantum-lab', 'vsepr-lab']
  },

  // 4. ATOMIC SPECTRA
  {
    id: 'atomic-spectra',
    title: 'Atomic Spectra & Emission Series',
    category: 'laboratories',
    tab: 'atomic-spectra',
    badge: 'Spectroscopy',
    accent: '#ec4899',
    iconName: 'Activity',
    summary: 'High-resolution emission and absorption spectral line generator with Rydberg formula calculator and flame test simulations.',
    whatItDoes: 'Simulates hydrogen Lyman (UV), Balmer (Visible), and Paschen (Infrared) series alongside flame emission colors for metal ions (Na, Cu, Sr, Ba, K).',
    inputs: ['Hydrogen spectral series selection', 'Custom element discharge gas', 'Flame test metal salt selection'],
    outputs: ['Continuous spectral band with sharp emission lines', 'Calculated wavelength $\lambda$ in nm', 'Color swatch matching photon frequency'],
    howToInterpret: 'Each element produces an unmistakable unique optical fingerprint caused by quantized transition gaps ($\Delta E = hc/\lambda$).',
    interactiveSteps: [
      { title: 'Step 1: Select Spectral Series', instruction: 'Choose the Balmer series to observe visible transitions: Red (656.3 nm), Cyan (486.1 nm), Blue (434.0 nm), and Violet (410.2 nm).', actionHint: 'Select Balmer series' },
      { title: 'Step 2: Test Element Flame Color', instruction: 'Select Sodium (Na - brilliant yellow 589 nm) or Copper (Cu - emerald green) to observe flame atomization.', actionHint: 'Select flame element' },
      { title: 'Step 3: Measure Spectral Peaks', instruction: 'Hover over individual emission lines on the spectrograph to read precise angstrom and nanometer wavelengths.', actionHint: 'Inspect spectral peak' }
    ],
    keyControls: ['Series Dropdown (Lyman, Balmer, Paschen)', 'Element Gas Picker', 'Flame Burner Igniter', 'Wavelength Ruler'],
    relatedModules: ['spectroscopy-suite', 'waves-radiation', 'atomic-structure']
  },

  // 5. SPECTROSCOPY SUITE (5 Instruments)
  {
    id: 'spectroscopy-suite',
    title: 'Spectroscopy Suite (5 Instruments)',
    category: 'modules',
    tab: 'spectroscopy-suite',
    badge: 'Analytical Instrumentation',
    accent: '#f43f5e',
    iconName: 'Activity',
    summary: 'Comprehensive analytical laboratory operating UV-Vis, FTIR, 1H-NMR, Mass Spectrometry, and XRD instruments.',
    whatItDoes: 'Simulates structural elucidation of unknown organic molecules through coordinated spectroscopic data interpretation.',
    inputs: ['Sample molecule selection (Ethanol, Acetone, Benzene, Aspirin)', 'Instrument mode (UV-Vis, FTIR, NMR, MS, XRD)', 'Solvent and baseline calibration'],
    outputs: ['FTIR absorption wavenumbers (cm⁻¹)', '1H-NMR chemical shift ppm & multiplicity', 'Mass Spec m/z molecular ion and fragments', 'UV-Vis $\lambda_{max}$ absorbance'],
    howToInterpret: 'FTIR: $1715\text{ cm}^{-1}$ indicates Carbonyl C=O, $3300\text{ cm}^{-1}$ indicates Alcohol -OH. NMR: chemical shift shows electronic shielding. MS: base peak & fragmentation pattern reveal structure.',
    interactiveSteps: [
      { title: 'Step 1: Load Unknown Sample', instruction: 'Select an unknown chemical compound from the sample bay (e.g., Unknown Ester or Unknown Carbonyl).', actionHint: 'Load sample' },
      { title: 'Step 2: Run FTIR Scan', instruction: 'Analyze IR stretching bands: look for sharp carbonyl peaks ($1700\text{ cm}^{-1}$) or broad OH peaks ($3300\text{ cm}^{-1}$).', actionHint: 'Run FTIR instrument' },
      { title: 'Step 3: Inspect 1H-NMR Chemical Shifts', instruction: 'Check splitting multiplicity (singlet, doublet, triplet) and integration ratios to determine neighboring protons.', actionHint: 'Switch to NMR tab' },
      { title: 'Step 4: Check Mass Spec M+ Peak', instruction: 'Determine molecular weight from the parent molecular ion peak $M^+$ and analyze stable carbocation fragments.', actionHint: 'Inspect MS chart' }
    ],
    keyControls: ['Instrument Mode Switcher', 'Peak Auto-Picker', 'Functional Group Overlay Guide', 'Baseline Subtraction'],
    relatedModules: ['analytical-lab', 'organic-chem', 'archive']
  },

  // 6. ORGANIC HIGHWAY
  {
    id: 'organic-chem',
    title: 'Organic Reaction Highway & Mechanisms',
    category: 'modules',
    tab: 'organic-chem',
    badge: 'Organic Synthesis',
    accent: '#10b981',
    iconName: 'Dna',
    summary: 'Interactive synthesis network mapping transformations between alkanes, alkenes, alcohols, halides, aldehydes, ketones, and carboxylic acids.',
    whatItDoes: 'Provides step-by-step electron curly arrow mechanisms (SN1, SN2, E1, E2, electrophilic addition, carbonyl condensation) with stereochemical outcomes.',
    inputs: ['Starting material functional group', 'Desired target product', 'Reagent selection (PCC, LiAlH4, H2SO4, Grignard)'],
    outputs: ['Multi-step synthesis route', 'Curved arrow mechanism animation', 'Transition states and carbocation intermediates', 'Markovnikov vs Anti-Markovnikov regiochemistry'],
    howToInterpret: 'Red arrows represent electron pair flow from nucleophile (electron rich) to electrophile (electron poor). Inversion of stereochemistry occurs exclusively in SN2.',
    interactiveSteps: [
      { title: 'Step 1: Select Starting Substrate', instruction: 'Click an alkene (e.g., Propene) on the highway matrix.', actionHint: 'Click starting material' },
      { title: 'Step 2: Choose Target Functional Group', instruction: 'Select 2-Propanol (Markovnikov hydration via $H_3O^+$) or 1-Propanol (Anti-Markovnikov hydroboration).', actionHint: 'Select target node' },
      { title: 'Step 3: Play Mechanism Walkthrough', instruction: 'Step through electron movements: protonation $\to$ carbocation formation $\to$ nucleophilic attack $\to$ deprotonation.', actionHint: 'Step through mechanism' }
    ],
    keyControls: ['Roadmap Filter by Functional Group', 'Named Reaction Explorer', 'Curved-Arrow Step Player', 'Retrosynthesis Planner'],
    relatedModules: ['advanced-organic', 'molecules-3d', 'chemistry-lab']
  },

  // 7. PHYSICAL CHEMISTRY & THERMODYNAMICS
  {
    id: 'thermo-kinetics',
    title: 'Physical Chemistry: Thermodynamics & Kinetics',
    category: 'modules',
    tab: 'thermo-kinetics',
    badge: 'Physical Chemistry',
    accent: '#f97316',
    iconName: 'Flame',
    summary: 'Thermodynamic enthalpy ($\Delta H$), entropy ($\Delta S$), Gibbs free energy ($\Delta G$), Arrhenius kinetics, and Le Chatelier equilibrium simulations.',
    whatItDoes: 'Calculates reaction spontaneity ($\Delta G = \Delta H - T\Delta S$), activation energy barriers from Arrhenius plots ($\ln k$ vs $1/T$), and dynamic equilibrium shifts.',
    inputs: ['Temperature (K)', 'Standard enthalpy $\Delta H^\circ$', 'Standard entropy $\Delta S^\circ$', 'Catalyst activation energy modifier'],
    outputs: ['Gibbs energy curve vs Temperature', 'Equilibrium constant $K_{eq}$ via Van \'t Hoff', 'Arrhenius rate constant $k$', 'Energy profile diagram'],
    howToInterpret: 'When $\Delta G < 0$, reaction is spontaneous. Temperature at which $\Delta G = 0$ is $T_{eq} = \Delta H / \Delta S$. Catalysts lower $E_a$ without altering equilibrium position.',
    interactiveSteps: [
      { title: 'Step 1: Adjust Reaction Temperature', instruction: 'Slide temperature from 200 K to 800 K to observe spontaneity inversion on an endothermic-entropy-driven reaction.', actionHint: 'Adjust temperature slider' },
      { title: 'Step 2: Add a Catalyst to Kinetics Barrier', instruction: 'Enable catalytic pathway to visualize reduction in transition state barrier $E_a$ and exponential rate boost.', actionHint: 'Toggle catalyst' },
      { title: 'Step 3: Perturb Chemical Equilibrium', instruction: 'Increase product concentration or compress volume to witness Le Chatelier shift toward reactants.', actionHint: 'Perturb equilibrium' }
    ],
    keyControls: ['Temperature Slider (0-1000 K)', 'Enthalpy/Entropy Sliders', 'Catalyst Toggle', 'Le Chatelier Pressure/Temp Controls'],
    relatedModules: ['electrochemistry-lab', 'universal-calc-graph', 'formula-vault']
  },

  // 8. ELECTROCHEMISTRY
  {
    id: 'electrochemistry-lab',
    title: 'Electrochemistry Lab & Nernst Engine',
    category: 'laboratories',
    tab: 'electrochemistry-lab',
    badge: 'Electrochemistry',
    accent: '#eab308',
    iconName: 'Zap',
    summary: 'Galvanic Daniell cell and electrolytic cell simulator with real-time electron flow, ion migration through salt bridge, and Nernst equation calculations.',
    whatItDoes: 'Calculates standard and non-standard cell potential $E_{cell} = E^\circ_{cell} - \frac{RT}{nF}\ln Q$, simulating electrode mass changes.',
    inputs: ['Anode metal/solution half-cell (e.g. Zn/Zn²⁺)', 'Cathode metal/solution half-cell (e.g. Cu/Cu²⁺)', 'Ion molar concentrations', 'External resistance/battery'],
    outputs: ['Open-circuit cell voltage $E_{cell}$', 'Direction of electron flow (Anode $\to$ Cathode)', 'Ion diffusion across salt bridge', 'Electrode mass gain/loss over time'],
    howToInterpret: 'Anode undergoes oxidation ($E^\circ$ lowest, loses mass). Cathode undergoes reduction ($E^\circ$ highest, gains mass). As reaction proceeds, $Q \to K$ and $E_{cell} \to 0$.',
    interactiveSteps: [
      { title: 'Step 1: Configure Daniell Cell', instruction: 'Select Zinc anode ($E^\circ = -0.76\text{ V}$) and Copper cathode ($E^\circ = +0.34\text{ V}$) for standard $E^\circ_{cell} = 1.10\text{ V}$.', actionHint: 'Select electrodes' },
      { title: 'Step 2: Alter Ion Concentrations', instruction: 'Change $[Zn^{2+}]$ to $0.001\text{ M}$ and observe cell voltage increase according to the Nernst equation.', actionHint: 'Adjust concentration' },
      { title: 'Step 3: Switch to Electrolytic Mode', instruction: 'Apply external voltage to force non-spontaneous electrolysis (e.g. water splitting into $H_2$ and $O_2$).', actionHint: 'Toggle electrolysis' }
    ],
    keyControls: ['Half-Cell Electrode Pickers', 'Concentration Sliders (0.001-2.0 M)', 'Salt Bridge Electrolyte', 'Voltmeter Display'],
    relatedModules: ['thermo-kinetics', 'formula-vault', 'chemistry-lab']
  },

  // 9. NUCLEAR CHEMISTRY
  {
    id: 'nuclear-chemistry',
    title: 'Nuclear Chemistry & Radioactive Decay',
    category: 'laboratories',
    tab: 'nuclear-chemistry',
    badge: 'Nuclear Physics',
    accent: '#ef4444',
    iconName: 'Radio',
    summary: 'Radioactive isotope half-life simulator, decay chain tracer (Alpha, Beta-minus, Beta-plus, Gamma), and nuclear fission/fusion energy calculator.',
    whatItDoes: 'Simulates radioactive decay kinetics $N(t) = N_0 e^{-\lambda t}$, nuclear binding energy per nucleon ($B/A$), and mass defect via Einstein\'s $E=mc^2$.',
    inputs: ['Radioisotope selection (Carbon-14, Uranium-238, Cobalt-60, Iodine-131)', 'Simulation elapsed time', 'Nuclear reaction target projectile'],
    outputs: ['Remaining undecayed nuclei percentage', 'Emitted radiation particle visual', 'Daughter isotope nuclear equation', 'Q-value / Energy release (MeV)'],
    howToInterpret: 'Alpha decay reduces mass by 4 and charge by 2 ($^4_2\alpha$). Beta-minus decay converts a neutron to a proton ($^0_{-1}\beta$). Stable nuclei sit on the Belt of Stability.',
    interactiveSteps: [
      { title: 'Step 1: Select Carbon-14 Radiocarbon', instruction: 'Observe beta-minus decay into Nitrogen-14 over its 5,730 year half-life curve.', actionHint: 'Select C-14' },
      { title: 'Step 2: Run Accelerated Decay Clock', instruction: 'Fast-forward time in half-life increments (1, 2, 3 half-lives) and watch nuclei decay exponentially.', actionHint: 'Run decay timer' },
      { title: 'Step 3: Inspect Uranium-235 Fission', instruction: 'Trigger thermal neutron capture on U-235 to initiate fission chain reaction and calculate mass defect energy.', actionHint: 'Trigger fission' }
    ],
    keyControls: ['Isotope Selector', 'Decay Speed Clock', 'Decay Mode Filter (α, β, γ)', 'Chain Reaction Initiator'],
    relatedModules: ['atomic-structure', 'waves-radiation', 'archive']
  },

  // 10. WAVES & RADIATION
  {
    id: 'waves-radiation',
    title: 'Waves & Electromagnetic Radiation',
    category: 'simulations',
    tab: 'waves-radiation',
    badge: 'Physical Optics',
    accent: '#8b5cf6',
    iconName: 'Radio',
    summary: 'Interactive electromagnetic wave synthesizer with wavelength, frequency, standing waves, wave interference, and photon energy relationships.',
    whatItDoes: 'Simulates the complete EM spectrum (Radio $\to$ Gamma), double-slit interference patterns, and photo-electric electron ejection.',
    inputs: ['Wavelength $\lambda$ (nm to m)', 'Wave frequency $\nu$ (Hz)', 'Light intensity / Photon flux', 'Work function $\Phi$ of metal surface'],
    outputs: ['Wave phase animation', 'Photon energy $E = h\nu = hc/\lambda$', 'Photoelectric kinetic energy $K_{max} = h\nu - \Phi$', 'Interference fringe spacing'],
    howToInterpret: 'Wavelength and frequency are inversely proportional ($c = \lambda \nu$). Increasing light intensity increases photon count, while increasing frequency increases individual photon energy.',
    interactiveSteps: [
      { title: 'Step 1: Tune Electromagnetic Wavelength', instruction: 'Slide across the EM spectrum: Radio $\to$ Microwave $\to$ Infrared $\to$ Visible $\to$ UV $\to$ X-Ray $\to$ Gamma.', actionHint: 'Slide wavelength' },
      { title: 'Step 2: Test Photoelectric Effect', instruction: 'Select a Potassium target ($\Phi = 2.3\text{ eV}$). Test with Red light (no ejection) vs Blue light (immediate electron ejection).', actionHint: 'Adjust photon energy' },
      { title: 'Step 3: Superimpose Wave Interference', instruction: 'Adjust wave phase difference to observe constructive interference (amplitude doubles) vs destructive interference (amplitude cancels).', actionHint: 'Tune wave phase' }
    ],
    keyControls: ['Wavelength/Frequency Slider', 'EM Spectrum Selector', 'Metal Target Selector', 'Wave Superposition Modes'],
    relatedModules: ['atomic-spectra', 'quantum-lab', 'spectroscopy-suite']
  },

  // 11. 3D MOLECULAR SIMULATOR
  {
    id: 'molecules-3d',
    title: '3D Molecular Simulator & CAD',
    category: 'simulations',
    tab: 'molecules-3d',
    badge: 'Structural Chemistry',
    accent: '#6366f1',
    iconName: 'Boxes',
    summary: 'Interactive 3D molecular structure visualizer with CPK space-filling, ball-and-stick, and wireframe representations.',
    whatItDoes: 'Allows free 3D rotation, zooming, atom distance measurement, bond angle calculation, and molecular dipole vector visualization for 60+ compounds.',
    inputs: ['Preloaded molecule selection (Water, Caffeine, Glucose, Benzene, DNA base pair, Penicillin)', 'Visualization style (Ball-and-stick, Space-filling, Wireframe)', 'Measurement tool selection'],
    outputs: ['Interactive 3D model', 'Measured bond lengths ($\text{Å}$) and angles ($^\circ$)', 'Net dipole moment vector', 'Molecular formula and molar mass'],
    howToInterpret: 'CPK coloring: White = Hydrogen, Gray = Carbon, Red = Oxygen, Blue = Nitrogen, Yellow = Sulfur, Green = Chlorine. Net dipole vector points towards negative charge center.',
    interactiveSteps: [
      { title: 'Step 1: Rotate and Zoom in 3D', instruction: 'Click and drag on the molecular viewport to rotate in 3 axes. Scroll to zoom in and examine atomic bonds.', actionHint: 'Drag canvas to rotate' },
      { title: 'Step 2: Switch Representation Mode', instruction: 'Toggle between Ball-and-Stick (clear geometry), Space-Filling (van der Waals radii), and Wireframe.', actionHint: 'Switch display mode' },
      { title: 'Step 3: Measure Bond Angle', instruction: 'Click any three adjacent atoms (e.g. H-O-H in water) to calculate the precise geometric angle.', actionHint: 'Select 3 atoms' }
    ],
    keyControls: ['Mouse Drag (Rotate)', 'Mouse Wheel (Zoom)', 'CPK / Wireframe / Ball-Stick Mode', 'Dipole Vector Toggle', 'Angle Measuring Tool'],
    relatedModules: ['vsepr-lab', 'organic-chem', 'tools']
  },

  // 12. VSEPR & CHEMICAL BONDING
  {
    id: 'vsepr-lab',
    title: 'VSEPR Theory & Hybridization Lab',
    category: 'laboratories',
    tab: 'vsepr-lab',
    badge: 'Bonding & Geometry',
    accent: '#3b82f6',
    iconName: 'Atom',
    summary: 'Valence Shell Electron Pair Repulsion geometry and orbital hybridization ($sp, sp^2, sp^3, sp^3d, sp^3d^2$) visualizer.',
    whatItDoes: 'Simulates electrostatic repulsion of electron domains around central atoms to predict molecular shapes from Linear ($AX_2$) to Octahedral ($AX_6$).',
    inputs: ['Bonding electron pairs count (B)', 'Non-bonding lone pairs count (L)', 'Central atom electronegativity'],
    outputs: ['Predicted electron geometry & molecular shape', 'Ideal vs actual bond angles', 'Hybridization state', 'Polarity status'],
    howToInterpret: 'Lone pairs occupy greater space than bonding pairs, compressing adjacent bond angles (e.g., $AX_4$ Tetrahedral $109.5^\circ \to AX_3E$ Trigonal Pyramidal $107^\circ \to AX_2E_2$ Bent $104.5^\circ$).',
    interactiveSteps: [
      { title: 'Step 1: Add Electron Domains', instruction: 'Configure 2 bonding pairs and 2 lone pairs to build Water ($H_2O$, $AX_2E_2$).', actionHint: 'Set 2 bonds, 2 lone pairs' },
      { title: 'Step 2: Observe Lone Pair Repulsion', instruction: 'Observe how the two non-bonding electron lobes compress the tetrahedral angle from $109.5^\circ$ down to $104.5^\circ$.', actionHint: 'Check angle measurement' },
      { title: 'Step 3: Explore 5 & 6 Domain Systems', instruction: 'Examine Phosphorus Pentachloride ($PCl_5$ - Trigonal Bipyramidal) and Sulfur Hexafluoride ($SF_6$ - Octahedral).', actionHint: 'Select SF6 preset' }
    ],
    keyControls: ['Bonding Pairs Counter (+/-)', 'Lone Pairs Counter (+/-)', 'Repulsion Vector Vectors', 'Molecule Preset Selector'],
    relatedModules: ['molecules-3d', 'orbital-atlas', 'periodic-table']
  },

  // 13. ANALYTICAL CHEMISTRY & TITRATION
  {
    id: 'analytical-lab',
    title: 'Analytical Chemistry & Chromatography',
    category: 'laboratories',
    tab: 'analytical-lab',
    badge: 'Quantitative Analysis',
    accent: '#14b8a6',
    iconName: 'FlaskConical',
    summary: 'Acid-base titration curve simulator, TLC chromatography retention factor calculator, and spectrophotometric Beer-Lambert solver.',
    whatItDoes: 'Generates titration curves for strong/weak acid-base pairings, determines equivalence point pH, and simulates chromatographic separation.',
    inputs: ['Analyte acid/base concentration and volume', 'Titrant concentration and addition rate', 'Indicator selection (Phenolphthalein, Methyl Orange, Bromothymol Blue)', 'Chromatography mobile/stationary phase'],
    outputs: ['Continuous titration curve (pH vs titrant volume)', 'Equivalence point and half-equivalence buffer point', 'Indicator color transition', 'Retention factor ($R_f$) values'],
    howToInterpret: 'Weak acid vs Strong base has basic equivalence point (pH > 7); at half-equivalence volume, $\text{pH} = \text{pK}_a$. In TLC, higher $R_f$ indicates lower affinity for stationary phase.',
    interactiveSteps: [
      { title: 'Step 1: Set Up Titration Burette', instruction: 'Load $0.1\text{ M } HCl$ into beaker and $0.1\text{ M } NaOH$ into burette with Phenolphthalein indicator.', actionHint: 'Configure titration' },
      { title: 'Step 2: Dispense Titrant', instruction: 'Add titrant dropwise: observe gradual pH climb, sharp vertical surge at $25.0\text{ mL}$, and vibrant pink color shift.', actionHint: 'Add titrant' },
      { title: 'Step 3: Run Thin Layer Chromatography', instruction: 'Spot amino acid mixture on silica plate and run solvent to measure component $R_f$ migration values.', actionHint: 'Run TLC plate' }
    ],
    keyControls: ['Burette Stopcock (Dropwise / Continuous)', 'Acid/Base pKa Selector', 'Indicator Palette', 'TLC Solvent Front Ruler'],
    relatedModules: ['spectroscopy-suite', 'chemistry-lab', 'formula-vault']
  },

  // 14. STOICHIOMETRY & BALANCING
  {
    id: 'stoichiometry',
    title: 'Stoichiometry & Equation Balancer',
    category: 'tools',
    tab: 'stoichiometry',
    badge: 'Quantitative Chemistry',
    accent: '#22c55e',
    iconName: 'FlaskConical',
    summary: 'Automated chemical equation balancer, mole-to-gram conversion engine, limiting reactant identifier, and percentage yield calculator.',
    whatItDoes: 'Applies linear algebraic matrix algorithms to balance complex redox and combustion equations, calculating theoretical yields.',
    inputs: ['Unbalanced chemical reaction (e.g. C3H8 + O2 -> CO2 + H2O)', 'Reactant starting masses (grams or moles)', 'Actual isolated yield (grams)'],
    outputs: ['Balanced equation with stoichiometric coefficients', 'Limiting and excess reagent identification', 'Theoretical product yield', 'Percentage yield (%)'],
    howToInterpret: 'The limiting reagent is completely consumed first, dictating the maximum theoretical mass of products formed according to mass conservation.',
    interactiveSteps: [
      { title: 'Step 1: Input Chemical Equation', instruction: 'Type or choose a preset reaction (e.g., Haber-Bosch $N_2 + H_2 \to NH_3$ or combustion of octane).', actionHint: 'Enter equation' },
      { title: 'Step 2: Assign Starting Masses', instruction: 'Input $28\text{ g } N_2$ and $9\text{ g } H_2$. The engine computes mole ratios to identify limiting reagents.', actionHint: 'Input reactant mass' },
      { title: 'Step 3: Calculate Yield & Excess Leftover', instruction: 'Read the theoretical yield ($34\text{ g } NH_3$) and unreacted leftover excess reagent mass.', actionHint: 'View yield results' }
    ],
    keyControls: ['Equation Input Field', 'Preset Reaction Drawer', 'Gram / Mole Unit Toggle', 'Limiting Reagent Matrix'],
    relatedModules: ['universal-calc-graph', 'chemistry-lab', 'questions-playground']
  },

  // 15. CHEMISTRY TOOLS MASTER ECOSYSTEM
  {
    id: 'tools',
    title: '🧰 Chemistry Tools & Discover Area',
    category: 'tools',
    tab: 'tools',
    badge: 'Universal Tool Suite',
    accent: '#06b6d4',
    iconName: 'Boxes',
    summary: 'All 20+ specialized chemistry calculators, molecular builders, scientific graphers, and reaction analyzers in one central workspace.',
    whatItDoes: 'Hosts purpose-built calculators (pH, Gas Laws, Nernst, Thermodynamics, Equilibrium), builders (Lewis structure, Electron config), and analytical graphers.',
    inputs: ['Specific tool parameters according to purpose cards'],
    outputs: ['Instant numerical solutions, formatted LaTeX derivations, molecular formula strings, and SVG charts'],
    howToInterpret: 'Every tool includes a dedicated Purpose Card outlining its exact scientific role, inputs, outputs, concrete examples, and related curriculum modules.',
    interactiveSteps: [
      { title: 'Step 1: Browse Categorized Tool Matrix', instruction: 'Explore tools organized under Practice, Experiment, Reference, Calculators, Builders, and Analysis.', actionHint: 'Filter by category' },
      { title: 'Step 2: Inspect a Tool\'s Purpose Card', instruction: 'Open the "What is this?" card on any tool to read its inputs, outputs, and scientific background.', actionHint: 'Click Purpose Card' },
      { title: 'Step 3: Run an Interactive Calculation', instruction: 'Test the pH / Buffer Calculator, Gas Law solver, or Lewis Structure Builder directly.', actionHint: 'Execute calculation' }
    ],
    keyControls: ['Category Tabs (Calculators, Builders, Reference, Analysis)', 'Purpose Card Drawer', 'Quick Preset Loaders', 'LaTeX Step Exporter'],
    relatedModules: ['formula-vault', 'questions-playground', 'chemistry-lab']
  },

  // 16. CHEMOBOT 2.0 AI SCIENTIFIC COPILOT
  {
    id: 'ai-tutor',
    title: 'ChemoBot 2.0 AI Scientific Copilot',
    category: 'chemobot',
    tab: 'ai-tutor',
    badge: 'AI Reasoning Engine',
    accent: '#c084fc',
    iconName: 'Bot',
    summary: 'Context-aware chemistry intelligence operating across 6 specialized modes (Tutor, Solver, Lab Assistant, Analyst, Quiz Me, Navigator).',
    whatItDoes: 'Understands your current screen (active element, reaction, or simulation state) to provide rigorous step-by-step derivations, mechanisms, and deep links.',
    inputs: ['Natural language chemistry query', 'Active screen context (Element, Molecule, Reaction, Graph)', 'Selected operating mode'],
    outputs: ['Pedagogical explanations formatted in Markdown & LaTeX math', 'Structured derivation steps', 'Direct navigation launch buttons to 3D labs'],
    howToInterpret: 'Solver mode formats responses strictly as Given $\to$ Formula $\to$ Substitution $\to$ Calculation $\to$ Answer $\to$ Explanation. Navigator mode jumps to matching modules.',
    interactiveSteps: [
      { title: 'Step 1: Switch Operating Modes', instruction: 'Select between 🧑‍🏫 Tutor (concepts), 🧮 Solver (calculations), 🔬 Lab Assistant (experiments), or 🧠 Quiz Me.', actionHint: 'Select mode pill' },
      { title: 'Step 2: Use Contextual "Explain This Screen"', instruction: 'Click the contextual trigger on any simulation to ask ChemoBot to analyze the current 3D canvas state.', actionHint: 'Click Explain button' },
      { title: 'Step 3: Launch Direct Lab Links', instruction: 'Click action buttons embedded in responses (e.g. "[Open Orbital Atlas ->]") to immediately jump into simulations.', actionHint: 'Click action link' }
    ],
    keyControls: ['6 AI Modes (Tutor, Solver, Assistant, Analyst, Quiz, Navigator)', 'Current Context Sensor', 'LaTeX Derivation Renderer', 'Voice / Text Input'],
    relatedModules: ['home', 'questions-playground', 'tools']
  }
];
