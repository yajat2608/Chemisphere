import { QuizQuestion } from '../types';

export const PRACTICE_QUESTIONS: QuizQuestion[] = [
  {
    id: 'q1',
    title: 'Atomic Structure & Quantum Orbitals',
    category: 'quantum-orbitals',
    difficulty: 'Easy',
    type: 'mcq',
    question: 'How many total nodal surfaces (radial + angular) exist in a 3d orbital?',
    options: ['0', '1', '2', '3'],
    correctAnswer: 2,
    explanation: 'Total nodes = n - 1. For a 3d orbital: n = 3, l = 2. Angular nodes = l = 2, Radial nodes = n - l - 1 = 3 - 2 - 1 = 0. Total nodes = 2 + 0 = 2.',
    conceptLink: 'orbital-atlas'
  },
  {
    id: 'q2',
    title: 'Periodic Trends & Ionization Energy',
    category: 'periodic-table',
    difficulty: 'Medium',
    type: 'mcq',
    question: 'Why is the first ionization energy of Nitrogen (N) higher than that of Oxygen (O), despite Oxygen having a higher nuclear charge?',
    options: [
      'Oxygen has a larger atomic radius than Nitrogen',
      'Nitrogen has an extra stable half-filled 2p³ subshell, whereas Oxygen has paired electron repulsion in 2p⁴',
      'Nitrogen has more shielding electrons than Oxygen',
      'Oxygen electrons experience higher effective nuclear charge'
    ],
    correctAnswer: 1,
    explanation: 'Nitrogen configuration is 1s² 2s² 2p³ (half-filled p-subshell with high exchange energy). In Oxygen (1s² 2s² 2p⁴), the fourth p-electron pairs up in an orbital, causing inter-electronic repulsion and making it easier to remove.',
    conceptLink: 'periodic-table'
  },
  {
    id: 'q3',
    title: 'VSEPR Theory & Molecular Geometry',
    category: 'vsepr',
    difficulty: 'Easy',
    type: 'mcq',
    question: 'What is the molecular geometry and approximate bond angle of Xenon Tetrafluoride (XeF₄)?',
    options: [
      'Tetrahedral, 109.5°',
      'Square Planar, 90°',
      'Seesaw, <120° and <90°',
      'Square Pyramidal, <90°'
    ],
    correctAnswer: 1,
    explanation: 'In XeF₄, Xenon has 8 valence electrons + 4 from fluorines = 12 electrons = 6 electron pairs (4 bonding pairs + 2 lone pairs). Steric number = 6 (Octahedral electron geometry). The 2 lone pairs occupy axial positions to minimize repulsion, yielding a Square Planar molecular geometry with 90° bond angles.',
    conceptLink: 'vsepr-lab'
  },
  {
    id: 'q4',
    title: 'Thermodynamics & Spontaneity',
    category: 'thermodynamics',
    difficulty: 'Hard',
    type: 'mcq',
    question: 'For a chemical process with ΔH = +30.5 kJ/mol and ΔS = +100 J/(mol·K), at what threshold temperature (in Kelvin) does the process transition into being thermodynamically spontaneous (ΔG < 0)?',
    options: [
      '273 K (0 °C)',
      '298 K (25 °C)',
      '305 K (32 °C)',
      '373 K (100 °C)'
    ],
    correctAnswer: 2,
    explanation: 'At equilibrium threshold: ΔG = ΔH - TΔS = 0 => T = ΔH / ΔS = (30,500 J/mol) / (100 J/(mol·K)) = 305 K. Above 305 K, the TΔS term dominates, driving ΔG negative.',
    conceptLink: 'physical-chem'
  },
  {
    id: 'q5',
    title: 'Stoichiometry & Limiting Reactants',
    category: 'stoichiometry',
    difficulty: 'Medium',
    type: 'mcq',
    question: 'In the reaction 2Al + 3Cl₂ → 2AlCl₃, if 54g of Al (Mw = 27 g/mol) reacts with 142g of Cl₂ (Mw = 71 g/mol), what is the limiting reactant?',
    options: [
      'Aluminium (Al)',
      'Chlorine gas (Cl₂)',
      'Both are present in exact stoichiometric proportions',
      'Aluminium Chloride (AlCl₃)'
    ],
    correctAnswer: 1,
    explanation: 'Moles of Al = 54/27 = 2.0 mol (needs 2.0 × 3/2 = 3.0 mol Cl₂). Moles of Cl₂ = 142/71 = 2.0 mol. Since we only have 2.0 mol Cl₂ (less than 3.0 mol required), Cl₂ is the limiting reactant.',
    conceptLink: 'stoichiometry'
  },
  {
    id: 'q6',
    title: 'Organic Chemistry & Reaction Mechanisms',
    category: 'organic',
    difficulty: 'Hard',
    type: 'mcq',
    question: 'Which substrate and solvent combination will proceed most rapidly via an SN2 substitution mechanism with aqueous NaCN?',
    options: [
      'tert-Butyl bromide in water (polar protic)',
      'Methyl bromide in DMSO (polar aprotic)',
      'Isopropyl bromide in ethanol',
      'tert-Butyl chloride in acetone'
    ],
    correctAnswer: 1,
    explanation: 'SN2 reactions are fastest with unhindered primary/methyl substrates (Methyl > 1° >> 2° > 3°) and are accelerated in polar aprotic solvents like DMSO which do not solvate the nucleophile anion tightly.',
    conceptLink: 'organic-chem'
  }
];

export type { QuizQuestion };
