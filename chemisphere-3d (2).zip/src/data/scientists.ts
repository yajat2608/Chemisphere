export interface TransitionalDiscovery {
  year: number;
  scientist: string;
  discovery: string;
  significance: string;
}

export interface ScientistData {
  id: string;
  name: string;
  lifespan: string;
  keyDiscovery: string;
  theory: string;
  experiment: string;
  keyIdea: string;
  limitations: string[];
  impact: string;
  modelName: string;
  year: number;
  romanYear: string;
  quote: string;
  archivalNotes: string[];
  transitionalDiscoveries?: TransitionalDiscovery[];
  formulaLatex?: string;
}

export const SCIENTISTS_TIMELINE: ScientistData[] = [
  {
    id: 'dalton',
    name: 'John Dalton',
    lifespan: '1766 – 1844',
    keyDiscovery: 'Modern Atomic Theory & Law of Multiple Proportions',
    keyIdea: 'Matter consists of indivisible, spherical, indestructible units with characteristic elemental masses.',
    theory: 'All matter is made of atoms. Atoms are indivisible and indestructible solid spheres. All atoms of a given element are identical in mass and properties. Compounds are combinations of two or more different types of atoms in simple whole-number ratios.',
    experiment: 'Quantitative gas pressure experiments (Dalton\'s Law of Partial Pressures) and stoichiometric gravimetric mass ratio analyses of nitric oxide gases (1803).',
    limitations: [
      'Failed to explain the existence of subatomic particles (electrons, protons, neutrons).',
      'Could not explain isotopes (atoms of same element with different masses).',
      'Could not explain allotropes (diamond vs graphite) or electrical conductivity in matter.'
    ],
    impact: 'Transformed speculative Greek atomism (Democritus) into an empirical, quantitative science of chemistry.',
    modelName: 'Billiard Ball Model',
    year: 1803,
    romanYear: 'MDCCCIII',
    quote: 'Matter, though divisible in an extreme degree, is nevertheless not infinitely divisible.',
    archivalNotes: [
      'Lab Notebook 1803: "Why does not water admit its bulk of every kind of gas alike? ... because of the different sizes and weights of the ultimate particles."',
      'Postulate I: Atoms of different elements have different weights and affinities.'
    ],
    formulaLatex: 'm_A : m_B = \\frac{a}{b} \\in \\mathbb{Q}',
    transitionalDiscoveries: [
      {
        year: 1789,
        scientist: 'Antoine Lavoisier',
        discovery: 'Law of Conservation of Mass',
        significance: 'Established that mass is neither created nor destroyed in chemical reactions.'
      },
      {
        year: 1799,
        scientist: 'Joseph Proust',
        discovery: 'Law of Definite Proportions',
        significance: 'Demonstrated compounds always contain elements in fixed mass ratios.'
      },
      {
        year: 1834,
        scientist: 'Michael Faraday',
        discovery: 'Laws of Electrolysis',
        significance: 'Proved an intrinsic link between electrical charge and chemical valence.'
      }
    ]
  },
  {
    id: 'thomson',
    name: 'J.J. Thomson',
    lifespan: '1856 – 1940',
    keyDiscovery: 'Discovery of the Electron & Specific Charge (e/m Ratio)',
    keyIdea: 'The atom is a positively charged spherical matrix embedded with negatively charged mobile electrons.',
    theory: 'The atom is electrically neutral, consisting of a uniform diffuse sphere of positive electrification (the "pudding") with tiny, negatively charged subatomic corpuscles (electrons) embedded throughout (the "plums").',
    experiment: 'High-vacuum Cathode Ray Tube (CRT) deflected by crossed electrostatic and magnetic fields at Cavendish Laboratory (1897), calculating e/m = 1.76 × 10¹¹ C/kg.',
    limitations: [
      'Lacked a concentrated positive nucleus, failing to account for large-angle alpha particle scattering.',
      'Could not explain discrete atomic emission spectra (hydrogen line series).',
      'Electrostatically unstable according to classical Earnshaw\'s theorem.'
    ],
    impact: 'Proved definitively that the atom is divisible and contains universal fundamental subatomic constituents.',
    modelName: 'Plum Pudding Model',
    year: 1897,
    romanYear: 'MDCCCXCVII',
    quote: 'The electron: may it never be of the slightest use to anybody!',
    archivalNotes: [
      'Cavendish Lab Report (April 30, 1897): "Cathode rays are matter in a new state, a state in which the subdivision of matter is carried very much further than in the ordinary gaseous state."',
      'Determined corpuscle mass to be approximately 1/1837 that of a hydrogen ion.'
    ],
    formulaLatex: '\\frac{e}{m} = \\frac{E}{B^2 r} \\approx 1.76 \\times 10^{11} \\text{ C/kg}',
    transitionalDiscoveries: [
      {
        year: 1895,
        scientist: 'Wilhelm Röntgen',
        discovery: 'Discovery of X-Rays',
        significance: 'Demonstrated high-energy penetrating electromagnetic radiation from CRT anodes.'
      },
      {
        year: 1896,
        scientist: 'Henri Becquerel',
        discovery: 'Spontaneous Radioactivity in Uranium',
        significance: 'Discovered atoms spontaneously disintegrate, emitting penetrating radiation.'
      },
      {
        year: 1898,
        scientist: 'Marie & Pierre Curie',
        discovery: 'Isolation of Polonium & Radium',
        significance: 'Proved radioactivity is an atomic property of unstable elements.'
      },
      {
        year: 1909,
        scientist: 'Robert Millikan',
        discovery: 'Oil Drop Experiment',
        significance: 'Quantized elementary charge e = 1.602 × 10⁻¹⁹ Coulombs.'
      }
    ]
  },
  {
    id: 'rutherford',
    name: 'Ernest Rutherford',
    lifespan: '1871 – 1937',
    keyDiscovery: 'Discovery of the Atomic Nucleus & Nuclear Planetary Atom',
    keyIdea: 'The atom is 99.999% empty space, with virtually all mass and positive charge concentrated in a minute central core.',
    theory: 'The positive charge and nearly total mass of the atom are compressed into a central nucleus (~10⁻¹⁵ m), while lightweight electrons orbit around it at astronomical relative distances (~10⁻¹⁰ m), like planets around the Sun.',
    experiment: 'Geiger-Marsden Gold Foil Experiment (1909–1911): Bombardment of 400 nm gold foil with high-velocity α-particles (⁴He²⁺). 1 in 8,000 deflected backwards (>90°).',
    limitations: [
      'Classical Electrodynamics (Larmor formula): accelerating orbiting electrons must radiate energy continuously, causing them to spiral into the nucleus within 10⁻¹¹ seconds.',
      'Could not explain why atoms do not collapse, nor why they emit discrete line spectra instead of continuous rainbows.'
    ],
    impact: 'Established the nuclear architecture of matter; initiated nuclear physics and artificial transmutation.',
    modelName: 'Nuclear Planetary Model',
    year: 1911,
    romanYear: 'MCMXI',
    quote: 'It was quite the most incredible event that has ever happened to me in my life. It was almost as incredible as if you fired a 15-inch shell at a piece of tissue paper and it came back and hit you.',
    archivalNotes: [
      'Manchester Phil. Mag. (1911): "Considering the data as a whole, it seems reasonable to suppose that the atom consists of a central charge concentrated at a point..."',
      'Nuclear radius calculated at r_0 ≈ 10⁻¹⁵ m, atom radius r ≈ 10⁻¹⁰ m (100,000× larger).'
    ],
    formulaLatex: '\\frac{d\\sigma}{d\\Omega} = \\left(\\frac{z Z e^2}{4\\pi \\varepsilon_0 \\cdot 2mv^2}\\right)^2 \\frac{1}{\\sin^4(\\theta/2)}',
    transitionalDiscoveries: [
      {
        year: 1913,
        scientist: 'Henry Moseley',
        discovery: 'X-Ray Spectroscopy & Atomic Number (Z)',
        significance: 'Proved the periodic table is ordered by nuclear charge (Z), not atomic weight.'
      },
      {
        year: 1920,
        scientist: 'Ernest Rutherford',
        discovery: 'Discovery of the Proton & Prediction of Neutron',
        significance: 'Transmuted nitrogen into oxygen, confirming hydrogen nucleus is a fundamental particle.'
      },
      {
        year: 1932,
        scientist: 'James Chadwick',
        discovery: 'Discovery of the Neutron',
        significance: 'Completed the nuclear particle triad with uncharged mass particle.'
      }
    ]
  },
  {
    id: 'bohr',
    name: 'Niels Bohr',
    lifespan: '1885 – 1962',
    keyDiscovery: 'Quantized Electron Orbits & Hydrogen Spectral Line Series',
    keyIdea: 'Electrons reside in non-radiating discrete energy shells; radiation occurs only during quantum transitions.',
    theory: 'Electrons orbit the nucleus only in stationary, non-radiating concentric circular orbits with quantized orbital angular momentum L = n·ℏ (n=1,2,3...). Radiation is emitted or absorbed as single photons only when an electron jumps between orbits (ΔE = hν).',
    experiment: 'Quantitative derivation of the Rydberg constant from first principles and explanation of the Balmer, Lyman, and Paschen hydrogen emission line spectra.',
    limitations: [
      'Only worked accurately for 1-electron (hydrogenic) systems (H, He⁺, Li²⁺); failed for multi-electron atoms.',
      'Could not explain the fine spectral splitting, Zeeman effect (magnetic fields), or Stark effect.',
      'Arbitrarily postulated stationary non-radiating states without explaining why electrons do not radiate.'
    ],
    impact: 'Successfully bridged classical mechanics and early quantum theory, earning the 1922 Nobel Prize.',
    modelName: 'Quantized Shell Model',
    year: 1913,
    romanYear: 'MCMXIII',
    quote: 'An expert is a person who has made all the mistakes that can be made in a very narrow field.',
    archivalNotes: [
      'Copenhagen Trilogy (1913): "The dynamical equilibrium of the systems in the stationary states can be discussed by help of the ordinary mechanics, while the passing of the systems between different states cannot."',
      'Rydberg energy states: E_n = -13.6 eV / n².'
    ],
    formulaLatex: 'L = m v r = n \\frac{h}{2\\pi} = n \\hbar, \\quad \\Delta E = h\\nu = \\frac{hc}{\\lambda}',
    transitionalDiscoveries: [
      {
        year: 1900,
        scientist: 'Max Planck',
        discovery: 'Quantum Hypothesis (E = hν)',
        significance: 'Resolved the ultraviolet catastrophe by proposing energy is exchanged in discrete packets.'
      },
      {
        year: 1905,
        scientist: 'Albert Einstein',
        discovery: 'Photoelectric Effect & Light Quanta (Photons)',
        significance: 'Proved electromagnetic radiation has quantized particle-like momentum.'
      },
      {
        year: 1916,
        scientist: 'Arnold Sommerfeld',
        discovery: 'Elliptical Orbits & Relativistic Corrections',
        significance: 'Introduced azimuthal (l) and magnetic (m) quantum numbers.'
      },
      {
        year: 1925,
        scientist: 'Wolfgang Pauli',
        discovery: 'Pauli Exclusion Principle',
        significance: 'No two electrons in an atom can occupy identical sets of four quantum numbers.'
      }
    ]
  },
  {
    id: 'de-broglie',
    name: 'Louis de Broglie',
    lifespan: '1892 – 1987',
    keyDiscovery: 'Wave-Particle Duality of Matter & Standing Electron Waves',
    keyIdea: 'All matter exhibits wave characteristics with wavelength inversely proportional to momentum.',
    theory: 'Matter is not purely corpuscular; every moving particle of mass m and velocity v possesses an associated matter wave of wavelength λ = h/p. Bohr\'s stable orbits correspond to constructive circular standing waves with an integer number of wavelengths fitting the circumference (2πr = nλ).',
    experiment: 'Electron diffraction experiments through nickel crystal by Clinton Davisson and Lester Germer (1927), and through thin gold films by George Thomson.',
    limitations: [
      'Did not provide a complete mathematical wave equation to calculate 3D probabilities or wave function dynamics in potential fields.',
      'Could not predict transition probabilities or spectral line intensities.'
    ],
    impact: 'Unified the dual nature of light and matter, establishing the conceptual cornerstone of modern quantum mechanics.',
    modelName: 'Matter Wave Model',
    year: 1924,
    romanYear: 'MCMXXIV',
    quote: 'Matter is made of waves as much as of particles.',
    archivalNotes: [
      'Sorbonne PhD Thesis (1924): "A fundamental connection between the ideas of wave and particle is found in the relation λ = h / p."',
      'Standing wave condition: 2πr = nλ explains Bohr\'s quantization postulate naturally.'
    ],
    formulaLatex: '\\lambda = \\frac{h}{p} = \\frac{h}{mv}, \\quad 2\\pi r = n\\lambda',
    transitionalDiscoveries: [
      {
        year: 1923,
        scientist: 'Arthur Compton',
        discovery: 'Compton Scattering',
        significance: 'Proved X-ray photons collide with electrons like billiard balls, conserving relativistic momentum.'
      },
      {
        year: 1927,
        scientist: 'Davisson & Germer',
        discovery: 'Electron Diffraction by Nickel Crystals',
        significance: 'Directly verified de Broglie wavelength for material electron beams.'
      }
    ]
  },
  {
    id: 'heisenberg',
    name: 'Werner Heisenberg',
    lifespan: '1901 – 1976',
    keyDiscovery: 'Heisenberg Uncertainty Principle & Quantum Matrix Mechanics',
    keyIdea: 'Definite classical orbits cannot exist because position and momentum cannot be measured simultaneously.',
    theory: 'Physical observables are represented by non-commuting mathematical operators. The conjugate uncertainties in position (Δx) and momentum (Δp) satisfy Δx · Δp ≥ ℏ/2. Attempting to locate an electron collapses its momentum certainty, rendering the classical concept of an exact orbital trajectory meaningless.',
    experiment: 'Heisenberg Gamma-Ray Microscope Thought Experiment; mathematical formulation of matrix mechanics via non-commutative algebra.',
    limitations: [
      'Abstract matrix formulation lacked intuitive physical spatial imagery until Schrödinger wave mechanics provided the coordinate representation.',
      'Philosophically rejected determinism in favor of fundamental indeterminism (Copenhagen interpretation).'
    ],
    impact: 'Demolished the Newtonian deterministic universe; replaced classical orbits with quantum probability states.',
    modelName: 'Matrix Mechanics & Uncertainty',
    year: 1927,
    romanYear: 'MCMXXVII',
    quote: 'What we observe is not nature itself, but nature exposed to our method of questioning.',
    archivalNotes: [
      'Helgoland Notes (June 1925): "It was about three o\'clock at night when the final result of the calculation lay before me... I was deeply shaken."',
      'Commutation relation: [x, p] = iℏ.'
    ],
    formulaLatex: '\\Delta x \\cdot \\Delta p \\ge \\frac{\\hbar}{2}, \\quad \\Delta E \\cdot \\Delta t \\ge \\frac{\\hbar}{2}',
    transitionalDiscoveries: [
      {
        year: 1925,
        scientist: 'Max Born & Pascual Jordan',
        discovery: 'Matrix Formulation of Quantum Mechanics',
        significance: 'Formalized quantum transition kinematics using matrix algebra.'
      },
      {
        year: 1928,
        scientist: 'Paul Dirac',
        discovery: 'Relativistic Dirac Equation',
        significance: 'Unified quantum mechanics with special relativity, predicting electron spin and antimatter (positron).'
      }
    ]
  },
  {
    id: 'schrodinger',
    name: 'Erwin Schrödinger',
    lifespan: '1887 – 1961',
    keyDiscovery: 'Schrödinger Wave Equation & 3D Atomic Orbitals (|ψ|²)',
    keyIdea: 'Electrons exist as continuous 3D probabilistic wave functions; the transition from Orbit to Orbital.',
    theory: 'The state of an atomic electron is described by a spatial wave function ψ(r, θ, φ) governed by the time-independent Schrödinger wave equation Ĥψ = Eψ. The probability density of finding the electron in a volume element dV is given by Born\'s interpretation: P = |ψ|² dV. Energy eigenvalues yield discrete 3D spatial electron clouds known as orbitals (s, p, d, f).',
    experiment: 'Exact mathematical solution of the 3D differential wave equation for the hydrogen atom in spherical coordinates, yielding quantum numbers n, l, ml, and electron probability densities.',
    limitations: [
      'Original non-relativistic formulation did not account for relativistic mass increase or electron intrinsic spin (resolved by Dirac in 1928).',
      'Interpretation of the collapse of the wave function during measurement remains an active subject in quantum measurement foundations.'
    ],
    impact: 'Formed the definitive foundation of modern chemistry, molecular bonding, hybridization, spectroscopy, and material physics.',
    modelName: 'Quantum Mechanical Wave Model',
    year: 1926,
    romanYear: 'MCMXXVI',
    quote: 'The task is not so much to see what no one has yet seen; but to think what nobody has yet thought, about that which everybody sees.',
    archivalNotes: [
      'Annalen der Physik (1926): "Quantization as an Eigenvalue Problem... the wave equation determines the stationary states without any artificial quantum conditions."',
      'Transition: ORBIT (1D path) ➔ ORBITAL (3D probability density manifold |ψ|²).'
    ],
    formulaLatex: '\\hat{H}\\psi = E\\psi \\iff -\\frac{\\hbar^2}{2m}\\nabla^2\\psi + V(r)\\psi = E\\psi',
    transitionalDiscoveries: [
      {
        year: 1926,
        scientist: 'Max Born',
        discovery: 'Probabilistic Interpretation of Wave Function (|ψ|²)',
        significance: 'Clarified that wave functions represent probability amplitudes rather than smeared physical charge.'
      },
      {
        year: 1927,
        scientist: 'Heitler & London',
        discovery: 'Quantum Mechanical Valence Bond Theory',
        significance: 'Applied Schrödinger equation to explain the covalent chemical bond in H₂.'
      }
    ]
  }
];

