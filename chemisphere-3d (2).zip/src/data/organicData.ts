export interface NameReaction {
  id: string;
  name: string;
  category: 'Carbon-Carbon Bond' | 'Carbonyl & Carboxylic' | 'Reductions & Oxidations' | 'Aromatic & Halides' | 'Rearrangements & Nitrogen';
  reactants: string;
  reagents: string;
  conditions: string;
  equationLatex: string;
  intermediate: string;
  mechanismSteps: string[];
  applications: string;
}

export const NAME_REACTIONS_DB: NameReaction[] = [
  {
    id: 'aldol-condensation',
    name: 'Aldol Condensation',
    category: 'Carbonyl & Carboxylic',
    reactants: 'Two molecules of Aldehyde/Ketone containing α-hydrogens (e.g., 2 CH₃CHO)',
    reagents: 'Dilute Base (NaOH or Ba(OH)₂) followed by Heat (Δ)',
    conditions: 'Mild basic aqueous medium, reflux for dehydration',
    equationLatex: '2 \\text{CH}_3\\text{CHO} \\xrightarrow{\\text{dil. NaOH}} \\text{CH}_3\\text{CH(OH)CH}_2\\text{CHO} \\xrightarrow{\\Delta, -\\text{H}_2\\text{O}} \\text{CH}_3\\text{CH=CH-CHO}',
    intermediate: 'Resonance-stabilized Enolate carbanion intermediate',
    mechanismSteps: [
      'Step 1: Hydroxide abstracts an α-hydrogen to form a nucleophilic enolate anion.',
      'Step 2: Enolate nucleophilically attacks the electrophilic carbonyl carbon of a second acetaldehyde molecule, generating an alkoxide.',
      'Step 3: Proton transfer from water produces the β-hydroxyaldehyde (Aldol).',
      'Step 4: Heating induces E1cB elimination of water to yield an α,β-unsaturated aldehyde (Crotonaldehyde).'
    ],
    applications: 'Core industrial synthesis of synthetic perfumes, plasticizers, and conjugated vitamins (Retinol).'
  },
  {
    id: 'cannizzaro-reaction',
    name: 'Cannizzaro Reaction',
    category: 'Carbonyl & Carboxylic',
    reactants: 'Non-enolizable Aldehydes (no α-hydrogen, e.g., HCHO, Benzaldehyde)',
    reagents: 'Concentrated Base (50% NaOH or KOH)',
    conditions: 'Strong basic reflux',
    equationLatex: '2 \\text{C}_6\\text{H}_5\\text{CHO} + \\text{conc. KOH} \\longrightarrow \\text{C}_6\\text{H}_5\\text{CH}_2\\text{OH} + \\text{C}_6\\text{H}_5\\text{COOK}',
    intermediate: 'Dianionic tetrahedral hydrate intermediate & direct hydride (H⁻) transfer',
    mechanismSteps: [
      'Step 1: OH⁻ adds nucleophilically to the carbonyl carbon of benzaldehyde.',
      'Step 2: A second base deprotonates the adduct to form a reactive dianion.',
      'Step 3: Direct hydride (H⁻) transfer from dianion to a second benzaldehyde molecule.',
      'Step 4: Proton exchange produces Benzyl alcohol and Potassium benzoate.'
    ],
    applications: 'Disproportionation synthesis of pentaerythritol for explosives (PETN) and high-grade resins.'
  },
  {
    id: 'friedel-crafts-alkylation',
    name: 'Friedel-Crafts Alkylation',
    category: 'Aromatic & Halides',
    reactants: 'Benzene + Alkyl Halide (e.g., C₆H₆ + CH₃Cl)',
    reagents: 'Anhydrous Lewis Acid (AlCl₃ / FeCl₃)',
    conditions: 'Dry organic solvent, room temperature',
    equationLatex: '\\text{C}_6\\text{H}_6 + \\text{CH}_3\\text{Cl} \\xrightarrow{\\text{anh. AlCl}_3} \\text{C}_6\\text{H}_5\\text{CH}_3 + \\text{HCl}',
    intermediate: 'Arenium ion (Sigma complex / Wheland intermediate)',
    mechanismSteps: [
      'Step 1: AlCl₃ complexes with CH₃Cl to generate a polarized carbocation electrophile (CH₃⁺ · AlCl₄⁻).',
      'Step 2: Electrophilic attack on the π-system of benzene forms the non-aromatic resonance-stabilized Arenium ion.',
      'Step 3: AlCl₄⁻ abstracts the ring proton, regenerating aromaticity and releasing AlCl₃ and HCl.'
    ],
    applications: 'Industrial synthesis of Toluene, Ethylbenzene (polystyrene precursor), and Cumene (phenol synthesis).'
  },
  {
    id: 'friedel-crafts-acylation',
    name: 'Friedel-Crafts Acylation',
    category: 'Aromatic & Halides',
    reactants: 'Benzene + Acyl Chloride (e.g., C₆H₆ + CH₃COCl)',
    reagents: 'Anhydrous AlCl₃',
    conditions: 'Reflux in anhydrous CS₂ or nitrobenzene',
    equationLatex: '\\text{C}_6\\text{H}_6 + \\text{CH}_3\\text{COCl} \\xrightarrow{\\text{anh. AlCl}_3} \\text{C}_6\\text{H}_5\\text{COCH}_3 + \\text{HCl}',
    intermediate: 'Resonance-stabilized Acylium ion [R-C≡O⁺ ↔ R-C⁺=O]',
    mechanismSteps: [
      'Step 1: Lewis acid AlCl₃ removes Cl⁻ to form the linear, resonance-stabilized acylium ion.',
      'Step 2: Electrophilic attack on benzene produces the acyl-arenium intermediate.',
      'Step 3: Loss of proton restores aromaticity, yielding Acetophenone without polyacylation risk.'
    ],
    applications: 'Synthesis of aryl ketones, pharmaceuticals (Ibuprofen, Ketoprofen intermediates), and dyes.'
  },
  {
    id: 'wurtz-reaction',
    name: 'Wurtz Reaction',
    category: 'Carbon-Carbon Bond',
    reactants: 'Alkyl Halides (2 R-X)',
    reagents: 'Dry Metallic Sodium (Na) in Dry Ether',
    conditions: 'Moisture-free anhydrous ether solvent',
    equationLatex: '2 \\text{R-X} + 2\\text{Na} \\xrightarrow{\\text{dry ether}} \\text{R-R} + 2\\text{NaX}',
    intermediate: 'Alkyl radical (R·) and Alkylsodium (R⁻ Na⁺) organometallic species',
    mechanismSteps: [
      'Step 1: Single electron transfer from Na to R-X forms an alkyl radical (R·) and NaX.',
      'Step 2: Second electron transfer generates an organosodium intermediate (R⁻Na⁺).',
      'Step 3: Nucleophilic displacement (SN2) by R⁻ on a second R-X molecule yields symmetrical higher alkane R-R.'
    ],
    applications: 'Laboratory synthesis of symmetrical alkanes (Ethane, Butane, Hexane).'
  },
  {
    id: 'grignard-synthesis',
    name: 'Grignard Reagent Synthesis & Addition',
    category: 'Carbon-Carbon Bond',
    reactants: 'Alkyl/Aryl Halide (R-X) + Mg, followed by Carbonyl (R\'CHO / R\'₂CO)',
    reagents: 'Magnesium metal in Anhydrous Dry Ether / THF, then H₃O⁺ workup',
    conditions: 'Strictly moisture-free environment under inert gas',
    equationLatex: '\\text{R-X} + \\text{Mg} \\xrightarrow{\\text{ether}} \\text{R-MgX} \\xrightarrow{1.\\text{ R\'CHO} \\; 2.\\text{ H}_3\\text{O}^+} \\text{R-CH(OH)-R\'}',
    intermediate: 'Nucleophilic Carbanion equivalent (R^δ⁻ - Mg^δ⁺X) & Magnesium alkoxide',
    mechanismSteps: [
      'Step 1: Radical insertion of Mg metal into C-X bond forming Grignard reagent R-MgX.',
      'Step 2: Nucleophilic attack of carbanionic R⁻ on the electrophilic carbonyl carbon.',
      'Step 3: Acidic aqueous workup protonates magnesium alkoxide to yield 1°, 2°, or 3° alcohols.'
    ],
    applications: 'Universal carbon-carbon bond construction in complex natural product and API drug synthesis.'
  },
  {
    id: 'clemmensen-reduction',
    name: 'Clemmensen Reduction',
    category: 'Reductions & Oxidations',
    reactants: 'Aldehydes or Ketones (R-CO-R\')',
    reagents: 'Zinc Amalgam (Zn-Hg) + Concentrated HCl',
    conditions: 'Refluxing acidic conditions',
    equationLatex: '\\text{R-CO-R\'} + 4[\\text{H}] \\xrightarrow{\\text{Zn-Hg / conc. HCl}} \\text{R-CH}_2\\text{-R\'} + \\text{H}_2\\text{O}',
    intermediate: 'Chemisorbed zinc-carbenoid on metal surface',
    mechanismSteps: [
      'Step 1: Protonation of carbonyl oxygen by strong HCl.',
      'Step 2: Heterogeneous multi-electron transfer from Zn amalgam surface to carbon.',
      'Step 3: Sequential protonation and cleavage of C-O bond, fully converting >C=O to -CH₂-.'
    ],
    applications: 'Direct conversion of Friedel-Crafts acylation products into straight-chain alkylbenzenes.'
  },
  {
    id: 'wolff-kishner-reduction',
    name: 'Wolff-Kishner Reduction',
    category: 'Reductions & Oxidations',
    reactants: 'Aldehydes or Ketones (R-CO-R\')',
    reagents: 'Hydrazine (NH₂NH₂) + Strong Base (KOH) in Ethylene Glycol / DMSO',
    conditions: 'High temperature (180–200 °C) in high-boiling solvent',
    equationLatex: '\\text{R-CO-R\'} \\xrightarrow{\\text{NH}_2\\text{NH}_2} \\text{R-C(=NNH}_2\\text{)-R\'} \\xrightarrow{\\text{KOH, glycol, } \\Delta} \\text{R-CH}_2\\text{-R\'} + \\text{N}_2 \\uparrow',
    intermediate: 'Hydrazone intermediate and resonance-stabilized azo-carbanion',
    mechanismSteps: [
      'Step 1: Carbonyl reacts with hydrazine to form a hydrazone (C=N-NH₂).',
      'Step 2: Base abstracts proton from -NH₂, generating an allylic-type resonance carbanion.',
      'Step 3: Irreversible extrusion of stable N₂ gas drives carbanion formation, followed by solvent protonation.'
    ],
    applications: 'Reduction of acid-sensitive carbonyl compounds to hydrocarbons.'
  },
  {
    id: 'diels-alder-reaction',
    name: 'Diels-Alder [4+2] Cycloaddition',
    category: 'Carbon-Carbon Bond',
    reactants: 'Conjugated Diene (s-cis) + Dienophile (Alkene with electron-withdrawing group)',
    reagents: 'Thermal energy (Δ) or Lewis acid catalysis',
    conditions: 'Pericyclic concerted symmetry-allowed transition state',
    equationLatex: '\\text{Diene (4}\\pi) + \\text{Dienophile (2}\\pi) \\xrightarrow{\\Delta} \\text{Cyclohexene Derivative (}\\sigma+\\pi)',
    intermediate: 'Concerted aromatic 6-electron cyclic transition state (Suprafacial-Suprafacial)',
    mechanismSteps: [
      'Step 1: Alignment of s-cis diene HOMO with dienophile LUMO.',
      'Step 2: Simultaneous overlap and concerted formation of two new C-C σ-bonds at the expense of two π-bonds.',
      'Step 3: Stereospecific retention of dienophile geometry with endo-rule selectivity.'
    ],
    applications: 'Total synthesis of steroids (Cholesterol, Cortisone), prostaglandins, and polycyclic agrochemicals.'
  },
  {
    id: 'wittig-reaction',
    name: 'Wittig Reaction',
    category: 'Carbon-Carbon Bond',
    reactants: 'Aldehyde / Ketone + Phosphonium Ylide (Ph₃P=CR₂)',
    reagents: 'Triphenylphosphine (PPh₃) + Alkyl Halide + Strong Base (n-BuLi / NaH)',
    conditions: 'Aprotic dry solvent at 0 °C to room temperature',
    equationLatex: '\\text{R}_2\\text{C=O} + \\text{Ph}_3\\text{P=CHR\'} \\longrightarrow \\text{R}_2\\text{C=CHR\'} + \\text{Ph}_3\\text{P=O}',
    intermediate: 'Oxaphosphetane 4-membered cyclic intermediate',
    mechanismSteps: [
      'Step 1: Nucleophilic ylide carbon attacks electrophilic carbonyl carbon.',
      'Step 2: Direct cyclization forms the 4-membered oxaphosphetane ring.',
      'Step 3: Concerted retro-[2+2] cycloreversion driven by the immense P=O bond enthalpy (540 kJ/mol), forming the alkene.'
    ],
    applications: 'Regiospecific synthesis of alkenes with unambiguous double bond location (Vitamin A synthesis).'
  },
  {
    id: 'reimer-tiemann-reaction',
    name: 'Reimer-Tiemann Reaction',
    category: 'Aromatic & Halides',
    reactants: 'Phenol (C₆H₅OH) + Chloroform (CHCl₃)',
    reagents: 'Aqueous NaOH / KOH',
    conditions: 'Heating at 60–70 °C',
    equationLatex: '\\text{C}_6\\text{H}_5\\text{OH} + \\text{CHCl}_3 + 3\\text{NaOH} \\longrightarrow o\\text{-HOC}_6\\text{H}_4\\text{CHO (Salicylaldehyde)} + 3\\text{NaCl} + 2\\text{H}_2\\text{O}',
    intermediate: 'Electrophilic Dichlorocarbene (:CCl₂) reactive intermediate',
    mechanismSteps: [
      'Step 1: Base deprotonates CHCl₃, followed by loss of Cl⁻ to generate singlet dichlorocarbene (:CCl₂).',
      'Step 2: Electrophilic attack of :CCl₂ on phenoxide ortho-position.',
      'Step 3: Hydrolysis of the gem-dichloride intermediate yields Salicylaldehyde.'
    ],
    applications: 'Synthesis of Salicylaldehyde for flavorings (vanillin precursor) and aspirin research.'
  },
  {
    id: 'kolbe-electrolysis-synthesis',
    name: 'Kolbe Reaction (Schmitt Synthesis)',
    category: 'Aromatic & Halides',
    reactants: 'Phenol (Sodium Phenoxide) + Carbon Dioxide (CO₂)',
    reagents: 'CO₂ under pressure (4–7 atm), 125–140 °C, followed by H⁺ workup',
    conditions: 'Dry sodium phenoxide heated with compressed CO₂',
    equationLatex: '\\text{C}_6\\text{H}_5\\text{ONa} + \\text{CO}_2 \\xrightarrow{125^\\circ\\text{C}, 5\\text{ atm}} o\\text{-HOC}_6\\text{H}_4\\text{COONa} \\xrightarrow{\\text{H}^+} o\\text{-HOC}_6\\text{H}_4\\text{COOH (Salicylic Acid)}',
    intermediate: 'Chelated sodium salicylate coordination complex',
    mechanismSteps: [
      'Step 1: Nucleophilic phenoxide ring attacks electrophilic carbon dioxide.',
      'Step 2: Chelation of Na⁺ with ortho-oxygen stabilizes ortho-attack.',
      'Step 3: Acidification yields Salicylic Acid.'
    ],
    applications: 'Commercial production of Salicylic Acid, the direct precursor to Acetylsalicylic Acid (Aspirin).'
  },
  {
    id: 'hofmann-bromamide',
    name: 'Hofmann Bromamide Degradation',
    category: 'Rearrangements & Nitrogen',
    reactants: 'Primary Amide (R-CONH₂)',
    reagents: 'Bromine (Br₂) + Aqueous or Alcoholic KOH',
    conditions: 'Heating at 70 °C',
    equationLatex: '\\text{R-CONH}_2 + \\text{Br}_2 + 4\\text{KOH} \\longrightarrow \\text{R-NH}_2 + \\text{K}_2\\text{CO}_3 + 2\\text{KBr} + 2\\text{H}_2\\text{O}',
    intermediate: 'N-bromoamide, acylnitrene, and Alkyl isocyanate (R-N=C=O)',
    mechanismSteps: [
      'Step 1: Deprotonation and bromination of amide nitrogen forming N-bromoamide.',
      'Step 2: Base abstracts second proton triggering 1,2-alkyl migration with loss of Br⁻ to form Isocyanate (R-N=C=O).',
      'Step 3: Nucleophilic addition of water to isocyanate followed by decarboxylation yields 1° amine with one fewer carbon.'
    ],
    applications: 'Step-down degradation of carbon chains in organic synthesis and aniline production.'
  },
  {
    id: 'sandmeyer-reaction',
    name: 'Sandmeyer Reaction',
    category: 'Aromatic & Halides',
    reactants: 'Benzene Diazonium Chloride (C₆H₅N₂⁺ Cl⁻)',
    reagents: 'Copper(I) Salts: CuCl / HCl, CuBr / HBr, or CuCN / KCN',
    conditions: '0–5 °C preparation of diazonium, warm with Cu(I) salt',
    equationLatex: '\\text{C}_6\\text{H}_5\\text{N}_2^+\\text{Cl}^- \\xrightarrow{\\text{CuX / HX}} \\text{C}_6\\text{H}_5\\text{X} + \\text{N}_2 \\uparrow \\quad (\\text{X} = \\text{Cl, Br, CN})',
    intermediate: 'Aryl radical (C₆H₅·) generated via single electron transfer from Cu(I)',
    mechanismSteps: [
      'Step 1: Single electron transfer from Cu(I) to diazonium cation releases N₂ gas and generates an aryl radical.',
      'Step 2: Transfer of halide/cyanide from Cu(II) complex to the aryl radical regenerates Cu(I) catalyst.',
      'Step 3: Yields Aryl chloride, bromide, or benzonitrile.'
    ],
    applications: 'Introduction of specific halogen or cyano substituents onto aromatic rings with high positional control.'
  }
];

export interface OrganicFundamentalItem {
  id: string;
  name: string;
  category: 'Hybridization' | 'Functional Groups' | 'Electronic Effects' | 'Aromaticity';
  concept: string;
  details: string;
  formula: string;
  examples: string[];
  keyTakeaway: string;
}

export const ORGANIC_FUNDAMENTALS: OrganicFundamentalItem[] = [
  {
    id: 'sp3-hybridization',
    name: 'sp³ Hybridization (Tetrahedral)',
    category: 'Hybridization',
    concept: 'Mixing of one 2s and three 2p orbitals to form 4 equivalent degenerate sp³ hybrid orbitals.',
    details: '25% s-character, 75% p-character. Spatial orientation points to corners of regular tetrahedron with 109.5° bond angles. Forms 4 strong localized σ-bonds.',
    formula: '\\text{Orbitals: } 4 \\times sp^3, \\quad \\theta = 109.5^\\circ, \\quad \\text{Geometry: Tetrahedral}',
    examples: ['Methane (CH₄)', 'Ethane (C₂H₆)', 'Diamond Carbon', 'Methanol (CH₃OH)'],
    keyTakeaway: 'Maximizes bond angle to minimize electron-pair repulsion; free rotation around single σ-bonds.'
  },
  {
    id: 'sp2-hybridization',
    name: 'sp² Hybridization (Trigonal Planar)',
    category: 'Hybridization',
    concept: 'Mixing of one 2s and two 2p orbitals to form 3 planar sp² hybrid orbitals and 1 unhybridized p-orbital.',
    details: '33.3% s-character. 120° bond angles in coplanar arrangement. The unhybridized 2p_z orbital overlaps sideways to form a π-bond, restricting rotation.',
    formula: '\\text{Orbitals: } 3 \\times sp^2 + 1 \\times p_z, \\quad \\theta = 120^\\circ, \\quad \\text{Geometry: Trigonal Planar}',
    examples: ['Ethene (CH₂=CH₂)', 'Benzene (C₆H₆)', 'Carbonyl group (>C=O)', 'Graphene'],
    keyTakeaway: 'Contains 1 σ-bond and 1 π-bond; rigid planar geometry enables cis-trans geometric isomerism.'
  },
  {
    id: 'sp-hybridization',
    name: 'sp Hybridization (Linear)',
    category: 'Hybridization',
    concept: 'Mixing of one 2s and one 2p orbital to form 2 collinear sp hybrid orbitals and 2 mutually perpendicular unhybridized p-orbitals.',
    details: '50% s-character. 180° bond angle. High electronegativity due to high s-character, explaining terminal alkyne acidity (pKa ~ 25).',
    formula: '\\text{Orbitals: } 2 \\times sp + 2 \\times p, \\quad \\theta = 180^\\circ, \\quad \\text{Geometry: Linear}',
    examples: ['Ethyne (CH≡CH)', 'Carbon Dioxide (O=C=O)', 'Hydrogen Cyanide (H-C≡N)', 'Allene central carbon'],
    keyTakeaway: 'Forms 1 σ-bond and 2 orthogonal π-bonds; linear geometry and shortest C-C bond length (1.20 Å).'
  },
  {
    id: 'inductive-effect',
    name: 'Inductive Effect (±I Effect)',
    category: 'Electronic Effects',
    concept: 'Permanent polarization of σ-bonds transmitted along carbon chains due to electronegativity differences.',
    details: '-I (Electron-withdrawing): -NO₂ > -CN > -COOH > -F > -Cl > -Br > -I > -OH. +I (Electron-donating): -O⁻ > -COO⁻ > -C(CH₃)₃ > -CH(CH₃)₂ > -CH₂CH₃ > -CH₃.',
    formula: '\\sigma\\text{-electron displacement diminishes rapidly with distance (negligible beyond 3 carbons)}',
    examples: ['Trichloroacetic acid is 10,000x more acidic than acetic acid', 'Carbocation stability: 3° > 2° > 1° (due to +I hyperconjugation)'],
    keyTakeaway: '-I groups stabilize anions and conjugate bases (increasing acidity); +I groups stabilize carbocations.'
  },
  {
    id: 'resonance-mesomeric',
    name: 'Resonance / Mesomeric Effect (±R)',
    category: 'Electronic Effects',
    concept: 'Delocalization of π-electrons or lone pairs across conjugated p-orbital systems.',
    details: '+R groups (+M) donate electron density via lone pair conjugation (-OH, -NH₂, -OR, -halogen). -R groups (-M) withdraw electron density through π-systems (-NO₂, -CHO, -COOH, -CN).',
    formula: '\\Delta E_{\\text{resonance}} = E_{\\text{isolated}} - E_{\\text{delocalized}} \\quad (\\text{Stabilizing Energy})',
    examples: ['Phenol is ortho/para-directing due to +R', 'Nitrobenzene is meta-directing due to -R', 'Carboxylate ion equivalence'],
    keyTakeaway: 'Resonance effects are stronger than inductive effects (except for halogens where -I > +R for reactivity).'
  },
  {
    id: 'hyperconjugation',
    name: 'Hyperconjugation (No-Bond Resonance / Baker-Nathan)',
    category: 'Electronic Effects',
    concept: 'Delocalization of σ(C-H) electrons into an adjacent vacant p-orbital or π*-antibonding orbital.',
    details: 'Proportional to number of α-hydrogens. Explains the stability order of carbocations and substituted alkenes (Saytzeff rule).',
    formula: '\\sigma(\\text{C-H}) \\longrightarrow p_{\\text{empty}} \\quad \\text{or} \\quad \\sigma(\\text{C-H}) \\longrightarrow \\pi^*',
    examples: ['tert-Butyl carbocation (9 α-H) is much more stable than ethyl (3 α-H)', 'Trans-2-butene is more stable than 1-butene'],
    keyTakeaway: 'Permanent electronic stabilization occurring through σ-p orbital overlap.'
  },
  {
    id: 'huckel-aromaticity',
    name: "Hückel's Rule & Aromaticity",
    category: 'Aromaticity',
    concept: 'A planar, fully cyclic, conjugated π-system containing (4n + 2) π-electrons exhibits extraordinary thermodynamic stability.',
    details: 'Criteria: 1. Cyclic, 2. Planar, 3. Complete conjugation (sp² hybridized atoms), 4. (4n + 2) π-electrons where n = 0, 1, 2, 3... Anti-aromatic: 4n π-electrons (unstable).',
    formula: 'N_{\\pi} = 4n + 2 \\quad (n = 0, 1, 2, 3...) \\implies 2, 6, 10, 14, 18 \\; \\pi\\text{ electrons}',
    examples: ['Benzene (6 π e⁻, n=1)', 'Cyclopentadienyl anion (6 π e⁻)', 'Tropylium cation (6 π e⁻)', 'Naphthalene (10 π e⁻, n=2)', 'Pyridine / Furan'],
    keyTakeaway: 'Aromatic compounds undergo electrophilic aromatic substitution rather than addition to preserve aromatic stabilization.'
  }
];

export interface OrganicMolecule3D {
  id: string;
  name: string;
  formula: string;
  iupacName: string;
  hybridization: string;
  geometry: string;
  molarMass: number;
  description: string;
  atoms: { symbol: string; x: number; y: number; z: number; color: string; radius: number }[];
  bonds: { source: number; target: number; order: 1 | 2 | 3 }[];
}

export const ORGANIC_MOLECULES_3D: OrganicMolecule3D[] = [
  {
    id: 'methane',
    name: 'Methane',
    formula: 'CH₄',
    iupacName: 'Methane',
    hybridization: 'sp³',
    geometry: 'Tetrahedral (109.5°)',
    molarMass: 16.04,
    description: 'The simplest alkane and primary component of natural gas. Symmetrical non-polar molecule with four identical C-H σ-bonds.',
    atoms: [
      { symbol: 'C', x: 0, y: 0, z: 0, color: '#334155', radius: 0.38 },
      { symbol: 'H', x: 0.65, y: 0.65, z: 0.65, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: -0.65, y: -0.65, z: 0.65, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: -0.65, y: 0.65, z: -0.65, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: 0.65, y: -0.65, z: -0.65, color: '#f8fafc', radius: 0.22 }
    ],
    bonds: [
      { source: 0, target: 1, order: 1 },
      { source: 0, target: 2, order: 1 },
      { source: 0, target: 3, order: 1 },
      { source: 0, target: 4, order: 1 }
    ]
  },
  {
    id: 'ethene',
    name: 'Ethene (Ethylene)',
    formula: 'C₂H₄',
    iupacName: 'Ethene',
    hybridization: 'sp²',
    geometry: 'Trigonal Planar (120°)',
    molarMass: 28.05,
    description: 'The simplest alkene containing a C=C double bond (1 σ and 1 π). Essential monomer for polyethylene and natural plant ripening hormone.',
    atoms: [
      { symbol: 'C', x: -0.67, y: 0, z: 0, color: '#334155', radius: 0.38 },
      { symbol: 'C', x: 0.67, y: 0, z: 0, color: '#334155', radius: 0.38 },
      { symbol: 'H', x: -1.25, y: 0.92, z: 0, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: -1.25, y: -0.92, z: 0, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: 1.25, y: 0.92, z: 0, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: 1.25, y: -0.92, z: 0, color: '#f8fafc', radius: 0.22 }
    ],
    bonds: [
      { source: 0, target: 1, order: 2 },
      { source: 0, target: 2, order: 1 },
      { source: 0, target: 3, order: 1 },
      { source: 1, target: 4, order: 1 },
      { source: 1, target: 5, order: 1 }
    ]
  },
  {
    id: 'ethyne',
    name: 'Ethyne (Acetylene)',
    formula: 'C₂H₂',
    iupacName: 'Ethyne',
    hybridization: 'sp',
    geometry: 'Linear (180°)',
    molarMass: 26.04,
    description: 'The simplest alkyne featuring a C≡C triple bond (1 σ and 2 π). Used in oxyacetylene welding torches due to its 3,300 °C combustion flame.',
    atoms: [
      { symbol: 'C', x: -0.6, y: 0, z: 0, color: '#334155', radius: 0.38 },
      { symbol: 'C', x: 0.6, y: 0, z: 0, color: '#334155', radius: 0.38 },
      { symbol: 'H', x: -1.65, y: 0, z: 0, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: 1.65, y: 0, z: 0, color: '#f8fafc', radius: 0.22 }
    ],
    bonds: [
      { source: 0, target: 1, order: 3 },
      { source: 0, target: 2, order: 1 },
      { source: 1, target: 3, order: 1 }
    ]
  },
  {
    id: 'benzene',
    name: 'Benzene',
    formula: 'C₆H₆',
    iupacName: 'Benzene',
    hybridization: 'sp²',
    geometry: 'Planar Hexagonal (120°)',
    molarMass: 78.11,
    description: 'The archetype aromatic hydrocarbon. Six delocalized π-electrons distributed over a completely planar symmetric ring (1.39 Å C-C bond length).',
    atoms: [
      { symbol: 'C', x: 0, y: 1.4, z: 0, color: '#334155', radius: 0.38 },
      { symbol: 'C', x: 1.21, y: 0.7, z: 0, color: '#334155', radius: 0.38 },
      { symbol: 'C', x: 1.21, y: -0.7, z: 0, color: '#334155', radius: 0.38 },
      { symbol: 'C', x: 0, y: -1.4, z: 0, color: '#334155', radius: 0.38 },
      { symbol: 'C', x: -1.21, y: -0.7, z: 0, color: '#334155', radius: 0.38 },
      { symbol: 'C', x: -1.21, y: 0.7, z: 0, color: '#334155', radius: 0.38 },
      { symbol: 'H', x: 0, y: 2.45, z: 0, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: 2.12, y: 1.22, z: 0, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: 2.12, y: -1.22, z: 0, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: 0, y: -2.45, z: 0, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: -2.12, y: -1.22, z: 0, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: -2.12, y: 1.22, z: 0, color: '#f8fafc', radius: 0.22 }
    ],
    bonds: [
      { source: 0, target: 1, order: 2 },
      { source: 1, target: 2, order: 1 },
      { source: 2, target: 3, order: 2 },
      { source: 3, target: 4, order: 1 },
      { source: 4, target: 5, order: 2 },
      { source: 5, target: 0, order: 1 },
      { source: 0, target: 6, order: 1 },
      { source: 1, target: 7, order: 1 },
      { source: 2, target: 8, order: 1 },
      { source: 3, target: 9, order: 1 },
      { source: 4, target: 10, order: 1 },
      { source: 5, target: 11, order: 1 }
    ]
  },
  {
    id: 'ethanol',
    name: 'Ethanol (Ethyl Alcohol)',
    formula: 'C₂H₅OH',
    iupacName: 'Ethanol',
    hybridization: 'sp³',
    geometry: 'Tetrahedral around C, Bent around O',
    molarMass: 46.07,
    description: 'Primary alcohol with strong intermolecular hydrogen bonding, giving it a high boiling point (78.37 °C) and full miscibility with water.',
    atoms: [
      { symbol: 'C', x: -1.1, y: -0.2, z: 0, color: '#334155', radius: 0.38 },
      { symbol: 'C', x: 0.1, y: 0.6, z: 0, color: '#334155', radius: 0.38 },
      { symbol: 'O', x: 1.25, y: -0.2, z: 0, color: '#ef4444', radius: 0.35 },
      { symbol: 'H', x: 2.05, y: 0.3, z: 0, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: -1.1, y: -0.85, z: 0.9, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: -1.1, y: -0.85, z: -0.9, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: -1.95, y: 0.45, z: 0, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: 0.1, y: 1.25, z: 0.9, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: 0.1, y: 1.25, z: -0.9, color: '#f8fafc', radius: 0.22 }
    ],
    bonds: [
      { source: 0, target: 1, order: 1 },
      { source: 1, target: 2, order: 1 },
      { source: 2, target: 3, order: 1 },
      { source: 0, target: 4, order: 1 },
      { source: 0, target: 5, order: 1 },
      { source: 0, target: 6, order: 1 },
      { source: 1, target: 7, order: 1 },
      { source: 1, target: 8, order: 1 }
    ]
  },
  {
    id: 'acetone',
    name: 'Acetone (Propanone)',
    formula: 'CH₃COCH₃',
    iupacName: 'Propan-2-one',
    hybridization: 'sp² (Carbonyl C), sp³ (Methyl C)',
    geometry: 'Trigonal Planar at C=O (120°)',
    molarMass: 58.08,
    description: 'The simplest ketone with a strongly polar carbonyl dipole (2.88 D). Universal polar aprotic laboratory and industrial solvent.',
    atoms: [
      { symbol: 'C', x: 0, y: 0.2, z: 0, color: '#334155', radius: 0.38 },
      { symbol: 'O', x: 0, y: 1.42, z: 0, color: '#ef4444', radius: 0.35 },
      { symbol: 'C', x: -1.25, y: -0.65, z: 0, color: '#334155', radius: 0.38 },
      { symbol: 'C', x: 1.25, y: -0.65, z: 0, color: '#334155', radius: 0.38 },
      { symbol: 'H', x: -1.3, y: -1.3, z: 0.88, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: -1.3, y: -1.3, z: -0.88, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: -2.1, y: -0.05, z: 0, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: 1.3, y: -1.3, z: 0.88, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: 1.3, y: -1.3, z: -0.88, color: '#f8fafc', radius: 0.22 },
      { symbol: 'H', x: 2.1, y: -0.05, z: 0, color: '#f8fafc', radius: 0.22 }
    ],
    bonds: [
      { source: 0, target: 1, order: 2 },
      { source: 0, target: 2, order: 1 },
      { source: 0, target: 3, order: 1 },
      { source: 2, target: 4, order: 1 },
      { source: 2, target: 5, order: 1 },
      { source: 2, target: 6, order: 1 },
      { source: 3, target: 7, order: 1 },
      { source: 3, target: 8, order: 1 },
      { source: 3, target: 9, order: 1 }
    ]
  }
];
