import { NavigationTab } from '../types';

export interface MapRegion {
  id: string;
  name: string;
  discipline: string;
  subtitle: string;
  description: string;
  lore: string;
  color: string;
  textColor: string;
  borderColor: string;
  center: { x: number; y: number };
  bounds: { minX: number; minY: number; maxX: number; maxY: number };
  climate: string;
  ruler: string;
  path: string; // SVG path data for continent outline
  secondaryPaths?: string[]; // islands / sub-regions
  mountainRanges?: { name: string; path: string; x: number; y: number }[];
  rivers?: { name: string; path: string }[];
  forests?: { name: string; x: number; y: number; width: number; height: number }[];
}

export interface MapLandmark {
  id: string;
  name: string;
  subtitle: string;
  tab: NavigationTab;
  regionId: string;
  discipline: string;
  coordinates: { x: number; y: number };
  geographicLocation: string; // e.g. "Northern Atomian Plateau, 48°N 12°E"
  shortDesc: string;
  detailedLore: string;
  fieldNotes: string;
  iconType: 'citadel' | 'sanctuary' | 'foundry' | 'lighthouse' | 'cauldron' | 'harbor' | 'observatory' | 'archive' | 'crucible' | 'arena' | 'spire';
  difficulty: 'Apprentice' | 'Journeyman' | 'Master' | 'Grand Scholar';
  xpReward: number;
  tags: string[];
}

export interface GeographicFeature {
  id: string;
  name: string;
  category: 'ocean' | 'sea' | 'gulf' | 'strait' | 'mountains' | 'forest' | 'abyss' | 'archipelago' | 'peaks' | 'reef';
  coordinates: { x: number; y: number };
  rotation?: number;
  description: string;
  styleClass?: string;
}

export interface CartographicShip {
  id: string;
  name: string;
  type: string;
  captain: string;
  routeDesc: string;
  startPos: { x: number; y: number };
  endPos: { x: number; y: number };
  durationSec: number;
}

export interface CartographicAnnotation {
  id: string;
  text: string;
  coordinates: { x: number; y: number };
  style: 'latin' | 'warning' | 'alchemical' | 'compass';
}

export const MAP_DIMENSIONS = {
  width: 2400,
  height: 1500,
  viewBox: '0 0 2400 1500'
};

// 9 Fictional Continents & Realms of Chemistry
export const MAP_REGIONS: MapRegion[] = [
  {
    id: 'atomia',
    name: 'Atomia',
    discipline: 'Atomic & Quantum Chemistry',
    subtitle: 'The Quantum Cradle & Cloud of Probabilities',
    description: 'The primordial cradle where subatomic particles coalesce into quantum wavefunctions and discrete electron shells.',
    lore: 'Charted during the Great Quantum Expedition. Here, matter exists in harmonic superposition, and the Schrödinger mists perpetually shroud the orbital plateaus.',
    color: '#8b5cf6',
    textColor: '#c4b5fd',
    borderColor: '#7c3aed',
    center: { x: 450, y: 380 },
    bounds: { minX: 220, minY: 180, maxX: 700, maxY: 580 },
    climate: 'Luminescent & Quantum-fluctuating',
    ruler: 'High Sovereign Niels Bohr & Erwin Schrödinger',
    path: 'M 250 320 C 270 230, 380 200, 480 210 C 580 220, 680 260, 690 350 C 700 440, 640 520, 560 550 C 470 580, 390 570, 320 530 C 240 480, 230 400, 250 320 Z',
    secondaryPaths: [
      'M 680 230 C 720 220, 750 250, 740 280 C 730 300, 690 310, 670 280 Z', // Quantum Isle
      'M 200 480 C 230 460, 250 490, 240 520 C 220 540, 190 520, 200 480 Z' // Positron Shoal
    ],
    mountainRanges: [
      { name: 'Wavefunction Highlands', path: 'M 350 280 Q 420 260 500 290 Q 560 310 610 300', x: 480, y: 285 }
    ],
    rivers: [
      { name: 'Planck Current', path: 'M 480 240 Q 450 320 420 380 Q 400 440 340 500' }
    ]
  },
  {
    id: 'organica',
    name: 'Organica',
    discipline: 'Organic Chemistry',
    subtitle: 'The Sprawling Carbon Valleys & Reaction Highways',
    description: 'The vast, dense continent of carbon catenation, chiral valleys, aromatic rings, and multi-step synthetic pathways.',
    lore: 'An endless labyrinth of tetrahedral bonds and functional group forests. Explorers navigate the legendary Reaction Highway connecting Grignard Pass to the Carbonyl Delta.',
    color: '#10b981',
    textColor: '#6ee7b7',
    borderColor: '#059669',
    center: { x: 1250, y: 380 },
    bounds: { minX: 1000, minY: 180, maxX: 1550, maxY: 620 },
    climate: 'Humid, Carbon-rich & Highly Reactive',
    ruler: 'Grand Architect Friedrich August Kekulé & R.B. Woodward',
    path: 'M 1040 320 C 1080 220, 1200 190, 1340 210 C 1460 230, 1540 310, 1520 420 C 1500 520, 1420 600, 1280 610 C 1160 620, 1060 540, 1020 460 C 990 390, 1010 350, 1040 320 Z',
    secondaryPaths: [
      'M 1540 240 C 1580 230, 1610 260, 1590 290 C 1570 310, 1530 280, 1540 240 Z', // Benzene Isle
      'M 1520 520 C 1560 510, 1580 540, 1570 570 C 1540 590, 1500 560, 1520 520 Z' // Alkene Shoal
    ],
    mountainRanges: [
      { name: 'Chiral Peaks', path: 'M 1150 280 Q 1260 250 1380 290 Q 1440 320 1480 360', x: 1310, y: 280 }
    ],
    rivers: [
      { name: 'Nucleophile River', path: 'M 1300 240 Q 1260 340 1230 420 Q 1180 500 1120 560' }
    ]
  },
  {
    id: 'thermoria',
    name: 'Thermoria',
    discipline: 'Physical Chemistry & Thermodynamics',
    subtitle: 'The Thermal Expanse & Energetic Highlands',
    description: 'A land of intense energy gradients, entropy canyons, Maxwell-Boltzmann plains, and Arrhenius volcanic furnaces.',
    lore: 'Here, the Laws of Thermodynamics are etched into basalt cliffs. Spontaneous reactions cascade down Gibbs Free Energy cataracts into the Equilibrium Sea.',
    color: '#f97316',
    textColor: '#fdba74',
    borderColor: '#ea580c',
    center: { x: 1950, y: 400 },
    bounds: { minX: 1720, minY: 200, maxX: 2260, maxY: 640 },
    climate: 'Volcanic, High-Entropy & Thermally Dynamic',
    ruler: 'High Chancellor J. Willard Gibbs & Svante Arrhenius',
    path: 'M 1760 300 C 1800 210, 1940 190, 2080 220 C 2200 250, 2260 360, 2240 480 C 2210 580, 2100 640, 1960 630 C 1840 620, 1750 540, 1720 440 C 1700 370, 1730 330, 1760 300 Z',
    secondaryPaths: [
      'M 2260 260 C 2300 250, 2330 290, 2310 320 C 2280 340, 2250 300, 2260 260 Z' // Enthalpy Reef
    ],
    mountainRanges: [
      { name: 'Activation Barrier Ridge', path: 'M 1850 270 Q 1980 240 2100 290 Q 2180 340 2200 400', x: 2020, y: 280 }
    ],
    rivers: [
      { name: 'Gibbs Cascade', path: 'M 2020 250 Q 1980 350 1940 440 Q 1880 520 1820 580' }
    ]
  },
  {
    id: 'spectralis',
    name: 'Spectralis',
    discipline: 'Spectroscopy & Photonic Science',
    subtitle: 'The Luminous Coast & Electromagnetic Archipelago',
    description: 'A radiant coastal kingdom bathed in continuous electromagnetic frequencies, from deep radio wavelengths to sharp gamma rays.',
    lore: 'Home to the Five Great Towers of Spectral Analysis. Every molecule that washes ashore here reveals its unique spectroscopic fingerprint.',
    color: '#ec4899',
    textColor: '#f472b6',
    borderColor: '#db2777',
    center: { x: 420, y: 920 },
    bounds: { minX: 180, minY: 720, maxX: 680, maxY: 1180 },
    climate: 'Iridescent, Photonic & Continuously Emitting',
    ruler: 'Grand Inquisitor Joseph von Fraunhofer & Robert Bunsen',
    path: 'M 220 840 C 250 740, 360 710, 480 730 C 600 750, 680 830, 660 950 C 640 1060, 540 1160, 410 1160 C 290 1160, 200 1070, 180 970 C 170 900, 190 860, 220 840 Z',
    secondaryPaths: [
      'M 680 780 C 720 770, 750 810, 730 840 C 700 860, 670 820, 680 780 Z', // Photonic Atoll
      'M 160 1060 C 200 1050, 220 1090, 200 1120 C 170 1130, 140 1100, 160 1060 Z' // Wavelength Shoals
    ],
    mountainRanges: [
      { name: 'Rydberg Prism Range', path: 'M 300 800 Q 400 770 510 810 Q 580 850 610 900', x: 450, y: 810 }
    ],
    rivers: [
      { name: 'Fluorescence Estuary', path: 'M 460 760 Q 420 860 390 940 Q 340 1020 280 1080' }
    ]
  },
  {
    id: 'analytica',
    name: 'Analytica',
    discipline: 'Analytical Chemistry',
    subtitle: 'The Precision Lowlands & Chromatographic Deltas',
    description: 'A meticulously surveyed territory of titrations, chromatographic stationary phases, buffer marshlands, and micro-precision sensors.',
    lore: 'No impurity escapes the border guardians of Analytica. Known throughout the world for resolving the most tangled mixtures into pure fractions.',
    color: '#14b8a6',
    textColor: '#5eead4',
    borderColor: '#0d9488',
    center: { x: 1000, y: 950 },
    bounds: { minX: 780, minY: 750, maxX: 1250, maxY: 1200 },
    climate: 'Calm, Buffered & High-Precision',
    ruler: 'Arch-Cartographer Antoine Lavoisier & Mikhail Tsvet',
    path: 'M 820 860 C 860 770, 970 740, 1090 760 C 1200 780, 1260 870, 1240 980 C 1210 1090, 1110 1180, 980 1180 C 870 1180, 790 1090, 770 990 C 760 920, 790 880, 820 860 Z',
    secondaryPaths: [
      'M 1250 820 C 1280 810, 1310 840, 1290 870 C 1270 890, 1230 860, 1250 820 Z' // Column Archipelago
    ],
    mountainRanges: [
      { name: 'Equivalence Escarpment', path: 'M 900 820 Q 990 790 1090 830 Q 1160 870 1190 920', x: 1030, y: 830 }
    ],
    rivers: [
      { name: 'Mobile Phase Channel', path: 'M 1040 780 Q 1000 870 970 960 Q 920 1040 860 1110' }
    ]
  },
  {
    id: 'electrona',
    name: 'Electrona',
    discipline: 'Electrochemistry',
    subtitle: 'The Galvanic Peninsula & Voltaic Reefs',
    description: 'A coastline charged with dynamic electrochemical potentials, battery reservoirs, redox couples, and Nernstian currents.',
    lore: 'Electrons flow like glittering rivers between the Anode Promontory and the Cathode Citadel, powering the continental lighthouses.',
    color: '#eab308',
    textColor: '#fde047',
    borderColor: '#ca8a04',
    center: { x: 1540, y: 940 },
    bounds: { minX: 1320, minY: 750, maxX: 1780, maxY: 1200 },
    climate: 'Electrified, Energetic & Ion-Conductive',
    ruler: 'Lord Alessandro Volta & Michael Faraday',
    path: 'M 1360 860 C 1400 770, 1500 740, 1620 760 C 1730 780, 1790 870, 1770 980 C 1740 1090, 1640 1180, 1520 1180 C 1410 1180, 1330 1090, 1310 990 C 1300 920, 1330 880, 1360 860 Z',
    secondaryPaths: [
      'M 1780 810 C 1820 800, 1850 840, 1830 870 C 1800 890, 1770 850, 1780 810 Z' // Salt Bridge Island
    ],
    mountainRanges: [
      { name: 'Standard Potential Ridge', path: 'M 1440 820 Q 1530 790 1630 830 Q 1700 870 1730 920', x: 1570, y: 830 }
    ],
    rivers: [
      { name: 'Redox Stream', path: 'M 1580 780 Q 1540 870 1510 960 Q 1460 1040 1400 1110' }
    ]
  },
  {
    id: 'nucleara',
    name: 'Nucleara',
    discipline: 'Nuclear Chemistry',
    subtitle: 'The Cosmic Fusion Crags & Isotope Badlands',
    description: 'The ancient, dense territory of nuclear binding energies, stellar nucleosynthesis, alpha-beta decay canyons, and heavy actinide peaks.',
    lore: 'Where the strong nuclear force reigns supreme. Legendary explorers Marie Curie and Ernest Rutherford first surveyed its radioactive peaks.',
    color: '#ef4444',
    textColor: '#fca5a5',
    borderColor: '#dc2626',
    center: { x: 2050, y: 920 },
    bounds: { minX: 1840, minY: 730, maxX: 2320, maxY: 1180 },
    climate: 'Radioactive, Cosmic & High-Energy',
    ruler: 'High Sovereign Marie Curie & Ernest Rutherford',
    path: 'M 1880 840 C 1920 740, 2030 710, 2150 730 C 2260 750, 2330 840, 2310 960 C 2280 1070, 2180 1160, 2050 1160 C 1940 1160, 1860 1070, 1840 970 C 1830 900, 1850 860, 1880 840 Z',
    secondaryPaths: [
      'M 2310 770 C 2350 760, 2380 800, 2360 830 C 2330 850, 2300 810, 2310 770 Z' // Island of Stability
    ],
    mountainRanges: [
      { name: 'Binding Energy Cliffs', path: 'M 1960 800 Q 2050 770 2160 810 Q 2230 850 2260 900', x: 2090, y: 810 }
    ],
    rivers: [
      { name: 'Decay Chain River', path: 'M 2100 760 Q 2060 860 2030 940 Q 1980 1020 1920 1080' }
    ]
  },
  {
    id: 'bioterra',
    name: 'Bioterra',
    discipline: 'Molecular Structures & VSEPR',
    subtitle: 'The Living Macromolecular Forest & Geometric Arches',
    description: 'A vibrant biological realm where 3D geometry, steric repulsions, hydrogen bonding networks, and molecular architectures weave life.',
    lore: 'Home to the magnificent VSEPR Arches where electron domain repulsions create perfect polyhedra and helical biomolecules.',
    color: '#06b6d4',
    textColor: '#67e8f9',
    borderColor: '#0891b2',
    center: { x: 740, y: 640 },
    bounds: { minX: 560, minY: 480, maxX: 940, maxY: 820 },
    climate: 'Temperate, Hydrated & Geometrically Ordered',
    ruler: 'Grand Architect Linus Pauling & Dorothy Hodgkin',
    path: 'M 600 560 C 640 490, 740 470, 840 490 C 930 510, 970 590, 950 680 C 930 760, 850 820, 750 820 C 660 820, 590 760, 580 670 C 570 620, 580 580, 600 560 Z',
    mountainRanges: [
      { name: 'Hybridization Arches', path: 'M 660 540 Q 740 520 820 550 Q 880 580 900 620', x: 770, y: 550 }
    ]
  },
  {
    id: 'crystallia',
    name: 'Crystallia',
    discipline: 'Inorganic & Periodic Trends',
    subtitle: 'The 118-Element Monolith & Crystal Lattices',
    description: 'The monumental bedrock continent housing the 118 elemental citadels, periodic trends escarpments, and Bravais unit cells.',
    lore: 'Discovered and codified in 1869 by Dmitri Mendeleev. Its crystal cliffs rise like periodic terraces reflecting electronegativity and ionization gradients.',
    color: '#38bdf8',
    textColor: '#7dd3fc',
    borderColor: '#0284c7',
    center: { x: 1650, y: 640 },
    bounds: { minX: 1460, minY: 480, maxX: 1860, maxY: 820 },
    climate: 'Crystalline, Symmetrical & Periodically Ordered',
    ruler: 'High Patriarch Dmitri Mendeleev',
    path: 'M 1500 560 C 1540 490, 1640 470, 1740 490 C 1830 510, 1870 590, 1850 680 C 1830 760, 1750 820, 1650 820 C 1560 820, 1490 760, 1480 670 C 1470 620, 1480 580, 1500 560 Z',
    mountainRanges: [
      { name: 'Periodic Ridge', path: 'M 1560 540 Q 1640 520 1720 550 Q 1780 580 1800 620', x: 1670, y: 550 }
    ]
  }
];

// 30+ Landmark Locations connected to actual Chemisphere NavigationTabs!
export const MAP_LANDMARKS: MapLandmark[] = [
  // Atomia Landmarks
  {
    id: 'lm_orbital_atlas',
    name: 'Sanctuary of Quantum Orbitals',
    subtitle: 'Spherical Harmonics 1s, 2p, 3d, 4f',
    tab: 'orbital-atlas',
    regionId: 'atomia',
    discipline: 'Atomic & Quantum',
    coordinates: { x: 450, y: 340 },
    geographicLocation: 'Central Atomian Plateau, 52°N 14°W',
    shortDesc: '3D iso-surface visualizations of quantum electron probabilities and angular wavefunctions.',
    detailedLore: 'An ethereal sanctuary perched atop the Wavefunction Highlands where electron density clouds materialize as glowing 3D manifolds.',
    fieldNotes: 'Niels Bohr recorded: "The orbitals do not follow fixed paths, but manifest as harmonic probability distributions across 3D space."',
    iconType: 'sanctuary',
    difficulty: 'Journeyman',
    xpReward: 40,
    tags: ['Orbitals', 'Quantum', '3D Spherical Harmonics']
  },
  {
    id: 'lm_atomic_structure',
    name: 'Foundry of Atomic History',
    subtitle: 'From Dalton Spheres to Quantum Clouds',
    tab: 'atomic-structure',
    regionId: 'atomia',
    discipline: 'Atomic & Quantum',
    coordinates: { x: 340, y: 440 },
    geographicLocation: 'Valley of Historical Discoveries, 46°N 22°W',
    shortDesc: 'Interactive 3D historical laboratory models of Thomson, Rutherford, Bohr, and Schrödinger.',
    detailedLore: 'A monumental foundry dedicated to the great experimental revolutions that unraveled the inner architecture of the atom.',
    fieldNotes: 'Rutherford Alpha scattering apparatus stands preserved in the central rotunda with golden foil target.',
    iconType: 'foundry',
    difficulty: 'Apprentice',
    xpReward: 35,
    tags: ['History', 'Rutherford', 'Bohr Atom']
  },
  {
    id: 'lm_quantum_lab',
    name: 'Observatory of Quantum Mechanics',
    subtitle: 'Tunnelling, Box States & Photoelectric Effect',
    tab: 'quantum-lab',
    regionId: 'atomia',
    discipline: 'Atomic & Quantum',
    coordinates: { x: 570, y: 420 },
    geographicLocation: 'Quantum Cliff of Superposition, 49°N 08°W',
    shortDesc: 'Interactive quantum simulation suite for wave-particle duality, potential wells, and barrier penetration.',
    detailedLore: 'An advanced observatory overlooking the Planck Current where wavepackets tunnel through seemingly impenetrable potential barriers.',
    fieldNotes: 'Max Planck\'s constant h is carved in obsidian atop the observation tower.',
    iconType: 'observatory',
    difficulty: 'Master',
    xpReward: 50,
    tags: ['Quantum Wells', 'Tunnelling', 'Photoelectric']
  },

  // Organica Landmarks
  {
    id: 'lm_organic_chem',
    name: 'Great Grand Highway of Organic Synthesis',
    subtitle: 'Functional Groups & Connected Pathways',
    tab: 'organic-chem',
    regionId: 'organica',
    discipline: 'Organic Chemistry',
    coordinates: { x: 1250, y: 340 },
    geographicLocation: 'Central Organica Thoroughfare, 54°N 24°E',
    shortDesc: 'Master map of interconnected synthetic transformations, reagents, and functional group conversions.',
    detailedLore: 'The primary trade artery of Organica, bustling with reagents transforming alkanes into alcohols, carbonyls, and complex macrocycles.',
    fieldNotes: 'Grignard, Friedel-Crafts, and Wittig junctions intersect at the Grand Carbonyl Roundabout.',
    iconType: 'citadel',
    difficulty: 'Journeyman',
    xpReward: 45,
    tags: ['Organic Highway', 'Functional Groups', 'Reagents']
  },
  {
    id: 'lm_advanced_organic',
    name: 'Citadel of Retrosynthesis & Named Reactions',
    subtitle: 'Multi-Step Architecture & Total Synthesis',
    tab: 'advanced-organic',
    regionId: 'organica',
    discipline: 'Organic Chemistry',
    coordinates: { x: 1400, y: 440 },
    geographicLocation: 'Woodward Synthesis Promontory, 48°N 32°E',
    shortDesc: 'Deep retrosynthetic disconnection engine, pericyclic reactions, and noble synthetic strategies.',
    detailedLore: 'A towering fortress of strategic retrosynthetic logic where grand synthetic targets are broken down into elegant synthons.',
    fieldNotes: 'R.B. Woodward\'s notebook rules for orbital symmetry conservation are preserved in the Great Hall.',
    iconType: 'citadel',
    difficulty: 'Master',
    xpReward: 55,
    tags: ['Retrosynthesis', 'Named Reactions', 'Stereocontrol']
  },
  {
    id: 'lm_organic_mechanisms',
    name: 'Labyrinth of Curved Arrow Mechanisms',
    subtitle: 'SN1, SN2, E1, E2 & 3D Chirality',
    tab: 'organic-mechanisms',
    regionId: 'organica',
    discipline: 'Organic Chemistry',
    coordinates: { x: 1120, y: 460 },
    geographicLocation: 'Chiral Basin of Inversion, 47°N 16°E',
    shortDesc: 'Step-by-step electron flow with curved arrows, transition states, and Walden inversion dynamics.',
    detailedLore: 'A winding canyon where nucleophiles attack electrophilic carbons, causing clean backside inversions of stereochemistry.',
    fieldNotes: 'Inspect the pentacoordinate carbon transition state frozen in crystalline amber.',
    iconType: 'foundry',
    difficulty: 'Journeyman',
    xpReward: 40,
    tags: ['SN1/SN2', 'Curved Arrows', 'Chirality']
  },

  // Thermoria Landmarks
  {
    id: 'lm_thermo_kinetics',
    name: 'Volcano of Arrhenius Kinetics & Equilibrium',
    subtitle: 'ΔG = ΔH - TΔS, Calorimetry & Collisions',
    tab: 'thermo-kinetics',
    regionId: 'thermoria',
    discipline: 'Physical Chemistry',
    coordinates: { x: 1950, y: 350 },
    geographicLocation: 'Mount Gibbs, 53°N 62°E',
    shortDesc: 'Thermodynamic spontaneity, 2D particle collision kinetics, activation energy barriers, and equilibrium shifts.',
    detailedLore: 'A fiery volcanic peak where reactants collide with sufficient energy to surmount the activation barrier and descend into low-enthalpy products.',
    fieldNotes: 'Calorimeters measure heat flows while Le Chatelier regulators balance the equilibrium valves.',
    iconType: 'cauldron',
    difficulty: 'Journeyman',
    xpReward: 45,
    tags: ['Thermodynamics', 'Kinetics', 'Arrhenius', 'ΔG']
  },
  {
    id: 'lm_physical_chem',
    name: 'Plateau of Gas Laws & Maxwell-Boltzmann',
    subtitle: 'PV=nRT, van der Waals & Molecular Speeds',
    tab: 'physical-chem',
    regionId: 'thermoria',
    discipline: 'Physical Chemistry',
    coordinates: { x: 2120, y: 460 },
    geographicLocation: 'Maxwell-Boltzmann Highlands, 47°N 72°E',
    shortDesc: 'Ideal & real gas law solvers, intermolecular forces, and molecular velocity distribution curves.',
    detailedLore: 'An expansive open plateau where billions of simulated gas molecules collide elastically against containment barriers.',
    fieldNotes: 'Van der Waals corrections for real gas volume and intermolecular attraction are calibrated here.',
    iconType: 'observatory',
    difficulty: 'Apprentice',
    xpReward: 35,
    tags: ['Gas Laws', 'PV=nRT', 'Maxwell-Boltzmann']
  },

  // Spectralis Landmarks
  {
    id: 'lm_spectroscopy_suite',
    name: 'Grand Spire of Spectroscopy (5 Instruments)',
    subtitle: 'UV-Vis, FTIR, 1H/13C NMR, MS & XRD',
    tab: 'spectroscopy-suite',
    regionId: 'spectralis',
    discipline: 'Spectroscopy',
    coordinates: { x: 420, y: 880 },
    geographicLocation: 'Cape Fraunhofer, 22°S 15°W',
    shortDesc: 'Comprehensive analytical suite with 5 professional instruments for structural elucidation.',
    detailedLore: 'The legendary Five Spires of Spectralis. Each spire harnesses a different frequency of the electromagnetic spectrum to decode molecular identity.',
    fieldNotes: 'NMR superconducting magnet and FTIR interferometer operate continuously in the lower sanctum.',
    iconType: 'spire',
    difficulty: 'Master',
    xpReward: 55,
    tags: ['UV-Vis', 'FTIR', 'NMR', 'Mass Spec', 'XRD']
  },
  {
    id: 'lm_atomic_spectra',
    name: 'Beacon of Rydberg Spectra & Flame Tests',
    subtitle: 'Discrete Line Emission & Balmer Transitions',
    tab: 'atomic-spectra',
    regionId: 'spectralis',
    discipline: 'Spectroscopy',
    coordinates: { x: 300, y: 980 },
    geographicLocation: 'Rydberg Coast, 28°S 24°W',
    shortDesc: 'Interactive Bohr electron jumping, Bunsen burner flame emission tests, and continuous absorption lines.',
    detailedLore: 'A towering lighthouse whose flame shifts vivid crimson for Strontium, violet for Potassium, and green for Copper.',
    fieldNotes: 'Johannes Rydberg formula 1/λ = R(1/n1² - 1/n2²) is inscribed on the glass lens.',
    iconType: 'lighthouse',
    difficulty: 'Apprentice',
    xpReward: 35,
    tags: ['Flame Tests', 'Emission Lines', 'Rydberg']
  },
  {
    id: 'lm_waves_radiation',
    name: 'Lighthouse of Maxwell Waves & EM Spectrum',
    subtitle: '7-Band Spectrum & 3D E-B Harmonic Waves',
    tab: 'waves-radiation',
    regionId: 'spectralis',
    discipline: 'Waves & Radiation',
    coordinates: { x: 550, y: 960 },
    geographicLocation: 'Electromagnetic Promontory, 26°S 06°W',
    shortDesc: '3D orthogonal electric and magnetic fields, photon energies, and comprehensive 7-band radiation explorer.',
    detailedLore: 'Where James Clerk Maxwell\'s equations illuminate the relationship between oscillating electric and magnetic vectors.',
    fieldNotes: 'c = λν and E = hν dials adjust frequency from kilohertz radio to exahertz gamma rays.',
    iconType: 'lighthouse',
    difficulty: 'Journeyman',
    xpReward: 40,
    tags: ['EM Spectrum', '3D Waves', 'Photon Energy']
  },

  // Analytica Landmarks
  {
    id: 'lm_analytical_lab',
    name: 'Harbor of Analytical Titrations & HPLC',
    subtitle: 'pH Titration Curves, Buffers & Chromatography',
    tab: 'analytical-lab',
    regionId: 'analytica',
    discipline: 'Analytical Chemistry',
    coordinates: { x: 1000, y: 900 },
    geographicLocation: 'Equivalence Point Delta, 23°S 12°E',
    shortDesc: 'High-precision titration burettes, Henderson-Hasselbalch buffer calculations, and HPLC liquid chromatography.',
    detailedLore: 'A serene scientific port where analytical chemists determine exact concentrations down to parts-per-billion precision.',
    fieldNotes: 'Phenolphthalein and methyl orange indicators stand prepared in the titration dock.',
    iconType: 'harbor',
    difficulty: 'Journeyman',
    xpReward: 40,
    tags: ['Titrations', 'pH Curves', 'Buffers', 'HPLC']
  },
  {
    id: 'lm_analytical_materials',
    name: 'Terrace of TLC Separation & 3D Unit Cells',
    subtitle: 'Thin Layer Chromatography & Crystal Lattices',
    tab: 'analytical-materials',
    regionId: 'analytica',
    discipline: 'Analytical & Materials',
    coordinates: { x: 1140, y: 1020 },
    geographicLocation: 'Chromatography Basin, 30°S 20°E',
    shortDesc: 'Interactive TLC plate retention factor Rf calculator and 3D Bravais unit cell visualizer.',
    detailedLore: 'Terraced laboratories where capillary action carries solvent fronts up silica plates, resolving intricate natural extracts.',
    fieldNotes: 'Bravais lattices (FCC, BCC, HCP) are rendered in transparent quartz blocks.',
    iconType: 'foundry',
    difficulty: 'Journeyman',
    xpReward: 40,
    tags: ['TLC', 'Rf Values', 'Unit Cells']
  },

  // Electrona Landmarks
  {
    id: 'lm_electrochemistry_lab',
    name: 'Bastion of Galvanic Batteries & Nernst Cells',
    subtitle: 'Nernst Equation Solver & Li-Ion Battery CAD',
    tab: 'electrochemistry-lab',
    regionId: 'electrona',
    discipline: 'Electrochemistry',
    coordinates: { x: 1540, y: 900 },
    geographicLocation: 'Galvanic Peninsula, 24°S 45°E',
    shortDesc: 'Comprehensive electrochemical potential solver, standard reduction tables, and Li-ion intercalation simulations.',
    detailedLore: 'A high-voltage citadel where standard cell potentials are calculated and lithium ions migrate across porous polymer separators.',
    fieldNotes: 'E = E° - (RT/nF)ln(Q) regulates the battery output terminals.',
    iconType: 'citadel',
    difficulty: 'Journeyman',
    xpReward: 45,
    tags: ['Batteries', 'Nernst Equation', 'Redox Potentials']
  },
  {
    id: 'lm_electro_solutions',
    name: 'Garrison of Daniell Voltaic Cells',
    subtitle: 'Zinc-Copper Redox Couple & Salt Bridge',
    tab: 'electro-solutions',
    regionId: 'electrona',
    discipline: 'Electrochemistry',
    coordinates: { x: 1680, y: 1010 },
    geographicLocation: 'Salt Bridge Reef, 31°S 52°E',
    shortDesc: 'Live 3D Daniell cell simulation with electron flux, ion diffusion, and mass transfer at electrodes.',
    detailedLore: 'The historic garrison where Zn²⁺ and Cu²⁺ half-cells are joined by an agar-agar potassium chloride salt bridge.',
    fieldNotes: 'Zinc anode dissolves as copper cathode gains brilliant metallic mass.',
    iconType: 'foundry',
    difficulty: 'Apprentice',
    xpReward: 35,
    tags: ['Daniell Cell', 'Salt Bridge', 'Electrodes']
  },

  // Nucleara Landmarks
  {
    id: 'lm_nuclear_chemistry',
    name: 'Cauldron of Cosmic Nucleosynthesis',
    subtitle: 'Stellar Fusion & Isotope Decay Chains',
    tab: 'nuclear-chemistry',
    regionId: 'nucleara',
    discipline: 'Nuclear Chemistry',
    coordinates: { x: 2050, y: 880 },
    geographicLocation: 'Stellar Fusion Caldera, 22°S 75°E',
    shortDesc: 'Cosmic origin of heavy elements in supernovae, proton-proton chains, and CNO stellar fusion cycles.',
    detailedLore: 'A primordial caldera reflecting the heart of red supergiant stars where hydrogen and helium fuse into the heavy elements of the universe.',
    fieldNotes: 'Trace the radioactive decay series of Uranium-238 down to stable Lead-206.',
    iconType: 'cauldron',
    difficulty: 'Master',
    xpReward: 50,
    tags: ['Nucleosynthesis', 'Decay Chains', 'Stellar Fusion']
  },
  {
    id: 'lm_nuclear_lab',
    name: 'Chamber of Monte Carlo Nuclear Decay',
    subtitle: '10,000 Nuclei Stochastic Decay & Fission',
    tab: 'nuclear-lab',
    regionId: 'nucleara',
    discipline: 'Nuclear Chemistry',
    coordinates: { x: 2180, y: 990 },
    geographicLocation: 'Half-Life Canyon, 29°S 82°E',
    shortDesc: 'Stochastic Monte Carlo simulation of nuclear decay, half-life statistics, and neutron-induced fission.',
    detailedLore: 'A subterranean chamber where 10,000 quantum nuclei undergo Poisson stochastic decays under exact half-life laws.',
    fieldNotes: 'Observe alpha ejection, beta minus transformation, and gamma de-excitation in real-time.',
    iconType: 'observatory',
    difficulty: 'Master',
    xpReward: 50,
    tags: ['Monte Carlo', 'Half-Life', 'Fission']
  },

  // Bioterra Landmarks
  {
    id: 'lm_molecules_3d',
    name: 'Atelier of 3D Molecular CAD & Architectures',
    subtitle: 'Ball-and-Stick, CPK Spacefill & Bond Angles',
    tab: 'molecules-3d',
    regionId: 'bioterra',
    discipline: 'Molecular Structures',
    coordinates: { x: 740, y: 600 },
    geographicLocation: 'Molecular Grove, 10°N 02°W',
    shortDesc: 'High-performance 3D molecular viewer and builder with dipole moments, bond lengths, and CPK colors.',
    detailedLore: 'An artist\'s atelier where complex organic and biological molecules are sculpted in full 3D interactive glory.',
    fieldNotes: 'Measure dihedral torsion angles and electrostatic surface potentials of organic ligands.',
    iconType: 'foundry',
    difficulty: 'Apprentice',
    xpReward: 35,
    tags: ['3D Molecules', 'CPK', 'Bond Angles']
  },
  {
    id: 'lm_vsepr_lab',
    name: 'Cathedral of VSEPR Geometry & Hybridization',
    subtitle: 'AXnEm Steric Repulsion & Molecular Shapes',
    tab: 'vsepr-lab',
    regionId: 'bioterra',
    discipline: 'Molecular Bonding',
    coordinates: { x: 840, y: 700 },
    geographicLocation: 'VSEPR Colonnade, 04°N 05°E',
    shortDesc: 'Steric domain geometry calculator from Linear (AX2) to Octahedral (AX6) with lone pair repulsions.',
    detailedLore: 'A soaring cathedral with geometric arches demonstrating how electron pairs position themselves at maximal angles in 3D space.',
    fieldNotes: 'Lone pair-lone pair repulsion compresses bond angles from tetrahedral 109.5° to water\'s 104.5°.',
    iconType: 'sanctuary',
    difficulty: 'Journeyman',
    xpReward: 40,
    tags: ['VSEPR', 'Hybridization', 'Lone Pairs']
  },

  // Crystallia Landmarks
  {
    id: 'lm_periodic_table',
    name: 'Great Citadel of 118 Elements & Trends',
    subtitle: 'Interactive Mendeleev Matrix & Trends Grapher',
    tab: 'periodic-table',
    regionId: 'crystallia',
    discipline: 'Inorganic Chemistry',
    coordinates: { x: 1650, y: 600 },
    geographicLocation: 'Mendeleev Ridge, 11°N 50°E',
    shortDesc: 'Complete 118 element database with electron shells, continuous SVG periodic trend graphs, and orbital blocks.',
    detailedLore: 'The monumental heart of inorganic chemistry. Dmitri Mendeleev\'s periodic matrix carved into indestructible crystal columns.',
    fieldNotes: 'Electronegativity escalates towards Fluorine while atomic radius peaks at Francium.',
    iconType: 'citadel',
    difficulty: 'Apprentice',
    xpReward: 35,
    tags: ['Periodic Table', '118 Elements', 'Trends']
  },

  // Core Scientific & System Landmarks across the Map
  {
    id: 'lm_stoichiometry',
    name: 'Nexus of Matrix Stoichiometry & Balancer',
    subtitle: 'Gaussian Elimination Balancing & Yield Engine',
    tab: 'stoichiometry',
    regionId: 'analytica',
    discipline: 'Stoichiometry & Math',
    coordinates: { x: 880, y: 1040 },
    geographicLocation: 'Conservation of Mass Basin, 32°S 04°E',
    shortDesc: 'Linear algebra equation balancing, limiting reagent solver, and percentage yield calculators.',
    detailedLore: 'Where Antoine Lavoisier\'s Law of Conservation of Mass is enforced by rigorous matrix algebra.',
    fieldNotes: 'No atom is created or destroyed across any reaction equation.',
    iconType: 'foundry',
    difficulty: 'Apprentice',
    xpReward: 35,
    tags: ['Balancing', 'Moles', 'Limiting Reagent']
  },
  {
    id: 'lm_universal_calc',
    name: 'Station of Universal Computation & Solvers',
    subtitle: '24 Stepwise Solvers & Dataset Plotter',
    tab: 'universal-calc-graph',
    regionId: 'crystallia',
    discipline: 'Calculators & Tools',
    coordinates: { x: 1770, y: 720 },
    geographicLocation: 'Universal Calculation Peak, 02°N 58°E',
    shortDesc: 'Multi-parameter chemistry calculator suite with live coordinate graphing and stepwise derivations.',
    detailedLore: 'An computational outpost capable of solving gas laws, pH equations, kinetics, and dilution curves instantaneously.',
    fieldNotes: 'All physical chemical equations unified into a single analytical engine.',
    iconType: 'observatory',
    difficulty: 'Journeyman',
    xpReward: 40,
    tags: ['24 Solvers', 'Grapher', 'Formulas']
  },
  {
    id: 'lm_formula_vault',
    name: 'Vault of Fundamental Constants & Equations',
    subtitle: 'SI Constants, Greek Symbols & Core Laws',
    tab: 'formula-vault',
    regionId: 'crystallia',
    discipline: 'Archive & Tools',
    coordinates: { x: 1530, y: 720 },
    geographicLocation: 'Constant Vault Terrace, 03°N 42°E',
    shortDesc: 'Searchable repository of physical constants (R, k_B, h, N_A, F) and standard formulas.',
    detailedLore: 'The subterranean library safeguarding the invariant numbers that govern the physical universe.',
    fieldNotes: 'Avogadro\'s number 6.02214076 × 10²³ is engraved in pure gold above the entry gate.',
    iconType: 'archive',
    difficulty: 'Apprentice',
    xpReward: 30,
    tags: ['Constants', 'SI Units', 'Equations']
  },
  {
    id: 'lm_questions_playground',
    name: 'Grand Arena of Olympiad Challenges',
    subtitle: 'Competitive MCQs, Timed Trials & Speed Rounds',
    tab: 'questions-playground',
    regionId: 'organica',
    discipline: 'Practice & Arena',
    coordinates: { x: 1320, y: 220 },
    geographicLocation: 'Challenger\'s Colosseum, 62°N 28°E',
    shortDesc: 'Battleground of chemistry Olympiad questions, speed challenges, and conceptual problem trials.',
    detailedLore: 'The grand arena where aspiring chemists test their intellect against international Olympiad challenges.',
    fieldNotes: 'Champions earn mastery XP and rank advancement stamps in their Chemist Passport.',
    iconType: 'arena',
    difficulty: 'Master',
    xpReward: 50,
    tags: ['Olympiad', 'MCQ Arena', 'Speed Trials']
  },
  {
    id: 'lm_chemistry_lab',
    name: 'Alchemical Reaction Sandbox & Wet-Lab',
    subtitle: 'Interactive Beakers, pH Probes & Reactions',
    tab: 'chemistry-lab',
    regionId: 'bioterra',
    discipline: 'Virtual Laboratory',
    coordinates: { x: 670, y: 740 },
    geographicLocation: 'Crucible Cove, 01°S 01°W',
    shortDesc: 'Virtual chemical mixing laboratory with precipitation, gas evolution, indicators, and flame probes.',
    detailedLore: 'A freeform reaction harbor where students mix acids, bases, salts, and indicators with zero hazard.',
    fieldNotes: 'Combine Silver Nitrate with Sodium Chloride to witness milky AgCl precipitation.',
    iconType: 'crucible',
    difficulty: 'Apprentice',
    xpReward: 40,
    tags: ['Wet Lab', 'Precipitation', 'Beakers']
  },
  {
    id: 'lm_beauty_of_chem',
    name: 'Sanctuary of Chemical Beauty & Harmonics',
    subtitle: 'Cinematic Visualizer & Acoustic Synthesizer',
    tab: 'beauty-of-chemistry',
    regionId: 'atomia',
    discipline: 'Exhibition & Harmonics',
    coordinates: { x: 260, y: 260 },
    geographicLocation: 'Haven of Aesthetic Harmonics, 58°N 28°W',
    shortDesc: 'Aesthetic visual exhibition celebrating the artistic elegance of crystal growth, orbitals, and reactions.',
    detailedLore: 'A peaceful sanctuary where science and art merge in harmonic resonance and stunning visuals.',
    fieldNotes: 'Features real-time harmonic sine synthesis mapped to atomic orbitals.',
    iconType: 'sanctuary',
    difficulty: 'Apprentice',
    xpReward: 30,
    tags: ['Beauty', 'Harmonics', 'Artistic Chemistry']
  },
  {
    id: 'lm_archive',
    name: 'Great Library & Nobel Discovery Vault',
    subtitle: 'Historical Chronology, MSDS & Spectral Tables',
    tab: 'archive',
    regionId: 'analytica',
    discipline: 'Archive & Reference',
    coordinates: { x: 1180, y: 840 },
    geographicLocation: 'Alexandrian Archive of Chemistry, 18°S 24°E',
    shortDesc: 'Exhaustive reference library documenting landmark Nobel discoveries, GHS hazard codes, and IR tables.',
    detailedLore: 'The vast collective memory of human chemical progress, cataloged from alchemical roots to modern quantum computing.',
    fieldNotes: 'MSDS hazard safety ratings and spectral correlation charts are archived in the north wing.',
    iconType: 'archive',
    difficulty: 'Apprentice',
    xpReward: 30,
    tags: ['Nobel Timeline', 'Safety MSDS', 'IR Tables']
  },
  {
    id: 'lm_profile',
    name: 'Chemist User Passport Pavilion',
    subtitle: 'Exploration Meter, XP Scores & Badges',
    tab: 'profile',
    regionId: 'atomia',
    discipline: 'Passport & Identity',
    coordinates: { x: 380, y: 220 },
    geographicLocation: 'Explorer\'s Registry Harbor, 61°N 18°W',
    shortDesc: 'Personal scientific passport displaying mastery level, badges, streak days, and expedition notes.',
    detailedLore: 'Where every explorer registers their name, selects curriculum interests, and reviews their worldly progress.',
    fieldNotes: 'Passports are stamped automatically whenever a new laboratory module is surveyed.',
    iconType: 'citadel',
    difficulty: 'Apprentice',
    xpReward: 25,
    tags: ['Passport', 'XP Badges', 'Streaks']
  },
  {
    id: 'lm_ai_tutor',
    name: 'ChemoBot AI High Council Observatory',
    subtitle: 'Context-Aware Chemistry AI Copilot',
    tab: 'ai-tutor',
    regionId: 'organica',
    discipline: 'Chemistry AI',
    coordinates: { x: 1460, y: 280 },
    geographicLocation: 'Summit of Algorithmic Intelligence, 57°N 36°E',
    shortDesc: 'Deep AI reasoning engine for step-by-step chemical problem solving and mechanism derivations.',
    detailedLore: 'The pinnacle observatory where ChemoBot AI processes questions from every corner of the chemical world.',
    fieldNotes: 'Ready to assist with reaction balancing, orbital quantum numbers, or thermodynamics.',
    iconType: 'observatory',
    difficulty: 'Journeyman',
    xpReward: 35,
    tags: ['ChemoBot AI', 'Stepwise Reasoning', 'Copilot']
  }
];

// Geographical Oceans, Seas, Straits, and Ranges
export const GEOGRAPHIC_FEATURES: GeographicFeature[] = [
  // Oceans & Seas
  {
    id: 'ocean_reaction',
    name: 'REACTION OCEAN',
    category: 'ocean',
    coordinates: { x: 1200, y: 130 },
    rotation: 0,
    description: 'The vast, endless expanse of chemical equilibrium and kinetic currents across the northern hemisphere.'
  },
  {
    id: 'sea_equilibrium',
    name: 'EQUILIBRIUM SEA',
    category: 'sea',
    coordinates: { x: 1200, y: 720 },
    rotation: -4,
    description: 'A tranquil sea where the rate of the forward reaction perfectly balances the reverse reaction.'
  },
  {
    id: 'sea_entropy',
    name: 'ENTROPY ABYSS',
    category: 'abyss',
    coordinates: { x: 2180, y: 1300 },
    rotation: 6,
    description: 'A fathomless oceanic trench of maximum disorder (ΔS > 0) where Gibbs Free Energy reaches its minimum.'
  },
  {
    id: 'gulf_solvation',
    name: 'SOLVATION GULF',
    category: 'gulf',
    coordinates: { x: 680, y: 1040 },
    rotation: 8,
    description: 'A sheltered gulf where solvent dipoles surround and stabilize ionic solutes in aqueous solution.'
  },
  {
    id: 'strait_periodic',
    name: 'PERIODIC STRAIT',
    category: 'strait',
    coordinates: { x: 1480, y: 640 },
    rotation: 70,
    description: 'A narrow nautical channel separating the crystal lattices of Crystallia from the organic valleys.'
  },
  {
    id: 'reef_activation',
    name: 'ACTIVATION BARRIER REEF',
    category: 'reef',
    coordinates: { x: 1820, y: 520 },
    rotation: -25,
    description: 'Treacherous underwater coral reefs requiring significant kinetic energy to safely navigate.'
  },
  {
    id: 'coast_wave',
    name: 'WAVE COAST',
    category: 'sea',
    coordinates: { x: 220, y: 620 },
    rotation: 85,
    description: 'Rocky coastline where electromagnetic radiation continually beats in harmonic frequency waves.'
  },
  {
    id: 'archipelago_bonding',
    name: 'BONDING ARCHIPELAGO',
    category: 'archipelago',
    coordinates: { x: 880, y: 440 },
    rotation: -15,
    description: 'A cluster of lush volcanic islands joined by covalent electron-sharing bridges.'
  },
  {
    id: 'peaks_energy',
    name: 'CATALYSIS MOUNTAINS',
    category: 'mountains',
    coordinates: { x: 1310, y: 260 },
    rotation: 0,
    description: 'Majestic mountain range that lowers the activation energy of passing synthetic expeditions.'
  }
];

// Historical Cartographic Ships Sailing the Oceans
export const CARTOGRAPHIC_SHIPS: CartographicShip[] = [
  {
    id: 'ship_phlogiston',
    name: 'H.M.S. Phlogiston',
    type: 'Three-Masted Cartographic Frigate',
    captain: 'Antoine Lavoisier',
    routeDesc: 'Sailing the trade route from Atomia to the Organic Highway',
    startPos: { x: 620, y: 240 },
    endPos: { x: 1020, y: 220 },
    durationSec: 28
  },
  {
    id: 'ship_valence',
    name: 'S.S. Valence',
    type: 'Scientific Expedition Schooner',
    captain: 'Gilbert N. Lewis',
    routeDesc: 'Patrolling the Equilibrium Sea between Electrona and Analytica',
    startPos: { x: 1100, y: 740 },
    endPos: { x: 1420, y: 720 },
    durationSec: 34
  },
  {
    id: 'ship_argonaut',
    name: 'Argonaut of Gibbs',
    type: 'Thermodynamic Clipper',
    captain: 'J. Willard Gibbs',
    routeDesc: 'Surfing the entropy currents across the Eastern Oceans',
    startPos: { x: 1780, y: 240 },
    endPos: { x: 2180, y: 220 },
    durationSec: 30
  }
];

// Antique Latin & Alchemical Annotations for Explorer Flavor
export const CARTOGRAPHIC_ANNOTATIONS: CartographicAnnotation[] = [
  {
    id: 'ann_radicals',
    text: 'HIC SUNT RADICALIA LIBERA (Here be Free Radicals)',
    coordinates: { x: 1580, y: 180 },
    style: 'warning'
  },
  {
    id: 'ann_entropy',
    text: 'ΔS > 0 — IN EVUM TENDIT UNIVERSUM',
    coordinates: { x: 2100, y: 1220 },
    style: 'latin'
  },
  {
    id: 'ann_quantum',
    text: 'ψ(r, θ, φ) — QUOD EST SUPERIUS EST SICUT QUOD EST INFERIUS',
    coordinates: { x: 280, y: 150 },
    style: 'alchemical'
  },
  {
    id: 'ann_equil',
    text: 'MARE AEQUILIBRII — K_eq = [C]^c [D]^d / [A]^a [B]^b',
    coordinates: { x: 1180, y: 760 },
    style: 'latin'
  }
];
