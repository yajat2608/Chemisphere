/**
 * Re-export and delegate to the centralized UserPassportStore
 * for unified identity, progress, and event-driven cross-module synchronization.
 */
export * from './UserPassportStore';
