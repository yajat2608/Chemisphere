import { NavigationTab } from '../types';

const STORAGE_KEY = 'chemisphere_recent_labs_v1';

export interface RecentLabEntry {
  tab: NavigationTab;
  name: string;
  category: string;
  timestamp: number;
  iconName?: string;
}

export const LAB_METADATA_MAP: Record<NavigationTab, { name: string; category: string; desc: string }> = {
  'home': { name: 'Command Center', category: 'System', desc: 'Chemisphere 3D Central Operations' },
  'chemistry-map': { name: 'Interactive Chemistry World Map', category: 'Cartography & Atlas', desc: 'Historical Geographical Map of the World of Chemistry' },
  'tools': { name: 'Tools & Discover Area', category: 'Tools & Reference', desc: 'Purpose Cards, pH & Gas Solvers, Builders & Graphers' },
  'lab-directory': { name: 'Curriculum & Knowledge Map', category: 'Curriculum & Hub', desc: '14 Disciplines Chemistry Matrix' },
  'questions-playground': { name: 'Questions Playground', category: 'Interactive Tools', desc: 'Problem Solving, Olympiad Challenges & Speed Trials' },
  'chemistry-lab': { name: 'Virtual Reaction Sandbox', category: 'Virtual Laboratory', desc: 'Interactive Beaker Experiments & Chemical Mixing' },
  'archive': { name: 'Scientific Archive & Library', category: 'Archive & Reference', desc: 'Landmark Discoveries, MSDS Safety & Spectral Tables' },
  'profile': { name: 'User Profile & Exploration', category: 'Profile & Passport', desc: 'Chemist Progress, Exploration Meter & Badges' },
  'beauty-of-chemistry': { name: 'The Beauty of Chemistry', category: 'Exhibition', desc: 'Cinematic Exhibition & Acoustic Harmonics' },
  'periodic-table': { name: 'Periodic Table & Trends', category: 'Inorganic Chemistry', desc: '118 Elements & Continuous SVG Grapher' },
  'orbital-atlas': { name: '3D Quantum Orbital Atlas', category: 'Atomic & Quantum', desc: 'Spherical Harmonics 1s, 2p, 3d, 4f Iso-surfaces' },
  'molecules-3d': { name: '3D Molecular Simulator & CAD', category: 'Molecular & Bonding', desc: 'Ball-and-Stick, CPK & Bond Angle Analyzer' },
  'vsepr-lab': { name: 'VSEPR & Hybridization Lab', category: 'Molecular & Bonding', desc: 'Electron Domain Repulsion & AXnEm Geometry' },
  'atomic-spectra': { name: 'Atomic Spectra & Emission Lab', category: 'Spectroscopy', desc: 'Rydberg Bohr Transitions & Bunsen Flame Tests' },
  'waves-radiation': { name: 'Waves & Radiation Lab', category: 'Waves & Radiation', desc: 'Harmonics, 3D E-B Fields & 7-Band EM Spectrum' },
  'quantum-lab': { name: 'Quantum Mechanics Lab', category: 'Atomic & Quantum', desc: 'Particle-in-a-Box, Tunnelling & Photoelectric' },
  'spectroscopy-suite': { name: 'Spectroscopy Suite (5 Instruments)', category: 'Spectroscopy', desc: 'UV-Vis, FTIR, NMR, Mass Spectrometry & XRD' },
  'nuclear-chemistry': { name: 'Nuclear Reactions & Synthesis', category: 'Nuclear Chemistry', desc: 'Cosmic Nucleosynthesis & Decay Series' },
  'nuclear-lab': { name: 'Nuclear Chemistry & Decay Lab', category: 'Nuclear Chemistry', desc: 'Monte Carlo 10,000 Nuclei Decay & Fission' },
  'thermo-kinetics': { name: 'Thermodynamics & Kinetics Lab', category: 'Physical Chemistry', desc: 'Calorimetry, 2D Collisions, Arrhenius & Equilibrium' },
  'advanced-organic': { name: 'Advanced Organic Synthesis', category: 'Organic Chemistry', desc: 'Retrosynthesis & Multi-Step Transformations' },
  'organic-mechanisms': { name: 'Organic Mechanisms Lab', category: 'Organic Chemistry', desc: 'Curved Arrow Flow & 3D Stereochemistry' },
  'analytical-lab': { name: 'Analytical Chemistry & Environmental', category: 'Analytical Chemistry', desc: 'Titration, Buffers & HPLC Separation' },
  'analytical-materials': { name: 'Analytical Chromatography & Materials', category: 'Analytical & Materials', desc: 'TLC Separation, 3D Unit Cells & Green Chem' },
  'universal-calc-graph': { name: 'Universal Calculator & Grapher', category: 'Calculators & Tools', desc: '24 Stepwise Solvers & Multi-Dataset Plotter' },
  'electrochemistry-lab': { name: 'Electrochemistry & Battery Lab', category: 'Electrochemistry', desc: 'Nernst Equation & Li-Ion Batteries' },
  'electro-solutions': { name: 'Electrochemistry & Solutions Lab', category: 'Electrochemistry', desc: 'Daniell Voltaic Cells & Redox Kinetics' },
  'atomic-structure': { name: 'Atomic Structure History', category: 'Atomic & Quantum', desc: 'Rutherford Alpha Scattering & Bohr Jumping' },
  'stoichiometry': { name: 'Stoichiometry & Balancer Engine', category: 'Stoichiometry', desc: 'Matrix Balancing, Limiting Reagents & Yield' },
  'physical-chem': { name: 'Physical Chemistry & Gas Laws', category: 'Physical Chemistry', desc: 'PV=nRT, van der Waals & Maxwell-Boltzmann' },
  'organic-chem': { name: 'Organic Highway & Functional Groups', category: 'Organic Chemistry', desc: 'Interconnected Synthetic Pathways & IUPAC' },
  'formula-vault': { name: 'Formula Vault & Constants', category: 'Calculators & Tools', desc: 'Fundamental Physical Constants & Equations' },
  'practice': { name: 'Practice & Olympiad Quizzes', category: 'Practice', desc: 'Competitive Exams & Conceptual Mastery' },
  'ai-tutor': { name: 'ChemoBot AI Copilot', category: 'Chemistry AI', desc: 'Stepwise Derivations & Reasoning' },
  'creator': { name: 'Yajat Sarkar Creator Portfolio', category: 'Creator', desc: 'PM Shri KV Balaghat & Infinity Learn' }
};

export function logLabVisit(tab: NavigationTab) {
  if (typeof window === 'undefined') return;
  if (tab === 'home') return; // Don't log home itself

  const meta = LAB_METADATA_MAP[tab];
  if (!meta) return;

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    let history: RecentLabEntry[] = raw ? JSON.parse(raw) : [];

    // Remove existing entry for this tab to bring it to top
    history = history.filter((item) => item.tab !== tab);

    // Prepend new entry
    history.unshift({
      tab,
      name: meta.name,
      category: meta.category,
      timestamp: Date.now()
    });

    // Cap history at 12 items
    if (history.length > 12) {
      history = history.slice(0, 12);
    }

    localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
  } catch (err) {
    console.warn('Could not log lab visit:', err);
  }
}

export function getRecentLabs(): RecentLabEntry[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (err) {
    console.warn('Could not read lab visit history:', err);
    return [];
  }
}

export function clearRecentLabs() {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (err) {
    console.warn('Could not clear lab visit history:', err);
  }
}
