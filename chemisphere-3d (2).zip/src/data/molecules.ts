import { Molecule3DData } from '../types';

export const MOLECULES_DATA: Molecule3DData[] = [
  {
    id: 'h2o',
    name: 'Water',
    formula: 'H₂O',
    category: 'inorganic',
    description: 'The universal solvent. Bent geometry with 104.5° bond angle due to two lone pairs repelling O-H bonds.',
    molarMass: 18.015,
    dipoleMoment: '1.85 D (Strongly Polar)',
    geometry: 'Bent (V-shaped)',
    hybridization: 'sp³ (with 2 lone pairs)',
    atoms: [
      { id: 'O1', element: 'O', x: 0, y: 0, z: 0.117, color: '#ef4444', radius: 0.45 },
      { id: 'H1', element: 'H', x: 0, y: 0.757, z: -0.469, color: '#f8fafc', radius: 0.28 },
      { id: 'H2', element: 'H', x: 0, y: -0.757, z: -0.469, color: '#f8fafc', radius: 0.28 },
    ],
    bonds: [
      { source: 0, target: 1, order: 1 },
      { source: 0, target: 2, order: 1 }
    ]
  },
  {
    id: 'co2',
    name: 'Carbon Dioxide',
    formula: 'CO₂',
    category: 'gas',
    description: 'Linear molecule with no net dipole moment (dipoles cancel out). Major greenhouse gas and plant photosynthesis substrate.',
    molarMass: 44.01,
    dipoleMoment: '0.00 D (Non-polar)',
    geometry: 'Linear (180°)',
    hybridization: 'sp (Central Carbon)',
    atoms: [
      { id: 'C1', element: 'C', x: 0, y: 0, z: 0, color: '#64748b', radius: 0.42 },
      { id: 'O1', element: 'O', x: 0, y: 0, z: 1.16, color: '#ef4444', radius: 0.45 },
      { id: 'O2', element: 'O', x: 0, y: 0, z: -1.16, color: '#ef4444', radius: 0.45 }
    ],
    bonds: [
      { source: 0, target: 1, order: 2 },
      { source: 0, target: 2, order: 2 }
    ]
  },
  {
    id: 'nh3',
    name: 'Ammonia',
    formula: 'NH₃',
    category: 'inorganic',
    description: 'Trigonal pyramidal geometry with 107.8° bond angle caused by the repulsive lone pair on nitrogen.',
    molarMass: 17.031,
    dipoleMoment: '1.47 D (Polar)',
    geometry: 'Trigonal Pyramidal',
    hybridization: 'sp³ (with 1 lone pair)',
    atoms: [
      { id: 'N1', element: 'N', x: 0, y: 0, z: 0.12, color: '#3b82f6', radius: 0.42 },
      { id: 'H1', element: 'H', x: 0, y: 0.94, z: -0.28, color: '#f8fafc', radius: 0.28 },
      { id: 'H2', element: 'H', x: 0.81, y: -0.47, z: -0.28, color: '#f8fafc', radius: 0.28 },
      { id: 'H3', element: 'H', x: -0.81, y: -0.47, z: -0.28, color: '#f8fafc', radius: 0.28 }
    ],
    bonds: [
      { source: 0, target: 1, order: 1 },
      { source: 0, target: 2, order: 1 },
      { source: 0, target: 3, order: 1 }
    ]
  },
  {
    id: 'ch4',
    name: 'Methane',
    formula: 'CH₄',
    category: 'organic',
    description: 'The simplest hydrocarbon alkane. Perfect tetrahedral symmetry with 109.5° H-C-H bond angles.',
    molarMass: 16.04,
    dipoleMoment: '0.00 D (Non-polar)',
    geometry: 'Tetrahedral (109.5°)',
    hybridization: 'sp³',
    atoms: [
      { id: 'C1', element: 'C', x: 0, y: 0, z: 0, color: '#64748b', radius: 0.42 },
      { id: 'H1', element: 'H', x: 0.63, y: 0.63, z: 0.63, color: '#f8fafc', radius: 0.28 },
      { id: 'H2', element: 'H', x: -0.63, y: -0.63, z: 0.63, color: '#f8fafc', radius: 0.28 },
      { id: 'H3', element: 'H', x: -0.63, y: 0.63, z: -0.63, color: '#f8fafc', radius: 0.28 },
      { id: 'H4', element: 'H', x: 0.63, y: -0.63, z: -0.63, color: '#f8fafc', radius: 0.28 }
    ],
    bonds: [
      { source: 0, target: 1, order: 1 },
      { source: 0, target: 2, order: 1 },
      { source: 0, target: 3, order: 1 },
      { source: 0, target: 4, order: 1 }
    ]
  },
  {
    id: 'benzene',
    name: 'Benzene',
    formula: 'C₆H₆',
    category: 'organic',
    description: 'Prototypical aromatic hydrocarbon. Planar ring with delocalized pi-electron cloud obeying Hückel\'s 4n+2 rule (n=1).',
    molarMass: 78.11,
    dipoleMoment: '0.00 D (Non-polar)',
    geometry: 'Planar Hexagonal (120°)',
    hybridization: 'sp² (All Carbons)',
    atoms: [
      { id: 'C1', element: 'C', x: 1.21, y: 0.70, z: 0, color: '#64748b', radius: 0.42 },
      { id: 'C2', element: 'C', x: 0, y: 1.40, z: 0, color: '#64748b', radius: 0.42 },
      { id: 'C3', element: 'C', x: -1.21, y: 0.70, z: 0, color: '#64748b', radius: 0.42 },
      { id: 'C4', element: 'C', x: -1.21, y: -0.70, z: 0, color: '#64748b', radius: 0.42 },
      { id: 'C5', element: 'C', x: 0, y: -1.40, z: 0, color: '#64748b', radius: 0.42 },
      { id: 'C6', element: 'C', x: 1.21, y: -0.70, z: 0, color: '#64748b', radius: 0.42 },
      { id: 'H1', element: 'H', x: 2.15, y: 1.24, z: 0, color: '#f8fafc', radius: 0.28 },
      { id: 'H2', element: 'H', x: 0, y: 2.48, z: 0, color: '#f8fafc', radius: 0.28 },
      { id: 'H3', element: 'H', x: -2.15, y: 1.24, z: 0, color: '#f8fafc', radius: 0.28 },
      { id: 'H4', element: 'H', x: -2.15, y: -1.24, z: 0, color: '#f8fafc', radius: 0.28 },
      { id: 'H5', element: 'H', x: 0, y: -2.48, z: 0, color: '#f8fafc', radius: 0.28 },
      { id: 'H6', element: 'H', x: 2.15, y: -1.24, z: 0, color: '#f8fafc', radius: 0.28 }
    ],
    bonds: [
      { source: 0, target: 1, order: 2 },
      { source: 1, target: 2, order: 1 },
      { source: 2, target: 3, order: 2 },
      { source: 3, target: 4, order: 1 },
      { source: 4, target: 5, order: 2 },
      { source: 5, target: 0, order: 1 },
      { source: 0, target: 6, order: 1 },
      { source: 1, target: 7, order: 1 },
      { source: 2, target: 8, order: 1 },
      { source: 3, target: 9, order: 1 },
      { source: 4, target: 10, order: 1 },
      { source: 5, target: 11, order: 1 }
    ]
  },
  {
    id: 'ethanol',
    name: 'Ethanol',
    formula: 'C₂H₅OH',
    category: 'organic',
    description: 'Primary alcohol. Possesses a hydroxyl (-OH) group capable of forming intermolecular hydrogen bonds.',
    molarMass: 46.07,
    dipoleMoment: '1.69 D (Polar)',
    geometry: 'Tetrahedral / Bent (-OH)',
    hybridization: 'sp³',
    atoms: [
      { id: 'C1', element: 'C', x: -1.15, y: -0.28, z: 0, color: '#64748b', radius: 0.42 },
      { id: 'C2', element: 'C', x: 0.05, y: 0.58, z: 0, color: '#64748b', radius: 0.42 },
      { id: 'O1', element: 'O', x: 1.25, y: -0.20, z: 0, color: '#ef4444', radius: 0.45 },
      { id: 'H1', element: 'H', x: 1.15, y: -1.15, z: 0, color: '#f8fafc', radius: 0.28 },
      { id: 'H2', element: 'H', x: -1.15, y: -0.92, z: 0.88, color: '#f8fafc', radius: 0.28 },
      { id: 'H3', element: 'H', x: -1.15, y: -0.92, z: -0.88, color: '#f8fafc', radius: 0.28 },
      { id: 'H4', element: 'H', x: -2.06, y: 0.32, z: 0, color: '#f8fafc', radius: 0.28 },
      { id: 'H5', element: 'H', x: 0.05, y: 1.22, z: 0.88, color: '#f8fafc', radius: 0.28 },
      { id: 'H6', element: 'H', x: 0.05, y: 1.22, z: -0.88, color: '#f8fafc', radius: 0.28 }
    ],
    bonds: [
      { source: 0, target: 1, order: 1 },
      { source: 1, target: 2, order: 1 },
      { source: 2, target: 3, order: 1 },
      { source: 0, target: 4, order: 1 },
      { source: 0, target: 5, order: 1 },
      { source: 0, target: 6, order: 1 },
      { source: 1, target: 7, order: 1 },
      { source: 1, target: 8, order: 1 }
    ]
  },
  {
    id: 'caffeine',
    name: 'Caffeine',
    formula: 'C₈H₁₀N₄O₂',
    category: 'pharmaceutical',
    description: 'Purine alkaloid that functions as a central nervous system stimulant and adenosine receptor antagonist.',
    molarMass: 194.19,
    dipoleMoment: '3.64 D',
    geometry: 'Bicyclic fused ring (Purine derivative)',
    hybridization: 'sp² / sp³',
    atoms: [
      { id: 'N1', element: 'N', x: -1.35, y: 0.65, z: 0, color: '#3b82f6', radius: 0.42 },
      { id: 'C2', element: 'C', x: -0.82, y: 1.88, z: 0, color: '#64748b', radius: 0.42 },
      { id: 'O2', element: 'O', x: -1.48, y: 2.91, z: 0, color: '#ef4444', radius: 0.45 },
      { id: 'N3', element: 'N', x: 0.55, y: 1.88, z: 0, color: '#3b82f6', radius: 0.42 },
      { id: 'C4', element: 'C', x: 1.34, y: 0.74, z: 0, color: '#64748b', radius: 0.42 },
      { id: 'C5', element: 'C', x: 0.72, y: -0.52, z: 0, color: '#64748b', radius: 0.42 },
      { id: 'C6', element: 'C', x: -0.72, y: -0.52, z: 0, color: '#64748b', radius: 0.42 },
      { id: 'O6', element: 'O', x: -1.40, y: -1.55, z: 0, color: '#ef4444', radius: 0.45 },
      { id: 'N7', element: 'N', x: 1.62, y: -1.52, z: 0, color: '#3b82f6', radius: 0.42 },
      { id: 'C8', element: 'C', x: 2.76, y: -0.87, z: 0, color: '#64748b', radius: 0.42 },
      { id: 'N9', element: 'N', x: 2.64, y: 0.48, z: 0, color: '#3b82f6', radius: 0.42 },
      { id: 'C10', element: 'C', x: -2.81, y: 0.53, z: 0, color: '#64748b', radius: 0.42 },
      { id: 'C11', element: 'C', x: 1.15, y: 3.19, z: 0, color: '#64748b', radius: 0.42 },
      { id: 'C12', element: 'C', x: 1.45, y: -2.97, z: 0, color: '#64748b', radius: 0.42 }
    ],
    bonds: [
      { source: 0, target: 1, order: 1 },
      { source: 1, target: 2, order: 2 },
      { source: 1, target: 3, order: 1 },
      { source: 3, target: 4, order: 1 },
      { source: 4, target: 5, order: 2 },
      { source: 5, target: 6, order: 1 },
      { source: 6, target: 7, order: 2 },
      { source: 6, target: 0, order: 1 },
      { source: 5, target: 8, order: 1 },
      { source: 8, target: 9, order: 1 },
      { source: 9, target: 10, order: 2 },
      { source: 10, target: 4, order: 1 },
      { source: 0, target: 11, order: 1 },
      { source: 3, target: 12, order: 1 },
      { source: 8, target: 13, order: 1 }
    ]
  },
  {
    id: 'glucose',
    name: 'D-Glucose',
    formula: 'C₆H₁₂O₆',
    category: 'biomolecule',
    description: 'Fundamental monosaccharide carbohydrate. The primary fuel for cellular respiration and ATP synthesis.',
    molarMass: 180.16,
    dipoleMoment: '3.12 D',
    geometry: 'Pyranose Ring (Chair Conformation)',
    hybridization: 'sp³',
    atoms: [
      { id: 'C1', element: 'C', x: 1.18, y: 0.35, z: -0.15, color: '#64748b', radius: 0.42 },
      { id: 'C2', element: 'C', x: 0.72, y: -1.06, z: 0.22, color: '#64748b', radius: 0.42 },
      { id: 'C3', element: 'C', x: -0.76, y: -1.22, z: -0.14, color: '#64748b', radius: 0.42 },
      { id: 'C4', element: 'C', x: -1.54, y: -0.05, z: 0.46, color: '#64748b', radius: 0.42 },
      { id: 'C5', element: 'C', x: -0.98, y: 1.29, z: -0.02, color: '#64748b', radius: 0.42 },
      { id: 'O5', element: 'O', x: 0.40, y: 1.34, z: 0.35, color: '#ef4444', radius: 0.45 },
      { id: 'O1', element: 'O', x: 2.50, y: 0.54, z: 0.32, color: '#ef4444', radius: 0.45 },
      { id: 'O2', element: 'O', x: 1.48, y: -2.06, z: -0.42, color: '#ef4444', radius: 0.45 },
      { id: 'O3', element: 'O', x: -0.89, y: -1.33, z: -1.55, color: '#ef4444', radius: 0.45 },
      { id: 'O4', element: 'O', x: -2.89, y: -0.22, z: 0.05, color: '#ef4444', radius: 0.45 },
      { id: 'C6', element: 'C', x: -1.74, y: 2.50, z: 0.51, color: '#64748b', radius: 0.42 },
      { id: 'O6', element: 'O', x: -1.45, y: 3.67, z: -0.23, color: '#ef4444', radius: 0.45 }
    ],
    bonds: [
      { source: 0, target: 1, order: 1 },
      { source: 1, target: 2, order: 1 },
      { source: 2, target: 3, order: 1 },
      { source: 3, target: 4, order: 1 },
      { source: 4, target: 5, order: 1 },
      { source: 5, target: 0, order: 1 },
      { source: 0, target: 6, order: 1 },
      { source: 1, target: 7, order: 1 },
      { source: 2, target: 8, order: 1 },
      { source: 3, target: 9, order: 1 },
      { source: 4, target: 10, order: 1 },
      { source: 10, target: 11, order: 1 }
    ]
  },
  {
    id: 'atp',
    name: 'ATP Fragment',
    formula: 'C₁₀H₁₆N₅O₁₃P₃',
    category: 'biomolecule',
    description: 'Adenosine Triphosphate: the primary energy currency of biological cells. Stores energy in high-energy phosphoanhydride bonds (ΔG° = -30.5 kJ/mol).',
    molarMass: 507.18,
    dipoleMoment: 'High (Poly-anionic)',
    geometry: 'Adenosine + Triphosphate chain',
    hybridization: 'sp³ (Phosphates) / sp² (Adenine)',
    atoms: [
      { id: 'P1', element: 'P', x: -2.8, y: 0, z: 0, color: '#a855f7', radius: 0.46 },
      { id: 'O1', element: 'O', x: -2.8, y: 1.2, z: 0, color: '#ef4444', radius: 0.45 },
      { id: 'O2', element: 'O', x: -3.8, y: -0.6, z: 0, color: '#ef4444', radius: 0.45 },
      { id: 'P2', element: 'P', x: -1.2, y: -0.4, z: 0, color: '#a855f7', radius: 0.46 },
      { id: 'O3', element: 'O', x: -2.0, y: -0.2, z: 0, color: '#ef4444', radius: 0.45 },
      { id: 'O4', element: 'O', x: -1.2, y: 0.8, z: 0, color: '#ef4444', radius: 0.45 },
      { id: 'P3', element: 'P', x: 0.4, y: 0, z: 0, color: '#a855f7', radius: 0.46 },
      { id: 'O5', element: 'O', x: -0.4, y: -0.2, z: 0, color: '#ef4444', radius: 0.45 },
      { id: 'O6', element: 'O', x: 0.4, y: 1.2, z: 0, color: '#ef4444', radius: 0.45 },
      { id: 'O7', element: 'O', x: 1.2, y: -0.8, z: 0, color: '#ef4444', radius: 0.45 },
      { id: 'C1', element: 'C', x: 2.4, y: -0.2, z: 0, color: '#64748b', radius: 0.42 },
      { id: 'N1', element: 'N', x: 3.6, y: 0.4, z: 0, color: '#3b82f6', radius: 0.42 }
    ],
    bonds: [
      { source: 0, target: 1, order: 2 },
      { source: 0, target: 2, order: 1 },
      { source: 0, target: 4, order: 1 },
      { source: 3, target: 4, order: 1 },
      { source: 3, target: 5, order: 2 },
      { source: 3, target: 7, order: 1 },
      { source: 6, target: 7, order: 1 },
      { source: 6, target: 8, order: 2 },
      { source: 6, target: 9, order: 1 },
      { source: 9, target: 10, order: 1 },
      { source: 10, target: 11, order: 1 }
    ]
  }
];
