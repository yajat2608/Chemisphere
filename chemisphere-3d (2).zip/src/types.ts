export type NavigationTab =
  | 'home'
  | 'chemistry-map'
  | 'tools'
  | 'lab-directory'
  | 'questions-playground'
  | 'chemistry-lab'
  | 'archive'
  | 'profile'
  | 'beauty-of-chemistry'
  | 'periodic-table'
  | 'orbital-atlas'
  | 'molecules-3d'
  | 'vsepr-lab'
  | 'atomic-structure'
  | 'atomic-spectra'
  | 'waves-radiation'
  | 'quantum-lab'
  | 'spectroscopy-suite'
  | 'nuclear-lab'
  | 'nuclear-chemistry'
  | 'thermo-kinetics'
  | 'electro-solutions'
  | 'electrochemistry-lab'
  | 'organic-mechanisms'
  | 'advanced-organic'
  | 'analytical-materials'
  | 'analytical-lab'
  | 'universal-calc-graph'
  | 'stoichiometry'
  | 'physical-chem'
  | 'organic-chem'
  | 'formula-vault'
  | 'practice'
  | 'ai-tutor'
  | 'creator';

export type NavigationSection = NavigationTab;

export interface ChemicalElement {
  number: number;
  atomicNumber?: number;
  symbol: string;
  name: string;
  atomicMass: number;
  category: string;
  period: number;
  group: number;
  block: 's' | 'p' | 'd' | 'f';
  electronConfiguration: string;
  electronConfigurationShort?: string;
  shells?: number[];
  electronShells?: number[];
  valenceElectrons?: number;
  electronegativity?: number | null; // Pauling scale
  atomicRadius?: number | null; // pm
  covalentRadius?: number | null; // pm
  ionicRadius?: number | null; // pm
  ionizationEnergy?: number | null; // kJ/mol
  ionizationEnergies?: number[];
  electronAffinity?: number | null; // kJ/mol
  oxidationStates?: number[];
  meltingPoint?: number | null; // K
  boilingPoint?: number | null; // K
  density?: number | null; // g/cm³
  phase?: 'gas' | 'liquid' | 'solid';
  standardState?: string;
  quantumStateTerm?: string;
  crystalStructure?: string;
  casNumber?: string;
  discoveredBy?: string;
  yearDiscovered?: string | number;
  discoveryLocation?: string;
  historicalContext?: string;
  summary?: string;
  thermalConductivity?: number | null; // W/(m·K)
  electricalConductivity?: number | null; // MS/m
  specificHeat?: number | null; // J/(g·K)
  reactivity?: string;
  commonIons?: string[];
  commonCompounds?: string[];
  realWorldApplications?: string[];
  colorHex?: string;
  isotopes?: { massNumber: number; abundance: string; spin?: string; halfLife?: string; decayMode?: string; isStable: boolean }[];
}

export interface AtomCoordinate {
  id: string;
  element: string;
  x: number;
  y: number;
  z: number;
  color: string;
  radius: number;
  formalCharge?: number;
}

export interface BondCoordinate {
  source: number; // index in atoms
  target: number;
  order: 1 | 2 | 3; // single, double, triple
}

export interface Molecule3DData {
  id: string;
  name: string;
  formula: string;
  category: 'inorganic' | 'organic' | 'biomolecule' | 'pharmaceutical' | 'gas';
  description: string;
  molarMass: number;
  dipoleMoment: string;
  geometry: string;
  hybridization: string;
  atoms: AtomCoordinate[];
  bonds: BondCoordinate[];
}

export interface OrbitalData {
  id: string;
  type: 's' | 'p' | 'd' | 'f';
  name: string;
  n: number;
  l: number;
  ml: number;
  radialNodes: number;
  angularNodes: number;
  totalNodes: number;
  formulaLatex: string;
  description: string;
  orientation: string;
}

export interface ChemicalReaction {
  id: string;
  name: string;
  category: 'Acid-Base' | 'Redox' | 'Precipitation' | 'Organic' | 'Combustion' | 'Synthesis' | 'Decomposition';
  reactants: string[];
  products: string[];
  balancedEquation: string;
  ionicEquation?: string;
  netIonicEquation?: string;
  deltaH?: string;
  typeDescription: string;
  conditions: string;
  applications: string;
}

export interface FormulaItem {
  id: string;
  name: string;
  category: string;
  equationLatex?: string;
  latex?: string;
  variables: any[];
  meaning?: string;
  whenToUse?: string;
  example?: string;
  description?: string;
  calculate?: (inputs: Record<string, number>) => { result: number; unit: string; steps: string };
  defaultInputs?: { id: string; label: string; unit: string; defaultValue: number }[];
}

export interface ChemicalConstant {
  symbol: string;
  name: string;
  value: string;
  unit: string;
  description: string;
  category: 'fundamental' | 'thermodynamics' | 'atomic' | 'solution';
}

export interface QuizQuestion {
  id: string;
  title?: string;
  category: string;
  difficulty?: 'Easy' | 'Medium' | 'Hard' | 'Olympiad' | string;
  type?: 'mcq' | 'assertion-reason' | 'numerical' | 'reaction' | string;
  question: string;
  options: string[];
  correctAnswer: any;
  assertion?: string;
  reason?: string;
  explanation: string;
  conceptLink?: string;
}

export interface AiTutorResponse {
  concept: string;
  reasoning: string;
  formula?: string;
  calculation?: string;
  result: string;
  visualTarget?: NavigationTab;
  visualExplanation?: string;
}
