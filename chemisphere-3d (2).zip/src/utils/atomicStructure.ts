import { ChemicalElement } from '../types';

export interface ElectronInfo {
  index: number;
  shellIndex: number; // 0 for K, 1 for L, etc.
  shellLetter: string; // 'K', 'L', 'M', 'N', 'O', 'P', 'Q'
  n: number;
  subshellName: string; // '1s', '2s', '2p', etc.
  l: number; // 0=s, 1=p, 2=d, 3=f
  orbitalName: string; // '1s', '2px', '2py', '2pz', etc.
  ml: number;
  ms: '+1/2' | '-1/2';
  ringAngle: number; // in radians
  shellRadius: number; // visual radius
}

export interface IsotopeInfo {
  massNumber: number;
  neutrons: number;
  abundance: string;
  isStable: boolean;
  halfLife?: string;
  decayMode?: string;
}

export const SHELL_INFO = [
  { n: 1, letter: 'K', maxCapacity: 2, subshells: ['1s'], color: '#38bdf8' },
  { n: 2, letter: 'L', maxCapacity: 8, subshells: ['2s', '2p'], color: '#818cf8' },
  { n: 3, letter: 'M', maxCapacity: 18, subshells: ['3s', '3p', '3d'], color: '#c084fc' },
  { n: 4, letter: 'N', maxCapacity: 32, subshells: ['4s', '4p', '4d', '4f'], color: '#f472b6' },
  { n: 5, letter: 'O', maxCapacity: 50, subshells: ['5s', '5p', '5d', '5f'], color: '#fb923c' },
  { n: 6, letter: 'P', maxCapacity: 72, subshells: ['6s', '6p', '6d'], color: '#facc15' },
  { n: 7, letter: 'Q', maxCapacity: 98, subshells: ['7s', '7p'], color: '#4ade80' }
];

// Standard neutral Bohr shell populations for elements 1 to 118
// (Derived from empirical electron configurations)
export const ELEMENT_BOHR_SHELLS: Record<number, number[]> = {
  1: [1],
  2: [2],
  3: [2, 1],
  4: [2, 2],
  5: [2, 3],
  6: [2, 4],
  7: [2, 5],
  8: [2, 6],
  9: [2, 7],
  10: [2, 8],
  11: [2, 8, 1],
  12: [2, 8, 2],
  13: [2, 8, 3],
  14: [2, 8, 4],
  15: [2, 8, 5],
  16: [2, 8, 6],
  17: [2, 8, 7],
  18: [2, 8, 8],
  19: [2, 8, 8, 1],
  20: [2, 8, 8, 2],
  21: [2, 8, 9, 2],
  22: [2, 8, 10, 2],
  23: [2, 8, 11, 2],
  24: [2, 8, 13, 1], // Cr exception
  25: [2, 8, 13, 2],
  26: [2, 8, 14, 2],
  27: [2, 8, 15, 2],
  28: [2, 8, 16, 2],
  29: [2, 8, 18, 1], // Cu exception
  30: [2, 8, 18, 2],
  31: [2, 8, 18, 3],
  32: [2, 8, 18, 4],
  33: [2, 8, 18, 5],
  34: [2, 8, 18, 6],
  35: [2, 8, 18, 7],
  36: [2, 8, 18, 8],
  37: [2, 8, 18, 8, 1],
  38: [2, 8, 18, 8, 2],
  39: [2, 8, 18, 9, 2],
  40: [2, 8, 18, 10, 2],
  41: [2, 8, 18, 12, 1], // Nb
  42: [2, 8, 18, 13, 1], // Mo
  43: [2, 8, 18, 13, 2], // Tc
  44: [2, 8, 18, 15, 1], // Ru
  45: [2, 8, 18, 16, 1], // Rh
  46: [2, 8, 18, 18],    // Pd
  47: [2, 8, 18, 18, 1], // Ag
  48: [2, 8, 18, 18, 2], // Cd
  49: [2, 8, 18, 18, 3], // In
  50: [2, 8, 18, 18, 4], // Sn
  51: [2, 8, 18, 18, 5], // Sb
  52: [2, 8, 18, 18, 6], // Te
  53: [2, 8, 18, 18, 7], // I
  54: [2, 8, 18, 18, 8], // Xe
  55: [2, 8, 18, 18, 8, 1],
  56: [2, 8, 18, 18, 8, 2],
  57: [2, 8, 18, 18, 9, 2], // La
  58: [2, 8, 18, 19, 9, 2], // Ce
  59: [2, 8, 18, 21, 8, 2], // Pr
  60: [2, 8, 18, 22, 8, 2], // Nd
  61: [2, 8, 18, 23, 8, 2], // Pm
  62: [2, 8, 18, 24, 8, 2], // Sm
  63: [2, 8, 18, 25, 8, 2], // Eu
  64: [2, 8, 18, 25, 9, 2], // Gd
  65: [2, 8, 18, 27, 8, 2], // Tb
  66: [2, 8, 18, 28, 8, 2], // Dy
  67: [2, 8, 18, 29, 8, 2], // Ho
  68: [2, 8, 18, 30, 8, 2], // Er
  69: [2, 8, 18, 31, 8, 2], // Tm
  70: [2, 8, 18, 32, 8, 2], // Yb
  71: [2, 8, 18, 32, 9, 2], // Lu
  72: [2, 8, 18, 32, 10, 2], // Hf
  73: [2, 8, 18, 32, 11, 2], // Ta
  74: [2, 8, 18, 32, 12, 2], // W
  75: [2, 8, 18, 32, 13, 2], // Re
  76: [2, 8, 18, 32, 14, 2], // Os
  77: [2, 8, 18, 32, 15, 2], // Ir
  78: [2, 8, 18, 32, 17, 1], // Pt
  79: [2, 8, 18, 32, 18, 1], // Au
  80: [2, 8, 18, 32, 18, 2], // Hg
  81: [2, 8, 18, 32, 18, 3], // Tl
  82: [2, 8, 18, 32, 18, 4], // Pb
  83: [2, 8, 18, 32, 18, 5], // Bi
  84: [2, 8, 18, 32, 18, 6], // Po
  85: [2, 8, 18, 32, 18, 7], // At
  86: [2, 8, 18, 32, 18, 8], // Rn
  87: [2, 8, 18, 32, 18, 8, 1], // Fr
  88: [2, 8, 18, 32, 18, 8, 2], // Ra
  89: [2, 8, 18, 32, 18, 9, 2], // Ac
  90: [2, 8, 18, 32, 18, 10, 2], // Th
  91: [2, 8, 18, 32, 20, 9, 2], // Pa
  92: [2, 8, 18, 32, 21, 9, 2], // U
  93: [2, 8, 18, 32, 22, 9, 2], // Np
  94: [2, 8, 18, 32, 24, 8, 2], // Pu
  95: [2, 8, 18, 32, 25, 8, 2], // Am
  96: [2, 8, 18, 32, 25, 9, 2], // Cm
  97: [2, 8, 18, 32, 27, 8, 2], // Bk
  98: [2, 8, 18, 32, 28, 8, 2], // Cf
  99: [2, 8, 18, 32, 29, 8, 2], // Es
  100: [2, 8, 18, 32, 30, 8, 2], // Fm
  101: [2, 8, 18, 32, 31, 8, 2], // Md
  102: [2, 8, 18, 32, 32, 8, 2], // No
  103: [2, 8, 18, 32, 32, 8, 3], // Lr
  104: [2, 8, 18, 32, 32, 10, 2], // Rf
  105: [2, 8, 18, 32, 32, 11, 2], // Db
  106: [2, 8, 18, 32, 32, 12, 2], // Sg
  107: [2, 8, 18, 32, 32, 13, 2], // Bh
  108: [2, 8, 18, 32, 32, 14, 2], // Hs
  109: [2, 8, 18, 32, 32, 15, 2], // Mt
  110: [2, 8, 18, 32, 32, 16, 2], // Ds
  111: [2, 8, 18, 32, 32, 17, 2], // Rg
  112: [2, 8, 18, 32, 32, 18, 2], // Cn
  113: [2, 8, 18, 32, 32, 18, 3], // Nh
  114: [2, 8, 18, 32, 32, 18, 4], // Fl
  115: [2, 8, 18, 32, 32, 18, 5], // Mc
  116: [2, 8, 18, 32, 32, 18, 6], // Lv
  117: [2, 8, 18, 32, 32, 18, 7], // Ts
  118: [2, 8, 18, 32, 32, 18, 8]  // Og
};

// Aufbau order with subshell capacities and quantum numbers
export const AUFBAU_SUBSHELLS = [
  { name: '1s', n: 1, l: 0, capacity: 2, orbitals: ['1s'] },
  { name: '2s', n: 2, l: 0, capacity: 2, orbitals: ['2s'] },
  { name: '2p', n: 2, l: 1, capacity: 6, orbitals: ['2px', '2py', '2pz'] },
  { name: '3s', n: 3, l: 0, capacity: 2, orbitals: ['3s'] },
  { name: '3p', n: 3, l: 1, capacity: 6, orbitals: ['3px', '3py', '3pz'] },
  { name: '4s', n: 4, l: 0, capacity: 2, orbitals: ['4s'] },
  { name: '3d', n: 3, l: 2, capacity: 10, orbitals: ['3dxy', '3dyz', '3dxz', '3dx2y2', '3dz2'] },
  { name: '4p', n: 4, l: 1, capacity: 6, orbitals: ['4px', '4py', '4pz'] },
  { name: '5s', n: 5, l: 0, capacity: 2, orbitals: ['5s'] },
  { name: '4d', n: 4, l: 2, capacity: 10, orbitals: ['4dxy', '4dyz', '4dxz', '4dx2y2', '4dz2'] },
  { name: '5p', n: 5, l: 1, capacity: 6, orbitals: ['5px', '5py', '5pz'] },
  { name: '6s', n: 6, l: 0, capacity: 2, orbitals: ['6s'] },
  { name: '4f', n: 4, l: 3, capacity: 14, orbitals: ['4fz3', '4fxz2', '4fyz2', '4fxyz', '4fz(x2-y2)', '4fx(x2-3y2)', '4fy(3x2-y2)'] },
  { name: '5d', n: 5, l: 2, capacity: 10, orbitals: ['5dxy', '5dyz', '5dxz', '5dx2y2', '5dz2'] },
  { name: '6p', n: 6, l: 1, capacity: 6, orbitals: ['6px', '6py', '6pz'] },
  { name: '7s', n: 7, l: 0, capacity: 2, orbitals: ['7s'] },
  { name: '5f', n: 5, l: 3, capacity: 14, orbitals: ['5fz3', '5fxz2', '5fyz2', '5fxyz', '5fz(x2-y2)', '5fx(x2-3y2)', '5fy(3x2-y2)'] },
  { name: '6d', n: 6, l: 2, capacity: 10, orbitals: ['6dxy', '6dyz', '6dxz', '6dx2y2', '6dz2'] },
  { name: '7p', n: 7, l: 1, capacity: 6, orbitals: ['7px', '7py', '7pz'] }
];

// Common isotopes for representative elements
export const ELEMENT_ISOTOPES: Record<number, IsotopeInfo[]> = {
  1: [
    { massNumber: 1, neutrons: 0, abundance: '99.988%', isStable: true },
    { massNumber: 2, neutrons: 1, abundance: '0.0115% (Deuterium)', isStable: true },
    { massNumber: 3, neutrons: 2, abundance: 'Trace (Tritium)', isStable: false, halfLife: '12.32 years', decayMode: 'β⁻' }
  ],
  2: [
    { massNumber: 3, neutrons: 1, abundance: '0.000134%', isStable: true },
    { massNumber: 4, neutrons: 2, abundance: '99.99986%', isStable: true }
  ],
  6: [
    { massNumber: 12, neutrons: 6, abundance: '98.93%', isStable: true },
    { massNumber: 13, neutrons: 7, abundance: '1.07%', isStable: true },
    { massNumber: 14, neutrons: 8, abundance: 'Trace (Radiocarbon)', isStable: false, halfLife: '5,730 years', decayMode: 'β⁻' }
  ],
  7: [
    { massNumber: 14, neutrons: 7, abundance: '99.63%', isStable: true },
    { massNumber: 15, neutrons: 8, abundance: '0.37%', isStable: true }
  ],
  8: [
    { massNumber: 16, neutrons: 8, abundance: '99.76%', isStable: true },
    { massNumber: 17, neutrons: 9, abundance: '0.04%', isStable: true },
    { massNumber: 18, neutrons: 10, abundance: '0.20%', isStable: true }
  ],
  11: [
    { massNumber: 23, neutrons: 12, abundance: '100%', isStable: true },
    { massNumber: 22, neutrons: 11, abundance: 'Synthetic', isStable: false, halfLife: '2.6 years', decayMode: 'β⁺' }
  ],
  17: [
    { massNumber: 35, neutrons: 18, abundance: '75.76%', isStable: true },
    { massNumber: 37, neutrons: 20, abundance: '24.24%', isStable: true }
  ],
  26: [
    { massNumber: 54, neutrons: 28, abundance: '5.85%', isStable: true },
    { massNumber: 56, neutrons: 30, abundance: '91.75%', isStable: true },
    { massNumber: 57, neutrons: 31, abundance: '2.12%', isStable: true },
    { massNumber: 58, neutrons: 32, abundance: '0.28%', isStable: true }
  ],
  79: [
    { massNumber: 197, neutrons: 118, abundance: '100%', isStable: true }
  ],
  92: [
    { massNumber: 235, neutrons: 143, abundance: '0.72%', isStable: false, halfLife: '704M years', decayMode: 'α (Fissile)' },
    { massNumber: 238, neutrons: 146, abundance: '99.27%', isStable: false, halfLife: '4.468B years', decayMode: 'α' }
  ]
};

/**
 * Returns the Bohr shells for an element, adjusting for ion charge
 */
export function getElementBohrShells(atomicNumber: number, ionCharge: number = 0): number[] {
  const baseShells = [...(ELEMENT_BOHR_SHELLS[atomicNumber] || [Math.min(atomicNumber, 2)])];
  if (ionCharge === 0) return baseShells;

  let remainingDelta = -ionCharge; // e.g. +1 removes 1 electron, -1 adds 1 electron
  const adjusted = [...baseShells];

  if (remainingDelta < 0) {
    // Remove electrons from outermost shells first
    let toRemove = -remainingDelta;
    for (let i = adjusted.length - 1; i >= 0 && toRemove > 0; i--) {
      const take = Math.min(adjusted[i], toRemove);
      adjusted[i] -= take;
      toRemove -= take;
    }
    // Filter trailing 0s (except if all empty, keep [0])
    while (adjusted.length > 1 && adjusted[adjusted.length - 1] === 0) {
      adjusted.pop();
    }
  } else if (remainingDelta > 0) {
    // Add electrons to valence shell up to capacity
    let toAdd = remainingDelta;
    for (let i = 0; i < adjusted.length && toAdd > 0; i++) {
      const maxCap = SHELL_INFO[i]?.maxCapacity || 8;
      const space = maxCap - adjusted[i];
      if (space > 0) {
        const put = Math.min(space, toAdd);
        adjusted[i] += put;
        toAdd -= put;
      }
    }
    if (toAdd > 0) {
      adjusted.push(toAdd);
    }
  }

  return adjusted;
}

/**
 * Generates an array of individual electron metadata with angles and quantum numbers
 */
export function getIndividualElectrons(
  atomicNumber: number,
  ionCharge: number = 0,
  shellRadii: number[] = [1.2, 1.8, 2.4, 3.0, 3.6, 4.2, 4.8]
): ElectronInfo[] {
  const shells = getElementBohrShells(atomicNumber, ionCharge);
  const electrons: ElectronInfo[] = [];
  let globalIndex = 1;

  shells.forEach((electronCount, shellIdx) => {
    const shellMeta = SHELL_INFO[shellIdx] || { n: shellIdx + 1, letter: `S${shellIdx + 1}`, maxCapacity: 8 };
    const r = shellRadii[shellIdx] || (1.2 + shellIdx * 0.6);

    for (let i = 0; i < electronCount; i++) {
      const ringAngle = (i / electronCount) * Math.PI * 2;
      
      // Determine probable subshell assignment based on position in shell
      let subshellName = `${shellMeta.n}s`;
      let l = 0;
      let orbitalName = `${shellMeta.n}s`;
      let ml = 0;
      const ms: '+1/2' | '-1/2' = i % 2 === 0 ? '+1/2' : '-1/2';

      if (shellMeta.n === 1) {
        subshellName = '1s';
        l = 0;
        orbitalName = '1s';
      } else if (shellMeta.n === 2) {
        if (i < 2) {
          subshellName = '2s';
          l = 0;
          orbitalName = '2s';
        } else {
          subshellName = '2p';
          l = 1;
          const pOrbs = ['2px', '2py', '2pz'];
          orbitalName = pOrbs[(i - 2) % 3];
          ml = ((i - 2) % 3) - 1;
        }
      } else if (shellMeta.n === 3) {
        if (i < 2) {
          subshellName = '3s';
          l = 0;
          orbitalName = '3s';
        } else if (i < 8) {
          subshellName = '3p';
          l = 1;
          const pOrbs = ['3px', '3py', '3pz'];
          orbitalName = pOrbs[(i - 2) % 3];
          ml = ((i - 2) % 3) - 1;
        } else {
          subshellName = '3d';
          l = 2;
          const dOrbs = ['3dxy', '3dyz', '3dxz', '3dx2-y2', '3dz2'];
          orbitalName = dOrbs[(i - 8) % 5];
          ml = ((i - 8) % 5) - 2;
        }
      } else {
        if (i < 2) {
          subshellName = `${shellMeta.n}s`;
          l = 0;
          orbitalName = `${shellMeta.n}s`;
        } else if (i < 8) {
          subshellName = `${shellMeta.n}p`;
          l = 1;
          orbitalName = `${shellMeta.n}p_${(i - 2) % 3}`;
          ml = ((i - 2) % 3) - 1;
        } else if (i < 18) {
          subshellName = `${shellMeta.n}d`;
          l = 2;
          orbitalName = `${shellMeta.n}d_${(i - 8) % 5}`;
          ml = ((i - 8) % 5) - 2;
        } else {
          subshellName = `${shellMeta.n}f`;
          l = 3;
          orbitalName = `${shellMeta.n}f_${(i - 18) % 7}`;
          ml = ((i - 18) % 7) - 3;
        }
      }

      electrons.push({
        index: globalIndex++,
        shellIndex: shellIdx,
        shellLetter: shellMeta.letter,
        n: shellMeta.n,
        subshellName,
        l,
        orbitalName,
        ml,
        ms,
        ringAngle,
        shellRadius: r
      });
    }
  });

  return electrons;
}

/**
 * Returns isotope list for an element
 */
export function getElementIsotopes(element: ChemicalElement): IsotopeInfo[] {
  if (ELEMENT_ISOTOPES[element.number]) {
    return ELEMENT_ISOTOPES[element.number];
  }
  const protons = element.number;
  const standardA = Math.round(typeof element.atomicMass === 'number' ? element.atomicMass : parseFloat(element.atomicMass as string) || protons * 2);
  const neutrons = standardA - protons;

  return [
    { massNumber: standardA, neutrons, abundance: 'Most Abundant / Standard', isStable: protons <= 82 }
  ];
}
